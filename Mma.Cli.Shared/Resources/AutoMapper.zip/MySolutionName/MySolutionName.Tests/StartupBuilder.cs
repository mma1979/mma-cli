using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

using MySolutionName.AppApi.Controllers.v1.Account;
using MySolutionName.Common.Models;
using MySolutionName.Core.Database.Identity;
using MySolutionName.EntityFramework;
using MySolutionName.Services;
using MySolutionName.Services.Account;
using System;
using System.Net;
using System.Net.Mail;

namespace MySolutionName.Tests
{
    public class StartupBuilder
    {

        public ServiceProvider ServiceProvider { get; set; }
        public StartupBuilder Init()
        {
            var services = new ServiceCollection();

            var env = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT") ?? "Production";
            var builder = new ConfigurationBuilder()
                .AddJsonFile("appsettings.json", optional: true, reloadOnChange: true)
                   .AddJsonFile($"appsettings.{env}.json", optional: true, reloadOnChange: true);

            var Configuration = builder.Build();

            services.AddOptions();

            services.Configure<AppSettings>(Configuration.GetSection("AppSettings"));

            services.AddSingleton<IConfiguration>(Configuration);
            services.AddLogging(config =>
            {
                config.AddDebug();
                config.AddConsole();
            });
            services.AddDbContext<AuthenticationDbContext>();
            services.AddIdentity<AppUser, AppRole>()
               .AddEntityFrameworkStores<AuthenticationDbContext>()
               .AddDefaultTokenProviders();

            // Service DI
            services.AddTransient<AccountService>();
            services.AddTransient<EmailService>();

            services
                  .AddFluentEmail(Configuration.GetValue<string>("SMTP:Email"))
                  .AddRazorRenderer()
                  .AddSmtpSender(new SmtpClient() { 
                  Host = Configuration.GetValue<string>("SMTP:SmtpServer"),
                  Port = Configuration.GetValue<int>("SMTP:Port"),
                      Credentials = new NetworkCredential(Configuration.GetValue<string>("SMTP:Email"), Configuration.GetValue<string>("SMTP:Password")),
                      EnableSsl= Configuration.GetValue<bool>("SMTP:EnableSsl")
                  });

            // Controllers DI
            services.AddTransient<AccountController>();



            ServiceProvider = services.BuildServiceProvider();

            return this;
        }

        public T GetInstance<T>()
        {
            var res = ServiceProvider.GetService<T>();
            return res;
        }
    }
}
