using Microsoft.AspNetCore.Identity;

using MySolutionName.Core.Database.Notifications;

using System;
using System.Collections.Generic;

namespace MySolutionName.Core.Database.Identity
{
    public class Role : IdentityRole<long>
    {
        public long? CreatedBy { get; set; }
        public DateTime? CreatedDate { get; set; }
        public long? ModifiedBy { get; set; }
        public DateTime? ModifiedDate { get; set; }
        public bool? IsDeleted { get; set; }
        public long? DeletedBy { get; set; }
        public DateTime? DeletedDate { get; set; }
        public virtual ICollection<UserRole> UserRoles { get; set; }
        public int Hash
        {
            get
            {
                return GetHashCode();
            }
        }

        private Role()
        {
            UserRoles = new HashSet<UserRole>();
        }
        public Role(RoleDto dto)
        {

            Name = dto.Name;
            CreatedDate = DateTime.UtcNow;

        }

        public Role Update(RoleDto dto)
        {
            Name = dto.Name;
            ModifiedDate = DateTime.UtcNow;
            return this;
        }

        public Role Delete()
        {
            IsDeleted = true;
            DeletedDate = DateTime.UtcNow;
            return this;
        }

        public Role(string rolename)
        {
            Name = rolename;
        }

        public override int GetHashCode()
        {
            return HashCode.Combine(Name);
        }

        public override bool Equals(object obj)
        {
            return obj is Role other &&
                Name == other.Name;
        }
    }
}
