using Microsoft.AspNetCore.Identity;

using MySolutionName.Core.Models.Identity;

using System;

namespace MySolutionName.Core.Database.Identity;

public class AppUserToken : IdentityUserToken<Guid>
{
    public string Token { get; private set; }
    public virtual AppUser AppUser { get; private set; }
    public Guid? CreatedBy { get; private set; }
    public DateTime? CreatedDate { get; private set; }
    public Guid? ModifiedBy { get; private set; }
    public DateTime? ModifiedDate { get; private set; }
    public bool? IsDeleted { get; private set; }
    public Guid? DeletedBy { get; private set; }
    public DateTime? DeletedDate { get; private set; }

    public AppUserToken()
    {

    }

    public AppUserToken(AppUserTokenModifyModel model)
    {
        Name = model.Name;
        LoginProvider = model.LoginProvider;
        Value = model.Value;
        Token = model.Token;
        UserId = model.UserId;
    }

}
