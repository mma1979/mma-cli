using Microsoft.AspNetCore.Identity;

using MySolutionName.Core.Database.Notifications;

using System;

namespace MySolutionName.Core.Database.Identity
{
    public class UserRole : IdentityUserRole<long>
    {
        public AppUser AppUser { get; set; }
        public Role Role { get; set; }
        public int Hash
        {
            get
            {
                return GetHashCode();
            }
        }
        public long? CreatedBy { get; set; }
        public DateTime? CreatedDate { get; set; }
        public long? ModifiedBy { get; set; }
        public DateTime? ModifiedDate { get; set; }
        public bool? IsDeleted { get; set; }
        public long? DeletedBy { get; set; }
        public DateTime? DeletedDate { get; set; }

        public override int GetHashCode()
        {
            return HashCode.Combine(UserId,RoleId);
        }

        public override bool Equals(object obj)
        {
            return obj is UserRole other &&
                UserId == other.UserId &&
                RoleId == other.RoleId;
        }
    }
}
