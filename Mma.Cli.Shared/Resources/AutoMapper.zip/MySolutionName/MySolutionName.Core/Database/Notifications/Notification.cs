﻿using FluentValidation.Results;

using MySolutionName.Common;
using MySolutionName.Core.Database.Identity;
using MySolutionName.Core.Database.Tables;
using MySolutionName.Core.Enums;
using MySolutionName.Core.Validations;

using Newtonsoft.Json;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MySolutionName.Core.Database.Notifications
{
    public class Notification : BaseEntity<Guid>
    {
        NotificationValidator _Validator;
        private NotificationValidator Validator
        {
            get
            {
                _Validator ??= new NotificationValidator();
                return _Validator;
            }
        }

        protected Notification() { }

        public long UserId { get; protected set; }
        public string Message { get; protected set; }
        public virtual AppUser User { get; protected set; }

        public NotificationStatuses NotificationStatus { get; protected set; }
        public NotificationTypes NotificationType { get; protected set; }
        public bool? IsRead { get; set; }
        public NotificationPeriorities Periority { get; set; }
        public DateTime? ExpireTime { get; set; }


        public Notification(NotificationDto dto)
        {
            ValidationResult result = Validator.Validate(dto);
            if (!result.IsValid)
            {
                var messages = result.Errors.Select(e => e.ErrorMessage);
                throw new HttpException(LoggingEvents.Constractor_ERROR, JsonConvert.SerializeObject(messages));
            }

            UserId = dto.UserId;
            Message = dto.Message;  
            NotificationStatus = dto.NotificationStatus;
            NotificationType = dto.NotificationType;
            IsRead = dto.IsRead;
            Periority = dto.Periority;
            ExpireTime = dto.ExpireTime;

            CreatedDate = DateTime.UtcNow;

        }

        public Notification Update(NotificationDto dto)
        {
            ValidationResult result = Validator.Validate(dto);
            if (!result.IsValid)
            {
                var messages = result.Errors.Select(e => e.ErrorMessage);
                throw new HttpException(LoggingEvents.Constractor_ERROR, JsonConvert.SerializeObject(messages));
            }


            UserId = dto.UserId;
            Message = dto.Message;
            NotificationStatus = dto.NotificationStatus;
            NotificationType = dto.NotificationType;
            IsRead = dto.IsRead;
            Periority = dto.Periority;
            ExpireTime = dto.ExpireTime;

            ModifiedDate = DateTime.UtcNow;
            return this;
        }

        public Notification Delete()
        {
            IsDeleted = true;
            DeletedDate = DateTime.UtcNow;
            return this;
        }

        public override int GetHashCode()
        {
            return HashCode.Combine(UserId, Message, NotificationType, NotificationStatus, CreatedDate);
        }

        public override bool Equals(object obj)
        {
            return obj is Notification other &&
                other.UserId == UserId &&
                other.Message == Message &&
                other.NotificationType == NotificationType &&
                other.NotificationStatus == NotificationStatus &&
                other.NotificationType == NotificationType &&
                other.CreatedDate == CreatedDate;
        }


    }

    public class EmailNotification : Notification
    {

    }

    public class SmsNotification : Notification
    {

    }

    public class PushNotification : Notification
    {

    }


}
