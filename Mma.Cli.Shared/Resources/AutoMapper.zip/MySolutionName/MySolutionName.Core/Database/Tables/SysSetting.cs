using MySolutionName.Core.Enums;

namespace MySolutionName.Core.Database.Tables
{
    public class SysSetting : BaseEntity<int>
    {
        public string SysKey { get; private set; }
        public string SysValue { get; private set; }
        public SettingsTypeEnum Enviroment { get; private set; }
    }
}
