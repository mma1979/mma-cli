using MySolutionName.Common.Extensions;

using System;

namespace MySolutionName.Core.Models
{
    public class QueryViewModel
    {
        public string Language { get; set; } = "ar";
        public Guid? UserId { get; set; }
        public string Order { get; set; }
        public string Filter { get; set; }
        public int PageNumber { get; set; }
        public int PageSize { get; set; }
        public long Timestamp { get; set; } = DateTime.UtcNow.ToLinuxTime();

        public override int GetHashCode()
        {
            return HashCode.Combine(UserId, Order, Filter, PageNumber, PageSize, Language);
        }

        public override bool Equals(object obj)
        {
            return obj is QueryViewModel other &&
                other.UserId == UserId &&
                other.Order == Order &&
                  other.Filter == Filter &&
                  other.PageNumber == PageNumber &&
                  other.PageSize == PageSize &&
                  other.Language == Language;
        }
    }
}
