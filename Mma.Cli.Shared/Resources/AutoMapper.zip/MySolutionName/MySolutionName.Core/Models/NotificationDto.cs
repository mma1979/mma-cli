using System;
using MySolutionName.Core.Database.Identity;
using MySolutionName.Core.Enums;

namespace MySolutionName.Core.Database.Tables
{
    public partial class NotificationDto
    {
        public Guid Id { get;  set; }
        public long? CreatedBy { get;  set; }
        public DateTime? CreatedDate { get;  set; }
        public long? ModifiedBy { get;  set; }
        public DateTime? ModifiedDate { get;  set; }
        public bool? IsDeleted { get;  set; }
        public long? DeletedBy { get;  set; }
        public DateTime? DeletedDate { get;  set; }


        public long UserId { get;  set; }
        public string Message { get;  set; }
        public virtual AppUserDto User { get;  set; }
        public NotificationStatuses NotificationStatus { get;  set; }
        public NotificationTypes NotificationType { get;  set; }
        public bool? IsRead { get; set; }
        public NotificationPeriorities Periority { get; set; }
        public DateTime? ExpireTime { get; set; }
    }
}