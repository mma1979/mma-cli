﻿namespace MySolutionName.Core.Models.Stripe
{
    public class CustomerModel
    {
        public string Description { get; set; }
        public string Email { get; set; }
        public string SourceId { get; set; }
    }
}
