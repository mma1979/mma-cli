using System;

namespace MySolutionName.Core.Models
{
    public class UserInfo
    {
        public string Token { get; set; }
        public DateTime Expiration { get; set; }
    }
}
