namespace MySolutionName.Core.Models.Localization
{
    public partial class LanguageReadModel
    {
        public int Id { get; set; }
        public string LanguageCode { get; set; }
        public string LanguageName { get; set; }
    }
}