namespace MySolutionName.Core.Models.Localization
{
    public partial class ResourceModifyModel
    {
        public long Id { get; set; }
        public int LanguageId { get; set; }
        public string Key { get; set; }
        public string Value { get; set; }
        public LanguageModifyModel Language { get; set; }
    }
}