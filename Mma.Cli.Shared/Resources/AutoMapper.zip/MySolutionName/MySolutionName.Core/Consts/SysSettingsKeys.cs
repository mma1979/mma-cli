namespace MySolutionName.Core.Consts
{
    public class SysSettingsKeys
    {
        public const string APIEndPoint = "APIEndPoint";
        public const string Attachments_Path = "Attachments_Path";
        public const string Default_Img_Name = "Default_Img_Name";


        public const string BasicUserName = "fPs29E9nQtv2$jIpMT@1cxFoSyIth8#0heq";
        public const string BasicPassword = "0vNAXZMnJVD@7z3ApsL1tz1GoqM*JMjf039tC@2^G77vXLhS6KOr5@W$UNggCemw56xItc382%iM7H8uxJ#cuvpFZw0@am83X@d";

    }
}
