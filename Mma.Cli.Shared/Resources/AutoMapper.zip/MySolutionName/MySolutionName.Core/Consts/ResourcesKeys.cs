namespace MySolutionName.Core.Consts
{
    public static class ResourcesKeys
    {
        public const string RequiredField = "RequiredField";
    }
}
