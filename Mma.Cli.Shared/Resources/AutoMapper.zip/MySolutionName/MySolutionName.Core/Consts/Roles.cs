namespace MySolutionName.Core.Consts
{
    public static class Roles
    {
        public const string ADMIN = "Admin";
        public const string SPONSER = "Sponsor";
        public const string SUPER_VISOR = "Super_Visor";
        public const string MEMBER = "Member";
    }
}
