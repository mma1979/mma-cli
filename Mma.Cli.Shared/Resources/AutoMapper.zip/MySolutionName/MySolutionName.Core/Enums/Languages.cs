namespace MySolutionName.Core.Enums
{
    public enum Languages:int
    {
        Arabic=1,
        English=2
    }
}
