﻿namespace MySolutionName.Core.Enums;

public enum ResourceTypes:int
{
    API = 1,
    Web = 2
}
