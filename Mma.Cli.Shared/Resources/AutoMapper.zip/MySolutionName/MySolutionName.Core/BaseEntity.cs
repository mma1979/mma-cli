using System;

namespace MySolutionName.Core
{
    public class BaseEntity<T>
    {
        public T Id { get; protected set; }
        public Guid? CreatedBy { get; protected set; }
        public DateTime? CreatedDate { get; protected set; }
        public Guid? ModifiedBy { get; protected set; }
        public DateTime? ModifiedDate { get; protected set; }
        public bool? IsDeleted { get; protected set; }
        public Guid? DeletedBy { get; protected set; }
        public DateTime? DeletedDate { get; protected set; }
    }
}
