using FluentValidation;

using MySolutionName.Core.Database.Tables;

namespace MySolutionName.Core.Validations
{
    public class NotificationValidator:AbstractValidator<NotificationDto>
    {

        public NotificationValidator()
        {
           
        }


    }
}