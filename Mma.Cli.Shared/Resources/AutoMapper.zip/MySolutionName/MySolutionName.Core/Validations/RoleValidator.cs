using FluentValidation;
using MySolutionName.Core.Database.Identity;

namespace MySolutionName.Core.Validations
{
    public class RoleValidator : AbstractValidator<RoleDto>
    {
        public RoleValidator()
        {
            RuleFor(e => e.Name).NotEmpty().WithMessage("Field_Required");
        }
    }
}
