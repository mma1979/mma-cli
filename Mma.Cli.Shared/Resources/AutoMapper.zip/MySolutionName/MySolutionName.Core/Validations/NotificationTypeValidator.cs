using FluentValidation;

using MySolutionName.Core.Models.Notifications;

namespace MySolutionName.Core.Validations
{
    public class NotificationTypeValidator:AbstractValidator<NotificationTypeModifyModel>
    {

        public NotificationTypeValidator()
        {
           
        }


    }
}