using FluentValidation;

using MySolutionName.Core.Database.Tables;

namespace MySolutionName.Core.Validations
{
    public class NotificationTypeValidator:AbstractValidator<NotificationTypeDto>
    {

        public NotificationTypeValidator()
        {
           
        }


    }
}