using FluentValidation;

using MySolutionName.Core.Database.Tables;

namespace MySolutionName.Core.Validations
{
    public class NotificationStatusValidator:AbstractValidator<NotificationStatusDto>
    {

        public NotificationStatusValidator()
        {
           
        }


    }
}