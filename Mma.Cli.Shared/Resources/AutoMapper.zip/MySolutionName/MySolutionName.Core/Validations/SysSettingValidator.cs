using FluentValidation;

using MySolutionName.Core.Models.Tables;

namespace MySolutionName.Core.Validations
{
    public class SysSettingValidator : AbstractValidator<SysSettingModifyModel>
    {
        public SysSettingValidator()
        {

            RuleFor(e => e.SysKey).NotNull().WithMessage("Key_Required");
            RuleFor(e => e.SysValue).NotNull().WithMessage("Value_Required");
        }
    }
}
