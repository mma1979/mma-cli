using MySolutionName.Core.Database.Identity;

using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace MySolutionName.EntityFramework.EntityConfigurations
{
    public class RolesConfig : IEntityTypeConfiguration<Role>
    {
        private readonly string _schema;
        public RolesConfig(string schema = "dbo")
        {
            _schema = schema;
        }


        public void Configure(EntityTypeBuilder<Role> builder)
        {
            builder.ToTable("Roles", _schema);


            builder.HasQueryFilter(e => e.IsDeleted != true);
            builder.Property(e => e.IsDeleted).IsRequired().HasDefaultValueSql("((0))");
            builder.Property(e => e.CreatedDate).IsRequired().HasDefaultValueSql("(getdate())");
            builder.HasIndex(e => e.IsDeleted);



            builder.HasMany(e => e.UserRoles)
                .WithOne(e => e.Role)
                .HasForeignKey(e => e.RoleId)
                .OnDelete(DeleteBehavior.Cascade);

            builder.Property(e => e.Name).HasMaxLength(100);
            builder.Property(e => e.NormalizedName).HasMaxLength(100);
            builder.Property(e => e.ConcurrencyStamp).HasMaxLength(1000);

        }
    }
}
