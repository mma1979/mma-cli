using MySolutionName.Core.Database.Tables;
using MySolutionName.Core.Enums;

using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace MySolutionName.EntityFramework.EntityConfigurations
{
    public class SysSettingConfig : IEntityTypeConfiguration<SysSetting>
    {
        private readonly string _schema;
        public SysSettingConfig(string schema = "dbo")
        {
            _schema = schema;
        }


        public void Configure(EntityTypeBuilder<SysSetting> builder)
        {
            builder.ToTable("SysSettings", _schema);

            builder.Property(e => e.Enviroment).HasDefaultValue(SettingsTypeEnum.Development);

            builder.HasQueryFilter(e => e.IsDeleted != true);
            builder.Property(e => e.IsDeleted).IsRequired().HasDefaultValueSql("((0))");
            builder.Property(e => e.CreatedDate).IsRequired().HasDefaultValueSql("(getdate())");
            builder.HasIndex(e => e.IsDeleted);


            builder.Property(e => e.SysKey).HasMaxLength(200);
            builder.Property(e => e.SysValue).HasMaxLength(2000);

            builder.HasIndex(e => e.SysKey);

        }
    }
}
