﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

using MySolutionName.Core.Database.Views;

namespace MySolutionName.EntityFramework.EntityConfigurations.AuthenticationDb
{
    internal class VwAclConfig: IEntityTypeConfiguration<VwAcl>
    {
        private readonly string _schema;

        public VwAclConfig(string schema="dbo")
        {
            _schema = schema;
        }

        public void Configure(EntityTypeBuilder<VwAcl> builder)
        {
           builder.ToView("VW_ACLs", _schema);
        }
    }
}
