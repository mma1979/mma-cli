using MySolutionName.Core.Database.Tables;
using MySolutionName.EntityFramework.EntityConfigurations;

using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;
using System;
using MySolutionName.Common.Extensions;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using System.Linq;
using System.Threading.Tasks;
using System.Threading;
using MySolutionName.Core.Database.Notifications;
using MySolutionName.Core.Database.Identity;

namespace MySolutionName.EntityFramework
{
    public class ApplicationDbContext : DbContext
    {


        private readonly IHttpContextAccessor _httpContextAccessor;

        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options, IHttpContextAccessor httpContextAccessor)
            : base(options)
        {

            _httpContextAccessor = httpContextAccessor;
            
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer("name=DefaultConnection");
            }
        }

        public virtual DbSet<SysSetting> SysSettings { get; set; }
        public virtual DbSet<Attachment> Attachments { get; set; }
               

        public virtual DbSet<Notification> Notifications { get; set; }
        public virtual DbSet<EmailNotification> EmailNotifications { get; set; }
        public virtual DbSet<SmsNotification> SmsNotifications { get; set; }
        public virtual DbSet<PushNotification> PushNotifications { get; set; }
        public virtual DbSet<NotificationType> NotificationTypes { get; set; }
        public virtual DbSet<NotificationStatus> NotificationStatuses { get; set; }


       





        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.HasDefaultSchema("dbo");

            modelBuilder.Ignore<AppRefreshToken>();
            modelBuilder.Ignore<AppRole>();
            modelBuilder.Ignore<AppRoleClaim>();
            modelBuilder.Ignore<AppUser>();
            modelBuilder.Ignore<AppUserClaim>();
            modelBuilder.Ignore<AppUserLogin>();
            modelBuilder.Ignore<AppUserRole>();
            modelBuilder.Ignore<AppUserToken>();
            modelBuilder.Ignore<AppResource>();
            modelBuilder.Ignore<AppAccessControlEntry>();
            modelBuilder.Ignore<AppFeature>();
            modelBuilder.Ignore<AppFeatureFlag>();

            modelBuilder.ApplyConfiguration(new SysSettingConfig());
            modelBuilder.ApplyConfiguration(new AttachmentConfig());
            modelBuilder.ApplyConfiguration(new NotificationConfig());
            modelBuilder.ApplyConfiguration(new NotificationStatusConfig());
            modelBuilder.ApplyConfiguration(new NotificationTypeConfig());

        }

        #region Traker and Shadow Properties
        public async override Task<int> SaveChangesAsync(CancellationToken cancellationToken = default)
        {
            ChangeTracker.DetectChanges();
            var entries = ChangeTracker.Entries().ToList();
            var dateTimeNow = DateTime.Now;
            var userId = GetUserId(_httpContextAccessor.HttpContext?.User);
            entries.ForEach(entry => SetShadowProperties(dateTimeNow, userId, entry));

            //var trackerList = this.SaveTracking(ChangeTracker.Entries());

            var saveChanges = await base.SaveChangesAsync(cancellationToken).ConfigureAwait(false);

            //var trackerList2 = this.SetNewItemsData(trackerList);
            //Trackers.AddRange(trackerList2);
            //await base.SaveChangesAsync();

            return saveChanges;
        }

        public override int SaveChanges()
        {
            ChangeTracker.DetectChanges();
            var entries = ChangeTracker.Entries().ToList();
            var dateTimeNow = DateTime.Now;
            var userId = GetUserId(_httpContextAccessor.HttpContext?.User);
            entries.ForEach(entry => SetShadowProperties(dateTimeNow, userId, entry));

            //var trackerList = this.SaveTracking(ChangeTracker.Entries());

            var saveChanges = base.SaveChanges();

            //var trackerList2 = this.SetNewItemsData(trackerList);
            //Trackers.AddRange(trackerList2);
            //base.SaveChanges();

            return saveChanges;
        }

        private Guid? GetUserId(ClaimsPrincipal principal)
        {
            if (principal == null || !principal.HasClaim(c => string.Equals(c.Type, "UserId", StringComparison.OrdinalIgnoreCase)))
            {
                return default;
            }
            var activeUserId = principal.FindFirst(c => string.Equals(c.Type, "UserId", StringComparison.OrdinalIgnoreCase)).Value;
            return Guid.Parse(activeUserId);
        }

        private void SetShadowProperties(DateTime dateTimeNow, Guid? userId, EntityEntry entry)
        {
            #region Get Shadow Properties
            var CreatedBy = entry
                    .CurrentValues.Properties
                    .FirstOrDefault(x => string.Equals(x.Name, "CreatedBy", StringComparison.OrdinalIgnoreCase));

            var CreatedDate = entry
                .CurrentValues.Properties
                .FirstOrDefault(x => string.Equals(x.Name, "CreatedDate", StringComparison.OrdinalIgnoreCase));

            var ModifiedBy = entry
                .CurrentValues.Properties
                .FirstOrDefault(x => string.Equals(x.Name, "ModifiedBy", StringComparison.OrdinalIgnoreCase));

            var ModifiedDate = entry
                .CurrentValues.Properties
                .FirstOrDefault(x => string.Equals(x.Name, "ModifiedDate", StringComparison.OrdinalIgnoreCase));

            var IsDeleted = entry
                .CurrentValues.Properties
                .FirstOrDefault(x => string.Equals(x.Name, "IsDeleted", StringComparison.OrdinalIgnoreCase));

            var DeletedBy = entry
               .CurrentValues.Properties
               .FirstOrDefault(x => string.Equals(x.Name, "DeletedBy", StringComparison.OrdinalIgnoreCase));

            var DeletedDate = entry
               .CurrentValues.Properties
               .FirstOrDefault(x => string.Equals(x.Name, "DeletedDate", StringComparison.OrdinalIgnoreCase));
            #endregion

            #region Clousers
            bool AddData()
            {

                entry.CurrentValues[IsDeleted?.Name] = false;
                entry.CurrentValues[CreatedDate?.Name] = dateTimeNow;

                if (userId != default && entry.CurrentValues[CreatedBy] != null)
                {
                    entry.CurrentValues[CreatedBy?.Name] = userId;
                }

                entry.CurrentValues[ModifiedDate?.Name] = null;
                entry.CurrentValues[ModifiedBy?.Name] = null;
                return true;
            }

            bool ModifyData()
            {

                entry.CurrentValues[ModifiedDate?.Name] = dateTimeNow;
                entry.CurrentValues[ModifiedBy?.Name] = userId;
                var isDeletedHasValue = entry.CurrentValues.ToBoolean() == true;
                if (isDeletedHasValue)
                {
                    entry.CurrentValues[DeletedDate?.Name] = dateTimeNow;
                    entry.CurrentValues[DeletedBy?.Name] = userId;
                }
                return true;
            }

            bool DeleteData()
            {
                entry.CurrentValues[DeletedDate?.Name] = dateTimeNow;
                entry.CurrentValues[DeletedBy?.Name] = userId;
                return true;
            }
            #endregion

            _ = entry.State switch
            {
                EntityState.Added => AddData(),
                EntityState.Modified => ModifyData(),
                EntityState.Deleted => DeleteData(),
                _ => false
            };

        }
        #endregion

    }
}