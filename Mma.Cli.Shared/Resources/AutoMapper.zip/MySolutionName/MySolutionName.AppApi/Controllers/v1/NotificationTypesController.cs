using MySolutionName.AppApi.Controllers.v1;
using MySolutionName.Common;
using MySolutionName.Common.Helpers;
using MySolutionName.Core.Database.Tables;
using MySolutionName.Core.Models;
using MySolutionName.Services;

using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using MySolutionName.Core.Database.Notifications;

namespace MySolutionName.AppAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class NotificationTypesController : BaseController
    {
        private readonly NotificationTypeService _notificationTypeService;
        private readonly Translator _translator;
        private readonly ILogger<NotificationTypesController> _logger;

        public NotificationTypesController(NotificationTypeService notificationTypeService, Translator translator, ILogger<NotificationTypesController> logger) : base(translator)
        {
            _notificationTypeService = notificationTypeService;
            _translator = translator;
            _logger = logger;
        }



        [HttpGet]
        public async Task<ActionResult<ResultViewModel<List<NotificationTypeDto>>>> GetAll([FromQuery] QueryViewModel query, CancellationToken cancellationToken)
        {
			if (cancellationToken.IsCancellationRequested)
            {
                return BadRequest(new
                {
                    IsSuccess = false,
                    Messages = new[] { "Request has been canceled" }
                });
            }
            var result = new ResultViewModel<List<NotificationTypeDto>>();
            try
            {
                query.UserId = UserId;
                var data = await _notificationTypeService.All(query);
                data.Messages = data.Messages.Select(m => _translator.Translate(m, Language)).ToList();
                if (data.IsSuccess)
                    return Ok(data);

                return BadRequest(data);

            }
            catch (HttpException ex)
            {
                _logger.LogError(ex.Message, query, ex);
                return BadRequest(HandleHttpException<List<NotificationTypeDto>>(ex));
            }
            catch (Exception ex)
            {

                _logger.LogError(ex.Message, ex);
                result.IsSuccess = false;
                result.StatusCode = 500;
                return BadRequest(result);
            }
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<ResultViewModel<NotificationTypeDto>>> GetOne(int id, CancellationToken cancellationToken)
        {
			if (cancellationToken.IsCancellationRequested)
            {
                return BadRequest(new
                {
                    IsSuccess = false,
                    Messages = new[] { "Request has been canceled" }
                });
            }
            var result = new ResultViewModel<NotificationTypeDto>();
            try
            {
                var data = await _notificationTypeService.Find(id);
                data.Messages = data.Messages.Select(m => _translator.Translate(m, Language)).ToList();

                if (data.IsSuccess)

                    return Ok(data);

                return BadRequest(data);

            }
            catch (HttpException ex)
            {

                _logger.LogError(ex.Message, ex);
                return BadRequest(HandleHttpException<NotificationTypeDto>(ex));
            }
            catch (Exception ex)
            {

                _logger.LogError(ex.Message, ex);
                result.IsSuccess = false;
                result.StatusCode = 500;
                return BadRequest(result);
            }
        }



        [HttpPost]
        public async Task<ActionResult<ResultViewModel<NotificationTypeDto>>> PostNotificationType([FromBody] NotificationTypeDto model, CancellationToken cancellationToken)
        {
			if (cancellationToken.IsCancellationRequested)
            {
                return BadRequest(new
                {
                    IsSuccess = false,
                    Messages = new[] { "Request has been canceled" }
                });
            }
            var result = new ResultViewModel<NotificationType>();
            try
            {
                var data = await _notificationTypeService.Add(model);
                data.Messages = data.Messages.Select(m => _translator.Translate(m, Language)).ToList();

                if (data.IsSuccess)
                    return Ok(data);

                return BadRequest(data);

            }
            catch (HttpException ex)
            {

                _logger.LogError(ex.Message, ex);
                return BadRequest(HandleHttpException<NotificationTypeDto>(ex));
            }
            catch (Exception ex)
            {

                _logger.LogError(ex.Message, ex);
                result.IsSuccess = false;
                result.StatusCode = 500;
                return BadRequest(result);
            }
        }

        [HttpPut("{id}")]
        public async Task<ActionResult<ResultViewModel<NotificationTypeDto>>> PutNotificationType(int id, [FromBody] NotificationTypeDto model, CancellationToken cancellationToken)
        {
			if (cancellationToken.IsCancellationRequested)
            {
                return BadRequest(new
                {
                    IsSuccess = false,
                    Messages = new[] { "Request has been canceled" }
                });
            }
			
            var result = new ResultViewModel<NotificationType>();
            try
            {
                if (model.Id != id)
                {
                    result.IsSuccess = false;
                    result.Messages.Add(_translator.Translate("InvalidData", Language));
                    return BadRequest(result);
                }
                var data = await _notificationTypeService.Update(model);
                data.Messages = data.Messages.Select(m => _translator.Translate(m, Language)).ToList();

                if (data.IsSuccess)
                    return Ok(data);

                return BadRequest(data);

            }
            catch (HttpException ex)
            {

                _logger.LogError(ex.Message, ex);
                return BadRequest(HandleHttpException<NotificationTypeDto>(ex));
            }
            catch (Exception ex)
            {

                _logger.LogError(ex.Message, ex);
                result.IsSuccess = false;
                result.StatusCode = 500;
                return BadRequest(result);
            }
        }

        [HttpDelete("{id}")]
        public async Task<ActionResult<ResultViewModel<NotificationTypeDto>>> DeleteNotificationType(int id, CancellationToken cancellationToken)
        {
			if (cancellationToken.IsCancellationRequested)
            {
                return BadRequest(new
                {
                    IsSuccess = false,
                    Messages = new[] { "Request has been canceled" }
                });
            }
			
            var result = new ResultViewModel<NotificationTypeDto>();
            try
            {
                var data = await _notificationTypeService.Delete(id);
                data.Messages = data.Messages.Select(m => _translator.Translate(m, Language)).ToList();

                if (data.IsSuccess)
                    return Ok(data);

                return BadRequest(data);

            }
            catch (HttpException ex)
            {

                _logger.LogError(ex.Message, ex);
                return BadRequest(HandleHttpException<NotificationTypeDto>(ex));
            }
            catch (Exception ex)
            {

                _logger.LogError(ex.Message, ex);
                result.IsSuccess = false;
                result.StatusCode = 500;
                return BadRequest(result);
            }
        }


    }

}