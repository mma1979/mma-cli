using MySolutionName.Services;

using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

using System.Linq;
using System.Threading;
using System.Threading.Tasks;

using MySolutionName.Core.Models;
using MySolutionName.Core.Consts;
using System;
using MySolutionName.AppApi.Infrastrcture;

namespace MySolutionName.AppApi.Controllers.v1.Account
{
    [Route("api/[controller]")]
    [ApiController]
    public class AccountController : ControllerBase
    {
        private readonly IServiceScopeFactory _scopeFactory;
        private readonly ILogger<AccountController> _logger;

        public AccountController(IServiceScopeFactory scopeFactory, ILogger<AccountController> logger)
        {
            _scopeFactory = scopeFactory;
            _logger = logger;
        }

        [AllowAnonymous]
        [HttpPost("Register")]
        public async Task<IActionResult> RegisterUser([FromBody] RegisterDto registerDto, CancellationToken cancellationToken)
        {
            if (cancellationToken.IsCancellationRequested)
            {
                return BadRequest(new { IsSuccess = false, Messages = new[] { "Request has been canceled" } });
            }

            if (!ModelState.IsValid)
            {
                var errors = ModelState.Values.SelectMany(value => value.Errors).Select(error => error.ErrorMessage).ToList();

                return BadRequest(new { IsSuccess = false, Messages = errors });
            }

            using var scope = _scopeFactory.CreateScope();
            var accountService = scope.ServiceProvider.GetRequiredService<AccountService>();
            var registrationResult = await accountService.Register(registerDto);

            if (registrationResult.IsSuccess)
            {
                return Ok(registrationResult);
            }

            return BadRequest(registrationResult);
        }

        [AllowAnonymous]
        [HttpPost("Login")]
        public async Task<IActionResult> Login([FromBody] LoginDto loginDto, CancellationToken cancellationToken)
        {
            if (cancellationToken.IsCancellationRequested)
            {
                return BadRequest(new
                {
                    IsSuccess = false,
                    Messages = new[] { "Request has been canceled" }
                });
            }
            if (!ModelState.IsValid)
            {
                var errors = ModelState.Values.SelectMany(value => value.Errors).Select(error => error.ErrorMessage).ToList();

                return BadRequest(new { IsSuccess = false, Messages = errors });
            }

            using var scope = _scopeFactory.CreateScope();
            using var service = scope.ServiceProvider.GetRequiredService<AccountService>();
            var result = await service.Login(loginDto);
            if (result.IsSuccess)
            {
                HttpContext.Request.Cookies.Keys.ToList().ForEach(x =>
                {
                    Response.Cookies.Delete(x);
                });

                CookieOptions option = new CookieOptions()
                {
                    Path = "/",
                    HttpOnly = true,
                    IsEssential = true,
                    Secure = true
                };

                Response.Cookies.Append("Token", result.Data.Token, option);
                Response.Cookies.Append("Refresh-Token", result.Data.RefreshToken, option);

                return Ok(result);
            }

            return BadRequest(result);
        }

        [AllowAnonymous]
        [HttpPost("forget-password")]
        public async Task<IActionResult> ForgetPassword([FromBody] ForgotPasswordDto forgetPasswordDto, CancellationToken cancellationToken)
        {
            if (cancellationToken.IsCancellationRequested)
            {
                return BadRequest(new
                {
                    IsSuccess = false,
                    Messages = new[] { "Request has been canceled" }
                });
            }
            if (!ModelState.IsValid)
            {
                var errors = ModelState.Values.SelectMany(value => value.Errors).Select(error => error.ErrorMessage).ToList();

                return BadRequest(new { IsSuccess = false, Messages = errors });
            }


            using var scope = _scopeFactory.CreateScope();
            using var service = scope.ServiceProvider.GetRequiredService<AccountService>();
            var result = await service.ForgetPassword(forgetPasswordDto);
            if (result.IsSuccess)
                return Ok(result);

            return BadRequest(result);
        }

        [AllowAnonymous]
        [HttpPost("forget-password-validate")]
        public async Task<IActionResult> ForgetPasswordValidate([FromBody] ForgotPasswordDto dto, CancellationToken cancellationToken)
        {
            if (cancellationToken.IsCancellationRequested)
            {
                return BadRequest(new
                {
                    IsSuccess = false,
                    Messages = new[] { "Request has been canceled" }
                });
            }
            if (!ModelState.IsValid)
            {
                var errors = ModelState.Values.SelectMany(value => value.Errors).Select(error => error.ErrorMessage).ToList();

                return BadRequest(new { IsSuccess = false, Messages = errors });
            }


            using var scope = _scopeFactory.CreateScope();
            using var service = scope.ServiceProvider.GetRequiredService<AccountService>();
            var result = await service.PenValidate(new(dto.Email, dto.Pen, TokenTypes.FORGET_PASSWORD_TOKEN));
            if (result.IsSuccess)
                return Ok(result);

            return BadRequest(result);
        }



        [HttpPost("confirm-email")]
        [RequiredPermission("Update")]
        public async Task<IActionResult> ConfirmCmail([FromQuery] Guid userId, [FromQuery] string pin, CancellationToken cancellationToken)
        {
            if (cancellationToken.IsCancellationRequested)
            {
                return BadRequest(new
                {
                    IsSuccess = false,
                    Messages = new[] { "Request has been canceled" }
                });
            }

            if (!ModelState.IsValid)
            {
                var errors = ModelState.Values.SelectMany(value => value.Errors).Select(error => error.ErrorMessage).ToList();

                return BadRequest(new { IsSuccess = false, Messages = errors });
            }

            using var scope = _scopeFactory.CreateScope();
            using var service = scope.ServiceProvider.GetRequiredService<AccountService>();
            var result = await service.ConfirmEmail(userId, pin);
            if (result.IsSuccess)
                return Ok(result);

            return BadRequest(result);
        }

       
        [HttpPost("reset-password")]
        [RequiredPermission("Update")]
        public async Task<IActionResult> ResetPassword([FromBody] ResetPasswordDto resetPasswordDto, CancellationToken cancellationToken)
        {
            if (cancellationToken.IsCancellationRequested)
            {
                return BadRequest(new
                {
                    IsSuccess = false,
                    Messages = new[] { "Request has been canceled" }
                });
            }
            if (!ModelState.IsValid)
            {
                var errors = ModelState.Values.SelectMany(value => value.Errors).Select(error => error.ErrorMessage).ToList();

                return BadRequest(new { IsSuccess = false, Messages = errors });
            }

            using var scope = _scopeFactory.CreateScope();
            using var service = scope.ServiceProvider.GetRequiredService<AccountService>();
            var result = await service.ResetPassword(resetPasswordDto);
            if (result.IsSuccess)
                return Ok(result);

            return BadRequest(result);
        }


        [HttpPost("validate-otp")]
        [RequiredPermission("Read")]
        public async Task<IActionResult> ValidateOTP([FromBody] ValidateOtpDto validateOtpDto, CancellationToken cancellationToken)
        {
            if (cancellationToken.IsCancellationRequested)
            {
                return BadRequest(new
                {
                    IsSuccess = false,
                    Messages = new[] { "Request has been canceled" }
                });
            }
            if (!ModelState.IsValid)
            {
                var errors = ModelState.Values.SelectMany(value => value.Errors).Select(error => error.ErrorMessage).ToList();

                return BadRequest(new { IsSuccess = false, Messages = errors });
            }

            using var scope = _scopeFactory.CreateScope();
            using var service = scope.ServiceProvider.GetRequiredService<AccountService>();
            var result = await service.ValidateOtp(validateOtpDto.Username, validateOtpDto.Otp);
            if (result.IsSuccess)
                return Ok(result);

            return BadRequest(result);

        }

        [HttpPost("AppRefreshToken")]
        [RequiredPermission("Update")]
        public async Task<IActionResult> RefreshToken([FromBody] TokenDto tokenRequest, CancellationToken cancellationToken)
        {
            if (cancellationToken.IsCancellationRequested)
            {
                return BadRequest(new
                {
                    IsSuccess = false,
                    Messages = new[] { "Request has been canceled" }
                });
            }

            if (!ModelState.IsValid)
            {
                var errors = ModelState.Values.SelectMany(value => value.Errors).Select(error => error.ErrorMessage).ToList();

                return BadRequest(new { IsSuccess = false, Messages = errors });
            }

            using var scope = _scopeFactory.CreateScope();
            using var service = scope.ServiceProvider.GetRequiredService<AccountService>();

            var result = await service.VerifyToken(tokenRequest);
            if (result.IsSuccess)
                return Ok(result);

            return BadRequest(result);

        }


        [HttpGet("Logout")]
        [RequiredPermission("Read")]
        public async Task<IActionResult> Logout(CancellationToken cancellationToken)
        {
            if (cancellationToken.IsCancellationRequested)
            {
                return BadRequest(new
                {
                    IsSuccess = false,
                    Messages = new[] { "Request has been canceled" }
                });
            }


            using var scope = _scopeFactory.CreateScope();
            using var service = scope.ServiceProvider.GetRequiredService<AccountService>();
            var userId = Guid.Parse(User.Claims.FirstOrDefault(c => c.Type == "UserId").Value);
            var result = await service.Logout(userId);
            if (result.IsSuccess)
            {
                HttpContext.Request.Cookies.Keys.ToList().ForEach(x =>
                {
                    Response.Cookies.Delete(x);
                });

                return Ok(result);
            }

            return BadRequest(result);
        }

    }
}
