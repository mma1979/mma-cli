using MySolutionName.Common;
using MySolutionName.Common.Helpers;
using MySolutionName.Core.Models;
using MySolutionName.Services;

using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using MySolutionName.AppApi.Infrastrcture;
using MySolutionName.Core.Models.Notifications;

namespace MySolutionName.AppApi.Controllers.v1.Notifications
{
    [Route("api/[controller]")]
    [ApiController]
    public class NotificationStatusesController : BaseController
    {
        private readonly NotificationStatusService _notificationStatusService;
        private readonly Translator _translator;
        private readonly ILogger<NotificationStatusesController> _logger;

        public NotificationStatusesController(NotificationStatusService notificationStatusService, Translator translator, ILogger<NotificationStatusesController> logger) : base(translator)
        {
            _notificationStatusService = notificationStatusService;
            _translator = translator;
            _logger = logger;
        }



        [HttpGet]
        [RequiredPermission("Read")]
        public async Task<IActionResult> GetAll([FromQuery] QueryViewModel query, CancellationToken cancellationToken)
        {
            if (cancellationToken.IsCancellationRequested)
            {
                return BadRequest(new
                {
                    IsSuccess = false,
                    Messages = new[] { "Request has been canceled" }
                });
            }
            var result = new ResultViewModel<List<NotificationStatusReadModel>>();
            try
            {
                query.UserId = UserId;
                var data = await _notificationStatusService.All(query);
                data.Messages = data.Messages.Select(m => _translator.Translate(m, Language)).ToList();
                if (data.IsSuccess)
                    return Ok(data);

                return BadRequest(data);

            }
            catch (HttpException ex)
            {
                _logger.LogError(ex.Message, query, ex);
                return BadRequest(HandleHttpException<List<NotificationStatusReadModel>>(ex));
            }
            catch (Exception ex)
            {

                _logger.LogError(ex.Message, ex);
                result.IsSuccess = false;
                result.StatusCode = 500;
                return BadRequest(result);
            }
        }

        [HttpGet("{id}")]
        [RequiredPermission("Read")]
        public async Task<IActionResult> GetOne(int id, CancellationToken cancellationToken)
        {
            if (cancellationToken.IsCancellationRequested)
            {
                return BadRequest(new
                {
                    IsSuccess = false,
                    Messages = new[] { "Request has been canceled" }
                });
            }
            var result = new ResultViewModel<NotificationStatusModifyModel>();
            try
            {
                var data = await _notificationStatusService.Find(id);
                data.Messages = data.Messages.Select(m => _translator.Translate(m, Language)).ToList();

                if (data.IsSuccess)

                    return Ok(data);

                return BadRequest(data);

            }
            catch (HttpException ex)
            {

                _logger.LogError(ex.Message, ex);
                return BadRequest(HandleHttpException<NotificationStatusModifyModel>(ex));
            }
            catch (Exception ex)
            {

                _logger.LogError(ex.Message, ex);
                result.IsSuccess = false;
                result.StatusCode = 500;
                return BadRequest(result);
            }
        }



        [HttpPost]
        [RequiredPermission("Create")]
        public async Task<IActionResult> PostNotificationStatus([FromBody] NotificationStatusModifyModel model, CancellationToken cancellationToken)
        {
            if (cancellationToken.IsCancellationRequested)
            {
                return BadRequest(new
                {
                    IsSuccess = false,
                    Messages = new[] { "Request has been canceled" }
                });
            }
            var result = new AcknowledgeViewModel();
            try
            {
                var data = await _notificationStatusService.Add(model);
                data.Messages = data.Messages.Select(m => _translator.Translate(m, Language)).ToList();

                if (data.IsSuccess)
                    return Ok(data);

                return BadRequest(data);

            }
            catch (HttpException ex)
            {

                _logger.LogError(ex.Message, ex);
                return BadRequest(HandleHttpException(ex));
            }
            catch (Exception ex)
            {

                _logger.LogError(ex.Message, ex);
                result.IsSuccess = false;
                result.StatusCode = 500;
                return BadRequest(result);
            }
        }

        [HttpPut("{id}")]
        [RequiredPermission("Update")]
        public async Task<IActionResult> PutNotificationStatus(int id, [FromBody] NotificationStatusModifyModel model, CancellationToken cancellationToken)
        {
            if (cancellationToken.IsCancellationRequested)
            {
                return BadRequest(new
                {
                    IsSuccess = false,
                    Messages = new[] { "Request has been canceled" }
                });
            }

            var result = new AcknowledgeViewModel();
            try
            {
                if (model.Id != id)
                {
                    result.IsSuccess = false;
                    result.Messages.Add(_translator.Translate("InvalidData", Language));
                    return BadRequest(result);
                }
                var data = await _notificationStatusService.Update(model);
                data.Messages = data.Messages.Select(m => _translator.Translate(m, Language)).ToList();

                if (data.IsSuccess)
                    return Ok(data);

                return BadRequest(data);

            }
            catch (HttpException ex)
            {

                _logger.LogError(ex.Message, ex);
                return BadRequest(HandleHttpException(ex));
            }
            catch (Exception ex)
            {

                _logger.LogError(ex.Message, ex);
                result.IsSuccess = false;
                result.StatusCode = 500;
                return BadRequest(result);
            }
        }

        [HttpDelete("{id}")]
        [RequiredPermission("Update,Delete")]
        public async Task<IActionResult> DeleteNotificationStatus(int id, CancellationToken cancellationToken)
        {
            if (cancellationToken.IsCancellationRequested)
            {
                return BadRequest(new
                {
                    IsSuccess = false,
                    Messages = new[] { "Request has been canceled" }
                });
            }

            var result = new AcknowledgeViewModel();
            try
            {
                var data = await _notificationStatusService.Delete(id);
                data.Messages = data.Messages.Select(m => _translator.Translate(m, Language)).ToList();

                if (data.IsSuccess)
                    return Ok(data);

                return BadRequest(data);

            }
            catch (HttpException ex)
            {

                _logger.LogError(ex.Message, ex);
                return BadRequest(HandleHttpException(ex));
            }
            catch (Exception ex)
            {

                _logger.LogError(ex.Message, ex);
                result.IsSuccess = false;
                result.StatusCode = 500;
                return BadRequest(result);
            }
        }


    }

}