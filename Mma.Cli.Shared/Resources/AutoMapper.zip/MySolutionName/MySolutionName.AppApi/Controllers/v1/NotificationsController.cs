using MySolutionName.AppApi.Controllers.v1;
using MySolutionName.Common;
using MySolutionName.Common.Helpers;
using MySolutionName.Core.Database.Tables;
using MySolutionName.Core.Models;
using MySolutionName.Services;

using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using MySolutionName.Core.Database.Notifications;

namespace MySolutionName.AppAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class NotificationsController : BaseController
    {
        private readonly NotificationService _notificationService;
        private readonly Translator _translator;
        private readonly ILogger<NotificationsController> _logger;

        public NotificationsController(NotificationService notificationService, Translator translator, ILogger<NotificationsController> logger) : base(translator)
        {
            _notificationService = notificationService;
            _translator = translator;
            _logger = logger;
        }



        [HttpGet]
        public async Task<ActionResult<ResultViewModel<List<NotificationDto>>>> GetAll([FromQuery] QueryViewModel query, CancellationToken cancellationToken)
        {
			if (cancellationToken.IsCancellationRequested)
            {
                return BadRequest(new
                {
                    IsSuccess = false,
                    Messages = new[] { "Request has been canceled" }
                });
            }
            var result = new ResultViewModel<List<NotificationDto>>();
            try
            {
                query.UserId = UserId;
                var data = await _notificationService.All(query);
                data.Messages = data.Messages.Select(m => _translator.Translate(m, Language)).ToList();
                if (data.IsSuccess)
                    return Ok(data);

                return BadRequest(data);

            }
            catch (HttpException ex)
            {
                _logger.LogError(ex.Message, query, ex);
                return BadRequest(HandleHttpException<List<NotificationDto>>(ex));
            }
            catch (Exception ex)
            {

                _logger.LogError(ex.Message, ex);
                result.IsSuccess = false;
                result.StatusCode = 500;
                return BadRequest(result);
            }
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<ResultViewModel<NotificationDto>>> GetOne(Guid id, CancellationToken cancellationToken)
        {
			if (cancellationToken.IsCancellationRequested)
            {
                return BadRequest(new
                {
                    IsSuccess = false,
                    Messages = new[] { "Request has been canceled" }
                });
            }
            var result = new ResultViewModel<NotificationDto>();
            try
            {
                var data = await _notificationService.Find(id);
                data.Messages = data.Messages.Select(m => _translator.Translate(m, Language)).ToList();

                if (data.IsSuccess)

                    return Ok(data);

                return BadRequest(data);

            }
            catch (HttpException ex)
            {

                _logger.LogError(ex.Message, ex);
                return BadRequest(HandleHttpException<NotificationDto>(ex));
            }
            catch (Exception ex)
            {

                _logger.LogError(ex.Message, ex);
                result.IsSuccess = false;
                result.StatusCode = 500;
                return BadRequest(result);
            }
        }



        [HttpPost]
        public async Task<ActionResult<ResultViewModel<NotificationDto>>> PostNotification([FromBody] NotificationDto model, CancellationToken cancellationToken)
        {
			if (cancellationToken.IsCancellationRequested)
            {
                return BadRequest(new
                {
                    IsSuccess = false,
                    Messages = new[] { "Request has been canceled" }
                });
            }
            var result = new ResultViewModel<Notification>();
            try
            {
                var data = await _notificationService.Add(model);
                data.Messages = data.Messages.Select(m => _translator.Translate(m, Language)).ToList();

                if (data.IsSuccess)
                    return Ok(data);

                return BadRequest(data);

            }
            catch (HttpException ex)
            {

                _logger.LogError(ex.Message, ex);
                return BadRequest(HandleHttpException<NotificationDto>(ex));
            }
            catch (Exception ex)
            {

                _logger.LogError(ex.Message, ex);
                result.IsSuccess = false;
                result.StatusCode = 500;
                return BadRequest(result);
            }
        }

        [HttpPut("{id}")]
        public async Task<ActionResult<ResultViewModel<NotificationDto>>> PutNotification(Guid id, [FromBody] NotificationDto model, CancellationToken cancellationToken)
        {
			if (cancellationToken.IsCancellationRequested)
            {
                return BadRequest(new
                {
                    IsSuccess = false,
                    Messages = new[] { "Request has been canceled" }
                });
            }
			
            var result = new ResultViewModel<Notification>();
            try
            {
                if (model.Id != id)
                {
                    result.IsSuccess = false;
                    result.Messages.Add(_translator.Translate("InvalidData", Language));
                    return BadRequest(result);
                }
                var data = await _notificationService.Update(model);
                data.Messages = data.Messages.Select(m => _translator.Translate(m, Language)).ToList();

                if (data.IsSuccess)
                    return Ok(data);

                return BadRequest(data);

            }
            catch (HttpException ex)
            {

                _logger.LogError(ex.Message, ex);
                return BadRequest(HandleHttpException<NotificationDto>(ex));
            }
            catch (Exception ex)
            {

                _logger.LogError(ex.Message, ex);
                result.IsSuccess = false;
                result.StatusCode = 500;
                return BadRequest(result);
            }
        }

        [HttpDelete("{id}")]
        public async Task<ActionResult<ResultViewModel<NotificationDto>>> DeleteNotification(Guid id, CancellationToken cancellationToken)
        {
			if (cancellationToken.IsCancellationRequested)
            {
                return BadRequest(new
                {
                    IsSuccess = false,
                    Messages = new[] { "Request has been canceled" }
                });
            }
			
            var result = new ResultViewModel<NotificationDto>();
            try
            {
                var data = await _notificationService.Delete(id);
                data.Messages = data.Messages.Select(m => _translator.Translate(m, Language)).ToList();

                if (data.IsSuccess)
                    return Ok(data);

                return BadRequest(data);

            }
            catch (HttpException ex)
            {

                _logger.LogError(ex.Message, ex);
                return BadRequest(HandleHttpException<NotificationDto>(ex));
            }
            catch (Exception ex)
            {

                _logger.LogError(ex.Message, ex);
                result.IsSuccess = false;
                result.StatusCode = 500;
                return BadRequest(result);
            }
        }


    }

}