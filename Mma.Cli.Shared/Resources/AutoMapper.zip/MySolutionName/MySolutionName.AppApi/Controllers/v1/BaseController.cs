using MySolutionName.AppApi.Filters;
using MySolutionName.Common;
using MySolutionName.Common.Extensions;
using MySolutionName.Common.Helpers;
using MySolutionName.Core.Models;

using Microsoft.AspNetCore.Mvc;

using Newtonsoft.Json;

using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;

namespace MySolutionName.AppApi.Controllers.v1
{
    [Route("api/[controller]")]
    [ApiController]
    [LoggingFilter]
    public class BaseController : ControllerBase
    {
        private Translator _translator;
        public BaseController(Translator translator)
        {
            _translator = translator;
        }

        protected long? UserId
        {
            get
            {
                var token = HttpContext.Request.Headers["Authorization"].ToString();
                if (string.IsNullOrEmpty(token) || string.IsNullOrWhiteSpace(token))
                {
                    return null;
                }
                var splits = token.Split(' ');
                if (splits.Length < 2)
                {
                    return null;
                }
                var handler = new JwtSecurityTokenHandler();
                JwtSecurityToken tokenInfo;
                try
                {
                    tokenInfo = handler.ReadJwtToken(splits[1]);
                }
                catch (Exception)
                {

                    return null;
                }

                return tokenInfo.Claims.FirstOrDefault(c => c.Type == "Id")?.Value.ToNullableLong();

            }
        }

        protected string Language
        {
            get
            {
                var lang = string.IsNullOrWhiteSpace(HttpContext.Request.Headers["Accept-Language"]) ?
                    "en" : HttpContext.Request.Headers["Accept-Language"].ToString();
                return lang;

            }
        }

        protected ResultViewModel<T> HandleHttpException<T>(HttpException exception)
        {
            var result = new ResultViewModel<T>
            {
                IsSuccess = false,
                StatusCode = 500,
                Messages = (JsonConvert.DeserializeObject<List<string>>(exception.Message) ?? new List<string>())
                    .Select(m => _translator.Translate(m, Language)).ToList()
            };

            return result;
        }

        protected IActionResult RequestCanceled()
        {

            return BadRequest(new
            {
                IsSuccess = false,
                Messages = new[] { "Request has been canceled" }
            });

        }
    }
}
