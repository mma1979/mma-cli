﻿using Microsoft.AspNetCore.SignalR;

namespace MySolutionName.AppApi.Hubs
{
    public class RabbitMQNotificationsHub:Hub
    {
    }
}
