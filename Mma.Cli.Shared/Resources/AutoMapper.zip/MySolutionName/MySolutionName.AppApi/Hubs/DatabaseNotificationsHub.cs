﻿using Amazon.SimpleNotificationService.Util;

using Microsoft.AspNetCore.SignalR;

using MySolutionName.Core.Enums;
using MySolutionName.EntityFramework;

using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using Microsoft.AspNetCore.Http;
using MySolutionName.Common.Extensions;

namespace MySolutionName.AppApi.Hubs
{
    public class DatabaseNotificationsHub:Hub
    {
        private readonly ApplicationDbContext _context;
        private readonly IHttpContextAccessor _contextAccessor;
        public DatabaseNotificationsHub(ApplicationDbContext context, IHttpContextAccessor contextAccessor)
        {
            _context = context;
            _contextAccessor = contextAccessor;
        }

        public async Task ReadMessages()
        {
            
            while (true)
            {
                var userId = _contextAccessor.HttpContext.User.Claims.FirstOrDefault(c => c.Type == "Id")?.Value.ToNullableLong();
                var messages = _context.PushNotifications
                    .Where(e=>e.NotificationStatus == NotificationStatuses.Pending && e.IsRead==false && 
                    e.UserId == userId)
                    .ToList();
                if (messages.Any())
                {
                    await Clients.All.SendAsync("LoadData", messages);
                }
            }

        }
    }
}
