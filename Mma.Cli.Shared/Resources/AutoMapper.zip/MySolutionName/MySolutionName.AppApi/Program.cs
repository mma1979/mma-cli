using Serilog;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Builder;
using MySolutionName.AppApi.Infrastrcture.Middlewares;
using MySolutionName.AppApi.Infrastrcture.Extensions;


var builder = WebApplication.CreateBuilder(args);

builder.ConfigureAppConfiguration()
    .ConfigureSeriLog()
    .ConfigureAuoMapper()
    .ConfigureStronglyTypedSettings()
    .ConfigureAllowedServices()
    .ConfigureApiVersioning()
    .ConfigureDataAccess()
    .ConfigureJwtAuthentication()
    .ConfigureRedisCache()
    .ConfigureSwagger()
    .ConfigurePollyResilience()
    .ConfigureFluentEmail()
    .ConfigureHangfire()
    .ConfigureHealthChecks();



var app = builder.Build();

// Configure the HTTP request pipeline.


app.UseDevelopment(!builder.Environment.IsProduction())
    .UseMiddleware<RequestSanitizationMiddleware>()
    .UseHttpsRedirection()
    .UseRouting()
    .UseCorsPolicy(builder.Configuration["AllowedOrigins"], builder.Environment)
    .UseSerilogRequestLogging()
    .UseAuthentication() 
    .UseAuthorization()
    .UseMiddleware<JwtAuthenticationMiddleware>()
    .UseMiddleware<PermissionMiddleware>()
    .UseRemoveHeaders("Server", "X-Powered-By");


app.UseMapRoutes();

app.Run();