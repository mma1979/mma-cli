﻿namespace MySolutionName.AppApi.Infrastrcture
{
    public static class NotificationsListner
    {
    }
}
