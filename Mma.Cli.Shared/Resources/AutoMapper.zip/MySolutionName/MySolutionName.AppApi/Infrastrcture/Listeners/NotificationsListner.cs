﻿namespace MySolutionName.AppApi.Infrastrcture.Listeners
{
    public static class NotificationsListner
    {
    }
}
