using MySolutionName.Common.Helpers;
using MySolutionName.Common.Models;
using MySolutionName.Core.Database.Identity;
using MySolutionName.EntityFramework;
using MySolutionName.Services;

using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;

using Serilog;

using Swashbuckle.AspNetCore.SwaggerUI;

using System;
using System.Net;
using System.Net.Mail;
using System.Text;


using Redis = StackExchange.Redis;
using MySolutionName.AppApi.Infrastrcture;
using MySolutionName.Core.Models;
using MySolutionName.AppApi.Middlewares;
using Asp.Versioning;
using HealthChecks.UI.Client;
using Microsoft.AspNetCore.Diagnostics.HealthChecks;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Diagnostics.HealthChecks;
using Polly;
using Polly.Retry;

namespace MySolutionName.AppApi
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        private const string _defaultCorsPolicyName = "localhost";

        public void ConfigureServices(IServiceCollection services)
        {
            services.AddAutoMapper(System.Reflection.Assembly.GetAssembly(typeof(Core.MappingProfile)));

           

            // configure strongly typed settings objects
            IConfigurationSection appSettingsSection = Configuration.GetSection("AppSettings");
            services.Configure<AppSettings>(appSettingsSection);

            services.AddMvc().AddNewtonsoftJson(options =>
            {
                //options.SerializerSettings.ContractResolver = new DefaultContractResolver();
                options.SerializerSettings.ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore;
            });
            services.AddControllers().AddNewtonsoftJson(options =>
            {
                //options.SerializerSettings.ContractResolver = new DefaultContractResolver();
                options.SerializerSettings.ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore;
            });
            services.AddLogging();
            services.AddHttpContextAccessor();

            #region API Versioning
            services.AddApiVersioning(c =>
            {
                c.DefaultApiVersion = new ApiVersion(1, 0);
                c.AssumeDefaultVersionWhenUnspecified = true;
                c.ReportApiVersions = true;
                c.ApiVersionReader = new UrlSegmentApiVersionReader();
            });
            #endregion


            #region  For Entity Framework
            services.AddDbContext<AuthenticationDbContext>(options => options.UseSqlServer(Configuration.GetConnectionString("AuthenticationConnection")));

            services.AddDbContext<ApplicationDbContext>(options => options.UseSqlServer(Configuration.GetConnectionString("DefaultConnection")));

            services.AddDbContext<LoggingDbContext>(options => options.UseSqlServer(Configuration.GetConnectionString("LogsConnection")));

            services.AddDbContext<LocalizationDbContext>(options => options.UseSqlite(Configuration.GetConnectionString("LocalizationConnection")));
            #endregion

            #region Authentication & JWT

            services.Configure<JwtConfig>(Configuration.GetSection("JWT"));
            // add validation paramter as singletone so that we can use it across the appications
            TokenValidationParameters tokenValidationParameters = new()
            {
                IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(Configuration["JWT:Secret"])),
                ValidateIssuerSigningKey = true,
                ValidateLifetime = true,
                ValidateIssuer = false,
                ValidateAudience = false,
                ValidAudience = Configuration["JWT:ValidAudience"],
                ValidIssuer = Configuration["JWT:ValidIssuer"],
                RequireExpirationTime = false,
                // Allow to use seconds for expiration of token
                // Required only when token lifetime less than 5 minutes
                // THIS ONE
                ClockSkew = TimeSpan.Zero

            };

            services.AddSingleton(tokenValidationParameters);

            // Adding Authentication
            services.AddAuthentication(options =>
            {
                options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
                options.DefaultScheme = JwtBearerDefaults.AuthenticationScheme;
            })
            // Adding Jwt Bearer
            .AddJwtBearer(options =>
            {
                options.SaveToken = true;
                options.RequireHttpsMetadata = false;
                options.TokenValidationParameters = tokenValidationParameters;
            });

            // For Identity
            services.AddIdentity<AppUser, AppRole>(options => options.SignIn.RequireConfirmedAccount = true)
                .AddEntityFrameworkStores<AuthenticationDbContext>()
                .AddDefaultTokenProviders();



            #endregion

            #region Redis Cache

            services.AddStackExchangeRedisCache(options =>
            {
                options.Configuration = $"{Configuration.GetValue<string>("Redis:Server")}:{Configuration.GetValue<int>("Redis:Port")}";
                options.ConfigurationOptions = Redis.ConfigurationOptions.Parse(options.Configuration);
                options.ConfigurationOptions.Password = Configuration.GetValue<string>("Redis:Password");



            });



            #endregion

            #region Swagger
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new OpenApiInfo { Title = "MySolutionName.AppApi", Version = "v1" });
                c.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
                {
                    Name = "Authorization",
                    Type = SecuritySchemeType.ApiKey,
                    Scheme = "Bearer",
                    BearerFormat = "JWT",
                    In = ParameterLocation.Header,
                    Description = "JWT Authorization header using the Bearer scheme."
                });
                c.AddSecurityRequirement(new OpenApiSecurityRequirement
                {
                    {
                        new OpenApiSecurityScheme
                        {
                            Reference = new OpenApiReference
                            {
                                Type = ReferenceType.SecurityScheme,
                                Id = "Bearer"
                            }
                        },
                        new string[] {}

                    }
                });
            });
            #endregion

            #region Polly resilience 
            services.AddResiliencePipeline("proxy-services", builder =>
            {
                builder
                    .AddRetry(new RetryStrategyOptions()
                    {
                        MaxRetryAttempts = Configuration.GetValue<int>("Polly:MaxRetryAttempts"),
                        Delay = TimeSpan.FromSeconds(Configuration.GetValue<int>("Polly:Delay"))
                    })
                    .AddTimeout(TimeSpan.FromSeconds(Configuration.GetValue<int>("Polly:Timeout")));
            });

            #endregion

            services
                 .AddFluentEmail(Configuration.GetValue<string>("SMTP:Email"))
                 .AddRazorRenderer()
                 .AddSmtpSender(new SmtpClient()
                 {
                     Host = Configuration.GetValue<string>("SMTP:SmtpServer"),
                     Port = Configuration.GetValue<int>("SMTP:Port"),
                     Credentials = new NetworkCredential(Configuration.GetValue<string>("SMTP:Email"), Configuration.GetValue<string>("SMTP:Password")),
                     EnableSsl = Configuration.GetValue<bool>("SMTP:EnableSsl")
                 });

            services.AddSignalR();
          
            services.ConnectHangfire(Configuration);

            services.AddHealthChecks()
               .AddSqlServer(Configuration.GetConnectionString("DefaultConnection"));

            services.AddSysSettingsHelper();
            services.AddTranslator();
            services.AddServices();
            services.AddTransient<RequestSanitizationMiddleware>();
            services.AddTransient<FeatureService>();
            services.AddScoped<PermissionService>();



        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env, TokenValidationParameters tokenValidationParameters, AuthenticationDbContext authContext, ApplicationDbContext appContext, LoggingDbContext logContext)
        {
            try
            {
                authContext.Database.EnsureCreated();
                authContext.Database.Migrate();
            }
            catch (Exception e)
            {
                Log.Fatal(e.Message, e);
            }
            
            try
            {
                appContext.Database.EnsureCreated();
                appContext.Database.Migrate();
            }
            catch (Exception e)
            {
                Log.Fatal(e.Message, e);
            }

            try
            {
                logContext.Database.EnsureCreated();
                logContext.Database.Migrate();
            }
            catch (Exception e)
            {
                Log.Fatal(e.Message, e);
            }

            if (!env.IsProduction())
            {
                app.UseDeveloperExceptionPage();
                app.UseSwagger();
                app.UseSwaggerUI(c =>
                {
                    c.DefaultModelRendering(ModelRendering.Model);
                    c.DefaultModelExpandDepth(-1);
                    c.DefaultModelsExpandDepth(-1);
                });
            }
            app.UseMiddleware<RequestSanitizationMiddleware>();
            app.UseHttpsRedirection();

            app.UseRouting();

            app.UseCorsPolicy(Configuration["AllowedOrigins"], env);

            app.UseSerilogRequestLogging();

            app.UseAuthentication();
            app.UseAuthorization();

            app.UseJwtAuthentication(tokenValidationParameters);
            app.UseMiddleware<PermissionMiddleware>();

            app.Use(async (ctx, next) =>
            {

                ctx.Response.Headers.Remove("Server");
                ctx.Response.Headers.Remove("x-powered-by");

                await next();

            });

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
                endpoints.MapRazorPages();

                endpoints.MapHealthChecks("/health", new HealthCheckOptions
                {
                    ResultStatusCodes =
                    {
                        [HealthStatus.Healthy] = StatusCodes.Status200OK,
                        [HealthStatus.Degraded] = StatusCodes.Status200OK,
                        [HealthStatus.Unhealthy] = StatusCodes.Status503ServiceUnavailable,
                    },
                    Predicate = _ => true,
                    ResponseWriter = UIResponseWriter.WriteHealthCheckUIResponse
                });
            });


        }


    }
}
