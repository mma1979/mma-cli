using AutoMapper;

using MySolutionName.Core.Database.Identity;
using MySolutionName.Core.Models;
using MySolutionName.EntityFramework;
using MySolutionName.Services.Chache;

using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Dynamic.Core;
using System.Linq.Expressions;
using System.Threading.Tasks;
namespace MySolutionName.Services
{
    public class RoleService
    {
        private readonly ApplicationDbContext _context;
        private readonly ILogger<RoleService> _logger;
        private readonly ICacheService _cacheService;
        private readonly IMapper _mapper;

        public RoleService(ApplicationDbContext context, ILogger<RoleService> logger, ICacheService cacheService, IMapper mapper)
        {
            _context = context;
            _logger = logger;
            _cacheService = cacheService;
            _mapper = mapper;
        }

        public async Task<ResultViewModel<List<RoleDto>>> All(QueryViewModel query)
        {
            try
            {
                var cached = _cacheService.Get<ResultViewModel<List<RoleDto>>>($"Role:GetAll_{query.GetHashCode()}");

                if (cached != null)
                {
                    return cached;
                }


                var data = _context.Roles.AsQueryable();
                if (!string.IsNullOrEmpty(query.Filter))
                {
                    data = data.Where(query.Filter);
                }

                query.Order = string.IsNullOrEmpty(query.Order) ? "Id Desc" : query.Order;
                data = data.OrderBy(query.Order);

                var page = query.PageNumber <= 0 ? data :
                           data.Skip((query.PageNumber - 1) * query.PageSize)
                           .Take(query.PageSize);

                var count = await data.CountAsync();
                var list = await page.ToListAsync();

                var result = new ResultViewModel<List<RoleDto>>
                {
                    IsSuccess = true,
                    StatusCode = 200,
                    Messages = { "data loaded successfully" },
                    Total = count,
                    PageSize = query.PageSize,
                    PageNumber = query.PageNumber,
                    Filter = query.Filter,
                    Data = _mapper.Map<List<RoleDto>>(list)
                };

                _cacheService.Set($"Role:GetAll_{query.GetHashCode()}", result);

                return result;
            }
            catch (Exception ex)
            {

                _logger.LogError(ex.Message, ex);
                return new ResultViewModel<List<RoleDto>>
                {
                    IsSuccess = false,
                    StatusCode = 500,
                    Messages = { "error while reading data." },
                    Filter = query.Filter,
                    PageNumber = query.PageNumber,
                    PageSize = query.PageSize,
                };
            }
        }

        public async Task<ResultViewModel<RoleDto>> Find(Expression<Func<Role, bool>> predicate)
        {
            try
            {
                var cached = _cacheService.Get<ResultViewModel<RoleDto>>($"Role:Find_{predicate.Body}");

                if (cached != null)
                {
                    return cached;
                }

                var data = await _context.Roles.SingleOrDefaultAsync(predicate);
                var result = new ResultViewModel<RoleDto>
                {
                    IsSuccess = true,
                    StatusCode = 200,
                    Messages = { "data loaded successfully" },
                    Data = _mapper.Map<RoleDto>(data)
                };

                _cacheService.Set($"Role:Find_{predicate.Body}", result);

                return result;
            }
            catch (Exception ex)
            {

                _logger.LogError(ex.Message, ex);
                return new ResultViewModel<RoleDto>
                {
                    IsSuccess = false,
                    StatusCode = 500,
                    Messages = { "error while loading data" },
                };
            }
        }
        public async Task<ResultViewModel<RoleDto>> Find(long id)
        {
            try
            {

                var cached = _cacheService.Get<ResultViewModel<RoleDto>>($"Role:Find_{id}");

                if (cached != null)
                {
                    return cached;
                }

                var data = await _context.Roles.FindAsync(id);
                var result = new ResultViewModel<RoleDto>
                {
                    IsSuccess = true,
                    StatusCode = 200,
                    Messages = { "data loaded successfully" },
                    Data = _mapper.Map<RoleDto>(data)
                };

                _cacheService.Set($"Role:Find_{id}", result);

                return result;
            }
            catch (Exception ex)
            {

                _logger.LogError(ex.Message, ex);
                return new ResultViewModel<RoleDto>
                {
                    IsSuccess = false,
                    StatusCode = 500,
                    Messages = { "error while loading data" },
                };
            }
        }


        public async Task<ResultViewModel<RoleDto>> Add(RoleDto dto)
        {
            try
            {
                var Role = new Role(dto);
                var entity = await _context.Roles.AddAsync(Role);
                _ = await _context.SaveChangesAsync();

                _cacheService.Clear("Role:");
                return new ResultViewModel<RoleDto>
                {

                    Data = _mapper.Map<RoleDto>(entity.Entity),
                    IsSuccess = true,
                    StatusCode = 200,
                    Messages = { "data saved successfully" },
                };

            }
            catch (Exception ex)
            {

                _logger.LogError(ex.Message, ex);
                return new ResultViewModel<RoleDto>
                {
                    IsSuccess = false,
                    StatusCode = 500,
                    Messages = { "error while saving data" },
                };
            }
        }

        public async Task<ResultViewModel<RoleDto>> Update(RoleDto dto)
        {
            try
            {
                var Role = await _context.Roles.FindAsync(dto.Id);
                if (Role == null)
                {
                    var exp = new KeyNotFoundException($"item number {dto.Id} does not Exist");
                    _logger.LogError(exp.Message, exp);
                    return new ResultViewModel<RoleDto>
                    {
                        IsSuccess = false,
                        StatusCode = 500,
                        Messages = { "Item Not Found" },
                    };
                }


                var entity = Role.Update(dto);

                _ = await _context.SaveChangesAsync();

                _cacheService.Clear("Role:");

                return new ResultViewModel<RoleDto>
                {
                    IsSuccess = true,
                    StatusCode = 200,
                    Messages = { "data modified successfully" },
                    Data = _mapper.Map<RoleDto>(entity)
                };

            }
            catch (Exception ex)
            {

                _logger.LogError(ex.Message, ex);
                return new ResultViewModel<RoleDto>
                {
                    IsSuccess = true,
                    StatusCode = 200,
                    Messages = { "error while saving data" },
                };
            }
        }

        public async Task<ResultViewModel<RoleDto>> Delete(long id)
        {
            try
            {
                var Role = await _context.Roles.FindAsync(id);
                if (Role == null)
                {
                    var exp = new KeyNotFoundException($"item number {id} does not Exist");
                    _logger.LogError(exp.Message, exp);
                    return new ResultViewModel<RoleDto>
                    {
                        IsSuccess = false,
                        StatusCode = 500,
                        Messages = { "Item Not Found" },
                    };
                }
                var entity = Role.Delete();
                _ = await _context.SaveChangesAsync();

                _cacheService.Clear("Role:");

                return new ResultViewModel<RoleDto>
                {
                    IsSuccess = true,
                    StatusCode = 200,
                    Messages = { "data removed successfully" },
                    Data = _mapper.Map<RoleDto>(entity)
                };

            }
            catch (Exception ex)
            {

                _logger.LogError(ex.Message, ex);
                return new ResultViewModel<RoleDto>
                {
                    IsSuccess = true,
                    StatusCode = 200,
                    Messages = { "error while removing data" },
                };
            }
        }

    }
}
