﻿using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.DependencyInjection;
using MySolutionName.ProxyServices;
using MySolutionName.Services.Chache;

using MySolutionName.Services.Settings;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MySolutionName.Services
{
    public static class ServicesDI
    {
        public static IServiceCollection AddServices(this IServiceCollection services)
        {
            
            services.AddStripeService();
            services.AddTransient<IMemoryCache, MemoryCache>();
            services.AddRedisCacheService();


            services.AddTransient<LocalizationSerivce>();
            services.AddTransient<SysSettingsService>();
            services.AddTransient<AccountService>();

            services.AddTransient<EmailService>();
            services.AddTransient<RoleService>();
            services.AddTransient<AttachmentsService>();

            return services;
        }
    }
}
