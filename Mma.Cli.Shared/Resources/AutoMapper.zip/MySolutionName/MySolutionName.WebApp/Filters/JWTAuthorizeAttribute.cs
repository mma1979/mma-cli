using MySolutionName.Common;
using MySolutionName.Core.Consts;

using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;

using System;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;

namespace MySolutionName.WebApp.Filters
{
    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Method, AllowMultiple = true, Inherited = true)]
    public class JWTAuthorizeAttribute : Attribute, IActionFilter
    {
        public string[] AllowedRoles { get; private set; }
        public JWTAuthorizeAttribute() { }

        public JWTAuthorizeAttribute(params string[] roles)
        {
            AllowedRoles = roles;
        }
        public void OnActionExecuting(ActionExecutingContext context)
        {
            if (context.ActionDescriptor.EndpointMetadata
               .Any(e => e is AllowAnonymousAttribute))
            {
                return;
            }

            var token = context.HttpContext.Request.Cookies[CookiesNames.Token];
            if (string.IsNullOrEmpty(token) || string.IsNullOrWhiteSpace(token))
            {
                context.Result = new RedirectToActionResult("Login", "Account", null);
                return;
            }



            var handler = new JwtSecurityTokenHandler();
            JwtSecurityToken tokenInfo;

            try
            {
                tokenInfo = handler.ReadJwtToken(token);
            }
            catch (Exception)
            {

                context.Result = new RedirectToActionResult("Login", "Account", null);
                return;
            }

            // Expiration Handle
            long.TryParse(tokenInfo.Claims.FirstOrDefault(c => c.Type == "exp")?.Value, out var exp);

            var now = (long)(DateTime.UtcNow.Subtract(new DateTime(1970, 1, 1))).TotalSeconds;

            if (exp <= now)
            {
                context.Result = new RedirectToActionResult("Login", "Account", null);
                return;
            }

            var roles = tokenInfo.Claims
                .Where(c => c.Type == "role")
                .Select(e => e.Value)
                .ToList();

            // is super admin or in AllowedRoles not set
            if (roles.Contains(Roles.ADMIN) || AllowedRoles == null)
            {
                return;
            }


            var isAllowed = AllowedRoles.Length > 0 && roles.All(e => AllowedRoles.Contains(e));



            if (!isAllowed)
            {
                context.Result = new RedirectToActionResult("Login", "Account", null);
                return;
            }


        }

        public void OnActionExecuted(ActionExecutedContext context)
        {

        }
    }
}
