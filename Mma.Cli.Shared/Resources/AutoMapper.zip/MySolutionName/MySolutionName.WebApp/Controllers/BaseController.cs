using MySolutionName.Common;
using MySolutionName.Common.Extensions;
using MySolutionName.WebApp.Filters;

using Microsoft.AspNetCore.Mvc;

using System.Linq;

namespace MySolutionName.WebApp.Controllers
{
    [JWTAuthorize]
    public class BaseController : Controller
    {
        protected long? UserId
        {
            get
            {
                return User.Claims.FirstOrDefault(e => e.Type == "Id")?.Value.ToNullableLong();
            }
        }

        protected string Language
        {
            get
            {
                var lang = string.IsNullOrWhiteSpace(HttpContext.Request.Cookies[CookiesNames.Language]) ?
                    "en" : HttpContext.Request.Cookies[CookiesNames.Language];
                return lang;

            }
        }

        protected string Token
        {
            get
            {
                var token = string.IsNullOrWhiteSpace(HttpContext.Request.Cookies[CookiesNames.Token]) ?
                    "" : HttpContext.Request.Cookies[CookiesNames.Token];
                return token;

            }
        }
    }
}
