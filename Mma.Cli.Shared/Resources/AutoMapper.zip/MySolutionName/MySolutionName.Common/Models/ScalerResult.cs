
namespace MySolutionName.Common.Models
{
    public class ScalerResult
    {
        public string Value { get; set; }
    }
}
