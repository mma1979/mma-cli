using MySolutionName.Common.Helpers;
using MySolutionName.Core.Consts;

using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.StaticFiles;

using System;
using System.IO;
using System.Net.Http;
using System.Threading.Tasks;

namespace MySolutionName.Admin.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class AttachmentsController : BaseController
    {
        private readonly RestHelper _restHelper;

        public AttachmentsController(RestHelper restHelper)
        {
            _restHelper = restHelper;
        }

        [HttpPost("Upload")]
        public async Task<IActionResult> Upload([FromForm] IFormFile myFile)
        {
            var client = new HttpClient
            {
                BaseAddress = new Uri(_restHelper.BaseUrl)
            };
            var multipartContent = new MultipartFormDataContent();
            var stream = new MemoryStream();
            await myFile.CopyToAsync(stream);
            var content = new ByteArrayContent(stream.ToArray());
            multipartContent.Add(content, "myFile", myFile.FileName);
            var result = await client.PostAsync($"{EndpointResources.ATTACHMENT_RESOURCE}/upload", multipartContent);
            var path = await result.Content.ReadAsStringAsync();
            return Ok(path);
        }


        // GET: Attachments/Files/Default
        [HttpGet("Files/{*imgName}")]
        [AllowAnonymous]
        public async Task<IActionResult> Files(string imgName)
        {
            var contentType = GetContentType(imgName);

            var client = new HttpClient
            {
                BaseAddress = new Uri(_restHelper.BaseUrl)
            };


            var response = await client.GetAsync($"{EndpointResources.ATTACHMENT_RESOURCE}/Files/Images/{imgName}");

            var ms = await response.Content.ReadAsStreamAsync();
            return File(ms, contentType);

        }


        private string GetContentType(string fileName)
        {
            if (fileName == "default") return "image/png";
            new FileExtensionContentTypeProvider().TryGetContentType(fileName, out string contentType);
            return contentType ?? "application/octet-stream";
        }

    }
}
