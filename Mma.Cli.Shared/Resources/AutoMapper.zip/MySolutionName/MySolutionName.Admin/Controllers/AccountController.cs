using MySolutionName.Common.Helpers;
using MySolutionName.Core.Consts;
using MySolutionName.Core.Models;

using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

using System.Linq;
using System.Threading.Tasks;

namespace MySolutionName.Admin.Controllers
{
    public class AccountController : BaseController
    {
        private readonly ILogger<AccountController> _logger;
        private readonly RestHelper _restHelper;

        public AccountController(ILogger<AccountController> logger, RestHelper restHelper)
        {
            _logger = logger;
            _restHelper = restHelper;
        }
        [AllowAnonymous]
        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

        [AllowAnonymous]
        [HttpPost]
        public async Task<IActionResult> Login(LoginDto dto)
        {
            var result = await _restHelper.Post<ResultViewModel<TokenDto>>(EndpointResources.LOGIN_RESOURCE, dto);
            if (result.IsSuccess)
            {
                HttpContext.Request.Cookies.Keys.ToList().ForEach(x =>
                {
                    Response.Cookies.Delete(x);
                });

                CookieOptions option = new CookieOptions()
                {
                    Path = "/",
                    HttpOnly = true,
                    IsEssential = true,
                    Secure = true
                };

                Response.Cookies.Append("Token", result.Data.Token, option);
                Response.Cookies.Append("Refresh-Token", result.Data.RefreshToken, option);
                Response.Cookies.Append("Language", Language, option);
                return RedirectToAction("Index", "Home");
            }

            ViewBag.Messages = result.Messages;
            return View(dto);
        }

        public IActionResult Logout()
        {
            HttpContext.Request.Cookies.Keys.ToList().ForEach(x =>
            {
                Response.Cookies.Delete(x);
            });

            return RedirectToAction("Index", "Home");
        }

    }
}
