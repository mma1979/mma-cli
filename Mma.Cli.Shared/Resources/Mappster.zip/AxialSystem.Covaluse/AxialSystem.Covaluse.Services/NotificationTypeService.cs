using AxialSystem.Covaluse.Core.Database.Notifications;
using AxialSystem.Covaluse.Core.Models;
using AxialSystem.Covaluse.EntityFramework;
using AxialSystem.Covaluse.Services.Chache;

using Mapster;

using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Dynamic.Core;
using System.Linq.Expressions;
using System.Threading.Tasks;


namespace AxialSystem.Covaluse.Services
{


    public class NotificationTypeService
    {
        private readonly ApplicationDbContext _context;
        private readonly ILogger<NotificationTypeService> _logger;
        private readonly ICacheService _cacheService;

        public NotificationTypeService(ApplicationDbContext context, ILogger<NotificationTypeService> logger, ICacheService cacheService)
        {
            _context = context;
            _logger = logger;
            _cacheService = cacheService;
        }



        public async Task<ResultViewModel<List<NotificationTypeReadModel>>> All(QueryViewModel query)
        {
            var cacheKey = $"NotificationType:GetAll_{query.GetHashCode()}".GetHashCode().ToString();
            try
            {
                var cached = _cacheService.Get<ResultViewModel<List<NotificationTypeReadModel>>>(cacheKey);

                if (cached != null)
                {
                    return cached;
                }


                var data = _context.NotificationTypes.AsQueryable();
                if (!string.IsNullOrEmpty(query.Filter))
                {
                    data = data.Where(query.Filter);
                }

                query.Order = string.IsNullOrEmpty(query.Order) ? "Id Desc" : query.Order;
                data = data.OrderBy(query.Order);

                var page = query.PageNumber <= 0 ? data :
                           data.Skip((query.PageNumber - 1) * query.PageSize)
                           .Take(query.PageSize);

                var count = await data.CountAsync();
                var list = await page.ToListAsync();

                var result = new ResultViewModel<List<NotificationTypeReadModel>>
                {
                    IsSuccess = true,
                    StatusCode = 200,
                    Messages = { "data loaded successfully" },
                    Total = count,
                    PageSize = query.PageSize,
                    PageNumber = query.PageNumber,
                    Filter = query.Filter,
                    Data = list.Adapt<List<NotificationTypeReadModel>>()
                };

                _cacheService.Set(cacheKey, result);

                return result;
            }
            catch (Exception ex)
            {

                _logger.LogError(ex.Message, ex);
                return new ResultViewModel<List<NotificationTypeReadModel>>
                {
                    IsSuccess = false,
                    StatusCode = 500,
                    Messages = { "error while reading data." },
                    Filter = query.Filter,
                    PageNumber = query.PageNumber,
                    PageSize = query.PageSize,
                };
            }
        }

        public async Task<ResultViewModel<NotificationTypeModifyModel>> Find(Expression<Func<NotificationType, bool>> predicate)
        {
            var cacheKey = $"NotificationType:Find_{predicate.Body.GetHashCode()}".GetHashCode().ToString();
            try
            {
                var cached = _cacheService.Get<ResultViewModel<NotificationTypeModifyModel>>(cacheKey);

                if (cached != null)
                {
                    return cached;
                }

                var data = await _context.NotificationTypes.SingleOrDefaultAsync(predicate);
                var result = new ResultViewModel<NotificationTypeModifyModel>
                {
                    IsSuccess = true,
                    StatusCode = 200,
                    Messages = { "data loaded successfully" },
                    Data = data.Adapt<NotificationTypeModifyModel>()
                };

                _cacheService.Set(cacheKey, result);

                return result;
            }
            catch (Exception ex)
            {

                _logger.LogError(ex.Message, ex);
                return new ResultViewModel<NotificationTypeModifyModel>
                {
                    IsSuccess = false,
                    StatusCode = 500,
                    Messages = { "error while loading data" },
                };
            }
        }
        public async Task<ResultViewModel<NotificationTypeModifyModel>> Find(int id)
        {
            var cacheKey = $"NotificationType:Find_{id}".GetHashCode().ToString();
            try
            {

                var cached = _cacheService.Get<ResultViewModel<NotificationTypeModifyModel>>(cacheKey);

                if (cached != null)
                {
                    return cached;
                }

                var data = await _context.NotificationTypes.FindAsync(id);
                var result = new ResultViewModel<NotificationTypeModifyModel>
                {
                    IsSuccess = true,
                    StatusCode = 200,
                    Messages = { "data loaded successfully" },
                    Data = data.Adapt<NotificationTypeModifyModel>()
                };

                _cacheService.Set($"NotificationType:Find_{id}", result);

                return result;
            }
            catch (Exception ex)
            {

                _logger.LogError(ex.Message, ex);
                return new ResultViewModel<NotificationTypeModifyModel>
                {
                    IsSuccess = false,
                    StatusCode = 500,
                    Messages = { "error while loading data" },
                };
            }
        }


        public async Task<AcknowledgeViewModel> Add(NotificationTypeModifyModel dto)
        {
            try
            {
                var record = new NotificationType(dto);
                var entity = await _context.NotificationTypes.AddAsync(record);
                _ = await _context.SaveChangesAsync();

                _cacheService.Clear("NotificationType:");
                return new ()
                {

                    IsSuccess = true,
                    StatusCode = 200,
                    Messages = { "data saved successfully" },
                };

            }
            catch (Exception ex)
            {

                _logger.LogError(ex.Message, ex);
                return new ()
                {
                    IsSuccess = false,
                    StatusCode = 500,
                    Messages = { "error while saving data" },
                };
            }
        }

        public async Task<AcknowledgeViewModel> Update(NotificationTypeModifyModel dto)
        {
            try
            {
                var record = await _context.NotificationTypes.FindAsync(dto.Id);
                if (record == null)
                {
                    var exp = new KeyNotFoundException($"item number {dto.Id} does not Exist");
                    _logger.LogError(exp.Message, exp);
                    return new ()
                    {
                        IsSuccess = false,
                        StatusCode = 500,
                        Messages = { "Item Not Found" },
                    };
                }


                var entity = record.Update(dto);

                _ = await _context.SaveChangesAsync();

                _cacheService.Clear("NotificationType:");

                return new ()
                {
                    IsSuccess = true,
                    StatusCode = 200,
                    Messages = { "data modified successfully" }
                };

            }
            catch (Exception ex)
            {

                _logger.LogError(ex.Message, ex);
                return new ()
                {
                    IsSuccess = false,
                    StatusCode = 500,
                    Messages = { "error while saving data" },
                };
            }
        }

        public async Task<AcknowledgeViewModel> Delete(int id)
        {
            try
            {
                var record = await _context.NotificationTypes.FindAsync(id);
                if (record == null)
                {
                    var exp = new KeyNotFoundException($"item number {id} does not Exist");
                    _logger.LogError(exp.Message, exp);
                    return new ()
                    {
                        IsSuccess = false,
                        StatusCode = 500,
                        Messages = { "Item Not Found" },
                    };
                }
                var entity = record.Delete();
                _context.Entry(entity).State = EntityState.Deleted;
                _ = await _context.SaveChangesAsync();

                _cacheService.Clear("NotificationType:");

                return new ()
                {
                    IsSuccess = true,
                    StatusCode = 200,
                    Messages = { "data removed successfully" }
                };

            }
            catch (Exception ex)
            {

                _logger.LogError(ex.Message, ex);
                return new ()
                {
                    IsSuccess = false,
                    StatusCode = 500,
                    Messages = { "error while removing data" },
                };
            }
        }


    }
}