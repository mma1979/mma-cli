using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.DependencyInjection;

using AxialSystem.Covaluse.ProxyServices;
using AxialSystem.Covaluse.Services.Chache;

using AxialSystem.Covaluse.Services.Settings;

namespace AxialSystem.Covaluse.Services
{
    public static class ServicesDI
    {
        public static IServiceCollection AddServices(this IServiceCollection services)
        {
            
            services.AddStripeService();
            services.AddTransient<IMemoryCache, MemoryCache>();
            services.AddRedisCacheService();


            services.AddTransient<LocalizationSerivce>();
            services.AddTransient<SysSettingsService>();
            services.AddTransient<AccountService>();
            services.AddTransient<FeatureService>();
            services.AddTransient<PermissionService>();

            services.AddTransient<EmailService>();
            services.AddTransient<RoleService>();
            services.AddTransient<AttachmentsService>();

            services.AddTransient<FeatureService>();
            services.AddScoped<PermissionService>();


            return services;
        }
    }
}
