﻿using AxialSystem.Covaluse.ProxyServices;

using Microsoft.Extensions.Configuration;

using NUnit.Framework;

using System;

namespace AxialSystem.Covaluse.Tests
{
    public class StripePaymentServiceTests
    {
        private StripePaymentService service;
        IConfigurationSection config;

        [OneTimeSetUp]
        public void SetupOnce()
        {

            var env = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT") ?? "Development";
            var builder = new ConfigurationBuilder()
                .AddJsonFile("appsettings.json", optional: true, reloadOnChange: true)
                   .AddJsonFile($"appsettings.{env}.json", optional: true, reloadOnChange: true);

            var Configuration = builder.Build();

            config = Configuration.GetSection("Stripe");

        }

        [SetUp]
        public void Setup()
        {

            service = new StripePaymentService(config);
        }

        //[Test]
        //public void Test_Payment_Returns_True()
        //{

        //    var result = service.Payment();
        //    Assert.IsTrue(result);
        //}

        //[Test]
        //public void Test_Payment_Returns_False()
        //{

        //    var result = service.Payment();
        //    Assert.IsFalse(result);
        //}

        [Test]
        public void Test_Refound_Retirns_True()
        {

            var result = service.Refound();
            Assert.IsTrue(result);
        }

        [Test]
        public void Test_Refound_Retirns_False()
        {

            var result = service.Refound();
            Assert.IsFalse(result);
        }
    }
}
