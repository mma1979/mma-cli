using System;
using System.Net;
using System.Net.Mail;
using System.Text;
using Asp.Versioning;
using AxialSystem.Covaluse.AppApi.Infrastrcture.Middlewares;
using AxialSystem.Covaluse.Common.Helpers;
using AxialSystem.Covaluse.Common.Models;
using AxialSystem.Covaluse.Core.Database.Identity;
using AxialSystem.Covaluse.Core.Models;
using AxialSystem.Covaluse.EntityFramework;
using AxialSystem.Covaluse.EntityFramework.Infrastrcture;
using AxialSystem.Covaluse.EntityFramework.Infrastrcture.Interceptors;
using AxialSystem.Covaluse.Services;
using Hangfire;
using Hangfire.SqlServer;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using Polly;
using Polly.Retry;
using Serilog;
using Serilog.Sinks.MSSqlServer;
using Redis = StackExchange.Redis;

namespace AxialSystem.Covaluse.AppApi.Infrastrcture.Extensions;

public static class WebApplicationBuilderExtensions
{

    public static WebApplicationBuilder ConfigureAppConfiguration(this WebApplicationBuilder builder)
    {
        builder.Configuration
.AddJsonFile("appsettings.json", optional: true, reloadOnChange: true)
            .AddJsonFile($"appsettings.{builder.Environment.EnvironmentName.Trim(' ')}.json", optional: true, reloadOnChange: true)
            .AddEnvironmentVariables();

        return builder;
    }

    public static WebApplicationBuilder ConfigureSeriLog(this WebApplicationBuilder builder)
    {
        builder.Host.UseSerilog((context, config) =>
        {
            config.Enrich.FromLogContext()
            .Enrich.WithMachineName()
            .WriteTo.Console()
            .WriteTo.MSSqlServer(
                connectionString: context.Configuration.GetConnectionString("LogsConnection"),
                sinkOptions: new MSSqlServerSinkOptions { TableName = "AppLogs", AutoCreateSqlTable = true }
                    )

                .Enrich.WithProperty("Environment", context.HostingEnvironment.EnvironmentName)
                .Enrich.WithProperty("ApplicationName", context.Configuration["Serilog:ApplicationName"])
                .Enrich.WithEnvironmentUserName()
                .ReadFrom.Configuration(context.Configuration);
        });

        return builder;
    }


    public static WebApplicationBuilder ConfigureStronglyTypedSettings(this WebApplicationBuilder builder)
    {

        // configure strongly typed settings objects
        IConfigurationSection appSettingsSection = builder.Configuration.GetSection("AppSettings");
        builder.Services.Configure<AppSettings>(appSettingsSection);
        return builder;
    }

    public static WebApplicationBuilder ConfigureAllowedServices(this WebApplicationBuilder builder)
    {
        // Add services to the container.

        builder.Services.AddMvc().AddNewtonsoftJson(options =>
        {
            //options.SerializerSettings.ContractResolver = new DefaultContractResolver();
            options.SerializerSettings.ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore;
        });
        builder.Services.AddControllers().AddNewtonsoftJson(options =>
        {
            //options.SerializerSettings.ContractResolver = new DefaultContractResolver();
            options.SerializerSettings.ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore;
        });
        builder.Services.AddLogging();
        builder.Services.AddHttpContextAccessor();
        builder.Services.AddSignalR();
        builder.Services.AddExceptionHandler<GlobalExceptionHandler>();
        builder.Services.AddProblemDetails();

        builder.Services.AddSysSettingsHelper();
        builder.Services.AddTransient<AppApi.Services.Translator>();
       
        builder.Services.AddTransient<RequestSanitizationMiddleware>();
        builder.Services.AddTransient<FeatureService>();
        builder.Services.AddScoped<PermissionService>();
        builder.Services.AddSingleton<CurrentUserService>();
        builder.Services.AddSingleton<SoftDeleteInterceptor>();
        builder.Services.AddSingleton<AuditUpdateInterceptor>();
        builder.Services.AddSingleton<AuditCreateInerceptor>();
        
        return builder;
    }

    public static WebApplicationBuilder ConfigureApiVersioning(this WebApplicationBuilder builder)
    {

        #region API Versioning
        builder.Services.AddApiVersioning(c =>
        {
            c.DefaultApiVersion = new ApiVersion(1, 0);
            c.AssumeDefaultVersionWhenUnspecified = true;
            c.ReportApiVersions = true;
            c.ApiVersionReader = new UrlSegmentApiVersionReader();
        });
        #endregion
        return builder;
    }

    public static WebApplicationBuilder ConfigureDataAccess(this WebApplicationBuilder builder)
    {

        #region  For Entity Framework
        builder.Services.AddDbContext<AuthenticationDbContext>((serviceProvider, options) =>
        options.UseSqlServer(builder.Configuration.GetConnectionString("AuthenticationConnection"))
        .AddInterceptors(
            serviceProvider.GetRequiredService<SoftDeleteInterceptor>(),
            serviceProvider.GetRequiredService<AuditUpdateInterceptor>(),
            serviceProvider.GetRequiredService<AuditCreateInerceptor>()
        ));

        builder.Services.AddDbContext<ApplicationDbContext>((serviceProvider, options) =>
        options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection"))
        .AddInterceptors(
            serviceProvider.GetRequiredService<SoftDeleteInterceptor>(),
            serviceProvider.GetRequiredService<AuditUpdateInterceptor>(),
            serviceProvider.GetRequiredService<AuditCreateInerceptor>()
        ));

        builder.Services.AddDbContext<LoggingDbContext>(options => options.UseSqlServer(builder.Configuration.GetConnectionString("LogsConnection")));

        builder.Services.AddDbContext<LocalizationDbContext>(options => options.UseSqlite(builder.Configuration.GetConnectionString("LocalizationConnection")));
        #endregion
        return builder;
    }

    public static WebApplicationBuilder ConfigureJwtAuthentication(this WebApplicationBuilder builder)
    {

        #region Authentication & JWT

        builder.Services.Configure<JwtConfig>(builder.Configuration.GetSection("JWT"));
        // add validation paramter as singletone so that we can use it across the appications
        TokenValidationParameters tokenValidationParameters = new()
        {
            IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(builder.Configuration["JWT:Secret"])),
            ValidateIssuerSigningKey = true,
            ValidateLifetime = true,
            ValidateIssuer = false,
            ValidateAudience = false,
            ValidAudience = builder.Configuration["JWT:ValidAudience"],
            ValidIssuer = builder.Configuration["JWT:ValidIssuer"],
            RequireExpirationTime = false,
            // Allow to use seconds for expiration of token
            // Required only when token lifetime less than 5 minutes
            // THIS ONE
            ClockSkew = TimeSpan.Zero
        };

        builder.Services.AddSingleton(tokenValidationParameters);

        // Adding Authentication
        builder.Services.AddAuthentication(options =>
        {
            options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
            options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
            options.DefaultScheme = JwtBearerDefaults.AuthenticationScheme;
        })
        // Adding Jwt Bearer
        .AddJwtBearer(options =>
        {
            options.SaveToken = true;
            options.RequireHttpsMetadata = false;
            options.TokenValidationParameters = tokenValidationParameters;
        });

        // For Identity
        builder.Services.AddIdentity<AppUser, AppRole>(options => options.SignIn.RequireConfirmedAccount = true)
            .AddEntityFrameworkStores<AuthenticationDbContext>()
            .AddDefaultTokenProviders();



        #endregion
        return builder;
    }

    public static WebApplicationBuilder ConfigureRedisCache(this WebApplicationBuilder builder)
    {

        #region Redis Cache

        builder.Services.AddStackExchangeRedisCache(options =>
        {
            options.Configuration = $"{builder.Configuration.GetValue<string>("Redis:Server")}:{builder.Configuration.GetValue<int>("Redis:Port")}";
            options.ConfigurationOptions = Redis.ConfigurationOptions.Parse(options.Configuration);
            options.ConfigurationOptions.Password = builder.Configuration.GetValue<string>("Redis:Password");



        });



        #endregion
        return builder;
    }

    public static WebApplicationBuilder ConfigureSwagger(this WebApplicationBuilder builder)
    {

        #region Swagger
        builder.Services.AddSwaggerGen(c =>
        {
            c.SwaggerDoc("v1", new OpenApiInfo { Title = "MySolutionName.AppApi", Version = "v1" });
            c.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
            {
                Name = "Authorization",
                Type = SecuritySchemeType.ApiKey,
                Scheme = "Bearer",
                BearerFormat = "JWT",
                In = ParameterLocation.Header,
                Description = "JWT Authorization header using the Bearer scheme."
            });
            c.AddSecurityRequirement(new OpenApiSecurityRequirement
                {
                    {
                        new OpenApiSecurityScheme
                        {
                            Reference = new OpenApiReference
                            {
                                Type = ReferenceType.SecurityScheme,
                                Id = "Bearer"
                            }
                        },
                        new string[] {}

                    }
                });
        });
        #endregion
        return builder;
    }

    public static WebApplicationBuilder ConfigurePollyResilience(this WebApplicationBuilder builder)
    {

        #region Polly resilience 
        builder.Services.AddResiliencePipeline("proxy-services", pipelineBuilder =>
        {
            pipelineBuilder
                .AddRetry(new RetryStrategyOptions()
                {
                    MaxRetryAttempts = builder.Configuration.GetValue<int>("Polly:MaxRetryAttempts"),
                    Delay = TimeSpan.FromSeconds(builder.Configuration.GetValue<int>("Polly:Delay"))
                })
                .AddTimeout(TimeSpan.FromSeconds(builder.Configuration.GetValue<int>("Polly:Timeout")));
        });

        #endregion
        return builder;
    }
    
    public static WebApplicationBuilder ConfigureFluentEmail(this WebApplicationBuilder builder)
    {

        builder.Services
      .AddFluentEmail(builder.Configuration.GetValue<string>("SMTP:Email"))
      .AddRazorRenderer()
      .AddSmtpSender(new SmtpClient()
      {
          Host = builder.Configuration.GetValue<string>("SMTP:SmtpServer"),
          Port = builder.Configuration.GetValue<int>("SMTP:Port"),
          Credentials = new NetworkCredential(builder.Configuration.GetValue<string>("SMTP:Email"), builder.Configuration.GetValue<string>("SMTP:Password")),
          EnableSsl = builder.Configuration.GetValue<bool>("SMTP:EnableSsl")
      });
        return builder;
    }

    public static WebApplicationBuilder ConfigureHangfire(this WebApplicationBuilder builder)
    {
        builder.Services.AddHangfire(config => config
           .SetDataCompatibilityLevel(CompatibilityLevel.Version_170)
           .UseSimpleAssemblyNameTypeSerializer()
           .UseRecommendedSerializerSettings()
           .UseSqlServerStorage(builder.Configuration.GetConnectionString("HangfireConnection"),
               new SqlServerStorageOptions
               {
                   CommandBatchMaxTimeout = TimeSpan.FromMinutes(5),
                   SlidingInvisibilityTimeout = TimeSpan.FromMinutes(5),
                   QueuePollInterval = TimeSpan.Zero,
                   UseRecommendedIsolationLevel = true,
                   DisableGlobalLocks = true
               })
           .WithJobExpirationTimeout(TimeSpan.FromHours(1)));
        return builder;
    }

    public static WebApplicationBuilder ConfigureHealthChecks(this WebApplicationBuilder builder)
    {
        builder.Services.AddHealthChecks()
   .AddSqlServer(builder.Configuration.GetConnectionString("DefaultConnection"));
        return builder;
    }
}