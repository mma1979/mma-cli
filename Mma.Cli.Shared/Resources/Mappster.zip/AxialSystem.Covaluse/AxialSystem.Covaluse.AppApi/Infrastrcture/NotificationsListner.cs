namespace AxialSystem.Covaluse.AppApi.Infrastrcture
{
    public static class NotificationsListner
    {
    }
}
