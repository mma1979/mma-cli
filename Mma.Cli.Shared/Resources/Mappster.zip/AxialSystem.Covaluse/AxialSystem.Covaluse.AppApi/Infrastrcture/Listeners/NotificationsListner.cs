namespace AxialSystem.Covaluse.AppApi.Infrastrcture.Listeners
{
    public static class NotificationsListner
    {
    }
}
