using System.Threading.Tasks;
using AxialSystem.Covaluse.AppApi.Infrastrcture.Extensions;
using Microsoft.AspNetCore.Http;
using Serilog.Context;

namespace AxialSystem.Covaluse.AppApi.Infrastrcture.Middlewares
{
    public class RequestLogContextMiddleware
    {
        private readonly RequestDelegate _next;

        public RequestLogContextMiddleware(RequestDelegate next)
        {
            _next = next;
        }

        public Task Invoke(HttpContext context)
        {
            using (LogContext.PushProperty("CorrelationId", context.GetCorrelationId()))
            {
                return _next.Invoke(context);
            }
        }
    }
}
