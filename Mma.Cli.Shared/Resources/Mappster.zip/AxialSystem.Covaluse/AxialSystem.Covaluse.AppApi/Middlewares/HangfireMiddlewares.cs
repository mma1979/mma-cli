using Hangfire;
using Hangfire.Dashboard.BasicAuthorization;
using Hangfire.SqlServer;

using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

using System;

namespace AxialSystem.Covaluse.AppApi.Middlewares;

public static class HangfireMiddlewares
{
    public static IServiceCollection ConnectHangfire(this IServiceCollection services, IConfiguration configuration)
    {
        services.AddHangfire(config => config
           .SetDataCompatibilityLevel(CompatibilityLevel.Version_170)
           .UseSimpleAssemblyNameTypeSerializer()
           .UseRecommendedSerializerSettings()
           .UseSqlServerStorage(configuration.GetConnectionString("HangfireConnection"),
               new SqlServerStorageOptions
               {
                   CommandBatchMaxTimeout = TimeSpan.FromMinutes(5),
                   SlidingInvisibilityTimeout = TimeSpan.FromMinutes(5),
                   QueuePollInterval = TimeSpan.Zero,
                   UseRecommendedIsolationLevel = true,
                   DisableGlobalLocks = true
               })
           .WithJobExpirationTimeout(TimeSpan.FromHours(1)));
        return services;
    }

    public static IApplicationBuilder UseSecuredHangfireDashboard(this IApplicationBuilder app, IConfiguration configuration)
    {
        var endpoint = configuration.GetValue<string>("HangFireDashboard:Endpoint");
        var username = configuration.GetValue<string>("HangFireDashboard:Username");
        var password = configuration.GetValue<string>("HangFireDashboard:Password");
        var requireSsl = configuration.GetValue<bool>("HangFireDashboard:RequireSsl");
        app.UseHangfireDashboard(endpoint, new DashboardOptions
        {
            Authorization = [ new BasicAuthAuthorizationFilter(new BasicAuthAuthorizationFilterOptions
            {
                RequireSsl = requireSsl,
                SslRedirect = requireSsl,
                LoginCaseSensitive = true,
                Users =
                [
                    new BasicAuthAuthorizationUser
                    {
                        Login = username,
                        PasswordClear =  password
                    }
                ]
             })]
        });

        return app;
    }
}
