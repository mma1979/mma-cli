using Microsoft.AspNetCore.SignalR;

namespace AxialSystem.Covaluse.AppApi.Hubs
{
    public class RabbitMQNotificationsHub:Hub
    {
    }
}
