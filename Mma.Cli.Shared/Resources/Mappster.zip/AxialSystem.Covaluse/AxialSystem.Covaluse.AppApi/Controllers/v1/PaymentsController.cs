﻿using AxialSystem.Covaluse.Core.Models;
using AxialSystem.Covaluse.ProxyServices;

using Microsoft.AspNetCore.Mvc;

namespace AxialSystem.Covaluse.AppApi.Controllers.v1
{
    [Route("api/[controller]")]
    [ApiController]
    public class PaymentsController : ControllerBase
    {
        private readonly StripePaymentService _stripeService;

        public PaymentsController(StripePaymentService stripeService)
        {
            _stripeService = stripeService;
        }




        [HttpPost("create-payment-intent")]
        public IActionResult Create([FromBody] PaymentIntentCreateRequest request)
        {
            var paymentIntent = _stripeService.Payment(request);

            return Ok(new { clientSecret = paymentIntent.ClientSecret });
        }
    }
}
