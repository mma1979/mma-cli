﻿using AxialSystem.Covaluse.ProxyServices;

using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;

namespace AxialSystem.Covaluse.AppApi.Controllers.WebView
{
    [Route("[controller]")]
    public class PaymentController : Controller
    {
        private readonly StripePaymentService _stripeService;
        private readonly IConfiguration _configuration;

        public PaymentController(StripePaymentService stripeService, IConfiguration configuration)
        {
            _stripeService = stripeService;
            _configuration = configuration;
        }

        [HttpGet]
        public IActionResult Index([FromQuery] double? amount, [FromQuery] string currency)
        {
            ViewBag.PK = _stripeService.PublishableKey;
            ViewBag.Amount = amount;
            ViewBag.Currency = currency;
            ViewBag.CallbackUrl = _configuration.GetValue<string>("Stripe:CallbackUrl");
            return View();
        }

        [HttpGet("Complete")]
        public IActionResult Complete([FromQuery] string payment_intent, [FromQuery] string payment_intent_client_secret, [FromQuery] string redirect_status)
        {

            ViewBag.Status = redirect_status;
            return View();
        }
    }
}
