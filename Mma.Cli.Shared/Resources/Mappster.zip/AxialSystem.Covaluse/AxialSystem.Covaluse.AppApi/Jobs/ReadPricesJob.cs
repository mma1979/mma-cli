﻿namespace AxialSystem.Covaluse.AppApi.Jobs
{
    public class ReadPricesJob
    {
    }
}
