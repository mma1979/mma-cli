using AxialSystem.Covaluse.AppApi.Infrastrcture.Extensions;
using AxialSystem.Covaluse.AppApi.Infrastrcture.Middlewares;
using AxialSystem.Covaluse.Services;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.Hosting;
using Serilog;

var builder = WebApplication.CreateBuilder(args);

builder.ConfigureAppConfiguration()
    .ConfigureSeriLog()
    .ConfigureStronglyTypedSettings()
    .ConfigureAllowedServices()
    .ConfigureApiVersioning()
    .ConfigureDataAccess()
    .ConfigureJwtAuthentication()
    .ConfigureRedisCache()
    .ConfigureSwagger()
    .ConfigurePollyResilience()
    .ConfigureFluentEmail()
    .ConfigureHangfire()
    .ConfigureHealthChecks()
    .AddApplicationServices();


var app = builder.Build();

// Configure the HTTP request pipeline.


app.UseDevelopment(!builder.Environment.IsProduction())
    .UseMiddleware<RequestSanitizationMiddleware>()
    .UseHttpsRedirection()
    .UseRouting()
    .UseCorsPolicy(builder.Configuration["AllowedOrigins"], builder.Environment)
    .UseSerilogRequestLogging()
    .UseAuthentication() 
    .UseAuthorization()
    .UseMiddleware<JwtAuthenticationMiddleware>()
    .UseMiddleware<PermissionMiddleware>()
    .UseRemoveHeaders("Server", "X-Powered-By");


app.UseMapRoutes();

app.Run();