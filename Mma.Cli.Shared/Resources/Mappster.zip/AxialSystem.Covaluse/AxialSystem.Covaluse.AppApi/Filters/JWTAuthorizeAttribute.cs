﻿using AxialSystem.Covaluse.Core.Consts;

using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;

using System;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;

namespace AxialSystem.Covaluse.AppApi.Filters
{
    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Method, AllowMultiple = true, Inherited = true)]
    public class JWTAuthorizeAttribute : Attribute, IActionFilter
    {
        public string[] AllowedRoles { get; private set; }
        public JWTAuthorizeAttribute() { }

        public JWTAuthorizeAttribute(params string[] roles)
        {
            AllowedRoles = roles;
        }

        public void OnActionExecuting(ActionExecutingContext context)
        {
            if (context.ActionDescriptor.EndpointMetadata
               .Any(e => e is AllowAnonymousAttribute))
            {
                return;
            }

            var token = context.HttpContext.Request.Headers["Authorization"].ToString();
            if (string.IsNullOrEmpty(token) || string.IsNullOrWhiteSpace(token))
            {
                context.Result = new UnauthorizedObjectResult("Unauthorized");
                return;
            }

            var splits = token.Split(' ');
            if (splits.Length < 2)
            {
                context.Result = new UnauthorizedObjectResult("Unauthorized");
                return;
            }
            var handler = new JwtSecurityTokenHandler();
            JwtSecurityToken tokenInfo;

            try
            {
                tokenInfo = handler.ReadJwtToken(splits[1]);
            }
            catch (Exception)
            {

                context.Result = new UnauthorizedObjectResult("Unauthorized");
                return;
            }

            // Expiration Handle
            long.TryParse(tokenInfo.Claims.FirstOrDefault(c => c.Type == "exp")?.Value, out var exp);

            var now = (long)(DateTime.UtcNow.Subtract(new DateTime(1970, 1, 1))).TotalSeconds;

            if (exp <= now)
            {
                context.Result = new UnauthorizedObjectResult("Unauthorized");
                return;
            }



            var roles = tokenInfo.Claims
                .Where(c => c.Type == "role")
                .Select(e => e.Value)
                .ToList();

            if (!roles.Any())
            {
                context.Result = new UnauthorizedObjectResult("Unauthorized");
                return;
            }

            // is super admin or in AllowedRoles not set
            if (roles.Contains(Roles.ADMIN) || AllowedRoles == null)
            {
                return;
            }


            var isAllowed = AllowedRoles.Length > 0 && roles.All(e => AllowedRoles.Contains(e));



            if (!isAllowed)
            {
                context.Result = new UnauthorizedObjectResult("Unauthorized");
                return;
            }




        }

        public void OnActionExecuted(ActionExecutedContext context)
        {

        }
    }
}
