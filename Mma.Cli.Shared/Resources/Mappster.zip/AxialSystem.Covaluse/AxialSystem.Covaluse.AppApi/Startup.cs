﻿using AxialSystem.Covaluse.Common.Helpers;
using AxialSystem.Covaluse.Common.Models;
using AxialSystem.Covaluse.Core.Database.Identity;
using AxialSystem.Covaluse.EntityFramework;
using AxialSystem.Covaluse.ProxyServices;
using AxialSystem.Covaluse.Services;
using AxialSystem.Covaluse.Services.Chache;
using AxialSystem.Covaluse.Services.Settings;

using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Versioning;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;

using Serilog;

using Swashbuckle.AspNetCore.SwaggerUI;

using System;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Text;

using static AxialSystem.Covaluse.Core.Models.AccountModels;

using Redis = StackExchange.Redis;

namespace AxialSystem.Covaluse.AppApi
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        private const string _defaultCorsPolicyName = "localhost";

        public void ConfigureServices(IServiceCollection services)
        {
            // configure strongly typed settings objects
            IConfigurationSection appSettingsSection = Configuration.GetSection("AppSettings");
            services.Configure<AppSettings>(appSettingsSection);

            services.AddMvc();
            services.AddControllers();
            services.AddLogging();
            services.AddHttpContextAccessor();

            #region API Versioning
            services.AddApiVersioning(c =>
            {
                c.DefaultApiVersion = new ApiVersion(1, 0);
                c.AssumeDefaultVersionWhenUnspecified = true;
                c.ReportApiVersions = true;
                c.ApiVersionReader = new UrlSegmentApiVersionReader();
            });
            #endregion


            #region  For Entity Framework
            services.AddDbContext<ApplicationDbContext>(options => options.UseSqlServer(Configuration.GetConnectionString("DefaultConnection")));

            services.AddDbContext<LoggingDbContext>(options => options.UseSqlServer(Configuration.GetConnectionString("LogsConnection")));

            services.AddDbContext<LocalizationDbContext>(options => options.UseSqlite(Configuration.GetConnectionString("LocalizationConnection")));
            #endregion

            #region Authentication & JWT

            services.Configure<JwtConfig>(Configuration.GetSection("JWT"));
            // add validation paramter as singletone so that we can use it across the appications
            TokenValidationParameters tokenValidationParameters = new()
            {
                IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(Configuration["JWT:Secret"])),
                ValidateIssuerSigningKey = true,
                ValidateLifetime = true,
                ValidateIssuer = true,
                ValidateAudience = true,
                ValidAudience = Configuration["JWT:ValidAudience"],
                ValidIssuer = Configuration["JWT:ValidIssuer"],
                RequireExpirationTime = false,
                // Allow to use seconds for expiration of token
                // Required only when token lifetime less than 5 minutes
                // THIS ONE
                ClockSkew = TimeSpan.Zero

            };

            services.AddSingleton(tokenValidationParameters);

            // Adding Authentication
            services.AddAuthentication(options =>
            {
                options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
                options.DefaultScheme = JwtBearerDefaults.AuthenticationScheme;
            })
            // Adding Jwt Bearer
            .AddJwtBearer(options =>
            {
                options.SaveToken = true;
                options.RequireHttpsMetadata = false;
                options.TokenValidationParameters = tokenValidationParameters;
            });

            // For Identity
            services.AddIdentity<AppUser, Role>(options => options.SignIn.RequireConfirmedAccount = true)
                .AddEntityFrameworkStores<ApplicationDbContext>()
                .AddDefaultTokenProviders();



            #endregion

            #region Redis Cache

            services.AddStackExchangeRedisCache(options =>
            {
                options.Configuration = $"{Configuration.GetValue<string>("Redis:Server")}:{Configuration.GetValue<int>("Redis:Port")}";
                options.ConfigurationOptions = Redis.ConfigurationOptions.Parse(options.Configuration);
                options.ConfigurationOptions.Password = Configuration.GetValue<string>("Redis:Password");



            });



            #endregion

            #region Swagger
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new OpenApiInfo { Title = "AxialSystem.Covaluse.AppApi", Version = "v1" });
            });
            #endregion


            services.AddSysSettingsHelper();
            services.AddTranslator();
            services.AddStripeService();
            services.AddTransient<IMemoryCache, MemoryCache>();
            services.AddRedisCacheService();


            services.AddTransient<LocalizationSerivce>();
            services.AddTransient<SysSettingsService>();
            services.AddTransient<AccountService>();

            services.AddTransient<EmailService>();


            services
                 .AddFluentEmail(Configuration.GetValue<string>("SMTP:Email"))
                 .AddRazorRenderer()
                 .AddSmtpSender(new SmtpClient()
                 {
                     Host = Configuration.GetValue<string>("SMTP:SmtpServer"),
                     Port = Configuration.GetValue<int>("SMTP:Port"),
                     Credentials = new NetworkCredential(Configuration.GetValue<string>("SMTP:Email"), Configuration.GetValue<string>("SMTP:Password")),
                     EnableSsl = Configuration.GetValue<bool>("SMTP:EnableSsl")
                 });



        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (!env.IsProduction())
            {
                app.UseDeveloperExceptionPage();
                app.UseSwagger();
                app.UseSwaggerUI(c =>
                {
                    c.DefaultModelRendering(ModelRendering.Model);
                    c.DefaultModelExpandDepth(1);
                });
            }

            app.Use(async (ctx, next) =>
            {

                ctx.Response.Headers.Remove("Server");
                ctx.Response.Headers.Remove("x-powered-by");

                await next();

            });

            var Orgins = Configuration["AppSettings:Orgins"]
               .Split(',')
               .Select(s => s.Trim());

            app.UseCors(opt =>
                opt.AllowAnyHeader()
                .AllowAnyMethod()
                .AllowCredentials()
                .SetIsOriginAllowed(origin =>
                {
                    if (string.IsNullOrWhiteSpace(origin)) return false;
                    // Only add this to allow testing with localhost, remove this line in production!  
                    if (origin.ToLower().Contains("localhost")) return true;
                    if (env.IsDevelopment()) return true;

                    // Insert your production domain here.  
                    var allowedOrigin = Orgins.Any(x => origin.ToLower().StartsWith(x.ToLower()));
                    return allowedOrigin;
                }));


            app.UseHttpsRedirection();

            app.UseRouting();

            //app.UseHealthAndMetricsMiddleware();
            //app.Use(next => new RequestLogContextMiddleware(next).Invoke(next));
            app.UseSerilogRequestLogging();

            app.UseAuthentication();
            app.UseAuthorization();


            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });


        }


    }
}
