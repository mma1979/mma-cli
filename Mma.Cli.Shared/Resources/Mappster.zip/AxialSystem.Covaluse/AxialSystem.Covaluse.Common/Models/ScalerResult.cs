﻿
namespace AxialSystem.Covaluse.Common.Models
{
    public class ScalerResult
    {
        public string Value { get; set; }
    }
}
