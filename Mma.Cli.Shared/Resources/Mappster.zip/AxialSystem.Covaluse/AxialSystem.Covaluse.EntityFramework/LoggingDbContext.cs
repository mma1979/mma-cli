﻿using AxialSystem.Covaluse.Core.Database.LogTables;

using Microsoft.EntityFrameworkCore;

namespace AxialSystem.Covaluse.EntityFramework
{
    public class LoggingDbContext : DbContext
    {

        public LoggingDbContext(DbContextOptions<LoggingDbContext> options)
            : base(options) { }


        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer("name=LogsConnection");
            }
        }

        public virtual DbSet<CovaluseLog> CovaluseLogs { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<CovaluseLog>(entity =>
            {
                entity.Property(e => e.Id)
                .HasDefaultValueSql("NEWID()");

                entity.Property(e => e.Level)
                .HasColumnType("nvarchar(128)");

                entity.Property(e => e.TimeStamp)
                .HasDefaultValueSql("GETDATE()");


            });
        }
    }
}
