using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace AxialSystem.Covaluse.EntityFramework.Migrations.LocalizationDb
{
    public partial class AddResources : Migration
    {
        protected override void Up(MigrationBuilder mb)
        {
            mb.InsertData(
                table: "Languages",
                columns: new string[] { "Id", "LanguageCode", "LanguageName" },
                values: new object[] { 1, "ar", "العربية" });
          
            mb.InsertData(
              table: "Languages",
              columns: new string[] { "Id", "LanguageCode", "LanguageName" },
              values: new object[] { 2, "en", "English" });

            mb.InsertData(
            table: "Resources",
            columns: new string[] { "Key", "Value", "LanguageId" },
            values: new object[] { "RequiredField", "هذا الحقل مطلوب",1 });

            mb.InsertData(
            table: "Resources",
            columns: new string[] { "Key", "Value", "LanguageId" },
            values: new object[] { "RequiredField", "Required field", 2 });
        }

        protected override void Down(MigrationBuilder mb)
        {
            mb.Sql("Delete Resources where Key in ('RequiredField')");

            mb.DeleteData("Languages", "Id", 1);
            mb.DeleteData("Languages", "Id", 2);

            
        }
    }
}
