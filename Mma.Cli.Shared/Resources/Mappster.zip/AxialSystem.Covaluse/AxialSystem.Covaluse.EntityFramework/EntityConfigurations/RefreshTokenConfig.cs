﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

using AxialSystem.Covaluse.Core.Database.Identity;

namespace AxialSystem.Covaluse.EntityFramework.EntityConfigurations
{
    public class RefreshTokenConfig : IEntityTypeConfiguration<RefreshToken>
    {
        private readonly string _schema;
        public RefreshTokenConfig(string schema = "dbo")
        {
            _schema = schema;
        }

       
        public void Configure(EntityTypeBuilder<RefreshToken> builder)
        {
            builder.ToTable("RefreshTokens", _schema);


            builder.HasQueryFilter(e => e.IsDeleted != true);
            builder.Property(e => e.IsDeleted).IsRequired().HasDefaultValueSql("((0))");
            builder.Property(e => e.CreatedDate).IsRequired().HasDefaultValueSql("(getdate())");
            builder.HasIndex(e => e.IsDeleted);

            builder.HasIndex(e => e.Hash);

            builder.Property(e => e.Token).HasMaxLength(2000);
            builder.Property(e => e.JwtId).HasMaxLength(1000);


        }
    }
}
