using System.Collections.Generic;
using AxialSystem.Covaluse.Core.Database.Identity;
using Mapster;

namespace AxialSystem.Covaluse.Core.Database.Identity
{
    public static partial class AppUserMapper
    {
        public static AppUserReadModel AdaptToReadModel(this AppUser p1)
        {
            return p1 == null ? null : new AppUserReadModel()
            {
                Hash = p1.Hash,
                FirstName = p1.FirstName,
                LastName = p1.LastName,
                Mobile = p1.Mobile,
                CountryCode = p1.CountryCode,
                TwoFactorMethod = p1.TwoFactorMethod,
                CreatedBy = p1.CreatedBy,
                CreatedDate = p1.CreatedDate,
                ModifiedBy = p1.ModifiedBy,
                ModifiedDate = p1.ModifiedDate,
                IsDeleted = p1.IsDeleted,
                DeletedBy = p1.DeletedBy,
                DeletedDate = p1.DeletedDate,
                MembershipType = p1.MembershipType,
                UserRoles = funcMain1(p1.UserRoles),
                UserTokens = funcMain11(p1.UserTokens),
                RefreshTokens = funcMain12(p1.RefreshTokens),
                AccessControlEntries = funcMain13(p1.AccessControlEntries),
                Id = p1.Id,
                UserName = p1.UserName,
                NormalizedUserName = p1.NormalizedUserName,
                Email = p1.Email,
                NormalizedEmail = p1.NormalizedEmail,
                EmailConfirmed = p1.EmailConfirmed,
                PasswordHash = p1.PasswordHash,
                SecurityStamp = p1.SecurityStamp,
                ConcurrencyStamp = p1.ConcurrencyStamp,
                PhoneNumber = p1.PhoneNumber,
                PhoneNumberConfirmed = p1.PhoneNumberConfirmed,
                TwoFactorEnabled = p1.TwoFactorEnabled,
                LockoutEnd = p1.LockoutEnd,
                LockoutEnabled = p1.LockoutEnabled,
                AccessFailedCount = p1.AccessFailedCount
            };
        }
        public static AppUserReadModel AdaptTo(this AppUser p23, AppUserReadModel p24)
        {
            if (p23 == null)
            {
                return null;
            }
            AppUserReadModel result = p24 ?? new AppUserReadModel();
            
            result.Hash = p23.Hash;
            result.FirstName = p23.FirstName;
            result.LastName = p23.LastName;
            result.Mobile = p23.Mobile;
            result.CountryCode = p23.CountryCode;
            result.TwoFactorMethod = p23.TwoFactorMethod;
            result.CreatedBy = p23.CreatedBy;
            result.CreatedDate = p23.CreatedDate;
            result.ModifiedBy = p23.ModifiedBy;
            result.ModifiedDate = p23.ModifiedDate;
            result.IsDeleted = p23.IsDeleted;
            result.DeletedBy = p23.DeletedBy;
            result.DeletedDate = p23.DeletedDate;
            result.MembershipType = p23.MembershipType;
            result.UserRoles = funcMain22(p23.UserRoles, result.UserRoles);
            result.UserTokens = funcMain32(p23.UserTokens, result.UserTokens);
            result.RefreshTokens = funcMain33(p23.RefreshTokens, result.RefreshTokens);
            result.AccessControlEntries = funcMain34(p23.AccessControlEntries, result.AccessControlEntries);
            result.Id = p23.Id;
            result.UserName = p23.UserName;
            result.NormalizedUserName = p23.NormalizedUserName;
            result.Email = p23.Email;
            result.NormalizedEmail = p23.NormalizedEmail;
            result.EmailConfirmed = p23.EmailConfirmed;
            result.PasswordHash = p23.PasswordHash;
            result.SecurityStamp = p23.SecurityStamp;
            result.ConcurrencyStamp = p23.ConcurrencyStamp;
            result.PhoneNumber = p23.PhoneNumber;
            result.PhoneNumberConfirmed = p23.PhoneNumberConfirmed;
            result.TwoFactorEnabled = p23.TwoFactorEnabled;
            result.LockoutEnd = p23.LockoutEnd;
            result.LockoutEnabled = p23.LockoutEnabled;
            result.AccessFailedCount = p23.AccessFailedCount;
            return result;
            
        }
        public static AppUserModifyModel AdaptToModifyModel(this AppUser p50)
        {
            return p50 == null ? null : new AppUserModifyModel()
            {
                Hash = p50.Hash,
                FirstName = p50.FirstName,
                LastName = p50.LastName,
                Mobile = p50.Mobile,
                CountryCode = p50.CountryCode,
                TwoFactorMethod = p50.TwoFactorMethod,
                CreatedBy = p50.CreatedBy,
                CreatedDate = p50.CreatedDate,
                ModifiedBy = p50.ModifiedBy,
                ModifiedDate = p50.ModifiedDate,
                IsDeleted = p50.IsDeleted,
                DeletedBy = p50.DeletedBy,
                DeletedDate = p50.DeletedDate,
                MembershipType = p50.MembershipType,
                UserRoles = funcMain43(p50.UserRoles),
                UserTokens = funcMain67(p50.UserTokens),
                RefreshTokens = funcMain90(p50.RefreshTokens),
                AccessControlEntries = funcMain113(p50.AccessControlEntries),
                Id = p50.Id,
                UserName = p50.UserName,
                NormalizedUserName = p50.NormalizedUserName,
                Email = p50.Email,
                NormalizedEmail = p50.NormalizedEmail,
                EmailConfirmed = p50.EmailConfirmed,
                PasswordHash = p50.PasswordHash,
                SecurityStamp = p50.SecurityStamp,
                ConcurrencyStamp = p50.ConcurrencyStamp,
                PhoneNumber = p50.PhoneNumber,
                PhoneNumberConfirmed = p50.PhoneNumberConfirmed,
                TwoFactorEnabled = p50.TwoFactorEnabled,
                LockoutEnd = p50.LockoutEnd,
                LockoutEnabled = p50.LockoutEnabled,
                AccessFailedCount = p50.AccessFailedCount
            };
        }
        public static AppUserModifyModel AdaptTo(this AppUser p141, AppUserModifyModel p142)
        {
            if (p141 == null)
            {
                return null;
            }
            AppUserModifyModel result = p142 ?? new AppUserModifyModel();
            
            result.Hash = p141.Hash;
            result.FirstName = p141.FirstName;
            result.LastName = p141.LastName;
            result.Mobile = p141.Mobile;
            result.CountryCode = p141.CountryCode;
            result.TwoFactorMethod = p141.TwoFactorMethod;
            result.CreatedBy = p141.CreatedBy;
            result.CreatedDate = p141.CreatedDate;
            result.ModifiedBy = p141.ModifiedBy;
            result.ModifiedDate = p141.ModifiedDate;
            result.IsDeleted = p141.IsDeleted;
            result.DeletedBy = p141.DeletedBy;
            result.DeletedDate = p141.DeletedDate;
            result.MembershipType = p141.MembershipType;
            result.UserRoles = funcMain133(p141.UserRoles, result.UserRoles);
            result.UserTokens = funcMain157(p141.UserTokens, result.UserTokens);
            result.RefreshTokens = funcMain180(p141.RefreshTokens, result.RefreshTokens);
            result.AccessControlEntries = funcMain203(p141.AccessControlEntries, result.AccessControlEntries);
            result.Id = p141.Id;
            result.UserName = p141.UserName;
            result.NormalizedUserName = p141.NormalizedUserName;
            result.Email = p141.Email;
            result.NormalizedEmail = p141.NormalizedEmail;
            result.EmailConfirmed = p141.EmailConfirmed;
            result.PasswordHash = p141.PasswordHash;
            result.SecurityStamp = p141.SecurityStamp;
            result.ConcurrencyStamp = p141.ConcurrencyStamp;
            result.PhoneNumber = p141.PhoneNumber;
            result.PhoneNumberConfirmed = p141.PhoneNumberConfirmed;
            result.TwoFactorEnabled = p141.TwoFactorEnabled;
            result.LockoutEnd = p141.LockoutEnd;
            result.LockoutEnabled = p141.LockoutEnabled;
            result.AccessFailedCount = p141.AccessFailedCount;
            return result;
            
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain1(ICollection<AppUserRole> p2)
        {
            if (p2 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p2.Count);
            
            IEnumerator<AppUserRole> enumerator = p2.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(funcMain2(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserTokenReadModel> funcMain11(ICollection<AppUserToken> p12)
        {
            if (p12 == null)
            {
                return null;
            }
            ICollection<AppUserTokenReadModel> result = new List<AppUserTokenReadModel>(p12.Count);
            
            IEnumerator<AppUserToken> enumerator = p12.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserToken item = enumerator.Current;
                result.Add(item == null ? null : new AppUserTokenReadModel()
                {
                    Token = item.Token,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    LoginProvider = item.LoginProvider,
                    Name = item.Name,
                    Value = item.Value
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRefreshTokenReadModel> funcMain12(ICollection<AppRefreshToken> p13)
        {
            if (p13 == null)
            {
                return null;
            }
            ICollection<AppRefreshTokenReadModel> result = new List<AppRefreshTokenReadModel>(p13.Count);
            
            IEnumerator<AppRefreshToken> enumerator = p13.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRefreshToken item = enumerator.Current;
                result.Add(item == null ? null : new AppRefreshTokenReadModel()
                {
                    UserId = item.UserId,
                    Token = item.Token,
                    JwtId = item.JwtId,
                    IsUsed = item.IsUsed,
                    IsRevoked = item.IsRevoked,
                    ExpiryDate = item.ExpiryDate,
                    Hash = item.Hash,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static ICollection<AppAccessControlEntryReadModel> funcMain13(ICollection<AppAccessControlEntry> p14)
        {
            if (p14 == null)
            {
                return null;
            }
            ICollection<AppAccessControlEntryReadModel> result = new List<AppAccessControlEntryReadModel>(p14.Count);
            
            IEnumerator<AppAccessControlEntry> enumerator = p14.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppAccessControlEntry item = enumerator.Current;
                result.Add(funcMain14(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain22(ICollection<AppUserRole> p25, ICollection<AppUserRoleReadModel> p26)
        {
            if (p25 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p25.Count);
            
            IEnumerator<AppUserRole> enumerator = p25.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(funcMain23(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserTokenReadModel> funcMain32(ICollection<AppUserToken> p36, ICollection<AppUserTokenReadModel> p37)
        {
            if (p36 == null)
            {
                return null;
            }
            ICollection<AppUserTokenReadModel> result = new List<AppUserTokenReadModel>(p36.Count);
            
            IEnumerator<AppUserToken> enumerator = p36.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserToken item = enumerator.Current;
                result.Add(item == null ? null : new AppUserTokenReadModel()
                {
                    Token = item.Token,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    LoginProvider = item.LoginProvider,
                    Name = item.Name,
                    Value = item.Value
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRefreshTokenReadModel> funcMain33(ICollection<AppRefreshToken> p38, ICollection<AppRefreshTokenReadModel> p39)
        {
            if (p38 == null)
            {
                return null;
            }
            ICollection<AppRefreshTokenReadModel> result = new List<AppRefreshTokenReadModel>(p38.Count);
            
            IEnumerator<AppRefreshToken> enumerator = p38.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRefreshToken item = enumerator.Current;
                result.Add(item == null ? null : new AppRefreshTokenReadModel()
                {
                    UserId = item.UserId,
                    Token = item.Token,
                    JwtId = item.JwtId,
                    IsUsed = item.IsUsed,
                    IsRevoked = item.IsRevoked,
                    ExpiryDate = item.ExpiryDate,
                    Hash = item.Hash,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static ICollection<AppAccessControlEntryReadModel> funcMain34(ICollection<AppAccessControlEntry> p40, ICollection<AppAccessControlEntryReadModel> p41)
        {
            if (p40 == null)
            {
                return null;
            }
            ICollection<AppAccessControlEntryReadModel> result = new List<AppAccessControlEntryReadModel>(p40.Count);
            
            IEnumerator<AppAccessControlEntry> enumerator = p40.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppAccessControlEntry item = enumerator.Current;
                result.Add(funcMain35(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain43(ICollection<AppUserRole> p51)
        {
            if (p51 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p51.Count);
            
            IEnumerator<AppUserRole> enumerator = p51.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(funcMain44(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserTokenReadModel> funcMain67(ICollection<AppUserToken> p75)
        {
            if (p75 == null)
            {
                return null;
            }
            ICollection<AppUserTokenReadModel> result = new List<AppUserTokenReadModel>(p75.Count);
            
            IEnumerator<AppUserToken> enumerator = p75.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserToken item = enumerator.Current;
                result.Add(funcMain68(item));
            }
            return result;
            
        }
        
        private static ICollection<AppRefreshTokenReadModel> funcMain90(ICollection<AppRefreshToken> p98)
        {
            if (p98 == null)
            {
                return null;
            }
            ICollection<AppRefreshTokenReadModel> result = new List<AppRefreshTokenReadModel>(p98.Count);
            
            IEnumerator<AppRefreshToken> enumerator = p98.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRefreshToken item = enumerator.Current;
                result.Add(funcMain91(item));
            }
            return result;
            
        }
        
        private static ICollection<AppAccessControlEntryReadModel> funcMain113(ICollection<AppAccessControlEntry> p121)
        {
            if (p121 == null)
            {
                return null;
            }
            ICollection<AppAccessControlEntryReadModel> result = new List<AppAccessControlEntryReadModel>(p121.Count);
            
            IEnumerator<AppAccessControlEntry> enumerator = p121.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppAccessControlEntry item = enumerator.Current;
                result.Add(funcMain114(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain133(ICollection<AppUserRole> p143, ICollection<AppUserRoleReadModel> p144)
        {
            if (p143 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p143.Count);
            
            IEnumerator<AppUserRole> enumerator = p143.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(funcMain134(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserTokenReadModel> funcMain157(ICollection<AppUserToken> p168, ICollection<AppUserTokenReadModel> p169)
        {
            if (p168 == null)
            {
                return null;
            }
            ICollection<AppUserTokenReadModel> result = new List<AppUserTokenReadModel>(p168.Count);
            
            IEnumerator<AppUserToken> enumerator = p168.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserToken item = enumerator.Current;
                result.Add(funcMain158(item));
            }
            return result;
            
        }
        
        private static ICollection<AppRefreshTokenReadModel> funcMain180(ICollection<AppRefreshToken> p192, ICollection<AppRefreshTokenReadModel> p193)
        {
            if (p192 == null)
            {
                return null;
            }
            ICollection<AppRefreshTokenReadModel> result = new List<AppRefreshTokenReadModel>(p192.Count);
            
            IEnumerator<AppRefreshToken> enumerator = p192.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRefreshToken item = enumerator.Current;
                result.Add(funcMain181(item));
            }
            return result;
            
        }
        
        private static ICollection<AppAccessControlEntryReadModel> funcMain203(ICollection<AppAccessControlEntry> p216, ICollection<AppAccessControlEntryReadModel> p217)
        {
            if (p216 == null)
            {
                return null;
            }
            ICollection<AppAccessControlEntryReadModel> result = new List<AppAccessControlEntryReadModel>(p216.Count);
            
            IEnumerator<AppAccessControlEntry> enumerator = p216.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppAccessControlEntry item = enumerator.Current;
                result.Add(funcMain204(item));
            }
            return result;
            
        }
        
        private static AppUserRoleReadModel funcMain2(AppUserRole p3)
        {
            return p3 == null ? null : new AppUserRoleReadModel()
            {
                AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(p3.AppUser),
                AppRole = funcMain3(p3.AppRole),
                Hash = p3.Hash,
                CreatedBy = p3.CreatedBy,
                CreatedDate = p3.CreatedDate,
                ModifiedBy = p3.ModifiedBy,
                ModifiedDate = p3.ModifiedDate,
                IsDeleted = p3.IsDeleted,
                DeletedBy = p3.DeletedBy,
                DeletedDate = p3.DeletedDate,
                UserId = p3.UserId,
                RoleId = p3.RoleId
            };
        }
        
        private static AppAccessControlEntryReadModel funcMain14(AppAccessControlEntry p15)
        {
            return p15 == null ? null : new AppAccessControlEntryReadModel()
            {
                ResourcePattern = p15.ResourcePattern,
                PermissionPattern = p15.PermissionPattern,
                FeatureId = p15.FeatureId,
                Feature = funcMain15(p15.Feature),
                AppRoles = funcMain17(p15.AppRoles),
                AppUsers = funcMain21(p15.AppUsers),
                AppResource = p15.AppResource == null ? null : new AppResourceReadModel()
                {
                    Url = p15.AppResource.Url,
                    Description = p15.AppResource.Description,
                    ResourceType = p15.AppResource.ResourceType,
                    AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p15.AppResource.AccessControlEntries),
                    Id = p15.AppResource.Id,
                    CreatedBy = p15.AppResource.CreatedBy,
                    CreatedDate = p15.AppResource.CreatedDate,
                    ModifiedBy = p15.AppResource.ModifiedBy,
                    ModifiedDate = p15.AppResource.ModifiedDate,
                    IsDeleted = p15.AppResource.IsDeleted,
                    DeletedBy = p15.AppResource.DeletedBy,
                    DeletedDate = p15.AppResource.DeletedDate
                },
                ResourceId = p15.ResourceId,
                Id = p15.Id,
                CreatedBy = p15.CreatedBy,
                CreatedDate = p15.CreatedDate,
                ModifiedBy = p15.ModifiedBy,
                ModifiedDate = p15.ModifiedDate,
                IsDeleted = p15.IsDeleted,
                DeletedBy = p15.DeletedBy,
                DeletedDate = p15.DeletedDate
            };
        }
        
        private static AppUserRoleReadModel funcMain23(AppUserRole p27)
        {
            return p27 == null ? null : new AppUserRoleReadModel()
            {
                AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(p27.AppUser),
                AppRole = funcMain24(p27.AppRole),
                Hash = p27.Hash,
                CreatedBy = p27.CreatedBy,
                CreatedDate = p27.CreatedDate,
                ModifiedBy = p27.ModifiedBy,
                ModifiedDate = p27.ModifiedDate,
                IsDeleted = p27.IsDeleted,
                DeletedBy = p27.DeletedBy,
                DeletedDate = p27.DeletedDate,
                UserId = p27.UserId,
                RoleId = p27.RoleId
            };
        }
        
        private static AppAccessControlEntryReadModel funcMain35(AppAccessControlEntry p42)
        {
            return p42 == null ? null : new AppAccessControlEntryReadModel()
            {
                ResourcePattern = p42.ResourcePattern,
                PermissionPattern = p42.PermissionPattern,
                FeatureId = p42.FeatureId,
                Feature = funcMain36(p42.Feature),
                AppRoles = funcMain38(p42.AppRoles),
                AppUsers = funcMain42(p42.AppUsers),
                AppResource = p42.AppResource == null ? null : new AppResourceReadModel()
                {
                    Url = p42.AppResource.Url,
                    Description = p42.AppResource.Description,
                    ResourceType = p42.AppResource.ResourceType,
                    AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p42.AppResource.AccessControlEntries),
                    Id = p42.AppResource.Id,
                    CreatedBy = p42.AppResource.CreatedBy,
                    CreatedDate = p42.AppResource.CreatedDate,
                    ModifiedBy = p42.AppResource.ModifiedBy,
                    ModifiedDate = p42.AppResource.ModifiedDate,
                    IsDeleted = p42.AppResource.IsDeleted,
                    DeletedBy = p42.AppResource.DeletedBy,
                    DeletedDate = p42.AppResource.DeletedDate
                },
                ResourceId = p42.ResourceId,
                Id = p42.Id,
                CreatedBy = p42.CreatedBy,
                CreatedDate = p42.CreatedDate,
                ModifiedBy = p42.ModifiedBy,
                ModifiedDate = p42.ModifiedDate,
                IsDeleted = p42.IsDeleted,
                DeletedBy = p42.DeletedBy,
                DeletedDate = p42.DeletedDate
            };
        }
        
        private static AppUserRoleReadModel funcMain44(AppUserRole p52)
        {
            return p52 == null ? null : new AppUserRoleReadModel()
            {
                AppUser = funcMain45(p52.AppUser),
                AppRole = funcMain56(p52.AppRole),
                Hash = p52.Hash,
                CreatedBy = p52.CreatedBy,
                CreatedDate = p52.CreatedDate,
                ModifiedBy = p52.ModifiedBy,
                ModifiedDate = p52.ModifiedDate,
                IsDeleted = p52.IsDeleted,
                DeletedBy = p52.DeletedBy,
                DeletedDate = p52.DeletedDate,
                UserId = p52.UserId,
                RoleId = p52.RoleId
            };
        }
        
        private static AppUserTokenReadModel funcMain68(AppUserToken p76)
        {
            return p76 == null ? null : new AppUserTokenReadModel()
            {
                Token = p76.Token,
                AppUser = funcMain69(p76.AppUser),
                CreatedBy = p76.CreatedBy,
                CreatedDate = p76.CreatedDate,
                ModifiedBy = p76.ModifiedBy,
                ModifiedDate = p76.ModifiedDate,
                IsDeleted = p76.IsDeleted,
                DeletedBy = p76.DeletedBy,
                DeletedDate = p76.DeletedDate,
                UserId = p76.UserId,
                LoginProvider = p76.LoginProvider,
                Name = p76.Name,
                Value = p76.Value
            };
        }
        
        private static AppRefreshTokenReadModel funcMain91(AppRefreshToken p99)
        {
            return p99 == null ? null : new AppRefreshTokenReadModel()
            {
                UserId = p99.UserId,
                Token = p99.Token,
                JwtId = p99.JwtId,
                IsUsed = p99.IsUsed,
                IsRevoked = p99.IsRevoked,
                ExpiryDate = p99.ExpiryDate,
                Hash = p99.Hash,
                AppUser = funcMain92(p99.AppUser),
                Id = p99.Id,
                CreatedBy = p99.CreatedBy,
                CreatedDate = p99.CreatedDate,
                ModifiedBy = p99.ModifiedBy,
                ModifiedDate = p99.ModifiedDate,
                IsDeleted = p99.IsDeleted,
                DeletedBy = p99.DeletedBy,
                DeletedDate = p99.DeletedDate
            };
        }
        
        private static AppAccessControlEntryReadModel funcMain114(AppAccessControlEntry p122)
        {
            return p122 == null ? null : new AppAccessControlEntryReadModel()
            {
                ResourcePattern = p122.ResourcePattern,
                PermissionPattern = p122.PermissionPattern,
                FeatureId = p122.FeatureId,
                Feature = funcMain115(p122.Feature),
                AppRoles = funcMain117(p122.AppRoles),
                AppUsers = funcMain125(p122.AppUsers),
                AppResource = p122.AppResource == null ? null : new AppResourceReadModel()
                {
                    Url = p122.AppResource.Url,
                    Description = p122.AppResource.Description,
                    ResourceType = p122.AppResource.ResourceType,
                    AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p122.AppResource.AccessControlEntries),
                    Id = p122.AppResource.Id,
                    CreatedBy = p122.AppResource.CreatedBy,
                    CreatedDate = p122.AppResource.CreatedDate,
                    ModifiedBy = p122.AppResource.ModifiedBy,
                    ModifiedDate = p122.AppResource.ModifiedDate,
                    IsDeleted = p122.AppResource.IsDeleted,
                    DeletedBy = p122.AppResource.DeletedBy,
                    DeletedDate = p122.AppResource.DeletedDate
                },
                ResourceId = p122.ResourceId,
                Id = p122.Id,
                CreatedBy = p122.CreatedBy,
                CreatedDate = p122.CreatedDate,
                ModifiedBy = p122.ModifiedBy,
                ModifiedDate = p122.ModifiedDate,
                IsDeleted = p122.IsDeleted,
                DeletedBy = p122.DeletedBy,
                DeletedDate = p122.DeletedDate
            };
        }
        
        private static AppUserRoleReadModel funcMain134(AppUserRole p145)
        {
            return p145 == null ? null : new AppUserRoleReadModel()
            {
                AppUser = funcMain135(p145.AppUser),
                AppRole = funcMain146(p145.AppRole),
                Hash = p145.Hash,
                CreatedBy = p145.CreatedBy,
                CreatedDate = p145.CreatedDate,
                ModifiedBy = p145.ModifiedBy,
                ModifiedDate = p145.ModifiedDate,
                IsDeleted = p145.IsDeleted,
                DeletedBy = p145.DeletedBy,
                DeletedDate = p145.DeletedDate,
                UserId = p145.UserId,
                RoleId = p145.RoleId
            };
        }
        
        private static AppUserTokenReadModel funcMain158(AppUserToken p170)
        {
            return p170 == null ? null : new AppUserTokenReadModel()
            {
                Token = p170.Token,
                AppUser = funcMain159(p170.AppUser),
                CreatedBy = p170.CreatedBy,
                CreatedDate = p170.CreatedDate,
                ModifiedBy = p170.ModifiedBy,
                ModifiedDate = p170.ModifiedDate,
                IsDeleted = p170.IsDeleted,
                DeletedBy = p170.DeletedBy,
                DeletedDate = p170.DeletedDate,
                UserId = p170.UserId,
                LoginProvider = p170.LoginProvider,
                Name = p170.Name,
                Value = p170.Value
            };
        }
        
        private static AppRefreshTokenReadModel funcMain181(AppRefreshToken p194)
        {
            return p194 == null ? null : new AppRefreshTokenReadModel()
            {
                UserId = p194.UserId,
                Token = p194.Token,
                JwtId = p194.JwtId,
                IsUsed = p194.IsUsed,
                IsRevoked = p194.IsRevoked,
                ExpiryDate = p194.ExpiryDate,
                Hash = p194.Hash,
                AppUser = funcMain182(p194.AppUser),
                Id = p194.Id,
                CreatedBy = p194.CreatedBy,
                CreatedDate = p194.CreatedDate,
                ModifiedBy = p194.ModifiedBy,
                ModifiedDate = p194.ModifiedDate,
                IsDeleted = p194.IsDeleted,
                DeletedBy = p194.DeletedBy,
                DeletedDate = p194.DeletedDate
            };
        }
        
        private static AppAccessControlEntryReadModel funcMain204(AppAccessControlEntry p218)
        {
            return p218 == null ? null : new AppAccessControlEntryReadModel()
            {
                ResourcePattern = p218.ResourcePattern,
                PermissionPattern = p218.PermissionPattern,
                FeatureId = p218.FeatureId,
                Feature = funcMain205(p218.Feature),
                AppRoles = funcMain207(p218.AppRoles),
                AppUsers = funcMain215(p218.AppUsers),
                AppResource = p218.AppResource == null ? null : new AppResourceReadModel()
                {
                    Url = p218.AppResource.Url,
                    Description = p218.AppResource.Description,
                    ResourceType = p218.AppResource.ResourceType,
                    AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p218.AppResource.AccessControlEntries),
                    Id = p218.AppResource.Id,
                    CreatedBy = p218.AppResource.CreatedBy,
                    CreatedDate = p218.AppResource.CreatedDate,
                    ModifiedBy = p218.AppResource.ModifiedBy,
                    ModifiedDate = p218.AppResource.ModifiedDate,
                    IsDeleted = p218.AppResource.IsDeleted,
                    DeletedBy = p218.AppResource.DeletedBy,
                    DeletedDate = p218.AppResource.DeletedDate
                },
                ResourceId = p218.ResourceId,
                Id = p218.Id,
                CreatedBy = p218.CreatedBy,
                CreatedDate = p218.CreatedDate,
                ModifiedBy = p218.ModifiedBy,
                ModifiedDate = p218.ModifiedDate,
                IsDeleted = p218.IsDeleted,
                DeletedBy = p218.DeletedBy,
                DeletedDate = p218.DeletedDate
            };
        }
        
        private static AppRoleReadModel funcMain3(AppRole p4)
        {
            return p4 == null ? null : new AppRoleReadModel()
            {
                CreatedBy = p4.CreatedBy,
                CreatedDate = p4.CreatedDate,
                ModifiedBy = p4.ModifiedBy,
                ModifiedDate = p4.ModifiedDate,
                IsDeleted = p4.IsDeleted,
                DeletedBy = p4.DeletedBy,
                DeletedDate = p4.DeletedDate,
                AppUserRoles = TypeAdapter<ICollection<AppUserRole>, ICollection<AppUserRoleReadModel>>.Map.Invoke(p4.AppUserRoles),
                AppRoleClaims = funcMain4(p4.AppRoleClaims),
                AccessControlEntries = funcMain5(p4.AccessControlEntries),
                Hash = p4.Hash,
                Id = p4.Id,
                Name = p4.Name,
                NormalizedName = p4.NormalizedName,
                ConcurrencyStamp = p4.ConcurrencyStamp
            };
        }
        
        private static AppFeatureReadModel funcMain15(AppFeature p16)
        {
            return p16 == null ? null : new AppFeatureReadModel()
            {
                Name = p16.Name,
                Description = p16.Description,
                IsEnabled = p16.IsEnabled,
                Scope = p16.Scope,
                FeatureFlags = funcMain16(p16.FeatureFlags),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p16.AccessControlEntries),
                Id = p16.Id,
                CreatedBy = p16.CreatedBy,
                CreatedDate = p16.CreatedDate,
                ModifiedBy = p16.ModifiedBy,
                ModifiedDate = p16.ModifiedDate,
                IsDeleted = p16.IsDeleted,
                DeletedBy = p16.DeletedBy,
                DeletedDate = p16.DeletedDate
            };
        }
        
        private static ICollection<AppRoleReadModel> funcMain17(ICollection<AppRole> p18)
        {
            if (p18 == null)
            {
                return null;
            }
            ICollection<AppRoleReadModel> result = new List<AppRoleReadModel>(p18.Count);
            
            IEnumerator<AppRole> enumerator = p18.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRole item = enumerator.Current;
                result.Add(funcMain18(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserReadModel> funcMain21(ICollection<AppUser> p22)
        {
            if (p22 == null)
            {
                return null;
            }
            ICollection<AppUserReadModel> result = new List<AppUserReadModel>(p22.Count);
            
            IEnumerator<AppUser> enumerator = p22.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUser item = enumerator.Current;
                result.Add(TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static AppRoleReadModel funcMain24(AppRole p28)
        {
            return p28 == null ? null : new AppRoleReadModel()
            {
                CreatedBy = p28.CreatedBy,
                CreatedDate = p28.CreatedDate,
                ModifiedBy = p28.ModifiedBy,
                ModifiedDate = p28.ModifiedDate,
                IsDeleted = p28.IsDeleted,
                DeletedBy = p28.DeletedBy,
                DeletedDate = p28.DeletedDate,
                AppUserRoles = TypeAdapter<ICollection<AppUserRole>, ICollection<AppUserRoleReadModel>>.Map.Invoke(p28.AppUserRoles),
                AppRoleClaims = funcMain25(p28.AppRoleClaims),
                AccessControlEntries = funcMain26(p28.AccessControlEntries),
                Hash = p28.Hash,
                Id = p28.Id,
                Name = p28.Name,
                NormalizedName = p28.NormalizedName,
                ConcurrencyStamp = p28.ConcurrencyStamp
            };
        }
        
        private static AppFeatureReadModel funcMain36(AppFeature p43)
        {
            return p43 == null ? null : new AppFeatureReadModel()
            {
                Name = p43.Name,
                Description = p43.Description,
                IsEnabled = p43.IsEnabled,
                Scope = p43.Scope,
                FeatureFlags = funcMain37(p43.FeatureFlags),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p43.AccessControlEntries),
                Id = p43.Id,
                CreatedBy = p43.CreatedBy,
                CreatedDate = p43.CreatedDate,
                ModifiedBy = p43.ModifiedBy,
                ModifiedDate = p43.ModifiedDate,
                IsDeleted = p43.IsDeleted,
                DeletedBy = p43.DeletedBy,
                DeletedDate = p43.DeletedDate
            };
        }
        
        private static ICollection<AppRoleReadModel> funcMain38(ICollection<AppRole> p45)
        {
            if (p45 == null)
            {
                return null;
            }
            ICollection<AppRoleReadModel> result = new List<AppRoleReadModel>(p45.Count);
            
            IEnumerator<AppRole> enumerator = p45.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRole item = enumerator.Current;
                result.Add(funcMain39(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserReadModel> funcMain42(ICollection<AppUser> p49)
        {
            if (p49 == null)
            {
                return null;
            }
            ICollection<AppUserReadModel> result = new List<AppUserReadModel>(p49.Count);
            
            IEnumerator<AppUser> enumerator = p49.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUser item = enumerator.Current;
                result.Add(TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static AppUserReadModel funcMain45(AppUser p53)
        {
            return p53 == null ? null : new AppUserReadModel()
            {
                Hash = p53.Hash,
                FirstName = p53.FirstName,
                LastName = p53.LastName,
                Mobile = p53.Mobile,
                CountryCode = p53.CountryCode,
                TwoFactorMethod = p53.TwoFactorMethod,
                CreatedBy = p53.CreatedBy,
                CreatedDate = p53.CreatedDate,
                ModifiedBy = p53.ModifiedBy,
                ModifiedDate = p53.ModifiedDate,
                IsDeleted = p53.IsDeleted,
                DeletedBy = p53.DeletedBy,
                DeletedDate = p53.DeletedDate,
                MembershipType = p53.MembershipType,
                UserRoles = TypeAdapter<ICollection<AppUserRole>, ICollection<AppUserRoleReadModel>>.Map.Invoke(p53.UserRoles),
                UserTokens = funcMain46(p53.UserTokens),
                RefreshTokens = funcMain47(p53.RefreshTokens),
                AccessControlEntries = funcMain48(p53.AccessControlEntries),
                Id = p53.Id,
                UserName = p53.UserName,
                NormalizedUserName = p53.NormalizedUserName,
                Email = p53.Email,
                NormalizedEmail = p53.NormalizedEmail,
                EmailConfirmed = p53.EmailConfirmed,
                PasswordHash = p53.PasswordHash,
                SecurityStamp = p53.SecurityStamp,
                ConcurrencyStamp = p53.ConcurrencyStamp,
                PhoneNumber = p53.PhoneNumber,
                PhoneNumberConfirmed = p53.PhoneNumberConfirmed,
                TwoFactorEnabled = p53.TwoFactorEnabled,
                LockoutEnd = p53.LockoutEnd,
                LockoutEnabled = p53.LockoutEnabled,
                AccessFailedCount = p53.AccessFailedCount
            };
        }
        
        private static AppRoleReadModel funcMain56(AppRole p64)
        {
            return p64 == null ? null : new AppRoleReadModel()
            {
                CreatedBy = p64.CreatedBy,
                CreatedDate = p64.CreatedDate,
                ModifiedBy = p64.ModifiedBy,
                ModifiedDate = p64.ModifiedDate,
                IsDeleted = p64.IsDeleted,
                DeletedBy = p64.DeletedBy,
                DeletedDate = p64.DeletedDate,
                AppUserRoles = TypeAdapter<ICollection<AppUserRole>, ICollection<AppUserRoleReadModel>>.Map.Invoke(p64.AppUserRoles),
                AppRoleClaims = funcMain57(p64.AppRoleClaims),
                AccessControlEntries = funcMain58(p64.AccessControlEntries),
                Hash = p64.Hash,
                Id = p64.Id,
                Name = p64.Name,
                NormalizedName = p64.NormalizedName,
                ConcurrencyStamp = p64.ConcurrencyStamp
            };
        }
        
        private static AppUserReadModel funcMain69(AppUser p77)
        {
            return p77 == null ? null : new AppUserReadModel()
            {
                Hash = p77.Hash,
                FirstName = p77.FirstName,
                LastName = p77.LastName,
                Mobile = p77.Mobile,
                CountryCode = p77.CountryCode,
                TwoFactorMethod = p77.TwoFactorMethod,
                CreatedBy = p77.CreatedBy,
                CreatedDate = p77.CreatedDate,
                ModifiedBy = p77.ModifiedBy,
                ModifiedDate = p77.ModifiedDate,
                IsDeleted = p77.IsDeleted,
                DeletedBy = p77.DeletedBy,
                DeletedDate = p77.DeletedDate,
                MembershipType = p77.MembershipType,
                UserRoles = funcMain70(p77.UserRoles),
                UserTokens = TypeAdapter<ICollection<AppUserToken>, ICollection<AppUserTokenReadModel>>.Map.Invoke(p77.UserTokens),
                RefreshTokens = funcMain80(p77.RefreshTokens),
                AccessControlEntries = funcMain81(p77.AccessControlEntries),
                Id = p77.Id,
                UserName = p77.UserName,
                NormalizedUserName = p77.NormalizedUserName,
                Email = p77.Email,
                NormalizedEmail = p77.NormalizedEmail,
                EmailConfirmed = p77.EmailConfirmed,
                PasswordHash = p77.PasswordHash,
                SecurityStamp = p77.SecurityStamp,
                ConcurrencyStamp = p77.ConcurrencyStamp,
                PhoneNumber = p77.PhoneNumber,
                PhoneNumberConfirmed = p77.PhoneNumberConfirmed,
                TwoFactorEnabled = p77.TwoFactorEnabled,
                LockoutEnd = p77.LockoutEnd,
                LockoutEnabled = p77.LockoutEnabled,
                AccessFailedCount = p77.AccessFailedCount
            };
        }
        
        private static AppUserReadModel funcMain92(AppUser p100)
        {
            return p100 == null ? null : new AppUserReadModel()
            {
                Hash = p100.Hash,
                FirstName = p100.FirstName,
                LastName = p100.LastName,
                Mobile = p100.Mobile,
                CountryCode = p100.CountryCode,
                TwoFactorMethod = p100.TwoFactorMethod,
                CreatedBy = p100.CreatedBy,
                CreatedDate = p100.CreatedDate,
                ModifiedBy = p100.ModifiedBy,
                ModifiedDate = p100.ModifiedDate,
                IsDeleted = p100.IsDeleted,
                DeletedBy = p100.DeletedBy,
                DeletedDate = p100.DeletedDate,
                MembershipType = p100.MembershipType,
                UserRoles = funcMain93(p100.UserRoles),
                UserTokens = funcMain103(p100.UserTokens),
                RefreshTokens = TypeAdapter<ICollection<AppRefreshToken>, ICollection<AppRefreshTokenReadModel>>.Map.Invoke(p100.RefreshTokens),
                AccessControlEntries = funcMain104(p100.AccessControlEntries),
                Id = p100.Id,
                UserName = p100.UserName,
                NormalizedUserName = p100.NormalizedUserName,
                Email = p100.Email,
                NormalizedEmail = p100.NormalizedEmail,
                EmailConfirmed = p100.EmailConfirmed,
                PasswordHash = p100.PasswordHash,
                SecurityStamp = p100.SecurityStamp,
                ConcurrencyStamp = p100.ConcurrencyStamp,
                PhoneNumber = p100.PhoneNumber,
                PhoneNumberConfirmed = p100.PhoneNumberConfirmed,
                TwoFactorEnabled = p100.TwoFactorEnabled,
                LockoutEnd = p100.LockoutEnd,
                LockoutEnabled = p100.LockoutEnabled,
                AccessFailedCount = p100.AccessFailedCount
            };
        }
        
        private static AppFeatureReadModel funcMain115(AppFeature p123)
        {
            return p123 == null ? null : new AppFeatureReadModel()
            {
                Name = p123.Name,
                Description = p123.Description,
                IsEnabled = p123.IsEnabled,
                Scope = p123.Scope,
                FeatureFlags = funcMain116(p123.FeatureFlags),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p123.AccessControlEntries),
                Id = p123.Id,
                CreatedBy = p123.CreatedBy,
                CreatedDate = p123.CreatedDate,
                ModifiedBy = p123.ModifiedBy,
                ModifiedDate = p123.ModifiedDate,
                IsDeleted = p123.IsDeleted,
                DeletedBy = p123.DeletedBy,
                DeletedDate = p123.DeletedDate
            };
        }
        
        private static ICollection<AppRoleReadModel> funcMain117(ICollection<AppRole> p125)
        {
            if (p125 == null)
            {
                return null;
            }
            ICollection<AppRoleReadModel> result = new List<AppRoleReadModel>(p125.Count);
            
            IEnumerator<AppRole> enumerator = p125.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRole item = enumerator.Current;
                result.Add(funcMain118(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserReadModel> funcMain125(ICollection<AppUser> p133)
        {
            if (p133 == null)
            {
                return null;
            }
            ICollection<AppUserReadModel> result = new List<AppUserReadModel>(p133.Count);
            
            IEnumerator<AppUser> enumerator = p133.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUser item = enumerator.Current;
                result.Add(funcMain126(item));
            }
            return result;
            
        }
        
        private static AppUserReadModel funcMain135(AppUser p146)
        {
            return p146 == null ? null : new AppUserReadModel()
            {
                Hash = p146.Hash,
                FirstName = p146.FirstName,
                LastName = p146.LastName,
                Mobile = p146.Mobile,
                CountryCode = p146.CountryCode,
                TwoFactorMethod = p146.TwoFactorMethod,
                CreatedBy = p146.CreatedBy,
                CreatedDate = p146.CreatedDate,
                ModifiedBy = p146.ModifiedBy,
                ModifiedDate = p146.ModifiedDate,
                IsDeleted = p146.IsDeleted,
                DeletedBy = p146.DeletedBy,
                DeletedDate = p146.DeletedDate,
                MembershipType = p146.MembershipType,
                UserRoles = TypeAdapter<ICollection<AppUserRole>, ICollection<AppUserRoleReadModel>>.Map.Invoke(p146.UserRoles),
                UserTokens = funcMain136(p146.UserTokens),
                RefreshTokens = funcMain137(p146.RefreshTokens),
                AccessControlEntries = funcMain138(p146.AccessControlEntries),
                Id = p146.Id,
                UserName = p146.UserName,
                NormalizedUserName = p146.NormalizedUserName,
                Email = p146.Email,
                NormalizedEmail = p146.NormalizedEmail,
                EmailConfirmed = p146.EmailConfirmed,
                PasswordHash = p146.PasswordHash,
                SecurityStamp = p146.SecurityStamp,
                ConcurrencyStamp = p146.ConcurrencyStamp,
                PhoneNumber = p146.PhoneNumber,
                PhoneNumberConfirmed = p146.PhoneNumberConfirmed,
                TwoFactorEnabled = p146.TwoFactorEnabled,
                LockoutEnd = p146.LockoutEnd,
                LockoutEnabled = p146.LockoutEnabled,
                AccessFailedCount = p146.AccessFailedCount
            };
        }
        
        private static AppRoleReadModel funcMain146(AppRole p157)
        {
            return p157 == null ? null : new AppRoleReadModel()
            {
                CreatedBy = p157.CreatedBy,
                CreatedDate = p157.CreatedDate,
                ModifiedBy = p157.ModifiedBy,
                ModifiedDate = p157.ModifiedDate,
                IsDeleted = p157.IsDeleted,
                DeletedBy = p157.DeletedBy,
                DeletedDate = p157.DeletedDate,
                AppUserRoles = TypeAdapter<ICollection<AppUserRole>, ICollection<AppUserRoleReadModel>>.Map.Invoke(p157.AppUserRoles),
                AppRoleClaims = funcMain147(p157.AppRoleClaims),
                AccessControlEntries = funcMain148(p157.AccessControlEntries),
                Hash = p157.Hash,
                Id = p157.Id,
                Name = p157.Name,
                NormalizedName = p157.NormalizedName,
                ConcurrencyStamp = p157.ConcurrencyStamp
            };
        }
        
        private static AppUserReadModel funcMain159(AppUser p171)
        {
            return p171 == null ? null : new AppUserReadModel()
            {
                Hash = p171.Hash,
                FirstName = p171.FirstName,
                LastName = p171.LastName,
                Mobile = p171.Mobile,
                CountryCode = p171.CountryCode,
                TwoFactorMethod = p171.TwoFactorMethod,
                CreatedBy = p171.CreatedBy,
                CreatedDate = p171.CreatedDate,
                ModifiedBy = p171.ModifiedBy,
                ModifiedDate = p171.ModifiedDate,
                IsDeleted = p171.IsDeleted,
                DeletedBy = p171.DeletedBy,
                DeletedDate = p171.DeletedDate,
                MembershipType = p171.MembershipType,
                UserRoles = funcMain160(p171.UserRoles),
                UserTokens = TypeAdapter<ICollection<AppUserToken>, ICollection<AppUserTokenReadModel>>.Map.Invoke(p171.UserTokens),
                RefreshTokens = funcMain170(p171.RefreshTokens),
                AccessControlEntries = funcMain171(p171.AccessControlEntries),
                Id = p171.Id,
                UserName = p171.UserName,
                NormalizedUserName = p171.NormalizedUserName,
                Email = p171.Email,
                NormalizedEmail = p171.NormalizedEmail,
                EmailConfirmed = p171.EmailConfirmed,
                PasswordHash = p171.PasswordHash,
                SecurityStamp = p171.SecurityStamp,
                ConcurrencyStamp = p171.ConcurrencyStamp,
                PhoneNumber = p171.PhoneNumber,
                PhoneNumberConfirmed = p171.PhoneNumberConfirmed,
                TwoFactorEnabled = p171.TwoFactorEnabled,
                LockoutEnd = p171.LockoutEnd,
                LockoutEnabled = p171.LockoutEnabled,
                AccessFailedCount = p171.AccessFailedCount
            };
        }
        
        private static AppUserReadModel funcMain182(AppUser p195)
        {
            return p195 == null ? null : new AppUserReadModel()
            {
                Hash = p195.Hash,
                FirstName = p195.FirstName,
                LastName = p195.LastName,
                Mobile = p195.Mobile,
                CountryCode = p195.CountryCode,
                TwoFactorMethod = p195.TwoFactorMethod,
                CreatedBy = p195.CreatedBy,
                CreatedDate = p195.CreatedDate,
                ModifiedBy = p195.ModifiedBy,
                ModifiedDate = p195.ModifiedDate,
                IsDeleted = p195.IsDeleted,
                DeletedBy = p195.DeletedBy,
                DeletedDate = p195.DeletedDate,
                MembershipType = p195.MembershipType,
                UserRoles = funcMain183(p195.UserRoles),
                UserTokens = funcMain193(p195.UserTokens),
                RefreshTokens = TypeAdapter<ICollection<AppRefreshToken>, ICollection<AppRefreshTokenReadModel>>.Map.Invoke(p195.RefreshTokens),
                AccessControlEntries = funcMain194(p195.AccessControlEntries),
                Id = p195.Id,
                UserName = p195.UserName,
                NormalizedUserName = p195.NormalizedUserName,
                Email = p195.Email,
                NormalizedEmail = p195.NormalizedEmail,
                EmailConfirmed = p195.EmailConfirmed,
                PasswordHash = p195.PasswordHash,
                SecurityStamp = p195.SecurityStamp,
                ConcurrencyStamp = p195.ConcurrencyStamp,
                PhoneNumber = p195.PhoneNumber,
                PhoneNumberConfirmed = p195.PhoneNumberConfirmed,
                TwoFactorEnabled = p195.TwoFactorEnabled,
                LockoutEnd = p195.LockoutEnd,
                LockoutEnabled = p195.LockoutEnabled,
                AccessFailedCount = p195.AccessFailedCount
            };
        }
        
        private static AppFeatureReadModel funcMain205(AppFeature p219)
        {
            return p219 == null ? null : new AppFeatureReadModel()
            {
                Name = p219.Name,
                Description = p219.Description,
                IsEnabled = p219.IsEnabled,
                Scope = p219.Scope,
                FeatureFlags = funcMain206(p219.FeatureFlags),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p219.AccessControlEntries),
                Id = p219.Id,
                CreatedBy = p219.CreatedBy,
                CreatedDate = p219.CreatedDate,
                ModifiedBy = p219.ModifiedBy,
                ModifiedDate = p219.ModifiedDate,
                IsDeleted = p219.IsDeleted,
                DeletedBy = p219.DeletedBy,
                DeletedDate = p219.DeletedDate
            };
        }
        
        private static ICollection<AppRoleReadModel> funcMain207(ICollection<AppRole> p221)
        {
            if (p221 == null)
            {
                return null;
            }
            ICollection<AppRoleReadModel> result = new List<AppRoleReadModel>(p221.Count);
            
            IEnumerator<AppRole> enumerator = p221.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRole item = enumerator.Current;
                result.Add(funcMain208(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserReadModel> funcMain215(ICollection<AppUser> p229)
        {
            if (p229 == null)
            {
                return null;
            }
            ICollection<AppUserReadModel> result = new List<AppUserReadModel>(p229.Count);
            
            IEnumerator<AppUser> enumerator = p229.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUser item = enumerator.Current;
                result.Add(funcMain216(item));
            }
            return result;
            
        }
        
        private static ICollection<AppRoleClaimReadModel> funcMain4(ICollection<AppRoleClaim> p5)
        {
            if (p5 == null)
            {
                return null;
            }
            ICollection<AppRoleClaimReadModel> result = new List<AppRoleClaimReadModel>(p5.Count);
            
            IEnumerator<AppRoleClaim> enumerator = p5.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRoleClaim item = enumerator.Current;
                result.Add(item == null ? null : new AppRoleClaimReadModel()
                {
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Id = item.Id,
                    RoleId = item.RoleId,
                    ClaimType = item.ClaimType,
                    ClaimValue = item.ClaimValue
                });
            }
            return result;
            
        }
        
        private static ICollection<AppAccessControlEntryReadModel> funcMain5(ICollection<AppAccessControlEntry> p6)
        {
            if (p6 == null)
            {
                return null;
            }
            ICollection<AppAccessControlEntryReadModel> result = new List<AppAccessControlEntryReadModel>(p6.Count);
            
            IEnumerator<AppAccessControlEntry> enumerator = p6.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppAccessControlEntry item = enumerator.Current;
                result.Add(funcMain6(item));
            }
            return result;
            
        }
        
        private static ICollection<AppFeatureFlagReadModel> funcMain16(ICollection<AppFeatureFlag> p17)
        {
            if (p17 == null)
            {
                return null;
            }
            ICollection<AppFeatureFlagReadModel> result = new List<AppFeatureFlagReadModel>(p17.Count);
            
            IEnumerator<AppFeatureFlag> enumerator = p17.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppFeatureFlag item = enumerator.Current;
                result.Add(item == null ? null : new AppFeatureFlagReadModel()
                {
                    FeatureId = item.FeatureId,
                    ScopeIdentifier = item.ScopeIdentifier,
                    IsEnabled = item.IsEnabled,
                    Feature = TypeAdapter<AppFeature, AppFeatureReadModel>.Map.Invoke(item.Feature),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static AppRoleReadModel funcMain18(AppRole p19)
        {
            return p19 == null ? null : new AppRoleReadModel()
            {
                CreatedBy = p19.CreatedBy,
                CreatedDate = p19.CreatedDate,
                ModifiedBy = p19.ModifiedBy,
                ModifiedDate = p19.ModifiedDate,
                IsDeleted = p19.IsDeleted,
                DeletedBy = p19.DeletedBy,
                DeletedDate = p19.DeletedDate,
                AppUserRoles = funcMain19(p19.AppUserRoles),
                AppRoleClaims = funcMain20(p19.AppRoleClaims),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p19.AccessControlEntries),
                Hash = p19.Hash,
                Id = p19.Id,
                Name = p19.Name,
                NormalizedName = p19.NormalizedName,
                ConcurrencyStamp = p19.ConcurrencyStamp
            };
        }
        
        private static ICollection<AppRoleClaimReadModel> funcMain25(ICollection<AppRoleClaim> p29)
        {
            if (p29 == null)
            {
                return null;
            }
            ICollection<AppRoleClaimReadModel> result = new List<AppRoleClaimReadModel>(p29.Count);
            
            IEnumerator<AppRoleClaim> enumerator = p29.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRoleClaim item = enumerator.Current;
                result.Add(item == null ? null : new AppRoleClaimReadModel()
                {
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Id = item.Id,
                    RoleId = item.RoleId,
                    ClaimType = item.ClaimType,
                    ClaimValue = item.ClaimValue
                });
            }
            return result;
            
        }
        
        private static ICollection<AppAccessControlEntryReadModel> funcMain26(ICollection<AppAccessControlEntry> p30)
        {
            if (p30 == null)
            {
                return null;
            }
            ICollection<AppAccessControlEntryReadModel> result = new List<AppAccessControlEntryReadModel>(p30.Count);
            
            IEnumerator<AppAccessControlEntry> enumerator = p30.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppAccessControlEntry item = enumerator.Current;
                result.Add(funcMain27(item));
            }
            return result;
            
        }
        
        private static ICollection<AppFeatureFlagReadModel> funcMain37(ICollection<AppFeatureFlag> p44)
        {
            if (p44 == null)
            {
                return null;
            }
            ICollection<AppFeatureFlagReadModel> result = new List<AppFeatureFlagReadModel>(p44.Count);
            
            IEnumerator<AppFeatureFlag> enumerator = p44.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppFeatureFlag item = enumerator.Current;
                result.Add(item == null ? null : new AppFeatureFlagReadModel()
                {
                    FeatureId = item.FeatureId,
                    ScopeIdentifier = item.ScopeIdentifier,
                    IsEnabled = item.IsEnabled,
                    Feature = TypeAdapter<AppFeature, AppFeatureReadModel>.Map.Invoke(item.Feature),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static AppRoleReadModel funcMain39(AppRole p46)
        {
            return p46 == null ? null : new AppRoleReadModel()
            {
                CreatedBy = p46.CreatedBy,
                CreatedDate = p46.CreatedDate,
                ModifiedBy = p46.ModifiedBy,
                ModifiedDate = p46.ModifiedDate,
                IsDeleted = p46.IsDeleted,
                DeletedBy = p46.DeletedBy,
                DeletedDate = p46.DeletedDate,
                AppUserRoles = funcMain40(p46.AppUserRoles),
                AppRoleClaims = funcMain41(p46.AppRoleClaims),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p46.AccessControlEntries),
                Hash = p46.Hash,
                Id = p46.Id,
                Name = p46.Name,
                NormalizedName = p46.NormalizedName,
                ConcurrencyStamp = p46.ConcurrencyStamp
            };
        }
        
        private static ICollection<AppUserTokenReadModel> funcMain46(ICollection<AppUserToken> p54)
        {
            if (p54 == null)
            {
                return null;
            }
            ICollection<AppUserTokenReadModel> result = new List<AppUserTokenReadModel>(p54.Count);
            
            IEnumerator<AppUserToken> enumerator = p54.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserToken item = enumerator.Current;
                result.Add(item == null ? null : new AppUserTokenReadModel()
                {
                    Token = item.Token,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    LoginProvider = item.LoginProvider,
                    Name = item.Name,
                    Value = item.Value
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRefreshTokenReadModel> funcMain47(ICollection<AppRefreshToken> p55)
        {
            if (p55 == null)
            {
                return null;
            }
            ICollection<AppRefreshTokenReadModel> result = new List<AppRefreshTokenReadModel>(p55.Count);
            
            IEnumerator<AppRefreshToken> enumerator = p55.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRefreshToken item = enumerator.Current;
                result.Add(item == null ? null : new AppRefreshTokenReadModel()
                {
                    UserId = item.UserId,
                    Token = item.Token,
                    JwtId = item.JwtId,
                    IsUsed = item.IsUsed,
                    IsRevoked = item.IsRevoked,
                    ExpiryDate = item.ExpiryDate,
                    Hash = item.Hash,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static ICollection<AppAccessControlEntryReadModel> funcMain48(ICollection<AppAccessControlEntry> p56)
        {
            if (p56 == null)
            {
                return null;
            }
            ICollection<AppAccessControlEntryReadModel> result = new List<AppAccessControlEntryReadModel>(p56.Count);
            
            IEnumerator<AppAccessControlEntry> enumerator = p56.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppAccessControlEntry item = enumerator.Current;
                result.Add(funcMain49(item));
            }
            return result;
            
        }
        
        private static ICollection<AppRoleClaimReadModel> funcMain57(ICollection<AppRoleClaim> p65)
        {
            if (p65 == null)
            {
                return null;
            }
            ICollection<AppRoleClaimReadModel> result = new List<AppRoleClaimReadModel>(p65.Count);
            
            IEnumerator<AppRoleClaim> enumerator = p65.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRoleClaim item = enumerator.Current;
                result.Add(item == null ? null : new AppRoleClaimReadModel()
                {
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Id = item.Id,
                    RoleId = item.RoleId,
                    ClaimType = item.ClaimType,
                    ClaimValue = item.ClaimValue
                });
            }
            return result;
            
        }
        
        private static ICollection<AppAccessControlEntryReadModel> funcMain58(ICollection<AppAccessControlEntry> p66)
        {
            if (p66 == null)
            {
                return null;
            }
            ICollection<AppAccessControlEntryReadModel> result = new List<AppAccessControlEntryReadModel>(p66.Count);
            
            IEnumerator<AppAccessControlEntry> enumerator = p66.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppAccessControlEntry item = enumerator.Current;
                result.Add(funcMain59(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain70(ICollection<AppUserRole> p78)
        {
            if (p78 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p78.Count);
            
            IEnumerator<AppUserRole> enumerator = p78.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(funcMain71(item));
            }
            return result;
            
        }
        
        private static ICollection<AppRefreshTokenReadModel> funcMain80(ICollection<AppRefreshToken> p88)
        {
            if (p88 == null)
            {
                return null;
            }
            ICollection<AppRefreshTokenReadModel> result = new List<AppRefreshTokenReadModel>(p88.Count);
            
            IEnumerator<AppRefreshToken> enumerator = p88.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRefreshToken item = enumerator.Current;
                result.Add(item == null ? null : new AppRefreshTokenReadModel()
                {
                    UserId = item.UserId,
                    Token = item.Token,
                    JwtId = item.JwtId,
                    IsUsed = item.IsUsed,
                    IsRevoked = item.IsRevoked,
                    ExpiryDate = item.ExpiryDate,
                    Hash = item.Hash,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static ICollection<AppAccessControlEntryReadModel> funcMain81(ICollection<AppAccessControlEntry> p89)
        {
            if (p89 == null)
            {
                return null;
            }
            ICollection<AppAccessControlEntryReadModel> result = new List<AppAccessControlEntryReadModel>(p89.Count);
            
            IEnumerator<AppAccessControlEntry> enumerator = p89.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppAccessControlEntry item = enumerator.Current;
                result.Add(funcMain82(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain93(ICollection<AppUserRole> p101)
        {
            if (p101 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p101.Count);
            
            IEnumerator<AppUserRole> enumerator = p101.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(funcMain94(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserTokenReadModel> funcMain103(ICollection<AppUserToken> p111)
        {
            if (p111 == null)
            {
                return null;
            }
            ICollection<AppUserTokenReadModel> result = new List<AppUserTokenReadModel>(p111.Count);
            
            IEnumerator<AppUserToken> enumerator = p111.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserToken item = enumerator.Current;
                result.Add(item == null ? null : new AppUserTokenReadModel()
                {
                    Token = item.Token,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    LoginProvider = item.LoginProvider,
                    Name = item.Name,
                    Value = item.Value
                });
            }
            return result;
            
        }
        
        private static ICollection<AppAccessControlEntryReadModel> funcMain104(ICollection<AppAccessControlEntry> p112)
        {
            if (p112 == null)
            {
                return null;
            }
            ICollection<AppAccessControlEntryReadModel> result = new List<AppAccessControlEntryReadModel>(p112.Count);
            
            IEnumerator<AppAccessControlEntry> enumerator = p112.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppAccessControlEntry item = enumerator.Current;
                result.Add(funcMain105(item));
            }
            return result;
            
        }
        
        private static ICollection<AppFeatureFlagReadModel> funcMain116(ICollection<AppFeatureFlag> p124)
        {
            if (p124 == null)
            {
                return null;
            }
            ICollection<AppFeatureFlagReadModel> result = new List<AppFeatureFlagReadModel>(p124.Count);
            
            IEnumerator<AppFeatureFlag> enumerator = p124.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppFeatureFlag item = enumerator.Current;
                result.Add(item == null ? null : new AppFeatureFlagReadModel()
                {
                    FeatureId = item.FeatureId,
                    ScopeIdentifier = item.ScopeIdentifier,
                    IsEnabled = item.IsEnabled,
                    Feature = TypeAdapter<AppFeature, AppFeatureReadModel>.Map.Invoke(item.Feature),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static AppRoleReadModel funcMain118(AppRole p126)
        {
            return p126 == null ? null : new AppRoleReadModel()
            {
                CreatedBy = p126.CreatedBy,
                CreatedDate = p126.CreatedDate,
                ModifiedBy = p126.ModifiedBy,
                ModifiedDate = p126.ModifiedDate,
                IsDeleted = p126.IsDeleted,
                DeletedBy = p126.DeletedBy,
                DeletedDate = p126.DeletedDate,
                AppUserRoles = funcMain119(p126.AppUserRoles),
                AppRoleClaims = funcMain124(p126.AppRoleClaims),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p126.AccessControlEntries),
                Hash = p126.Hash,
                Id = p126.Id,
                Name = p126.Name,
                NormalizedName = p126.NormalizedName,
                ConcurrencyStamp = p126.ConcurrencyStamp
            };
        }
        
        private static AppUserReadModel funcMain126(AppUser p134)
        {
            return p134 == null ? null : new AppUserReadModel()
            {
                Hash = p134.Hash,
                FirstName = p134.FirstName,
                LastName = p134.LastName,
                Mobile = p134.Mobile,
                CountryCode = p134.CountryCode,
                TwoFactorMethod = p134.TwoFactorMethod,
                CreatedBy = p134.CreatedBy,
                CreatedDate = p134.CreatedDate,
                ModifiedBy = p134.ModifiedBy,
                ModifiedDate = p134.ModifiedDate,
                IsDeleted = p134.IsDeleted,
                DeletedBy = p134.DeletedBy,
                DeletedDate = p134.DeletedDate,
                MembershipType = p134.MembershipType,
                UserRoles = funcMain127(p134.UserRoles),
                UserTokens = funcMain131(p134.UserTokens),
                RefreshTokens = funcMain132(p134.RefreshTokens),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p134.AccessControlEntries),
                Id = p134.Id,
                UserName = p134.UserName,
                NormalizedUserName = p134.NormalizedUserName,
                Email = p134.Email,
                NormalizedEmail = p134.NormalizedEmail,
                EmailConfirmed = p134.EmailConfirmed,
                PasswordHash = p134.PasswordHash,
                SecurityStamp = p134.SecurityStamp,
                ConcurrencyStamp = p134.ConcurrencyStamp,
                PhoneNumber = p134.PhoneNumber,
                PhoneNumberConfirmed = p134.PhoneNumberConfirmed,
                TwoFactorEnabled = p134.TwoFactorEnabled,
                LockoutEnd = p134.LockoutEnd,
                LockoutEnabled = p134.LockoutEnabled,
                AccessFailedCount = p134.AccessFailedCount
            };
        }
        
        private static ICollection<AppUserTokenReadModel> funcMain136(ICollection<AppUserToken> p147)
        {
            if (p147 == null)
            {
                return null;
            }
            ICollection<AppUserTokenReadModel> result = new List<AppUserTokenReadModel>(p147.Count);
            
            IEnumerator<AppUserToken> enumerator = p147.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserToken item = enumerator.Current;
                result.Add(item == null ? null : new AppUserTokenReadModel()
                {
                    Token = item.Token,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    LoginProvider = item.LoginProvider,
                    Name = item.Name,
                    Value = item.Value
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRefreshTokenReadModel> funcMain137(ICollection<AppRefreshToken> p148)
        {
            if (p148 == null)
            {
                return null;
            }
            ICollection<AppRefreshTokenReadModel> result = new List<AppRefreshTokenReadModel>(p148.Count);
            
            IEnumerator<AppRefreshToken> enumerator = p148.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRefreshToken item = enumerator.Current;
                result.Add(item == null ? null : new AppRefreshTokenReadModel()
                {
                    UserId = item.UserId,
                    Token = item.Token,
                    JwtId = item.JwtId,
                    IsUsed = item.IsUsed,
                    IsRevoked = item.IsRevoked,
                    ExpiryDate = item.ExpiryDate,
                    Hash = item.Hash,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static ICollection<AppAccessControlEntryReadModel> funcMain138(ICollection<AppAccessControlEntry> p149)
        {
            if (p149 == null)
            {
                return null;
            }
            ICollection<AppAccessControlEntryReadModel> result = new List<AppAccessControlEntryReadModel>(p149.Count);
            
            IEnumerator<AppAccessControlEntry> enumerator = p149.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppAccessControlEntry item = enumerator.Current;
                result.Add(funcMain139(item));
            }
            return result;
            
        }
        
        private static ICollection<AppRoleClaimReadModel> funcMain147(ICollection<AppRoleClaim> p158)
        {
            if (p158 == null)
            {
                return null;
            }
            ICollection<AppRoleClaimReadModel> result = new List<AppRoleClaimReadModel>(p158.Count);
            
            IEnumerator<AppRoleClaim> enumerator = p158.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRoleClaim item = enumerator.Current;
                result.Add(item == null ? null : new AppRoleClaimReadModel()
                {
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Id = item.Id,
                    RoleId = item.RoleId,
                    ClaimType = item.ClaimType,
                    ClaimValue = item.ClaimValue
                });
            }
            return result;
            
        }
        
        private static ICollection<AppAccessControlEntryReadModel> funcMain148(ICollection<AppAccessControlEntry> p159)
        {
            if (p159 == null)
            {
                return null;
            }
            ICollection<AppAccessControlEntryReadModel> result = new List<AppAccessControlEntryReadModel>(p159.Count);
            
            IEnumerator<AppAccessControlEntry> enumerator = p159.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppAccessControlEntry item = enumerator.Current;
                result.Add(funcMain149(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain160(ICollection<AppUserRole> p172)
        {
            if (p172 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p172.Count);
            
            IEnumerator<AppUserRole> enumerator = p172.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(funcMain161(item));
            }
            return result;
            
        }
        
        private static ICollection<AppRefreshTokenReadModel> funcMain170(ICollection<AppRefreshToken> p182)
        {
            if (p182 == null)
            {
                return null;
            }
            ICollection<AppRefreshTokenReadModel> result = new List<AppRefreshTokenReadModel>(p182.Count);
            
            IEnumerator<AppRefreshToken> enumerator = p182.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRefreshToken item = enumerator.Current;
                result.Add(item == null ? null : new AppRefreshTokenReadModel()
                {
                    UserId = item.UserId,
                    Token = item.Token,
                    JwtId = item.JwtId,
                    IsUsed = item.IsUsed,
                    IsRevoked = item.IsRevoked,
                    ExpiryDate = item.ExpiryDate,
                    Hash = item.Hash,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static ICollection<AppAccessControlEntryReadModel> funcMain171(ICollection<AppAccessControlEntry> p183)
        {
            if (p183 == null)
            {
                return null;
            }
            ICollection<AppAccessControlEntryReadModel> result = new List<AppAccessControlEntryReadModel>(p183.Count);
            
            IEnumerator<AppAccessControlEntry> enumerator = p183.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppAccessControlEntry item = enumerator.Current;
                result.Add(funcMain172(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain183(ICollection<AppUserRole> p196)
        {
            if (p196 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p196.Count);
            
            IEnumerator<AppUserRole> enumerator = p196.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(funcMain184(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserTokenReadModel> funcMain193(ICollection<AppUserToken> p206)
        {
            if (p206 == null)
            {
                return null;
            }
            ICollection<AppUserTokenReadModel> result = new List<AppUserTokenReadModel>(p206.Count);
            
            IEnumerator<AppUserToken> enumerator = p206.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserToken item = enumerator.Current;
                result.Add(item == null ? null : new AppUserTokenReadModel()
                {
                    Token = item.Token,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    LoginProvider = item.LoginProvider,
                    Name = item.Name,
                    Value = item.Value
                });
            }
            return result;
            
        }
        
        private static ICollection<AppAccessControlEntryReadModel> funcMain194(ICollection<AppAccessControlEntry> p207)
        {
            if (p207 == null)
            {
                return null;
            }
            ICollection<AppAccessControlEntryReadModel> result = new List<AppAccessControlEntryReadModel>(p207.Count);
            
            IEnumerator<AppAccessControlEntry> enumerator = p207.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppAccessControlEntry item = enumerator.Current;
                result.Add(funcMain195(item));
            }
            return result;
            
        }
        
        private static ICollection<AppFeatureFlagReadModel> funcMain206(ICollection<AppFeatureFlag> p220)
        {
            if (p220 == null)
            {
                return null;
            }
            ICollection<AppFeatureFlagReadModel> result = new List<AppFeatureFlagReadModel>(p220.Count);
            
            IEnumerator<AppFeatureFlag> enumerator = p220.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppFeatureFlag item = enumerator.Current;
                result.Add(item == null ? null : new AppFeatureFlagReadModel()
                {
                    FeatureId = item.FeatureId,
                    ScopeIdentifier = item.ScopeIdentifier,
                    IsEnabled = item.IsEnabled,
                    Feature = TypeAdapter<AppFeature, AppFeatureReadModel>.Map.Invoke(item.Feature),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static AppRoleReadModel funcMain208(AppRole p222)
        {
            return p222 == null ? null : new AppRoleReadModel()
            {
                CreatedBy = p222.CreatedBy,
                CreatedDate = p222.CreatedDate,
                ModifiedBy = p222.ModifiedBy,
                ModifiedDate = p222.ModifiedDate,
                IsDeleted = p222.IsDeleted,
                DeletedBy = p222.DeletedBy,
                DeletedDate = p222.DeletedDate,
                AppUserRoles = funcMain209(p222.AppUserRoles),
                AppRoleClaims = funcMain214(p222.AppRoleClaims),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p222.AccessControlEntries),
                Hash = p222.Hash,
                Id = p222.Id,
                Name = p222.Name,
                NormalizedName = p222.NormalizedName,
                ConcurrencyStamp = p222.ConcurrencyStamp
            };
        }
        
        private static AppUserReadModel funcMain216(AppUser p230)
        {
            return p230 == null ? null : new AppUserReadModel()
            {
                Hash = p230.Hash,
                FirstName = p230.FirstName,
                LastName = p230.LastName,
                Mobile = p230.Mobile,
                CountryCode = p230.CountryCode,
                TwoFactorMethod = p230.TwoFactorMethod,
                CreatedBy = p230.CreatedBy,
                CreatedDate = p230.CreatedDate,
                ModifiedBy = p230.ModifiedBy,
                ModifiedDate = p230.ModifiedDate,
                IsDeleted = p230.IsDeleted,
                DeletedBy = p230.DeletedBy,
                DeletedDate = p230.DeletedDate,
                MembershipType = p230.MembershipType,
                UserRoles = funcMain217(p230.UserRoles),
                UserTokens = funcMain221(p230.UserTokens),
                RefreshTokens = funcMain222(p230.RefreshTokens),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p230.AccessControlEntries),
                Id = p230.Id,
                UserName = p230.UserName,
                NormalizedUserName = p230.NormalizedUserName,
                Email = p230.Email,
                NormalizedEmail = p230.NormalizedEmail,
                EmailConfirmed = p230.EmailConfirmed,
                PasswordHash = p230.PasswordHash,
                SecurityStamp = p230.SecurityStamp,
                ConcurrencyStamp = p230.ConcurrencyStamp,
                PhoneNumber = p230.PhoneNumber,
                PhoneNumberConfirmed = p230.PhoneNumberConfirmed,
                TwoFactorEnabled = p230.TwoFactorEnabled,
                LockoutEnd = p230.LockoutEnd,
                LockoutEnabled = p230.LockoutEnabled,
                AccessFailedCount = p230.AccessFailedCount
            };
        }
        
        private static AppAccessControlEntryReadModel funcMain6(AppAccessControlEntry p7)
        {
            return p7 == null ? null : new AppAccessControlEntryReadModel()
            {
                ResourcePattern = p7.ResourcePattern,
                PermissionPattern = p7.PermissionPattern,
                FeatureId = p7.FeatureId,
                Feature = funcMain7(p7.Feature),
                AppRoles = funcMain9(p7.AppRoles),
                AppUsers = funcMain10(p7.AppUsers),
                AppResource = p7.AppResource == null ? null : new AppResourceReadModel()
                {
                    Url = p7.AppResource.Url,
                    Description = p7.AppResource.Description,
                    ResourceType = p7.AppResource.ResourceType,
                    AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p7.AppResource.AccessControlEntries),
                    Id = p7.AppResource.Id,
                    CreatedBy = p7.AppResource.CreatedBy,
                    CreatedDate = p7.AppResource.CreatedDate,
                    ModifiedBy = p7.AppResource.ModifiedBy,
                    ModifiedDate = p7.AppResource.ModifiedDate,
                    IsDeleted = p7.AppResource.IsDeleted,
                    DeletedBy = p7.AppResource.DeletedBy,
                    DeletedDate = p7.AppResource.DeletedDate
                },
                ResourceId = p7.ResourceId,
                Id = p7.Id,
                CreatedBy = p7.CreatedBy,
                CreatedDate = p7.CreatedDate,
                ModifiedBy = p7.ModifiedBy,
                ModifiedDate = p7.ModifiedDate,
                IsDeleted = p7.IsDeleted,
                DeletedBy = p7.DeletedBy,
                DeletedDate = p7.DeletedDate
            };
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain19(ICollection<AppUserRole> p20)
        {
            if (p20 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p20.Count);
            
            IEnumerator<AppUserRole> enumerator = p20.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(item == null ? null : new AppUserRoleReadModel()
                {
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Hash = item.Hash,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    RoleId = item.RoleId
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRoleClaimReadModel> funcMain20(ICollection<AppRoleClaim> p21)
        {
            if (p21 == null)
            {
                return null;
            }
            ICollection<AppRoleClaimReadModel> result = new List<AppRoleClaimReadModel>(p21.Count);
            
            IEnumerator<AppRoleClaim> enumerator = p21.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRoleClaim item = enumerator.Current;
                result.Add(item == null ? null : new AppRoleClaimReadModel()
                {
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Id = item.Id,
                    RoleId = item.RoleId,
                    ClaimType = item.ClaimType,
                    ClaimValue = item.ClaimValue
                });
            }
            return result;
            
        }
        
        private static AppAccessControlEntryReadModel funcMain27(AppAccessControlEntry p31)
        {
            return p31 == null ? null : new AppAccessControlEntryReadModel()
            {
                ResourcePattern = p31.ResourcePattern,
                PermissionPattern = p31.PermissionPattern,
                FeatureId = p31.FeatureId,
                Feature = funcMain28(p31.Feature),
                AppRoles = funcMain30(p31.AppRoles),
                AppUsers = funcMain31(p31.AppUsers),
                AppResource = p31.AppResource == null ? null : new AppResourceReadModel()
                {
                    Url = p31.AppResource.Url,
                    Description = p31.AppResource.Description,
                    ResourceType = p31.AppResource.ResourceType,
                    AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p31.AppResource.AccessControlEntries),
                    Id = p31.AppResource.Id,
                    CreatedBy = p31.AppResource.CreatedBy,
                    CreatedDate = p31.AppResource.CreatedDate,
                    ModifiedBy = p31.AppResource.ModifiedBy,
                    ModifiedDate = p31.AppResource.ModifiedDate,
                    IsDeleted = p31.AppResource.IsDeleted,
                    DeletedBy = p31.AppResource.DeletedBy,
                    DeletedDate = p31.AppResource.DeletedDate
                },
                ResourceId = p31.ResourceId,
                Id = p31.Id,
                CreatedBy = p31.CreatedBy,
                CreatedDate = p31.CreatedDate,
                ModifiedBy = p31.ModifiedBy,
                ModifiedDate = p31.ModifiedDate,
                IsDeleted = p31.IsDeleted,
                DeletedBy = p31.DeletedBy,
                DeletedDate = p31.DeletedDate
            };
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain40(ICollection<AppUserRole> p47)
        {
            if (p47 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p47.Count);
            
            IEnumerator<AppUserRole> enumerator = p47.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(item == null ? null : new AppUserRoleReadModel()
                {
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Hash = item.Hash,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    RoleId = item.RoleId
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRoleClaimReadModel> funcMain41(ICollection<AppRoleClaim> p48)
        {
            if (p48 == null)
            {
                return null;
            }
            ICollection<AppRoleClaimReadModel> result = new List<AppRoleClaimReadModel>(p48.Count);
            
            IEnumerator<AppRoleClaim> enumerator = p48.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRoleClaim item = enumerator.Current;
                result.Add(item == null ? null : new AppRoleClaimReadModel()
                {
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Id = item.Id,
                    RoleId = item.RoleId,
                    ClaimType = item.ClaimType,
                    ClaimValue = item.ClaimValue
                });
            }
            return result;
            
        }
        
        private static AppAccessControlEntryReadModel funcMain49(AppAccessControlEntry p57)
        {
            return p57 == null ? null : new AppAccessControlEntryReadModel()
            {
                ResourcePattern = p57.ResourcePattern,
                PermissionPattern = p57.PermissionPattern,
                FeatureId = p57.FeatureId,
                Feature = funcMain50(p57.Feature),
                AppRoles = funcMain52(p57.AppRoles),
                AppUsers = funcMain55(p57.AppUsers),
                AppResource = p57.AppResource == null ? null : new AppResourceReadModel()
                {
                    Url = p57.AppResource.Url,
                    Description = p57.AppResource.Description,
                    ResourceType = p57.AppResource.ResourceType,
                    AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p57.AppResource.AccessControlEntries),
                    Id = p57.AppResource.Id,
                    CreatedBy = p57.AppResource.CreatedBy,
                    CreatedDate = p57.AppResource.CreatedDate,
                    ModifiedBy = p57.AppResource.ModifiedBy,
                    ModifiedDate = p57.AppResource.ModifiedDate,
                    IsDeleted = p57.AppResource.IsDeleted,
                    DeletedBy = p57.AppResource.DeletedBy,
                    DeletedDate = p57.AppResource.DeletedDate
                },
                ResourceId = p57.ResourceId,
                Id = p57.Id,
                CreatedBy = p57.CreatedBy,
                CreatedDate = p57.CreatedDate,
                ModifiedBy = p57.ModifiedBy,
                ModifiedDate = p57.ModifiedDate,
                IsDeleted = p57.IsDeleted,
                DeletedBy = p57.DeletedBy,
                DeletedDate = p57.DeletedDate
            };
        }
        
        private static AppAccessControlEntryReadModel funcMain59(AppAccessControlEntry p67)
        {
            return p67 == null ? null : new AppAccessControlEntryReadModel()
            {
                ResourcePattern = p67.ResourcePattern,
                PermissionPattern = p67.PermissionPattern,
                FeatureId = p67.FeatureId,
                Feature = funcMain60(p67.Feature),
                AppRoles = funcMain62(p67.AppRoles),
                AppUsers = funcMain63(p67.AppUsers),
                AppResource = p67.AppResource == null ? null : new AppResourceReadModel()
                {
                    Url = p67.AppResource.Url,
                    Description = p67.AppResource.Description,
                    ResourceType = p67.AppResource.ResourceType,
                    AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p67.AppResource.AccessControlEntries),
                    Id = p67.AppResource.Id,
                    CreatedBy = p67.AppResource.CreatedBy,
                    CreatedDate = p67.AppResource.CreatedDate,
                    ModifiedBy = p67.AppResource.ModifiedBy,
                    ModifiedDate = p67.AppResource.ModifiedDate,
                    IsDeleted = p67.AppResource.IsDeleted,
                    DeletedBy = p67.AppResource.DeletedBy,
                    DeletedDate = p67.AppResource.DeletedDate
                },
                ResourceId = p67.ResourceId,
                Id = p67.Id,
                CreatedBy = p67.CreatedBy,
                CreatedDate = p67.CreatedDate,
                ModifiedBy = p67.ModifiedBy,
                ModifiedDate = p67.ModifiedDate,
                IsDeleted = p67.IsDeleted,
                DeletedBy = p67.DeletedBy,
                DeletedDate = p67.DeletedDate
            };
        }
        
        private static AppUserRoleReadModel funcMain71(AppUserRole p79)
        {
            return p79 == null ? null : new AppUserRoleReadModel()
            {
                AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(p79.AppUser),
                AppRole = funcMain72(p79.AppRole),
                Hash = p79.Hash,
                CreatedBy = p79.CreatedBy,
                CreatedDate = p79.CreatedDate,
                ModifiedBy = p79.ModifiedBy,
                ModifiedDate = p79.ModifiedDate,
                IsDeleted = p79.IsDeleted,
                DeletedBy = p79.DeletedBy,
                DeletedDate = p79.DeletedDate,
                UserId = p79.UserId,
                RoleId = p79.RoleId
            };
        }
        
        private static AppAccessControlEntryReadModel funcMain82(AppAccessControlEntry p90)
        {
            return p90 == null ? null : new AppAccessControlEntryReadModel()
            {
                ResourcePattern = p90.ResourcePattern,
                PermissionPattern = p90.PermissionPattern,
                FeatureId = p90.FeatureId,
                Feature = funcMain83(p90.Feature),
                AppRoles = funcMain85(p90.AppRoles),
                AppUsers = funcMain89(p90.AppUsers),
                AppResource = p90.AppResource == null ? null : new AppResourceReadModel()
                {
                    Url = p90.AppResource.Url,
                    Description = p90.AppResource.Description,
                    ResourceType = p90.AppResource.ResourceType,
                    AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p90.AppResource.AccessControlEntries),
                    Id = p90.AppResource.Id,
                    CreatedBy = p90.AppResource.CreatedBy,
                    CreatedDate = p90.AppResource.CreatedDate,
                    ModifiedBy = p90.AppResource.ModifiedBy,
                    ModifiedDate = p90.AppResource.ModifiedDate,
                    IsDeleted = p90.AppResource.IsDeleted,
                    DeletedBy = p90.AppResource.DeletedBy,
                    DeletedDate = p90.AppResource.DeletedDate
                },
                ResourceId = p90.ResourceId,
                Id = p90.Id,
                CreatedBy = p90.CreatedBy,
                CreatedDate = p90.CreatedDate,
                ModifiedBy = p90.ModifiedBy,
                ModifiedDate = p90.ModifiedDate,
                IsDeleted = p90.IsDeleted,
                DeletedBy = p90.DeletedBy,
                DeletedDate = p90.DeletedDate
            };
        }
        
        private static AppUserRoleReadModel funcMain94(AppUserRole p102)
        {
            return p102 == null ? null : new AppUserRoleReadModel()
            {
                AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(p102.AppUser),
                AppRole = funcMain95(p102.AppRole),
                Hash = p102.Hash,
                CreatedBy = p102.CreatedBy,
                CreatedDate = p102.CreatedDate,
                ModifiedBy = p102.ModifiedBy,
                ModifiedDate = p102.ModifiedDate,
                IsDeleted = p102.IsDeleted,
                DeletedBy = p102.DeletedBy,
                DeletedDate = p102.DeletedDate,
                UserId = p102.UserId,
                RoleId = p102.RoleId
            };
        }
        
        private static AppAccessControlEntryReadModel funcMain105(AppAccessControlEntry p113)
        {
            return p113 == null ? null : new AppAccessControlEntryReadModel()
            {
                ResourcePattern = p113.ResourcePattern,
                PermissionPattern = p113.PermissionPattern,
                FeatureId = p113.FeatureId,
                Feature = funcMain106(p113.Feature),
                AppRoles = funcMain108(p113.AppRoles),
                AppUsers = funcMain112(p113.AppUsers),
                AppResource = p113.AppResource == null ? null : new AppResourceReadModel()
                {
                    Url = p113.AppResource.Url,
                    Description = p113.AppResource.Description,
                    ResourceType = p113.AppResource.ResourceType,
                    AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p113.AppResource.AccessControlEntries),
                    Id = p113.AppResource.Id,
                    CreatedBy = p113.AppResource.CreatedBy,
                    CreatedDate = p113.AppResource.CreatedDate,
                    ModifiedBy = p113.AppResource.ModifiedBy,
                    ModifiedDate = p113.AppResource.ModifiedDate,
                    IsDeleted = p113.AppResource.IsDeleted,
                    DeletedBy = p113.AppResource.DeletedBy,
                    DeletedDate = p113.AppResource.DeletedDate
                },
                ResourceId = p113.ResourceId,
                Id = p113.Id,
                CreatedBy = p113.CreatedBy,
                CreatedDate = p113.CreatedDate,
                ModifiedBy = p113.ModifiedBy,
                ModifiedDate = p113.ModifiedDate,
                IsDeleted = p113.IsDeleted,
                DeletedBy = p113.DeletedBy,
                DeletedDate = p113.DeletedDate
            };
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain119(ICollection<AppUserRole> p127)
        {
            if (p127 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p127.Count);
            
            IEnumerator<AppUserRole> enumerator = p127.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(funcMain120(item));
            }
            return result;
            
        }
        
        private static ICollection<AppRoleClaimReadModel> funcMain124(ICollection<AppRoleClaim> p132)
        {
            if (p132 == null)
            {
                return null;
            }
            ICollection<AppRoleClaimReadModel> result = new List<AppRoleClaimReadModel>(p132.Count);
            
            IEnumerator<AppRoleClaim> enumerator = p132.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRoleClaim item = enumerator.Current;
                result.Add(item == null ? null : new AppRoleClaimReadModel()
                {
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Id = item.Id,
                    RoleId = item.RoleId,
                    ClaimType = item.ClaimType,
                    ClaimValue = item.ClaimValue
                });
            }
            return result;
            
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain127(ICollection<AppUserRole> p135)
        {
            if (p135 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p135.Count);
            
            IEnumerator<AppUserRole> enumerator = p135.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(funcMain128(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserTokenReadModel> funcMain131(ICollection<AppUserToken> p139)
        {
            if (p139 == null)
            {
                return null;
            }
            ICollection<AppUserTokenReadModel> result = new List<AppUserTokenReadModel>(p139.Count);
            
            IEnumerator<AppUserToken> enumerator = p139.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserToken item = enumerator.Current;
                result.Add(item == null ? null : new AppUserTokenReadModel()
                {
                    Token = item.Token,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    LoginProvider = item.LoginProvider,
                    Name = item.Name,
                    Value = item.Value
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRefreshTokenReadModel> funcMain132(ICollection<AppRefreshToken> p140)
        {
            if (p140 == null)
            {
                return null;
            }
            ICollection<AppRefreshTokenReadModel> result = new List<AppRefreshTokenReadModel>(p140.Count);
            
            IEnumerator<AppRefreshToken> enumerator = p140.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRefreshToken item = enumerator.Current;
                result.Add(item == null ? null : new AppRefreshTokenReadModel()
                {
                    UserId = item.UserId,
                    Token = item.Token,
                    JwtId = item.JwtId,
                    IsUsed = item.IsUsed,
                    IsRevoked = item.IsRevoked,
                    ExpiryDate = item.ExpiryDate,
                    Hash = item.Hash,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static AppAccessControlEntryReadModel funcMain139(AppAccessControlEntry p150)
        {
            return p150 == null ? null : new AppAccessControlEntryReadModel()
            {
                ResourcePattern = p150.ResourcePattern,
                PermissionPattern = p150.PermissionPattern,
                FeatureId = p150.FeatureId,
                Feature = funcMain140(p150.Feature),
                AppRoles = funcMain142(p150.AppRoles),
                AppUsers = funcMain145(p150.AppUsers),
                AppResource = p150.AppResource == null ? null : new AppResourceReadModel()
                {
                    Url = p150.AppResource.Url,
                    Description = p150.AppResource.Description,
                    ResourceType = p150.AppResource.ResourceType,
                    AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p150.AppResource.AccessControlEntries),
                    Id = p150.AppResource.Id,
                    CreatedBy = p150.AppResource.CreatedBy,
                    CreatedDate = p150.AppResource.CreatedDate,
                    ModifiedBy = p150.AppResource.ModifiedBy,
                    ModifiedDate = p150.AppResource.ModifiedDate,
                    IsDeleted = p150.AppResource.IsDeleted,
                    DeletedBy = p150.AppResource.DeletedBy,
                    DeletedDate = p150.AppResource.DeletedDate
                },
                ResourceId = p150.ResourceId,
                Id = p150.Id,
                CreatedBy = p150.CreatedBy,
                CreatedDate = p150.CreatedDate,
                ModifiedBy = p150.ModifiedBy,
                ModifiedDate = p150.ModifiedDate,
                IsDeleted = p150.IsDeleted,
                DeletedBy = p150.DeletedBy,
                DeletedDate = p150.DeletedDate
            };
        }
        
        private static AppAccessControlEntryReadModel funcMain149(AppAccessControlEntry p160)
        {
            return p160 == null ? null : new AppAccessControlEntryReadModel()
            {
                ResourcePattern = p160.ResourcePattern,
                PermissionPattern = p160.PermissionPattern,
                FeatureId = p160.FeatureId,
                Feature = funcMain150(p160.Feature),
                AppRoles = funcMain152(p160.AppRoles),
                AppUsers = funcMain153(p160.AppUsers),
                AppResource = p160.AppResource == null ? null : new AppResourceReadModel()
                {
                    Url = p160.AppResource.Url,
                    Description = p160.AppResource.Description,
                    ResourceType = p160.AppResource.ResourceType,
                    AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p160.AppResource.AccessControlEntries),
                    Id = p160.AppResource.Id,
                    CreatedBy = p160.AppResource.CreatedBy,
                    CreatedDate = p160.AppResource.CreatedDate,
                    ModifiedBy = p160.AppResource.ModifiedBy,
                    ModifiedDate = p160.AppResource.ModifiedDate,
                    IsDeleted = p160.AppResource.IsDeleted,
                    DeletedBy = p160.AppResource.DeletedBy,
                    DeletedDate = p160.AppResource.DeletedDate
                },
                ResourceId = p160.ResourceId,
                Id = p160.Id,
                CreatedBy = p160.CreatedBy,
                CreatedDate = p160.CreatedDate,
                ModifiedBy = p160.ModifiedBy,
                ModifiedDate = p160.ModifiedDate,
                IsDeleted = p160.IsDeleted,
                DeletedBy = p160.DeletedBy,
                DeletedDate = p160.DeletedDate
            };
        }
        
        private static AppUserRoleReadModel funcMain161(AppUserRole p173)
        {
            return p173 == null ? null : new AppUserRoleReadModel()
            {
                AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(p173.AppUser),
                AppRole = funcMain162(p173.AppRole),
                Hash = p173.Hash,
                CreatedBy = p173.CreatedBy,
                CreatedDate = p173.CreatedDate,
                ModifiedBy = p173.ModifiedBy,
                ModifiedDate = p173.ModifiedDate,
                IsDeleted = p173.IsDeleted,
                DeletedBy = p173.DeletedBy,
                DeletedDate = p173.DeletedDate,
                UserId = p173.UserId,
                RoleId = p173.RoleId
            };
        }
        
        private static AppAccessControlEntryReadModel funcMain172(AppAccessControlEntry p184)
        {
            return p184 == null ? null : new AppAccessControlEntryReadModel()
            {
                ResourcePattern = p184.ResourcePattern,
                PermissionPattern = p184.PermissionPattern,
                FeatureId = p184.FeatureId,
                Feature = funcMain173(p184.Feature),
                AppRoles = funcMain175(p184.AppRoles),
                AppUsers = funcMain179(p184.AppUsers),
                AppResource = p184.AppResource == null ? null : new AppResourceReadModel()
                {
                    Url = p184.AppResource.Url,
                    Description = p184.AppResource.Description,
                    ResourceType = p184.AppResource.ResourceType,
                    AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p184.AppResource.AccessControlEntries),
                    Id = p184.AppResource.Id,
                    CreatedBy = p184.AppResource.CreatedBy,
                    CreatedDate = p184.AppResource.CreatedDate,
                    ModifiedBy = p184.AppResource.ModifiedBy,
                    ModifiedDate = p184.AppResource.ModifiedDate,
                    IsDeleted = p184.AppResource.IsDeleted,
                    DeletedBy = p184.AppResource.DeletedBy,
                    DeletedDate = p184.AppResource.DeletedDate
                },
                ResourceId = p184.ResourceId,
                Id = p184.Id,
                CreatedBy = p184.CreatedBy,
                CreatedDate = p184.CreatedDate,
                ModifiedBy = p184.ModifiedBy,
                ModifiedDate = p184.ModifiedDate,
                IsDeleted = p184.IsDeleted,
                DeletedBy = p184.DeletedBy,
                DeletedDate = p184.DeletedDate
            };
        }
        
        private static AppUserRoleReadModel funcMain184(AppUserRole p197)
        {
            return p197 == null ? null : new AppUserRoleReadModel()
            {
                AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(p197.AppUser),
                AppRole = funcMain185(p197.AppRole),
                Hash = p197.Hash,
                CreatedBy = p197.CreatedBy,
                CreatedDate = p197.CreatedDate,
                ModifiedBy = p197.ModifiedBy,
                ModifiedDate = p197.ModifiedDate,
                IsDeleted = p197.IsDeleted,
                DeletedBy = p197.DeletedBy,
                DeletedDate = p197.DeletedDate,
                UserId = p197.UserId,
                RoleId = p197.RoleId
            };
        }
        
        private static AppAccessControlEntryReadModel funcMain195(AppAccessControlEntry p208)
        {
            return p208 == null ? null : new AppAccessControlEntryReadModel()
            {
                ResourcePattern = p208.ResourcePattern,
                PermissionPattern = p208.PermissionPattern,
                FeatureId = p208.FeatureId,
                Feature = funcMain196(p208.Feature),
                AppRoles = funcMain198(p208.AppRoles),
                AppUsers = funcMain202(p208.AppUsers),
                AppResource = p208.AppResource == null ? null : new AppResourceReadModel()
                {
                    Url = p208.AppResource.Url,
                    Description = p208.AppResource.Description,
                    ResourceType = p208.AppResource.ResourceType,
                    AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p208.AppResource.AccessControlEntries),
                    Id = p208.AppResource.Id,
                    CreatedBy = p208.AppResource.CreatedBy,
                    CreatedDate = p208.AppResource.CreatedDate,
                    ModifiedBy = p208.AppResource.ModifiedBy,
                    ModifiedDate = p208.AppResource.ModifiedDate,
                    IsDeleted = p208.AppResource.IsDeleted,
                    DeletedBy = p208.AppResource.DeletedBy,
                    DeletedDate = p208.AppResource.DeletedDate
                },
                ResourceId = p208.ResourceId,
                Id = p208.Id,
                CreatedBy = p208.CreatedBy,
                CreatedDate = p208.CreatedDate,
                ModifiedBy = p208.ModifiedBy,
                ModifiedDate = p208.ModifiedDate,
                IsDeleted = p208.IsDeleted,
                DeletedBy = p208.DeletedBy,
                DeletedDate = p208.DeletedDate
            };
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain209(ICollection<AppUserRole> p223)
        {
            if (p223 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p223.Count);
            
            IEnumerator<AppUserRole> enumerator = p223.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(funcMain210(item));
            }
            return result;
            
        }
        
        private static ICollection<AppRoleClaimReadModel> funcMain214(ICollection<AppRoleClaim> p228)
        {
            if (p228 == null)
            {
                return null;
            }
            ICollection<AppRoleClaimReadModel> result = new List<AppRoleClaimReadModel>(p228.Count);
            
            IEnumerator<AppRoleClaim> enumerator = p228.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRoleClaim item = enumerator.Current;
                result.Add(item == null ? null : new AppRoleClaimReadModel()
                {
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Id = item.Id,
                    RoleId = item.RoleId,
                    ClaimType = item.ClaimType,
                    ClaimValue = item.ClaimValue
                });
            }
            return result;
            
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain217(ICollection<AppUserRole> p231)
        {
            if (p231 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p231.Count);
            
            IEnumerator<AppUserRole> enumerator = p231.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(funcMain218(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserTokenReadModel> funcMain221(ICollection<AppUserToken> p235)
        {
            if (p235 == null)
            {
                return null;
            }
            ICollection<AppUserTokenReadModel> result = new List<AppUserTokenReadModel>(p235.Count);
            
            IEnumerator<AppUserToken> enumerator = p235.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserToken item = enumerator.Current;
                result.Add(item == null ? null : new AppUserTokenReadModel()
                {
                    Token = item.Token,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    LoginProvider = item.LoginProvider,
                    Name = item.Name,
                    Value = item.Value
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRefreshTokenReadModel> funcMain222(ICollection<AppRefreshToken> p236)
        {
            if (p236 == null)
            {
                return null;
            }
            ICollection<AppRefreshTokenReadModel> result = new List<AppRefreshTokenReadModel>(p236.Count);
            
            IEnumerator<AppRefreshToken> enumerator = p236.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRefreshToken item = enumerator.Current;
                result.Add(item == null ? null : new AppRefreshTokenReadModel()
                {
                    UserId = item.UserId,
                    Token = item.Token,
                    JwtId = item.JwtId,
                    IsUsed = item.IsUsed,
                    IsRevoked = item.IsRevoked,
                    ExpiryDate = item.ExpiryDate,
                    Hash = item.Hash,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static AppFeatureReadModel funcMain7(AppFeature p8)
        {
            return p8 == null ? null : new AppFeatureReadModel()
            {
                Name = p8.Name,
                Description = p8.Description,
                IsEnabled = p8.IsEnabled,
                Scope = p8.Scope,
                FeatureFlags = funcMain8(p8.FeatureFlags),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p8.AccessControlEntries),
                Id = p8.Id,
                CreatedBy = p8.CreatedBy,
                CreatedDate = p8.CreatedDate,
                ModifiedBy = p8.ModifiedBy,
                ModifiedDate = p8.ModifiedDate,
                IsDeleted = p8.IsDeleted,
                DeletedBy = p8.DeletedBy,
                DeletedDate = p8.DeletedDate
            };
        }
        
        private static ICollection<AppRoleReadModel> funcMain9(ICollection<AppRole> p10)
        {
            if (p10 == null)
            {
                return null;
            }
            ICollection<AppRoleReadModel> result = new List<AppRoleReadModel>(p10.Count);
            
            IEnumerator<AppRole> enumerator = p10.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRole item = enumerator.Current;
                result.Add(TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserReadModel> funcMain10(ICollection<AppUser> p11)
        {
            if (p11 == null)
            {
                return null;
            }
            ICollection<AppUserReadModel> result = new List<AppUserReadModel>(p11.Count);
            
            IEnumerator<AppUser> enumerator = p11.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUser item = enumerator.Current;
                result.Add(TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static AppFeatureReadModel funcMain28(AppFeature p32)
        {
            return p32 == null ? null : new AppFeatureReadModel()
            {
                Name = p32.Name,
                Description = p32.Description,
                IsEnabled = p32.IsEnabled,
                Scope = p32.Scope,
                FeatureFlags = funcMain29(p32.FeatureFlags),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p32.AccessControlEntries),
                Id = p32.Id,
                CreatedBy = p32.CreatedBy,
                CreatedDate = p32.CreatedDate,
                ModifiedBy = p32.ModifiedBy,
                ModifiedDate = p32.ModifiedDate,
                IsDeleted = p32.IsDeleted,
                DeletedBy = p32.DeletedBy,
                DeletedDate = p32.DeletedDate
            };
        }
        
        private static ICollection<AppRoleReadModel> funcMain30(ICollection<AppRole> p34)
        {
            if (p34 == null)
            {
                return null;
            }
            ICollection<AppRoleReadModel> result = new List<AppRoleReadModel>(p34.Count);
            
            IEnumerator<AppRole> enumerator = p34.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRole item = enumerator.Current;
                result.Add(TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserReadModel> funcMain31(ICollection<AppUser> p35)
        {
            if (p35 == null)
            {
                return null;
            }
            ICollection<AppUserReadModel> result = new List<AppUserReadModel>(p35.Count);
            
            IEnumerator<AppUser> enumerator = p35.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUser item = enumerator.Current;
                result.Add(TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static AppFeatureReadModel funcMain50(AppFeature p58)
        {
            return p58 == null ? null : new AppFeatureReadModel()
            {
                Name = p58.Name,
                Description = p58.Description,
                IsEnabled = p58.IsEnabled,
                Scope = p58.Scope,
                FeatureFlags = funcMain51(p58.FeatureFlags),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p58.AccessControlEntries),
                Id = p58.Id,
                CreatedBy = p58.CreatedBy,
                CreatedDate = p58.CreatedDate,
                ModifiedBy = p58.ModifiedBy,
                ModifiedDate = p58.ModifiedDate,
                IsDeleted = p58.IsDeleted,
                DeletedBy = p58.DeletedBy,
                DeletedDate = p58.DeletedDate
            };
        }
        
        private static ICollection<AppRoleReadModel> funcMain52(ICollection<AppRole> p60)
        {
            if (p60 == null)
            {
                return null;
            }
            ICollection<AppRoleReadModel> result = new List<AppRoleReadModel>(p60.Count);
            
            IEnumerator<AppRole> enumerator = p60.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRole item = enumerator.Current;
                result.Add(funcMain53(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserReadModel> funcMain55(ICollection<AppUser> p63)
        {
            if (p63 == null)
            {
                return null;
            }
            ICollection<AppUserReadModel> result = new List<AppUserReadModel>(p63.Count);
            
            IEnumerator<AppUser> enumerator = p63.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUser item = enumerator.Current;
                result.Add(TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static AppFeatureReadModel funcMain60(AppFeature p68)
        {
            return p68 == null ? null : new AppFeatureReadModel()
            {
                Name = p68.Name,
                Description = p68.Description,
                IsEnabled = p68.IsEnabled,
                Scope = p68.Scope,
                FeatureFlags = funcMain61(p68.FeatureFlags),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p68.AccessControlEntries),
                Id = p68.Id,
                CreatedBy = p68.CreatedBy,
                CreatedDate = p68.CreatedDate,
                ModifiedBy = p68.ModifiedBy,
                ModifiedDate = p68.ModifiedDate,
                IsDeleted = p68.IsDeleted,
                DeletedBy = p68.DeletedBy,
                DeletedDate = p68.DeletedDate
            };
        }
        
        private static ICollection<AppRoleReadModel> funcMain62(ICollection<AppRole> p70)
        {
            if (p70 == null)
            {
                return null;
            }
            ICollection<AppRoleReadModel> result = new List<AppRoleReadModel>(p70.Count);
            
            IEnumerator<AppRole> enumerator = p70.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRole item = enumerator.Current;
                result.Add(TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserReadModel> funcMain63(ICollection<AppUser> p71)
        {
            if (p71 == null)
            {
                return null;
            }
            ICollection<AppUserReadModel> result = new List<AppUserReadModel>(p71.Count);
            
            IEnumerator<AppUser> enumerator = p71.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUser item = enumerator.Current;
                result.Add(funcMain64(item));
            }
            return result;
            
        }
        
        private static AppRoleReadModel funcMain72(AppRole p80)
        {
            return p80 == null ? null : new AppRoleReadModel()
            {
                CreatedBy = p80.CreatedBy,
                CreatedDate = p80.CreatedDate,
                ModifiedBy = p80.ModifiedBy,
                ModifiedDate = p80.ModifiedDate,
                IsDeleted = p80.IsDeleted,
                DeletedBy = p80.DeletedBy,
                DeletedDate = p80.DeletedDate,
                AppUserRoles = TypeAdapter<ICollection<AppUserRole>, ICollection<AppUserRoleReadModel>>.Map.Invoke(p80.AppUserRoles),
                AppRoleClaims = funcMain73(p80.AppRoleClaims),
                AccessControlEntries = funcMain74(p80.AccessControlEntries),
                Hash = p80.Hash,
                Id = p80.Id,
                Name = p80.Name,
                NormalizedName = p80.NormalizedName,
                ConcurrencyStamp = p80.ConcurrencyStamp
            };
        }
        
        private static AppFeatureReadModel funcMain83(AppFeature p91)
        {
            return p91 == null ? null : new AppFeatureReadModel()
            {
                Name = p91.Name,
                Description = p91.Description,
                IsEnabled = p91.IsEnabled,
                Scope = p91.Scope,
                FeatureFlags = funcMain84(p91.FeatureFlags),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p91.AccessControlEntries),
                Id = p91.Id,
                CreatedBy = p91.CreatedBy,
                CreatedDate = p91.CreatedDate,
                ModifiedBy = p91.ModifiedBy,
                ModifiedDate = p91.ModifiedDate,
                IsDeleted = p91.IsDeleted,
                DeletedBy = p91.DeletedBy,
                DeletedDate = p91.DeletedDate
            };
        }
        
        private static ICollection<AppRoleReadModel> funcMain85(ICollection<AppRole> p93)
        {
            if (p93 == null)
            {
                return null;
            }
            ICollection<AppRoleReadModel> result = new List<AppRoleReadModel>(p93.Count);
            
            IEnumerator<AppRole> enumerator = p93.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRole item = enumerator.Current;
                result.Add(funcMain86(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserReadModel> funcMain89(ICollection<AppUser> p97)
        {
            if (p97 == null)
            {
                return null;
            }
            ICollection<AppUserReadModel> result = new List<AppUserReadModel>(p97.Count);
            
            IEnumerator<AppUser> enumerator = p97.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUser item = enumerator.Current;
                result.Add(TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static AppRoleReadModel funcMain95(AppRole p103)
        {
            return p103 == null ? null : new AppRoleReadModel()
            {
                CreatedBy = p103.CreatedBy,
                CreatedDate = p103.CreatedDate,
                ModifiedBy = p103.ModifiedBy,
                ModifiedDate = p103.ModifiedDate,
                IsDeleted = p103.IsDeleted,
                DeletedBy = p103.DeletedBy,
                DeletedDate = p103.DeletedDate,
                AppUserRoles = TypeAdapter<ICollection<AppUserRole>, ICollection<AppUserRoleReadModel>>.Map.Invoke(p103.AppUserRoles),
                AppRoleClaims = funcMain96(p103.AppRoleClaims),
                AccessControlEntries = funcMain97(p103.AccessControlEntries),
                Hash = p103.Hash,
                Id = p103.Id,
                Name = p103.Name,
                NormalizedName = p103.NormalizedName,
                ConcurrencyStamp = p103.ConcurrencyStamp
            };
        }
        
        private static AppFeatureReadModel funcMain106(AppFeature p114)
        {
            return p114 == null ? null : new AppFeatureReadModel()
            {
                Name = p114.Name,
                Description = p114.Description,
                IsEnabled = p114.IsEnabled,
                Scope = p114.Scope,
                FeatureFlags = funcMain107(p114.FeatureFlags),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p114.AccessControlEntries),
                Id = p114.Id,
                CreatedBy = p114.CreatedBy,
                CreatedDate = p114.CreatedDate,
                ModifiedBy = p114.ModifiedBy,
                ModifiedDate = p114.ModifiedDate,
                IsDeleted = p114.IsDeleted,
                DeletedBy = p114.DeletedBy,
                DeletedDate = p114.DeletedDate
            };
        }
        
        private static ICollection<AppRoleReadModel> funcMain108(ICollection<AppRole> p116)
        {
            if (p116 == null)
            {
                return null;
            }
            ICollection<AppRoleReadModel> result = new List<AppRoleReadModel>(p116.Count);
            
            IEnumerator<AppRole> enumerator = p116.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRole item = enumerator.Current;
                result.Add(funcMain109(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserReadModel> funcMain112(ICollection<AppUser> p120)
        {
            if (p120 == null)
            {
                return null;
            }
            ICollection<AppUserReadModel> result = new List<AppUserReadModel>(p120.Count);
            
            IEnumerator<AppUser> enumerator = p120.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUser item = enumerator.Current;
                result.Add(TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static AppUserRoleReadModel funcMain120(AppUserRole p128)
        {
            return p128 == null ? null : new AppUserRoleReadModel()
            {
                AppUser = funcMain121(p128.AppUser),
                AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(p128.AppRole),
                Hash = p128.Hash,
                CreatedBy = p128.CreatedBy,
                CreatedDate = p128.CreatedDate,
                ModifiedBy = p128.ModifiedBy,
                ModifiedDate = p128.ModifiedDate,
                IsDeleted = p128.IsDeleted,
                DeletedBy = p128.DeletedBy,
                DeletedDate = p128.DeletedDate,
                UserId = p128.UserId,
                RoleId = p128.RoleId
            };
        }
        
        private static AppUserRoleReadModel funcMain128(AppUserRole p136)
        {
            return p136 == null ? null : new AppUserRoleReadModel()
            {
                AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(p136.AppUser),
                AppRole = funcMain129(p136.AppRole),
                Hash = p136.Hash,
                CreatedBy = p136.CreatedBy,
                CreatedDate = p136.CreatedDate,
                ModifiedBy = p136.ModifiedBy,
                ModifiedDate = p136.ModifiedDate,
                IsDeleted = p136.IsDeleted,
                DeletedBy = p136.DeletedBy,
                DeletedDate = p136.DeletedDate,
                UserId = p136.UserId,
                RoleId = p136.RoleId
            };
        }
        
        private static AppFeatureReadModel funcMain140(AppFeature p151)
        {
            return p151 == null ? null : new AppFeatureReadModel()
            {
                Name = p151.Name,
                Description = p151.Description,
                IsEnabled = p151.IsEnabled,
                Scope = p151.Scope,
                FeatureFlags = funcMain141(p151.FeatureFlags),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p151.AccessControlEntries),
                Id = p151.Id,
                CreatedBy = p151.CreatedBy,
                CreatedDate = p151.CreatedDate,
                ModifiedBy = p151.ModifiedBy,
                ModifiedDate = p151.ModifiedDate,
                IsDeleted = p151.IsDeleted,
                DeletedBy = p151.DeletedBy,
                DeletedDate = p151.DeletedDate
            };
        }
        
        private static ICollection<AppRoleReadModel> funcMain142(ICollection<AppRole> p153)
        {
            if (p153 == null)
            {
                return null;
            }
            ICollection<AppRoleReadModel> result = new List<AppRoleReadModel>(p153.Count);
            
            IEnumerator<AppRole> enumerator = p153.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRole item = enumerator.Current;
                result.Add(funcMain143(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserReadModel> funcMain145(ICollection<AppUser> p156)
        {
            if (p156 == null)
            {
                return null;
            }
            ICollection<AppUserReadModel> result = new List<AppUserReadModel>(p156.Count);
            
            IEnumerator<AppUser> enumerator = p156.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUser item = enumerator.Current;
                result.Add(TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static AppFeatureReadModel funcMain150(AppFeature p161)
        {
            return p161 == null ? null : new AppFeatureReadModel()
            {
                Name = p161.Name,
                Description = p161.Description,
                IsEnabled = p161.IsEnabled,
                Scope = p161.Scope,
                FeatureFlags = funcMain151(p161.FeatureFlags),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p161.AccessControlEntries),
                Id = p161.Id,
                CreatedBy = p161.CreatedBy,
                CreatedDate = p161.CreatedDate,
                ModifiedBy = p161.ModifiedBy,
                ModifiedDate = p161.ModifiedDate,
                IsDeleted = p161.IsDeleted,
                DeletedBy = p161.DeletedBy,
                DeletedDate = p161.DeletedDate
            };
        }
        
        private static ICollection<AppRoleReadModel> funcMain152(ICollection<AppRole> p163)
        {
            if (p163 == null)
            {
                return null;
            }
            ICollection<AppRoleReadModel> result = new List<AppRoleReadModel>(p163.Count);
            
            IEnumerator<AppRole> enumerator = p163.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRole item = enumerator.Current;
                result.Add(TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserReadModel> funcMain153(ICollection<AppUser> p164)
        {
            if (p164 == null)
            {
                return null;
            }
            ICollection<AppUserReadModel> result = new List<AppUserReadModel>(p164.Count);
            
            IEnumerator<AppUser> enumerator = p164.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUser item = enumerator.Current;
                result.Add(funcMain154(item));
            }
            return result;
            
        }
        
        private static AppRoleReadModel funcMain162(AppRole p174)
        {
            return p174 == null ? null : new AppRoleReadModel()
            {
                CreatedBy = p174.CreatedBy,
                CreatedDate = p174.CreatedDate,
                ModifiedBy = p174.ModifiedBy,
                ModifiedDate = p174.ModifiedDate,
                IsDeleted = p174.IsDeleted,
                DeletedBy = p174.DeletedBy,
                DeletedDate = p174.DeletedDate,
                AppUserRoles = TypeAdapter<ICollection<AppUserRole>, ICollection<AppUserRoleReadModel>>.Map.Invoke(p174.AppUserRoles),
                AppRoleClaims = funcMain163(p174.AppRoleClaims),
                AccessControlEntries = funcMain164(p174.AccessControlEntries),
                Hash = p174.Hash,
                Id = p174.Id,
                Name = p174.Name,
                NormalizedName = p174.NormalizedName,
                ConcurrencyStamp = p174.ConcurrencyStamp
            };
        }
        
        private static AppFeatureReadModel funcMain173(AppFeature p185)
        {
            return p185 == null ? null : new AppFeatureReadModel()
            {
                Name = p185.Name,
                Description = p185.Description,
                IsEnabled = p185.IsEnabled,
                Scope = p185.Scope,
                FeatureFlags = funcMain174(p185.FeatureFlags),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p185.AccessControlEntries),
                Id = p185.Id,
                CreatedBy = p185.CreatedBy,
                CreatedDate = p185.CreatedDate,
                ModifiedBy = p185.ModifiedBy,
                ModifiedDate = p185.ModifiedDate,
                IsDeleted = p185.IsDeleted,
                DeletedBy = p185.DeletedBy,
                DeletedDate = p185.DeletedDate
            };
        }
        
        private static ICollection<AppRoleReadModel> funcMain175(ICollection<AppRole> p187)
        {
            if (p187 == null)
            {
                return null;
            }
            ICollection<AppRoleReadModel> result = new List<AppRoleReadModel>(p187.Count);
            
            IEnumerator<AppRole> enumerator = p187.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRole item = enumerator.Current;
                result.Add(funcMain176(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserReadModel> funcMain179(ICollection<AppUser> p191)
        {
            if (p191 == null)
            {
                return null;
            }
            ICollection<AppUserReadModel> result = new List<AppUserReadModel>(p191.Count);
            
            IEnumerator<AppUser> enumerator = p191.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUser item = enumerator.Current;
                result.Add(TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static AppRoleReadModel funcMain185(AppRole p198)
        {
            return p198 == null ? null : new AppRoleReadModel()
            {
                CreatedBy = p198.CreatedBy,
                CreatedDate = p198.CreatedDate,
                ModifiedBy = p198.ModifiedBy,
                ModifiedDate = p198.ModifiedDate,
                IsDeleted = p198.IsDeleted,
                DeletedBy = p198.DeletedBy,
                DeletedDate = p198.DeletedDate,
                AppUserRoles = TypeAdapter<ICollection<AppUserRole>, ICollection<AppUserRoleReadModel>>.Map.Invoke(p198.AppUserRoles),
                AppRoleClaims = funcMain186(p198.AppRoleClaims),
                AccessControlEntries = funcMain187(p198.AccessControlEntries),
                Hash = p198.Hash,
                Id = p198.Id,
                Name = p198.Name,
                NormalizedName = p198.NormalizedName,
                ConcurrencyStamp = p198.ConcurrencyStamp
            };
        }
        
        private static AppFeatureReadModel funcMain196(AppFeature p209)
        {
            return p209 == null ? null : new AppFeatureReadModel()
            {
                Name = p209.Name,
                Description = p209.Description,
                IsEnabled = p209.IsEnabled,
                Scope = p209.Scope,
                FeatureFlags = funcMain197(p209.FeatureFlags),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p209.AccessControlEntries),
                Id = p209.Id,
                CreatedBy = p209.CreatedBy,
                CreatedDate = p209.CreatedDate,
                ModifiedBy = p209.ModifiedBy,
                ModifiedDate = p209.ModifiedDate,
                IsDeleted = p209.IsDeleted,
                DeletedBy = p209.DeletedBy,
                DeletedDate = p209.DeletedDate
            };
        }
        
        private static ICollection<AppRoleReadModel> funcMain198(ICollection<AppRole> p211)
        {
            if (p211 == null)
            {
                return null;
            }
            ICollection<AppRoleReadModel> result = new List<AppRoleReadModel>(p211.Count);
            
            IEnumerator<AppRole> enumerator = p211.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRole item = enumerator.Current;
                result.Add(funcMain199(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserReadModel> funcMain202(ICollection<AppUser> p215)
        {
            if (p215 == null)
            {
                return null;
            }
            ICollection<AppUserReadModel> result = new List<AppUserReadModel>(p215.Count);
            
            IEnumerator<AppUser> enumerator = p215.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUser item = enumerator.Current;
                result.Add(TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static AppUserRoleReadModel funcMain210(AppUserRole p224)
        {
            return p224 == null ? null : new AppUserRoleReadModel()
            {
                AppUser = funcMain211(p224.AppUser),
                AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(p224.AppRole),
                Hash = p224.Hash,
                CreatedBy = p224.CreatedBy,
                CreatedDate = p224.CreatedDate,
                ModifiedBy = p224.ModifiedBy,
                ModifiedDate = p224.ModifiedDate,
                IsDeleted = p224.IsDeleted,
                DeletedBy = p224.DeletedBy,
                DeletedDate = p224.DeletedDate,
                UserId = p224.UserId,
                RoleId = p224.RoleId
            };
        }
        
        private static AppUserRoleReadModel funcMain218(AppUserRole p232)
        {
            return p232 == null ? null : new AppUserRoleReadModel()
            {
                AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(p232.AppUser),
                AppRole = funcMain219(p232.AppRole),
                Hash = p232.Hash,
                CreatedBy = p232.CreatedBy,
                CreatedDate = p232.CreatedDate,
                ModifiedBy = p232.ModifiedBy,
                ModifiedDate = p232.ModifiedDate,
                IsDeleted = p232.IsDeleted,
                DeletedBy = p232.DeletedBy,
                DeletedDate = p232.DeletedDate,
                UserId = p232.UserId,
                RoleId = p232.RoleId
            };
        }
        
        private static ICollection<AppFeatureFlagReadModel> funcMain8(ICollection<AppFeatureFlag> p9)
        {
            if (p9 == null)
            {
                return null;
            }
            ICollection<AppFeatureFlagReadModel> result = new List<AppFeatureFlagReadModel>(p9.Count);
            
            IEnumerator<AppFeatureFlag> enumerator = p9.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppFeatureFlag item = enumerator.Current;
                result.Add(item == null ? null : new AppFeatureFlagReadModel()
                {
                    FeatureId = item.FeatureId,
                    ScopeIdentifier = item.ScopeIdentifier,
                    IsEnabled = item.IsEnabled,
                    Feature = TypeAdapter<AppFeature, AppFeatureReadModel>.Map.Invoke(item.Feature),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static ICollection<AppFeatureFlagReadModel> funcMain29(ICollection<AppFeatureFlag> p33)
        {
            if (p33 == null)
            {
                return null;
            }
            ICollection<AppFeatureFlagReadModel> result = new List<AppFeatureFlagReadModel>(p33.Count);
            
            IEnumerator<AppFeatureFlag> enumerator = p33.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppFeatureFlag item = enumerator.Current;
                result.Add(item == null ? null : new AppFeatureFlagReadModel()
                {
                    FeatureId = item.FeatureId,
                    ScopeIdentifier = item.ScopeIdentifier,
                    IsEnabled = item.IsEnabled,
                    Feature = TypeAdapter<AppFeature, AppFeatureReadModel>.Map.Invoke(item.Feature),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static ICollection<AppFeatureFlagReadModel> funcMain51(ICollection<AppFeatureFlag> p59)
        {
            if (p59 == null)
            {
                return null;
            }
            ICollection<AppFeatureFlagReadModel> result = new List<AppFeatureFlagReadModel>(p59.Count);
            
            IEnumerator<AppFeatureFlag> enumerator = p59.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppFeatureFlag item = enumerator.Current;
                result.Add(item == null ? null : new AppFeatureFlagReadModel()
                {
                    FeatureId = item.FeatureId,
                    ScopeIdentifier = item.ScopeIdentifier,
                    IsEnabled = item.IsEnabled,
                    Feature = TypeAdapter<AppFeature, AppFeatureReadModel>.Map.Invoke(item.Feature),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static AppRoleReadModel funcMain53(AppRole p61)
        {
            return p61 == null ? null : new AppRoleReadModel()
            {
                CreatedBy = p61.CreatedBy,
                CreatedDate = p61.CreatedDate,
                ModifiedBy = p61.ModifiedBy,
                ModifiedDate = p61.ModifiedDate,
                IsDeleted = p61.IsDeleted,
                DeletedBy = p61.DeletedBy,
                DeletedDate = p61.DeletedDate,
                AppUserRoles = TypeAdapter<ICollection<AppUserRole>, ICollection<AppUserRoleReadModel>>.Map.Invoke(p61.AppUserRoles),
                AppRoleClaims = funcMain54(p61.AppRoleClaims),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p61.AccessControlEntries),
                Hash = p61.Hash,
                Id = p61.Id,
                Name = p61.Name,
                NormalizedName = p61.NormalizedName,
                ConcurrencyStamp = p61.ConcurrencyStamp
            };
        }
        
        private static ICollection<AppFeatureFlagReadModel> funcMain61(ICollection<AppFeatureFlag> p69)
        {
            if (p69 == null)
            {
                return null;
            }
            ICollection<AppFeatureFlagReadModel> result = new List<AppFeatureFlagReadModel>(p69.Count);
            
            IEnumerator<AppFeatureFlag> enumerator = p69.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppFeatureFlag item = enumerator.Current;
                result.Add(item == null ? null : new AppFeatureFlagReadModel()
                {
                    FeatureId = item.FeatureId,
                    ScopeIdentifier = item.ScopeIdentifier,
                    IsEnabled = item.IsEnabled,
                    Feature = TypeAdapter<AppFeature, AppFeatureReadModel>.Map.Invoke(item.Feature),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static AppUserReadModel funcMain64(AppUser p72)
        {
            return p72 == null ? null : new AppUserReadModel()
            {
                Hash = p72.Hash,
                FirstName = p72.FirstName,
                LastName = p72.LastName,
                Mobile = p72.Mobile,
                CountryCode = p72.CountryCode,
                TwoFactorMethod = p72.TwoFactorMethod,
                CreatedBy = p72.CreatedBy,
                CreatedDate = p72.CreatedDate,
                ModifiedBy = p72.ModifiedBy,
                ModifiedDate = p72.ModifiedDate,
                IsDeleted = p72.IsDeleted,
                DeletedBy = p72.DeletedBy,
                DeletedDate = p72.DeletedDate,
                MembershipType = p72.MembershipType,
                UserRoles = TypeAdapter<ICollection<AppUserRole>, ICollection<AppUserRoleReadModel>>.Map.Invoke(p72.UserRoles),
                UserTokens = funcMain65(p72.UserTokens),
                RefreshTokens = funcMain66(p72.RefreshTokens),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p72.AccessControlEntries),
                Id = p72.Id,
                UserName = p72.UserName,
                NormalizedUserName = p72.NormalizedUserName,
                Email = p72.Email,
                NormalizedEmail = p72.NormalizedEmail,
                EmailConfirmed = p72.EmailConfirmed,
                PasswordHash = p72.PasswordHash,
                SecurityStamp = p72.SecurityStamp,
                ConcurrencyStamp = p72.ConcurrencyStamp,
                PhoneNumber = p72.PhoneNumber,
                PhoneNumberConfirmed = p72.PhoneNumberConfirmed,
                TwoFactorEnabled = p72.TwoFactorEnabled,
                LockoutEnd = p72.LockoutEnd,
                LockoutEnabled = p72.LockoutEnabled,
                AccessFailedCount = p72.AccessFailedCount
            };
        }
        
        private static ICollection<AppRoleClaimReadModel> funcMain73(ICollection<AppRoleClaim> p81)
        {
            if (p81 == null)
            {
                return null;
            }
            ICollection<AppRoleClaimReadModel> result = new List<AppRoleClaimReadModel>(p81.Count);
            
            IEnumerator<AppRoleClaim> enumerator = p81.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRoleClaim item = enumerator.Current;
                result.Add(item == null ? null : new AppRoleClaimReadModel()
                {
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Id = item.Id,
                    RoleId = item.RoleId,
                    ClaimType = item.ClaimType,
                    ClaimValue = item.ClaimValue
                });
            }
            return result;
            
        }
        
        private static ICollection<AppAccessControlEntryReadModel> funcMain74(ICollection<AppAccessControlEntry> p82)
        {
            if (p82 == null)
            {
                return null;
            }
            ICollection<AppAccessControlEntryReadModel> result = new List<AppAccessControlEntryReadModel>(p82.Count);
            
            IEnumerator<AppAccessControlEntry> enumerator = p82.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppAccessControlEntry item = enumerator.Current;
                result.Add(funcMain75(item));
            }
            return result;
            
        }
        
        private static ICollection<AppFeatureFlagReadModel> funcMain84(ICollection<AppFeatureFlag> p92)
        {
            if (p92 == null)
            {
                return null;
            }
            ICollection<AppFeatureFlagReadModel> result = new List<AppFeatureFlagReadModel>(p92.Count);
            
            IEnumerator<AppFeatureFlag> enumerator = p92.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppFeatureFlag item = enumerator.Current;
                result.Add(item == null ? null : new AppFeatureFlagReadModel()
                {
                    FeatureId = item.FeatureId,
                    ScopeIdentifier = item.ScopeIdentifier,
                    IsEnabled = item.IsEnabled,
                    Feature = TypeAdapter<AppFeature, AppFeatureReadModel>.Map.Invoke(item.Feature),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static AppRoleReadModel funcMain86(AppRole p94)
        {
            return p94 == null ? null : new AppRoleReadModel()
            {
                CreatedBy = p94.CreatedBy,
                CreatedDate = p94.CreatedDate,
                ModifiedBy = p94.ModifiedBy,
                ModifiedDate = p94.ModifiedDate,
                IsDeleted = p94.IsDeleted,
                DeletedBy = p94.DeletedBy,
                DeletedDate = p94.DeletedDate,
                AppUserRoles = funcMain87(p94.AppUserRoles),
                AppRoleClaims = funcMain88(p94.AppRoleClaims),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p94.AccessControlEntries),
                Hash = p94.Hash,
                Id = p94.Id,
                Name = p94.Name,
                NormalizedName = p94.NormalizedName,
                ConcurrencyStamp = p94.ConcurrencyStamp
            };
        }
        
        private static ICollection<AppRoleClaimReadModel> funcMain96(ICollection<AppRoleClaim> p104)
        {
            if (p104 == null)
            {
                return null;
            }
            ICollection<AppRoleClaimReadModel> result = new List<AppRoleClaimReadModel>(p104.Count);
            
            IEnumerator<AppRoleClaim> enumerator = p104.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRoleClaim item = enumerator.Current;
                result.Add(item == null ? null : new AppRoleClaimReadModel()
                {
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Id = item.Id,
                    RoleId = item.RoleId,
                    ClaimType = item.ClaimType,
                    ClaimValue = item.ClaimValue
                });
            }
            return result;
            
        }
        
        private static ICollection<AppAccessControlEntryReadModel> funcMain97(ICollection<AppAccessControlEntry> p105)
        {
            if (p105 == null)
            {
                return null;
            }
            ICollection<AppAccessControlEntryReadModel> result = new List<AppAccessControlEntryReadModel>(p105.Count);
            
            IEnumerator<AppAccessControlEntry> enumerator = p105.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppAccessControlEntry item = enumerator.Current;
                result.Add(funcMain98(item));
            }
            return result;
            
        }
        
        private static ICollection<AppFeatureFlagReadModel> funcMain107(ICollection<AppFeatureFlag> p115)
        {
            if (p115 == null)
            {
                return null;
            }
            ICollection<AppFeatureFlagReadModel> result = new List<AppFeatureFlagReadModel>(p115.Count);
            
            IEnumerator<AppFeatureFlag> enumerator = p115.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppFeatureFlag item = enumerator.Current;
                result.Add(item == null ? null : new AppFeatureFlagReadModel()
                {
                    FeatureId = item.FeatureId,
                    ScopeIdentifier = item.ScopeIdentifier,
                    IsEnabled = item.IsEnabled,
                    Feature = TypeAdapter<AppFeature, AppFeatureReadModel>.Map.Invoke(item.Feature),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static AppRoleReadModel funcMain109(AppRole p117)
        {
            return p117 == null ? null : new AppRoleReadModel()
            {
                CreatedBy = p117.CreatedBy,
                CreatedDate = p117.CreatedDate,
                ModifiedBy = p117.ModifiedBy,
                ModifiedDate = p117.ModifiedDate,
                IsDeleted = p117.IsDeleted,
                DeletedBy = p117.DeletedBy,
                DeletedDate = p117.DeletedDate,
                AppUserRoles = funcMain110(p117.AppUserRoles),
                AppRoleClaims = funcMain111(p117.AppRoleClaims),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p117.AccessControlEntries),
                Hash = p117.Hash,
                Id = p117.Id,
                Name = p117.Name,
                NormalizedName = p117.NormalizedName,
                ConcurrencyStamp = p117.ConcurrencyStamp
            };
        }
        
        private static AppUserReadModel funcMain121(AppUser p129)
        {
            return p129 == null ? null : new AppUserReadModel()
            {
                Hash = p129.Hash,
                FirstName = p129.FirstName,
                LastName = p129.LastName,
                Mobile = p129.Mobile,
                CountryCode = p129.CountryCode,
                TwoFactorMethod = p129.TwoFactorMethod,
                CreatedBy = p129.CreatedBy,
                CreatedDate = p129.CreatedDate,
                ModifiedBy = p129.ModifiedBy,
                ModifiedDate = p129.ModifiedDate,
                IsDeleted = p129.IsDeleted,
                DeletedBy = p129.DeletedBy,
                DeletedDate = p129.DeletedDate,
                MembershipType = p129.MembershipType,
                UserRoles = TypeAdapter<ICollection<AppUserRole>, ICollection<AppUserRoleReadModel>>.Map.Invoke(p129.UserRoles),
                UserTokens = funcMain122(p129.UserTokens),
                RefreshTokens = funcMain123(p129.RefreshTokens),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p129.AccessControlEntries),
                Id = p129.Id,
                UserName = p129.UserName,
                NormalizedUserName = p129.NormalizedUserName,
                Email = p129.Email,
                NormalizedEmail = p129.NormalizedEmail,
                EmailConfirmed = p129.EmailConfirmed,
                PasswordHash = p129.PasswordHash,
                SecurityStamp = p129.SecurityStamp,
                ConcurrencyStamp = p129.ConcurrencyStamp,
                PhoneNumber = p129.PhoneNumber,
                PhoneNumberConfirmed = p129.PhoneNumberConfirmed,
                TwoFactorEnabled = p129.TwoFactorEnabled,
                LockoutEnd = p129.LockoutEnd,
                LockoutEnabled = p129.LockoutEnabled,
                AccessFailedCount = p129.AccessFailedCount
            };
        }
        
        private static AppRoleReadModel funcMain129(AppRole p137)
        {
            return p137 == null ? null : new AppRoleReadModel()
            {
                CreatedBy = p137.CreatedBy,
                CreatedDate = p137.CreatedDate,
                ModifiedBy = p137.ModifiedBy,
                ModifiedDate = p137.ModifiedDate,
                IsDeleted = p137.IsDeleted,
                DeletedBy = p137.DeletedBy,
                DeletedDate = p137.DeletedDate,
                AppUserRoles = TypeAdapter<ICollection<AppUserRole>, ICollection<AppUserRoleReadModel>>.Map.Invoke(p137.AppUserRoles),
                AppRoleClaims = funcMain130(p137.AppRoleClaims),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p137.AccessControlEntries),
                Hash = p137.Hash,
                Id = p137.Id,
                Name = p137.Name,
                NormalizedName = p137.NormalizedName,
                ConcurrencyStamp = p137.ConcurrencyStamp
            };
        }
        
        private static ICollection<AppFeatureFlagReadModel> funcMain141(ICollection<AppFeatureFlag> p152)
        {
            if (p152 == null)
            {
                return null;
            }
            ICollection<AppFeatureFlagReadModel> result = new List<AppFeatureFlagReadModel>(p152.Count);
            
            IEnumerator<AppFeatureFlag> enumerator = p152.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppFeatureFlag item = enumerator.Current;
                result.Add(item == null ? null : new AppFeatureFlagReadModel()
                {
                    FeatureId = item.FeatureId,
                    ScopeIdentifier = item.ScopeIdentifier,
                    IsEnabled = item.IsEnabled,
                    Feature = TypeAdapter<AppFeature, AppFeatureReadModel>.Map.Invoke(item.Feature),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static AppRoleReadModel funcMain143(AppRole p154)
        {
            return p154 == null ? null : new AppRoleReadModel()
            {
                CreatedBy = p154.CreatedBy,
                CreatedDate = p154.CreatedDate,
                ModifiedBy = p154.ModifiedBy,
                ModifiedDate = p154.ModifiedDate,
                IsDeleted = p154.IsDeleted,
                DeletedBy = p154.DeletedBy,
                DeletedDate = p154.DeletedDate,
                AppUserRoles = TypeAdapter<ICollection<AppUserRole>, ICollection<AppUserRoleReadModel>>.Map.Invoke(p154.AppUserRoles),
                AppRoleClaims = funcMain144(p154.AppRoleClaims),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p154.AccessControlEntries),
                Hash = p154.Hash,
                Id = p154.Id,
                Name = p154.Name,
                NormalizedName = p154.NormalizedName,
                ConcurrencyStamp = p154.ConcurrencyStamp
            };
        }
        
        private static ICollection<AppFeatureFlagReadModel> funcMain151(ICollection<AppFeatureFlag> p162)
        {
            if (p162 == null)
            {
                return null;
            }
            ICollection<AppFeatureFlagReadModel> result = new List<AppFeatureFlagReadModel>(p162.Count);
            
            IEnumerator<AppFeatureFlag> enumerator = p162.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppFeatureFlag item = enumerator.Current;
                result.Add(item == null ? null : new AppFeatureFlagReadModel()
                {
                    FeatureId = item.FeatureId,
                    ScopeIdentifier = item.ScopeIdentifier,
                    IsEnabled = item.IsEnabled,
                    Feature = TypeAdapter<AppFeature, AppFeatureReadModel>.Map.Invoke(item.Feature),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static AppUserReadModel funcMain154(AppUser p165)
        {
            return p165 == null ? null : new AppUserReadModel()
            {
                Hash = p165.Hash,
                FirstName = p165.FirstName,
                LastName = p165.LastName,
                Mobile = p165.Mobile,
                CountryCode = p165.CountryCode,
                TwoFactorMethod = p165.TwoFactorMethod,
                CreatedBy = p165.CreatedBy,
                CreatedDate = p165.CreatedDate,
                ModifiedBy = p165.ModifiedBy,
                ModifiedDate = p165.ModifiedDate,
                IsDeleted = p165.IsDeleted,
                DeletedBy = p165.DeletedBy,
                DeletedDate = p165.DeletedDate,
                MembershipType = p165.MembershipType,
                UserRoles = TypeAdapter<ICollection<AppUserRole>, ICollection<AppUserRoleReadModel>>.Map.Invoke(p165.UserRoles),
                UserTokens = funcMain155(p165.UserTokens),
                RefreshTokens = funcMain156(p165.RefreshTokens),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p165.AccessControlEntries),
                Id = p165.Id,
                UserName = p165.UserName,
                NormalizedUserName = p165.NormalizedUserName,
                Email = p165.Email,
                NormalizedEmail = p165.NormalizedEmail,
                EmailConfirmed = p165.EmailConfirmed,
                PasswordHash = p165.PasswordHash,
                SecurityStamp = p165.SecurityStamp,
                ConcurrencyStamp = p165.ConcurrencyStamp,
                PhoneNumber = p165.PhoneNumber,
                PhoneNumberConfirmed = p165.PhoneNumberConfirmed,
                TwoFactorEnabled = p165.TwoFactorEnabled,
                LockoutEnd = p165.LockoutEnd,
                LockoutEnabled = p165.LockoutEnabled,
                AccessFailedCount = p165.AccessFailedCount
            };
        }
        
        private static ICollection<AppRoleClaimReadModel> funcMain163(ICollection<AppRoleClaim> p175)
        {
            if (p175 == null)
            {
                return null;
            }
            ICollection<AppRoleClaimReadModel> result = new List<AppRoleClaimReadModel>(p175.Count);
            
            IEnumerator<AppRoleClaim> enumerator = p175.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRoleClaim item = enumerator.Current;
                result.Add(item == null ? null : new AppRoleClaimReadModel()
                {
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Id = item.Id,
                    RoleId = item.RoleId,
                    ClaimType = item.ClaimType,
                    ClaimValue = item.ClaimValue
                });
            }
            return result;
            
        }
        
        private static ICollection<AppAccessControlEntryReadModel> funcMain164(ICollection<AppAccessControlEntry> p176)
        {
            if (p176 == null)
            {
                return null;
            }
            ICollection<AppAccessControlEntryReadModel> result = new List<AppAccessControlEntryReadModel>(p176.Count);
            
            IEnumerator<AppAccessControlEntry> enumerator = p176.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppAccessControlEntry item = enumerator.Current;
                result.Add(funcMain165(item));
            }
            return result;
            
        }
        
        private static ICollection<AppFeatureFlagReadModel> funcMain174(ICollection<AppFeatureFlag> p186)
        {
            if (p186 == null)
            {
                return null;
            }
            ICollection<AppFeatureFlagReadModel> result = new List<AppFeatureFlagReadModel>(p186.Count);
            
            IEnumerator<AppFeatureFlag> enumerator = p186.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppFeatureFlag item = enumerator.Current;
                result.Add(item == null ? null : new AppFeatureFlagReadModel()
                {
                    FeatureId = item.FeatureId,
                    ScopeIdentifier = item.ScopeIdentifier,
                    IsEnabled = item.IsEnabled,
                    Feature = TypeAdapter<AppFeature, AppFeatureReadModel>.Map.Invoke(item.Feature),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static AppRoleReadModel funcMain176(AppRole p188)
        {
            return p188 == null ? null : new AppRoleReadModel()
            {
                CreatedBy = p188.CreatedBy,
                CreatedDate = p188.CreatedDate,
                ModifiedBy = p188.ModifiedBy,
                ModifiedDate = p188.ModifiedDate,
                IsDeleted = p188.IsDeleted,
                DeletedBy = p188.DeletedBy,
                DeletedDate = p188.DeletedDate,
                AppUserRoles = funcMain177(p188.AppUserRoles),
                AppRoleClaims = funcMain178(p188.AppRoleClaims),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p188.AccessControlEntries),
                Hash = p188.Hash,
                Id = p188.Id,
                Name = p188.Name,
                NormalizedName = p188.NormalizedName,
                ConcurrencyStamp = p188.ConcurrencyStamp
            };
        }
        
        private static ICollection<AppRoleClaimReadModel> funcMain186(ICollection<AppRoleClaim> p199)
        {
            if (p199 == null)
            {
                return null;
            }
            ICollection<AppRoleClaimReadModel> result = new List<AppRoleClaimReadModel>(p199.Count);
            
            IEnumerator<AppRoleClaim> enumerator = p199.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRoleClaim item = enumerator.Current;
                result.Add(item == null ? null : new AppRoleClaimReadModel()
                {
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Id = item.Id,
                    RoleId = item.RoleId,
                    ClaimType = item.ClaimType,
                    ClaimValue = item.ClaimValue
                });
            }
            return result;
            
        }
        
        private static ICollection<AppAccessControlEntryReadModel> funcMain187(ICollection<AppAccessControlEntry> p200)
        {
            if (p200 == null)
            {
                return null;
            }
            ICollection<AppAccessControlEntryReadModel> result = new List<AppAccessControlEntryReadModel>(p200.Count);
            
            IEnumerator<AppAccessControlEntry> enumerator = p200.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppAccessControlEntry item = enumerator.Current;
                result.Add(funcMain188(item));
            }
            return result;
            
        }
        
        private static ICollection<AppFeatureFlagReadModel> funcMain197(ICollection<AppFeatureFlag> p210)
        {
            if (p210 == null)
            {
                return null;
            }
            ICollection<AppFeatureFlagReadModel> result = new List<AppFeatureFlagReadModel>(p210.Count);
            
            IEnumerator<AppFeatureFlag> enumerator = p210.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppFeatureFlag item = enumerator.Current;
                result.Add(item == null ? null : new AppFeatureFlagReadModel()
                {
                    FeatureId = item.FeatureId,
                    ScopeIdentifier = item.ScopeIdentifier,
                    IsEnabled = item.IsEnabled,
                    Feature = TypeAdapter<AppFeature, AppFeatureReadModel>.Map.Invoke(item.Feature),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static AppRoleReadModel funcMain199(AppRole p212)
        {
            return p212 == null ? null : new AppRoleReadModel()
            {
                CreatedBy = p212.CreatedBy,
                CreatedDate = p212.CreatedDate,
                ModifiedBy = p212.ModifiedBy,
                ModifiedDate = p212.ModifiedDate,
                IsDeleted = p212.IsDeleted,
                DeletedBy = p212.DeletedBy,
                DeletedDate = p212.DeletedDate,
                AppUserRoles = funcMain200(p212.AppUserRoles),
                AppRoleClaims = funcMain201(p212.AppRoleClaims),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p212.AccessControlEntries),
                Hash = p212.Hash,
                Id = p212.Id,
                Name = p212.Name,
                NormalizedName = p212.NormalizedName,
                ConcurrencyStamp = p212.ConcurrencyStamp
            };
        }
        
        private static AppUserReadModel funcMain211(AppUser p225)
        {
            return p225 == null ? null : new AppUserReadModel()
            {
                Hash = p225.Hash,
                FirstName = p225.FirstName,
                LastName = p225.LastName,
                Mobile = p225.Mobile,
                CountryCode = p225.CountryCode,
                TwoFactorMethod = p225.TwoFactorMethod,
                CreatedBy = p225.CreatedBy,
                CreatedDate = p225.CreatedDate,
                ModifiedBy = p225.ModifiedBy,
                ModifiedDate = p225.ModifiedDate,
                IsDeleted = p225.IsDeleted,
                DeletedBy = p225.DeletedBy,
                DeletedDate = p225.DeletedDate,
                MembershipType = p225.MembershipType,
                UserRoles = TypeAdapter<ICollection<AppUserRole>, ICollection<AppUserRoleReadModel>>.Map.Invoke(p225.UserRoles),
                UserTokens = funcMain212(p225.UserTokens),
                RefreshTokens = funcMain213(p225.RefreshTokens),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p225.AccessControlEntries),
                Id = p225.Id,
                UserName = p225.UserName,
                NormalizedUserName = p225.NormalizedUserName,
                Email = p225.Email,
                NormalizedEmail = p225.NormalizedEmail,
                EmailConfirmed = p225.EmailConfirmed,
                PasswordHash = p225.PasswordHash,
                SecurityStamp = p225.SecurityStamp,
                ConcurrencyStamp = p225.ConcurrencyStamp,
                PhoneNumber = p225.PhoneNumber,
                PhoneNumberConfirmed = p225.PhoneNumberConfirmed,
                TwoFactorEnabled = p225.TwoFactorEnabled,
                LockoutEnd = p225.LockoutEnd,
                LockoutEnabled = p225.LockoutEnabled,
                AccessFailedCount = p225.AccessFailedCount
            };
        }
        
        private static AppRoleReadModel funcMain219(AppRole p233)
        {
            return p233 == null ? null : new AppRoleReadModel()
            {
                CreatedBy = p233.CreatedBy,
                CreatedDate = p233.CreatedDate,
                ModifiedBy = p233.ModifiedBy,
                ModifiedDate = p233.ModifiedDate,
                IsDeleted = p233.IsDeleted,
                DeletedBy = p233.DeletedBy,
                DeletedDate = p233.DeletedDate,
                AppUserRoles = TypeAdapter<ICollection<AppUserRole>, ICollection<AppUserRoleReadModel>>.Map.Invoke(p233.AppUserRoles),
                AppRoleClaims = funcMain220(p233.AppRoleClaims),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p233.AccessControlEntries),
                Hash = p233.Hash,
                Id = p233.Id,
                Name = p233.Name,
                NormalizedName = p233.NormalizedName,
                ConcurrencyStamp = p233.ConcurrencyStamp
            };
        }
        
        private static ICollection<AppRoleClaimReadModel> funcMain54(ICollection<AppRoleClaim> p62)
        {
            if (p62 == null)
            {
                return null;
            }
            ICollection<AppRoleClaimReadModel> result = new List<AppRoleClaimReadModel>(p62.Count);
            
            IEnumerator<AppRoleClaim> enumerator = p62.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRoleClaim item = enumerator.Current;
                result.Add(item == null ? null : new AppRoleClaimReadModel()
                {
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Id = item.Id,
                    RoleId = item.RoleId,
                    ClaimType = item.ClaimType,
                    ClaimValue = item.ClaimValue
                });
            }
            return result;
            
        }
        
        private static ICollection<AppUserTokenReadModel> funcMain65(ICollection<AppUserToken> p73)
        {
            if (p73 == null)
            {
                return null;
            }
            ICollection<AppUserTokenReadModel> result = new List<AppUserTokenReadModel>(p73.Count);
            
            IEnumerator<AppUserToken> enumerator = p73.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserToken item = enumerator.Current;
                result.Add(item == null ? null : new AppUserTokenReadModel()
                {
                    Token = item.Token,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    LoginProvider = item.LoginProvider,
                    Name = item.Name,
                    Value = item.Value
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRefreshTokenReadModel> funcMain66(ICollection<AppRefreshToken> p74)
        {
            if (p74 == null)
            {
                return null;
            }
            ICollection<AppRefreshTokenReadModel> result = new List<AppRefreshTokenReadModel>(p74.Count);
            
            IEnumerator<AppRefreshToken> enumerator = p74.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRefreshToken item = enumerator.Current;
                result.Add(item == null ? null : new AppRefreshTokenReadModel()
                {
                    UserId = item.UserId,
                    Token = item.Token,
                    JwtId = item.JwtId,
                    IsUsed = item.IsUsed,
                    IsRevoked = item.IsRevoked,
                    ExpiryDate = item.ExpiryDate,
                    Hash = item.Hash,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static AppAccessControlEntryReadModel funcMain75(AppAccessControlEntry p83)
        {
            return p83 == null ? null : new AppAccessControlEntryReadModel()
            {
                ResourcePattern = p83.ResourcePattern,
                PermissionPattern = p83.PermissionPattern,
                FeatureId = p83.FeatureId,
                Feature = funcMain76(p83.Feature),
                AppRoles = funcMain78(p83.AppRoles),
                AppUsers = funcMain79(p83.AppUsers),
                AppResource = p83.AppResource == null ? null : new AppResourceReadModel()
                {
                    Url = p83.AppResource.Url,
                    Description = p83.AppResource.Description,
                    ResourceType = p83.AppResource.ResourceType,
                    AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p83.AppResource.AccessControlEntries),
                    Id = p83.AppResource.Id,
                    CreatedBy = p83.AppResource.CreatedBy,
                    CreatedDate = p83.AppResource.CreatedDate,
                    ModifiedBy = p83.AppResource.ModifiedBy,
                    ModifiedDate = p83.AppResource.ModifiedDate,
                    IsDeleted = p83.AppResource.IsDeleted,
                    DeletedBy = p83.AppResource.DeletedBy,
                    DeletedDate = p83.AppResource.DeletedDate
                },
                ResourceId = p83.ResourceId,
                Id = p83.Id,
                CreatedBy = p83.CreatedBy,
                CreatedDate = p83.CreatedDate,
                ModifiedBy = p83.ModifiedBy,
                ModifiedDate = p83.ModifiedDate,
                IsDeleted = p83.IsDeleted,
                DeletedBy = p83.DeletedBy,
                DeletedDate = p83.DeletedDate
            };
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain87(ICollection<AppUserRole> p95)
        {
            if (p95 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p95.Count);
            
            IEnumerator<AppUserRole> enumerator = p95.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(item == null ? null : new AppUserRoleReadModel()
                {
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Hash = item.Hash,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    RoleId = item.RoleId
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRoleClaimReadModel> funcMain88(ICollection<AppRoleClaim> p96)
        {
            if (p96 == null)
            {
                return null;
            }
            ICollection<AppRoleClaimReadModel> result = new List<AppRoleClaimReadModel>(p96.Count);
            
            IEnumerator<AppRoleClaim> enumerator = p96.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRoleClaim item = enumerator.Current;
                result.Add(item == null ? null : new AppRoleClaimReadModel()
                {
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Id = item.Id,
                    RoleId = item.RoleId,
                    ClaimType = item.ClaimType,
                    ClaimValue = item.ClaimValue
                });
            }
            return result;
            
        }
        
        private static AppAccessControlEntryReadModel funcMain98(AppAccessControlEntry p106)
        {
            return p106 == null ? null : new AppAccessControlEntryReadModel()
            {
                ResourcePattern = p106.ResourcePattern,
                PermissionPattern = p106.PermissionPattern,
                FeatureId = p106.FeatureId,
                Feature = funcMain99(p106.Feature),
                AppRoles = funcMain101(p106.AppRoles),
                AppUsers = funcMain102(p106.AppUsers),
                AppResource = p106.AppResource == null ? null : new AppResourceReadModel()
                {
                    Url = p106.AppResource.Url,
                    Description = p106.AppResource.Description,
                    ResourceType = p106.AppResource.ResourceType,
                    AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p106.AppResource.AccessControlEntries),
                    Id = p106.AppResource.Id,
                    CreatedBy = p106.AppResource.CreatedBy,
                    CreatedDate = p106.AppResource.CreatedDate,
                    ModifiedBy = p106.AppResource.ModifiedBy,
                    ModifiedDate = p106.AppResource.ModifiedDate,
                    IsDeleted = p106.AppResource.IsDeleted,
                    DeletedBy = p106.AppResource.DeletedBy,
                    DeletedDate = p106.AppResource.DeletedDate
                },
                ResourceId = p106.ResourceId,
                Id = p106.Id,
                CreatedBy = p106.CreatedBy,
                CreatedDate = p106.CreatedDate,
                ModifiedBy = p106.ModifiedBy,
                ModifiedDate = p106.ModifiedDate,
                IsDeleted = p106.IsDeleted,
                DeletedBy = p106.DeletedBy,
                DeletedDate = p106.DeletedDate
            };
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain110(ICollection<AppUserRole> p118)
        {
            if (p118 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p118.Count);
            
            IEnumerator<AppUserRole> enumerator = p118.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(item == null ? null : new AppUserRoleReadModel()
                {
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Hash = item.Hash,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    RoleId = item.RoleId
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRoleClaimReadModel> funcMain111(ICollection<AppRoleClaim> p119)
        {
            if (p119 == null)
            {
                return null;
            }
            ICollection<AppRoleClaimReadModel> result = new List<AppRoleClaimReadModel>(p119.Count);
            
            IEnumerator<AppRoleClaim> enumerator = p119.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRoleClaim item = enumerator.Current;
                result.Add(item == null ? null : new AppRoleClaimReadModel()
                {
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Id = item.Id,
                    RoleId = item.RoleId,
                    ClaimType = item.ClaimType,
                    ClaimValue = item.ClaimValue
                });
            }
            return result;
            
        }
        
        private static ICollection<AppUserTokenReadModel> funcMain122(ICollection<AppUserToken> p130)
        {
            if (p130 == null)
            {
                return null;
            }
            ICollection<AppUserTokenReadModel> result = new List<AppUserTokenReadModel>(p130.Count);
            
            IEnumerator<AppUserToken> enumerator = p130.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserToken item = enumerator.Current;
                result.Add(item == null ? null : new AppUserTokenReadModel()
                {
                    Token = item.Token,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    LoginProvider = item.LoginProvider,
                    Name = item.Name,
                    Value = item.Value
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRefreshTokenReadModel> funcMain123(ICollection<AppRefreshToken> p131)
        {
            if (p131 == null)
            {
                return null;
            }
            ICollection<AppRefreshTokenReadModel> result = new List<AppRefreshTokenReadModel>(p131.Count);
            
            IEnumerator<AppRefreshToken> enumerator = p131.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRefreshToken item = enumerator.Current;
                result.Add(item == null ? null : new AppRefreshTokenReadModel()
                {
                    UserId = item.UserId,
                    Token = item.Token,
                    JwtId = item.JwtId,
                    IsUsed = item.IsUsed,
                    IsRevoked = item.IsRevoked,
                    ExpiryDate = item.ExpiryDate,
                    Hash = item.Hash,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRoleClaimReadModel> funcMain130(ICollection<AppRoleClaim> p138)
        {
            if (p138 == null)
            {
                return null;
            }
            ICollection<AppRoleClaimReadModel> result = new List<AppRoleClaimReadModel>(p138.Count);
            
            IEnumerator<AppRoleClaim> enumerator = p138.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRoleClaim item = enumerator.Current;
                result.Add(item == null ? null : new AppRoleClaimReadModel()
                {
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Id = item.Id,
                    RoleId = item.RoleId,
                    ClaimType = item.ClaimType,
                    ClaimValue = item.ClaimValue
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRoleClaimReadModel> funcMain144(ICollection<AppRoleClaim> p155)
        {
            if (p155 == null)
            {
                return null;
            }
            ICollection<AppRoleClaimReadModel> result = new List<AppRoleClaimReadModel>(p155.Count);
            
            IEnumerator<AppRoleClaim> enumerator = p155.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRoleClaim item = enumerator.Current;
                result.Add(item == null ? null : new AppRoleClaimReadModel()
                {
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Id = item.Id,
                    RoleId = item.RoleId,
                    ClaimType = item.ClaimType,
                    ClaimValue = item.ClaimValue
                });
            }
            return result;
            
        }
        
        private static ICollection<AppUserTokenReadModel> funcMain155(ICollection<AppUserToken> p166)
        {
            if (p166 == null)
            {
                return null;
            }
            ICollection<AppUserTokenReadModel> result = new List<AppUserTokenReadModel>(p166.Count);
            
            IEnumerator<AppUserToken> enumerator = p166.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserToken item = enumerator.Current;
                result.Add(item == null ? null : new AppUserTokenReadModel()
                {
                    Token = item.Token,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    LoginProvider = item.LoginProvider,
                    Name = item.Name,
                    Value = item.Value
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRefreshTokenReadModel> funcMain156(ICollection<AppRefreshToken> p167)
        {
            if (p167 == null)
            {
                return null;
            }
            ICollection<AppRefreshTokenReadModel> result = new List<AppRefreshTokenReadModel>(p167.Count);
            
            IEnumerator<AppRefreshToken> enumerator = p167.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRefreshToken item = enumerator.Current;
                result.Add(item == null ? null : new AppRefreshTokenReadModel()
                {
                    UserId = item.UserId,
                    Token = item.Token,
                    JwtId = item.JwtId,
                    IsUsed = item.IsUsed,
                    IsRevoked = item.IsRevoked,
                    ExpiryDate = item.ExpiryDate,
                    Hash = item.Hash,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static AppAccessControlEntryReadModel funcMain165(AppAccessControlEntry p177)
        {
            return p177 == null ? null : new AppAccessControlEntryReadModel()
            {
                ResourcePattern = p177.ResourcePattern,
                PermissionPattern = p177.PermissionPattern,
                FeatureId = p177.FeatureId,
                Feature = funcMain166(p177.Feature),
                AppRoles = funcMain168(p177.AppRoles),
                AppUsers = funcMain169(p177.AppUsers),
                AppResource = p177.AppResource == null ? null : new AppResourceReadModel()
                {
                    Url = p177.AppResource.Url,
                    Description = p177.AppResource.Description,
                    ResourceType = p177.AppResource.ResourceType,
                    AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p177.AppResource.AccessControlEntries),
                    Id = p177.AppResource.Id,
                    CreatedBy = p177.AppResource.CreatedBy,
                    CreatedDate = p177.AppResource.CreatedDate,
                    ModifiedBy = p177.AppResource.ModifiedBy,
                    ModifiedDate = p177.AppResource.ModifiedDate,
                    IsDeleted = p177.AppResource.IsDeleted,
                    DeletedBy = p177.AppResource.DeletedBy,
                    DeletedDate = p177.AppResource.DeletedDate
                },
                ResourceId = p177.ResourceId,
                Id = p177.Id,
                CreatedBy = p177.CreatedBy,
                CreatedDate = p177.CreatedDate,
                ModifiedBy = p177.ModifiedBy,
                ModifiedDate = p177.ModifiedDate,
                IsDeleted = p177.IsDeleted,
                DeletedBy = p177.DeletedBy,
                DeletedDate = p177.DeletedDate
            };
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain177(ICollection<AppUserRole> p189)
        {
            if (p189 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p189.Count);
            
            IEnumerator<AppUserRole> enumerator = p189.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(item == null ? null : new AppUserRoleReadModel()
                {
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Hash = item.Hash,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    RoleId = item.RoleId
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRoleClaimReadModel> funcMain178(ICollection<AppRoleClaim> p190)
        {
            if (p190 == null)
            {
                return null;
            }
            ICollection<AppRoleClaimReadModel> result = new List<AppRoleClaimReadModel>(p190.Count);
            
            IEnumerator<AppRoleClaim> enumerator = p190.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRoleClaim item = enumerator.Current;
                result.Add(item == null ? null : new AppRoleClaimReadModel()
                {
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Id = item.Id,
                    RoleId = item.RoleId,
                    ClaimType = item.ClaimType,
                    ClaimValue = item.ClaimValue
                });
            }
            return result;
            
        }
        
        private static AppAccessControlEntryReadModel funcMain188(AppAccessControlEntry p201)
        {
            return p201 == null ? null : new AppAccessControlEntryReadModel()
            {
                ResourcePattern = p201.ResourcePattern,
                PermissionPattern = p201.PermissionPattern,
                FeatureId = p201.FeatureId,
                Feature = funcMain189(p201.Feature),
                AppRoles = funcMain191(p201.AppRoles),
                AppUsers = funcMain192(p201.AppUsers),
                AppResource = p201.AppResource == null ? null : new AppResourceReadModel()
                {
                    Url = p201.AppResource.Url,
                    Description = p201.AppResource.Description,
                    ResourceType = p201.AppResource.ResourceType,
                    AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p201.AppResource.AccessControlEntries),
                    Id = p201.AppResource.Id,
                    CreatedBy = p201.AppResource.CreatedBy,
                    CreatedDate = p201.AppResource.CreatedDate,
                    ModifiedBy = p201.AppResource.ModifiedBy,
                    ModifiedDate = p201.AppResource.ModifiedDate,
                    IsDeleted = p201.AppResource.IsDeleted,
                    DeletedBy = p201.AppResource.DeletedBy,
                    DeletedDate = p201.AppResource.DeletedDate
                },
                ResourceId = p201.ResourceId,
                Id = p201.Id,
                CreatedBy = p201.CreatedBy,
                CreatedDate = p201.CreatedDate,
                ModifiedBy = p201.ModifiedBy,
                ModifiedDate = p201.ModifiedDate,
                IsDeleted = p201.IsDeleted,
                DeletedBy = p201.DeletedBy,
                DeletedDate = p201.DeletedDate
            };
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain200(ICollection<AppUserRole> p213)
        {
            if (p213 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p213.Count);
            
            IEnumerator<AppUserRole> enumerator = p213.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(item == null ? null : new AppUserRoleReadModel()
                {
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Hash = item.Hash,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    RoleId = item.RoleId
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRoleClaimReadModel> funcMain201(ICollection<AppRoleClaim> p214)
        {
            if (p214 == null)
            {
                return null;
            }
            ICollection<AppRoleClaimReadModel> result = new List<AppRoleClaimReadModel>(p214.Count);
            
            IEnumerator<AppRoleClaim> enumerator = p214.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRoleClaim item = enumerator.Current;
                result.Add(item == null ? null : new AppRoleClaimReadModel()
                {
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Id = item.Id,
                    RoleId = item.RoleId,
                    ClaimType = item.ClaimType,
                    ClaimValue = item.ClaimValue
                });
            }
            return result;
            
        }
        
        private static ICollection<AppUserTokenReadModel> funcMain212(ICollection<AppUserToken> p226)
        {
            if (p226 == null)
            {
                return null;
            }
            ICollection<AppUserTokenReadModel> result = new List<AppUserTokenReadModel>(p226.Count);
            
            IEnumerator<AppUserToken> enumerator = p226.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserToken item = enumerator.Current;
                result.Add(item == null ? null : new AppUserTokenReadModel()
                {
                    Token = item.Token,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    LoginProvider = item.LoginProvider,
                    Name = item.Name,
                    Value = item.Value
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRefreshTokenReadModel> funcMain213(ICollection<AppRefreshToken> p227)
        {
            if (p227 == null)
            {
                return null;
            }
            ICollection<AppRefreshTokenReadModel> result = new List<AppRefreshTokenReadModel>(p227.Count);
            
            IEnumerator<AppRefreshToken> enumerator = p227.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRefreshToken item = enumerator.Current;
                result.Add(item == null ? null : new AppRefreshTokenReadModel()
                {
                    UserId = item.UserId,
                    Token = item.Token,
                    JwtId = item.JwtId,
                    IsUsed = item.IsUsed,
                    IsRevoked = item.IsRevoked,
                    ExpiryDate = item.ExpiryDate,
                    Hash = item.Hash,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRoleClaimReadModel> funcMain220(ICollection<AppRoleClaim> p234)
        {
            if (p234 == null)
            {
                return null;
            }
            ICollection<AppRoleClaimReadModel> result = new List<AppRoleClaimReadModel>(p234.Count);
            
            IEnumerator<AppRoleClaim> enumerator = p234.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRoleClaim item = enumerator.Current;
                result.Add(item == null ? null : new AppRoleClaimReadModel()
                {
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Id = item.Id,
                    RoleId = item.RoleId,
                    ClaimType = item.ClaimType,
                    ClaimValue = item.ClaimValue
                });
            }
            return result;
            
        }
        
        private static AppFeatureReadModel funcMain76(AppFeature p84)
        {
            return p84 == null ? null : new AppFeatureReadModel()
            {
                Name = p84.Name,
                Description = p84.Description,
                IsEnabled = p84.IsEnabled,
                Scope = p84.Scope,
                FeatureFlags = funcMain77(p84.FeatureFlags),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p84.AccessControlEntries),
                Id = p84.Id,
                CreatedBy = p84.CreatedBy,
                CreatedDate = p84.CreatedDate,
                ModifiedBy = p84.ModifiedBy,
                ModifiedDate = p84.ModifiedDate,
                IsDeleted = p84.IsDeleted,
                DeletedBy = p84.DeletedBy,
                DeletedDate = p84.DeletedDate
            };
        }
        
        private static ICollection<AppRoleReadModel> funcMain78(ICollection<AppRole> p86)
        {
            if (p86 == null)
            {
                return null;
            }
            ICollection<AppRoleReadModel> result = new List<AppRoleReadModel>(p86.Count);
            
            IEnumerator<AppRole> enumerator = p86.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRole item = enumerator.Current;
                result.Add(TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserReadModel> funcMain79(ICollection<AppUser> p87)
        {
            if (p87 == null)
            {
                return null;
            }
            ICollection<AppUserReadModel> result = new List<AppUserReadModel>(p87.Count);
            
            IEnumerator<AppUser> enumerator = p87.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUser item = enumerator.Current;
                result.Add(TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static AppFeatureReadModel funcMain99(AppFeature p107)
        {
            return p107 == null ? null : new AppFeatureReadModel()
            {
                Name = p107.Name,
                Description = p107.Description,
                IsEnabled = p107.IsEnabled,
                Scope = p107.Scope,
                FeatureFlags = funcMain100(p107.FeatureFlags),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p107.AccessControlEntries),
                Id = p107.Id,
                CreatedBy = p107.CreatedBy,
                CreatedDate = p107.CreatedDate,
                ModifiedBy = p107.ModifiedBy,
                ModifiedDate = p107.ModifiedDate,
                IsDeleted = p107.IsDeleted,
                DeletedBy = p107.DeletedBy,
                DeletedDate = p107.DeletedDate
            };
        }
        
        private static ICollection<AppRoleReadModel> funcMain101(ICollection<AppRole> p109)
        {
            if (p109 == null)
            {
                return null;
            }
            ICollection<AppRoleReadModel> result = new List<AppRoleReadModel>(p109.Count);
            
            IEnumerator<AppRole> enumerator = p109.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRole item = enumerator.Current;
                result.Add(TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserReadModel> funcMain102(ICollection<AppUser> p110)
        {
            if (p110 == null)
            {
                return null;
            }
            ICollection<AppUserReadModel> result = new List<AppUserReadModel>(p110.Count);
            
            IEnumerator<AppUser> enumerator = p110.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUser item = enumerator.Current;
                result.Add(TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static AppFeatureReadModel funcMain166(AppFeature p178)
        {
            return p178 == null ? null : new AppFeatureReadModel()
            {
                Name = p178.Name,
                Description = p178.Description,
                IsEnabled = p178.IsEnabled,
                Scope = p178.Scope,
                FeatureFlags = funcMain167(p178.FeatureFlags),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p178.AccessControlEntries),
                Id = p178.Id,
                CreatedBy = p178.CreatedBy,
                CreatedDate = p178.CreatedDate,
                ModifiedBy = p178.ModifiedBy,
                ModifiedDate = p178.ModifiedDate,
                IsDeleted = p178.IsDeleted,
                DeletedBy = p178.DeletedBy,
                DeletedDate = p178.DeletedDate
            };
        }
        
        private static ICollection<AppRoleReadModel> funcMain168(ICollection<AppRole> p180)
        {
            if (p180 == null)
            {
                return null;
            }
            ICollection<AppRoleReadModel> result = new List<AppRoleReadModel>(p180.Count);
            
            IEnumerator<AppRole> enumerator = p180.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRole item = enumerator.Current;
                result.Add(TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserReadModel> funcMain169(ICollection<AppUser> p181)
        {
            if (p181 == null)
            {
                return null;
            }
            ICollection<AppUserReadModel> result = new List<AppUserReadModel>(p181.Count);
            
            IEnumerator<AppUser> enumerator = p181.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUser item = enumerator.Current;
                result.Add(TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static AppFeatureReadModel funcMain189(AppFeature p202)
        {
            return p202 == null ? null : new AppFeatureReadModel()
            {
                Name = p202.Name,
                Description = p202.Description,
                IsEnabled = p202.IsEnabled,
                Scope = p202.Scope,
                FeatureFlags = funcMain190(p202.FeatureFlags),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p202.AccessControlEntries),
                Id = p202.Id,
                CreatedBy = p202.CreatedBy,
                CreatedDate = p202.CreatedDate,
                ModifiedBy = p202.ModifiedBy,
                ModifiedDate = p202.ModifiedDate,
                IsDeleted = p202.IsDeleted,
                DeletedBy = p202.DeletedBy,
                DeletedDate = p202.DeletedDate
            };
        }
        
        private static ICollection<AppRoleReadModel> funcMain191(ICollection<AppRole> p204)
        {
            if (p204 == null)
            {
                return null;
            }
            ICollection<AppRoleReadModel> result = new List<AppRoleReadModel>(p204.Count);
            
            IEnumerator<AppRole> enumerator = p204.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRole item = enumerator.Current;
                result.Add(TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserReadModel> funcMain192(ICollection<AppUser> p205)
        {
            if (p205 == null)
            {
                return null;
            }
            ICollection<AppUserReadModel> result = new List<AppUserReadModel>(p205.Count);
            
            IEnumerator<AppUser> enumerator = p205.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUser item = enumerator.Current;
                result.Add(TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static ICollection<AppFeatureFlagReadModel> funcMain77(ICollection<AppFeatureFlag> p85)
        {
            if (p85 == null)
            {
                return null;
            }
            ICollection<AppFeatureFlagReadModel> result = new List<AppFeatureFlagReadModel>(p85.Count);
            
            IEnumerator<AppFeatureFlag> enumerator = p85.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppFeatureFlag item = enumerator.Current;
                result.Add(item == null ? null : new AppFeatureFlagReadModel()
                {
                    FeatureId = item.FeatureId,
                    ScopeIdentifier = item.ScopeIdentifier,
                    IsEnabled = item.IsEnabled,
                    Feature = TypeAdapter<AppFeature, AppFeatureReadModel>.Map.Invoke(item.Feature),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static ICollection<AppFeatureFlagReadModel> funcMain100(ICollection<AppFeatureFlag> p108)
        {
            if (p108 == null)
            {
                return null;
            }
            ICollection<AppFeatureFlagReadModel> result = new List<AppFeatureFlagReadModel>(p108.Count);
            
            IEnumerator<AppFeatureFlag> enumerator = p108.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppFeatureFlag item = enumerator.Current;
                result.Add(item == null ? null : new AppFeatureFlagReadModel()
                {
                    FeatureId = item.FeatureId,
                    ScopeIdentifier = item.ScopeIdentifier,
                    IsEnabled = item.IsEnabled,
                    Feature = TypeAdapter<AppFeature, AppFeatureReadModel>.Map.Invoke(item.Feature),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static ICollection<AppFeatureFlagReadModel> funcMain167(ICollection<AppFeatureFlag> p179)
        {
            if (p179 == null)
            {
                return null;
            }
            ICollection<AppFeatureFlagReadModel> result = new List<AppFeatureFlagReadModel>(p179.Count);
            
            IEnumerator<AppFeatureFlag> enumerator = p179.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppFeatureFlag item = enumerator.Current;
                result.Add(item == null ? null : new AppFeatureFlagReadModel()
                {
                    FeatureId = item.FeatureId,
                    ScopeIdentifier = item.ScopeIdentifier,
                    IsEnabled = item.IsEnabled,
                    Feature = TypeAdapter<AppFeature, AppFeatureReadModel>.Map.Invoke(item.Feature),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static ICollection<AppFeatureFlagReadModel> funcMain190(ICollection<AppFeatureFlag> p203)
        {
            if (p203 == null)
            {
                return null;
            }
            ICollection<AppFeatureFlagReadModel> result = new List<AppFeatureFlagReadModel>(p203.Count);
            
            IEnumerator<AppFeatureFlag> enumerator = p203.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppFeatureFlag item = enumerator.Current;
                result.Add(item == null ? null : new AppFeatureFlagReadModel()
                {
                    FeatureId = item.FeatureId,
                    ScopeIdentifier = item.ScopeIdentifier,
                    IsEnabled = item.IsEnabled,
                    Feature = TypeAdapter<AppFeature, AppFeatureReadModel>.Map.Invoke(item.Feature),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
    }
}