using System.Collections.Generic;
using AxialSystem.Covaluse.Core.Database.Identity;
using Mapster;

namespace AxialSystem.Covaluse.Core.Database.Identity
{
    public static partial class AppUserMapper
    {
        public static AppUserDto AdaptToDto(this AppUser p1)
        {
            return p1 == null ? null : new AppUserDto()
            {
                Hash = p1.Hash,
                FirstName = p1.FirstName,
                LastName = p1.LastName,
                Mobile = p1.Mobile,
                CountryCode = p1.CountryCode,
                TwoFactorMethod = p1.TwoFactorMethod,
                CreatedBy = p1.CreatedBy,
                CreatedDate = p1.CreatedDate,
                ModifiedBy = p1.ModifiedBy,
                ModifiedDate = p1.ModifiedDate,
                IsDeleted = p1.IsDeleted,
                DeletedBy = p1.DeletedBy,
                DeletedDate = p1.DeletedDate,
                MembershipType = p1.MembershipType,
                UserRoles = funcMain1(p1.UserRoles),
                UserTokens = funcMain2(p1.UserTokens),
                RefreshTokens = funcMain3(p1.RefreshTokens),
                Id = p1.Id,
                UserName = p1.UserName,
                NormalizedUserName = p1.NormalizedUserName,
                Email = p1.Email,
                NormalizedEmail = p1.NormalizedEmail,
                EmailConfirmed = p1.EmailConfirmed,
                PasswordHash = p1.PasswordHash,
                SecurityStamp = p1.SecurityStamp,
                ConcurrencyStamp = p1.ConcurrencyStamp,
                PhoneNumber = p1.PhoneNumber,
                PhoneNumberConfirmed = p1.PhoneNumberConfirmed,
                TwoFactorEnabled = p1.TwoFactorEnabled,
                LockoutEnd = p1.LockoutEnd,
                LockoutEnabled = p1.LockoutEnabled,
                AccessFailedCount = p1.AccessFailedCount
            };
        }
        public static AppUserDto AdaptTo(this AppUser p5, AppUserDto p6)
        {
            if (p5 == null)
            {
                return null;
            }
            AppUserDto result = p6 ?? new AppUserDto();
            
            result.Hash = p5.Hash;
            result.FirstName = p5.FirstName;
            result.LastName = p5.LastName;
            result.Mobile = p5.Mobile;
            result.CountryCode = p5.CountryCode;
            result.TwoFactorMethod = p5.TwoFactorMethod;
            result.CreatedBy = p5.CreatedBy;
            result.CreatedDate = p5.CreatedDate;
            result.ModifiedBy = p5.ModifiedBy;
            result.ModifiedDate = p5.ModifiedDate;
            result.IsDeleted = p5.IsDeleted;
            result.DeletedBy = p5.DeletedBy;
            result.DeletedDate = p5.DeletedDate;
            result.MembershipType = p5.MembershipType;
            result.UserRoles = funcMain4(p5.UserRoles, result.UserRoles);
            result.UserTokens = funcMain5(p5.UserTokens, result.UserTokens);
            result.RefreshTokens = funcMain6(p5.RefreshTokens, result.RefreshTokens);
            result.Id = p5.Id;
            result.UserName = p5.UserName;
            result.NormalizedUserName = p5.NormalizedUserName;
            result.Email = p5.Email;
            result.NormalizedEmail = p5.NormalizedEmail;
            result.EmailConfirmed = p5.EmailConfirmed;
            result.PasswordHash = p5.PasswordHash;
            result.SecurityStamp = p5.SecurityStamp;
            result.ConcurrencyStamp = p5.ConcurrencyStamp;
            result.PhoneNumber = p5.PhoneNumber;
            result.PhoneNumberConfirmed = p5.PhoneNumberConfirmed;
            result.TwoFactorEnabled = p5.TwoFactorEnabled;
            result.LockoutEnd = p5.LockoutEnd;
            result.LockoutEnabled = p5.LockoutEnabled;
            result.AccessFailedCount = p5.AccessFailedCount;
            return result;
            
        }
        
        private static ICollection<UserRoleDto> funcMain1(ICollection<UserRole> p2)
        {
            if (p2 == null)
            {
                return null;
            }
            ICollection<UserRoleDto> result = new List<UserRoleDto>(p2.Count);
            
            IEnumerator<UserRole> enumerator = p2.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                UserRole item = enumerator.Current;
                result.Add(item == null ? null : new UserRoleDto()
                {
                    AppUser = TypeAdapter<AppUser, AppUserDto>.Map.Invoke(item.AppUser),
                    Role = item.Role == null ? null : new RoleDto()
                    {
                        CreatedBy = item.Role.CreatedBy,
                        CreatedDate = item.Role.CreatedDate,
                        ModifiedBy = item.Role.ModifiedBy,
                        ModifiedDate = item.Role.ModifiedDate,
                        IsDeleted = item.Role.IsDeleted,
                        DeletedBy = item.Role.DeletedBy,
                        DeletedDate = item.Role.DeletedDate,
                        UserRoles = TypeAdapter<ICollection<UserRole>, ICollection<UserRoleDto>>.Map.Invoke(item.Role.UserRoles),
                        Id = item.Role.Id,
                        Name = item.Role.Name,
                        NormalizedName = item.Role.NormalizedName,
                        ConcurrencyStamp = item.Role.ConcurrencyStamp
                    },
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    RoleId = item.RoleId
                });
            }
            return result;
            
        }
        
        private static ICollection<UserTokenDto> funcMain2(ICollection<UserToken> p3)
        {
            if (p3 == null)
            {
                return null;
            }
            ICollection<UserTokenDto> result = new List<UserTokenDto>(p3.Count);
            
            IEnumerator<UserToken> enumerator = p3.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                UserToken item = enumerator.Current;
                result.Add(item == null ? null : new UserTokenDto()
                {
                    Token = item.Token,
                    AppUser = TypeAdapter<AppUser, AppUserDto>.Map.Invoke(item.AppUser),
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    LoginProvider = item.LoginProvider,
                    Name = item.Name,
                    Value = item.Value
                });
            }
            return result;
            
        }
        
        private static ICollection<RefreshTokenDto> funcMain3(ICollection<RefreshToken> p4)
        {
            if (p4 == null)
            {
                return null;
            }
            ICollection<RefreshTokenDto> result = new List<RefreshTokenDto>(p4.Count);
            
            IEnumerator<RefreshToken> enumerator = p4.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                RefreshToken item = enumerator.Current;
                result.Add(item == null ? null : new RefreshTokenDto()
                {
                    UserId = item.UserId,
                    Token = item.Token,
                    JwtId = item.JwtId,
                    IsUsed = item.IsUsed,
                    IsRevoked = item.IsRevoked,
                    ExpiryDate = item.ExpiryDate,
                    Hash = item.Hash,
                    AppUser = TypeAdapter<AppUser, AppUserDto>.Map.Invoke(item.AppUser),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static ICollection<UserRoleDto> funcMain4(ICollection<UserRole> p7, ICollection<UserRoleDto> p8)
        {
            if (p7 == null)
            {
                return null;
            }
            ICollection<UserRoleDto> result = new List<UserRoleDto>(p7.Count);
            
            IEnumerator<UserRole> enumerator = p7.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                UserRole item = enumerator.Current;
                result.Add(item == null ? null : new UserRoleDto()
                {
                    AppUser = TypeAdapter<AppUser, AppUserDto>.Map.Invoke(item.AppUser),
                    Role = item.Role == null ? null : new RoleDto()
                    {
                        CreatedBy = item.Role.CreatedBy,
                        CreatedDate = item.Role.CreatedDate,
                        ModifiedBy = item.Role.ModifiedBy,
                        ModifiedDate = item.Role.ModifiedDate,
                        IsDeleted = item.Role.IsDeleted,
                        DeletedBy = item.Role.DeletedBy,
                        DeletedDate = item.Role.DeletedDate,
                        UserRoles = TypeAdapter<ICollection<UserRole>, ICollection<UserRoleDto>>.Map.Invoke(item.Role.UserRoles),
                        Id = item.Role.Id,
                        Name = item.Role.Name,
                        NormalizedName = item.Role.NormalizedName,
                        ConcurrencyStamp = item.Role.ConcurrencyStamp
                    },
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    RoleId = item.RoleId
                });
            }
            return result;
            
        }
        
        private static ICollection<UserTokenDto> funcMain5(ICollection<UserToken> p9, ICollection<UserTokenDto> p10)
        {
            if (p9 == null)
            {
                return null;
            }
            ICollection<UserTokenDto> result = new List<UserTokenDto>(p9.Count);
            
            IEnumerator<UserToken> enumerator = p9.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                UserToken item = enumerator.Current;
                result.Add(item == null ? null : new UserTokenDto()
                {
                    Token = item.Token,
                    AppUser = TypeAdapter<AppUser, AppUserDto>.Map.Invoke(item.AppUser),
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    LoginProvider = item.LoginProvider,
                    Name = item.Name,
                    Value = item.Value
                });
            }
            return result;
            
        }
        
        private static ICollection<RefreshTokenDto> funcMain6(ICollection<RefreshToken> p11, ICollection<RefreshTokenDto> p12)
        {
            if (p11 == null)
            {
                return null;
            }
            ICollection<RefreshTokenDto> result = new List<RefreshTokenDto>(p11.Count);
            
            IEnumerator<RefreshToken> enumerator = p11.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                RefreshToken item = enumerator.Current;
                result.Add(item == null ? null : new RefreshTokenDto()
                {
                    UserId = item.UserId,
                    Token = item.Token,
                    JwtId = item.JwtId,
                    IsUsed = item.IsUsed,
                    IsRevoked = item.IsRevoked,
                    ExpiryDate = item.ExpiryDate,
                    Hash = item.Hash,
                    AppUser = TypeAdapter<AppUser, AppUserDto>.Map.Invoke(item.AppUser),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
    }
}