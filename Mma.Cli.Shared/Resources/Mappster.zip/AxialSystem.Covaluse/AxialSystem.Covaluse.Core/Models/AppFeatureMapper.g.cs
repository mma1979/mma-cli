using System.Collections.Generic;
using AxialSystem.Covaluse.Core.Database.Identity;
using Mapster;

namespace AxialSystem.Covaluse.Core.Database.Identity
{
    public static partial class AppFeatureMapper
    {
        public static AppFeatureReadModel AdaptToReadModel(this AppFeature p1)
        {
            return p1 == null ? null : new AppFeatureReadModel()
            {
                Name = p1.Name,
                Description = p1.Description,
                IsEnabled = p1.IsEnabled,
                Scope = p1.Scope,
                FeatureFlags = funcMain1(p1.FeatureFlags),
                AccessControlEntries = funcMain2(p1.AccessControlEntries),
                Id = p1.Id,
                CreatedBy = p1.CreatedBy,
                CreatedDate = p1.CreatedDate,
                ModifiedBy = p1.ModifiedBy,
                ModifiedDate = p1.ModifiedDate,
                IsDeleted = p1.IsDeleted,
                DeletedBy = p1.DeletedBy,
                DeletedDate = p1.DeletedDate
            };
        }
        public static AppFeatureReadModel AdaptTo(this AppFeature p21, AppFeatureReadModel p22)
        {
            if (p21 == null)
            {
                return null;
            }
            AppFeatureReadModel result = p22 ?? new AppFeatureReadModel();
            
            result.Name = p21.Name;
            result.Description = p21.Description;
            result.IsEnabled = p21.IsEnabled;
            result.Scope = p21.Scope;
            result.FeatureFlags = funcMain20(p21.FeatureFlags, result.FeatureFlags);
            result.AccessControlEntries = funcMain21(p21.AccessControlEntries, result.AccessControlEntries);
            result.Id = p21.Id;
            result.CreatedBy = p21.CreatedBy;
            result.CreatedDate = p21.CreatedDate;
            result.ModifiedBy = p21.ModifiedBy;
            result.ModifiedDate = p21.ModifiedDate;
            result.IsDeleted = p21.IsDeleted;
            result.DeletedBy = p21.DeletedBy;
            result.DeletedDate = p21.DeletedDate;
            return result;
            
        }
        public static AppFeatureModifyModel AdaptToModifyModel(this AppFeature p44)
        {
            return p44 == null ? null : new AppFeatureModifyModel()
            {
                Name = p44.Name,
                Description = p44.Description,
                IsEnabled = p44.IsEnabled,
                Scope = p44.Scope,
                FeatureFlags = funcMain39(p44.FeatureFlags),
                AccessControlEntries = funcMain60(p44.AccessControlEntries),
                Id = p44.Id,
                CreatedBy = p44.CreatedBy,
                CreatedDate = p44.CreatedDate,
                ModifiedBy = p44.ModifiedBy,
                ModifiedDate = p44.ModifiedDate,
                IsDeleted = p44.IsDeleted,
                DeletedBy = p44.DeletedBy,
                DeletedDate = p44.DeletedDate
            };
        }
        public static AppFeatureModifyModel AdaptTo(this AppFeature p86, AppFeatureModifyModel p87)
        {
            if (p86 == null)
            {
                return null;
            }
            AppFeatureModifyModel result = p87 ?? new AppFeatureModifyModel();
            
            result.Name = p86.Name;
            result.Description = p86.Description;
            result.IsEnabled = p86.IsEnabled;
            result.Scope = p86.Scope;
            result.FeatureFlags = funcMain80(p86.FeatureFlags, result.FeatureFlags);
            result.AccessControlEntries = funcMain101(p86.AccessControlEntries, result.AccessControlEntries);
            result.Id = p86.Id;
            result.CreatedBy = p86.CreatedBy;
            result.CreatedDate = p86.CreatedDate;
            result.ModifiedBy = p86.ModifiedBy;
            result.ModifiedDate = p86.ModifiedDate;
            result.IsDeleted = p86.IsDeleted;
            result.DeletedBy = p86.DeletedBy;
            result.DeletedDate = p86.DeletedDate;
            return result;
            
        }
        
        private static ICollection<AppFeatureFlagReadModel> funcMain1(ICollection<AppFeatureFlag> p2)
        {
            if (p2 == null)
            {
                return null;
            }
            ICollection<AppFeatureFlagReadModel> result = new List<AppFeatureFlagReadModel>(p2.Count);
            
            IEnumerator<AppFeatureFlag> enumerator = p2.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppFeatureFlag item = enumerator.Current;
                result.Add(item == null ? null : new AppFeatureFlagReadModel()
                {
                    FeatureId = item.FeatureId,
                    ScopeIdentifier = item.ScopeIdentifier,
                    IsEnabled = item.IsEnabled,
                    Feature = TypeAdapter<AppFeature, AppFeatureReadModel>.Map.Invoke(item.Feature),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static ICollection<AppAccessControlEntryReadModel> funcMain2(ICollection<AppAccessControlEntry> p3)
        {
            if (p3 == null)
            {
                return null;
            }
            ICollection<AppAccessControlEntryReadModel> result = new List<AppAccessControlEntryReadModel>(p3.Count);
            
            IEnumerator<AppAccessControlEntry> enumerator = p3.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppAccessControlEntry item = enumerator.Current;
                result.Add(funcMain3(item));
            }
            return result;
            
        }
        
        private static ICollection<AppFeatureFlagReadModel> funcMain20(ICollection<AppFeatureFlag> p23, ICollection<AppFeatureFlagReadModel> p24)
        {
            if (p23 == null)
            {
                return null;
            }
            ICollection<AppFeatureFlagReadModel> result = new List<AppFeatureFlagReadModel>(p23.Count);
            
            IEnumerator<AppFeatureFlag> enumerator = p23.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppFeatureFlag item = enumerator.Current;
                result.Add(item == null ? null : new AppFeatureFlagReadModel()
                {
                    FeatureId = item.FeatureId,
                    ScopeIdentifier = item.ScopeIdentifier,
                    IsEnabled = item.IsEnabled,
                    Feature = TypeAdapter<AppFeature, AppFeatureReadModel>.Map.Invoke(item.Feature),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static ICollection<AppAccessControlEntryReadModel> funcMain21(ICollection<AppAccessControlEntry> p25, ICollection<AppAccessControlEntryReadModel> p26)
        {
            if (p25 == null)
            {
                return null;
            }
            ICollection<AppAccessControlEntryReadModel> result = new List<AppAccessControlEntryReadModel>(p25.Count);
            
            IEnumerator<AppAccessControlEntry> enumerator = p25.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppAccessControlEntry item = enumerator.Current;
                result.Add(funcMain22(item));
            }
            return result;
            
        }
        
        private static ICollection<AppFeatureFlagReadModel> funcMain39(ICollection<AppFeatureFlag> p45)
        {
            if (p45 == null)
            {
                return null;
            }
            ICollection<AppFeatureFlagReadModel> result = new List<AppFeatureFlagReadModel>(p45.Count);
            
            IEnumerator<AppFeatureFlag> enumerator = p45.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppFeatureFlag item = enumerator.Current;
                result.Add(funcMain40(item));
            }
            return result;
            
        }
        
        private static ICollection<AppAccessControlEntryReadModel> funcMain60(ICollection<AppAccessControlEntry> p66)
        {
            if (p66 == null)
            {
                return null;
            }
            ICollection<AppAccessControlEntryReadModel> result = new List<AppAccessControlEntryReadModel>(p66.Count);
            
            IEnumerator<AppAccessControlEntry> enumerator = p66.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppAccessControlEntry item = enumerator.Current;
                result.Add(funcMain61(item));
            }
            return result;
            
        }
        
        private static ICollection<AppFeatureFlagReadModel> funcMain80(ICollection<AppFeatureFlag> p88, ICollection<AppFeatureFlagReadModel> p89)
        {
            if (p88 == null)
            {
                return null;
            }
            ICollection<AppFeatureFlagReadModel> result = new List<AppFeatureFlagReadModel>(p88.Count);
            
            IEnumerator<AppFeatureFlag> enumerator = p88.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppFeatureFlag item = enumerator.Current;
                result.Add(funcMain81(item));
            }
            return result;
            
        }
        
        private static ICollection<AppAccessControlEntryReadModel> funcMain101(ICollection<AppAccessControlEntry> p110, ICollection<AppAccessControlEntryReadModel> p111)
        {
            if (p110 == null)
            {
                return null;
            }
            ICollection<AppAccessControlEntryReadModel> result = new List<AppAccessControlEntryReadModel>(p110.Count);
            
            IEnumerator<AppAccessControlEntry> enumerator = p110.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppAccessControlEntry item = enumerator.Current;
                result.Add(funcMain102(item));
            }
            return result;
            
        }
        
        private static AppAccessControlEntryReadModel funcMain3(AppAccessControlEntry p4)
        {
            return p4 == null ? null : new AppAccessControlEntryReadModel()
            {
                ResourcePattern = p4.ResourcePattern,
                PermissionPattern = p4.PermissionPattern,
                FeatureId = p4.FeatureId,
                Feature = TypeAdapter<AppFeature, AppFeatureReadModel>.Map.Invoke(p4.Feature),
                AppRoles = funcMain4(p4.AppRoles),
                AppUsers = funcMain12(p4.AppUsers),
                AppResource = p4.AppResource == null ? null : new AppResourceReadModel()
                {
                    Url = p4.AppResource.Url,
                    Description = p4.AppResource.Description,
                    ResourceType = p4.AppResource.ResourceType,
                    AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p4.AppResource.AccessControlEntries),
                    Id = p4.AppResource.Id,
                    CreatedBy = p4.AppResource.CreatedBy,
                    CreatedDate = p4.AppResource.CreatedDate,
                    ModifiedBy = p4.AppResource.ModifiedBy,
                    ModifiedDate = p4.AppResource.ModifiedDate,
                    IsDeleted = p4.AppResource.IsDeleted,
                    DeletedBy = p4.AppResource.DeletedBy,
                    DeletedDate = p4.AppResource.DeletedDate
                },
                ResourceId = p4.ResourceId,
                Id = p4.Id,
                CreatedBy = p4.CreatedBy,
                CreatedDate = p4.CreatedDate,
                ModifiedBy = p4.ModifiedBy,
                ModifiedDate = p4.ModifiedDate,
                IsDeleted = p4.IsDeleted,
                DeletedBy = p4.DeletedBy,
                DeletedDate = p4.DeletedDate
            };
        }
        
        private static AppAccessControlEntryReadModel funcMain22(AppAccessControlEntry p27)
        {
            return p27 == null ? null : new AppAccessControlEntryReadModel()
            {
                ResourcePattern = p27.ResourcePattern,
                PermissionPattern = p27.PermissionPattern,
                FeatureId = p27.FeatureId,
                Feature = TypeAdapter<AppFeature, AppFeatureReadModel>.Map.Invoke(p27.Feature),
                AppRoles = funcMain23(p27.AppRoles),
                AppUsers = funcMain31(p27.AppUsers),
                AppResource = p27.AppResource == null ? null : new AppResourceReadModel()
                {
                    Url = p27.AppResource.Url,
                    Description = p27.AppResource.Description,
                    ResourceType = p27.AppResource.ResourceType,
                    AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p27.AppResource.AccessControlEntries),
                    Id = p27.AppResource.Id,
                    CreatedBy = p27.AppResource.CreatedBy,
                    CreatedDate = p27.AppResource.CreatedDate,
                    ModifiedBy = p27.AppResource.ModifiedBy,
                    ModifiedDate = p27.AppResource.ModifiedDate,
                    IsDeleted = p27.AppResource.IsDeleted,
                    DeletedBy = p27.AppResource.DeletedBy,
                    DeletedDate = p27.AppResource.DeletedDate
                },
                ResourceId = p27.ResourceId,
                Id = p27.Id,
                CreatedBy = p27.CreatedBy,
                CreatedDate = p27.CreatedDate,
                ModifiedBy = p27.ModifiedBy,
                ModifiedDate = p27.ModifiedDate,
                IsDeleted = p27.IsDeleted,
                DeletedBy = p27.DeletedBy,
                DeletedDate = p27.DeletedDate
            };
        }
        
        private static AppFeatureFlagReadModel funcMain40(AppFeatureFlag p46)
        {
            return p46 == null ? null : new AppFeatureFlagReadModel()
            {
                FeatureId = p46.FeatureId,
                ScopeIdentifier = p46.ScopeIdentifier,
                IsEnabled = p46.IsEnabled,
                Feature = funcMain41(p46.Feature),
                Id = p46.Id,
                CreatedBy = p46.CreatedBy,
                CreatedDate = p46.CreatedDate,
                ModifiedBy = p46.ModifiedBy,
                ModifiedDate = p46.ModifiedDate,
                IsDeleted = p46.IsDeleted,
                DeletedBy = p46.DeletedBy,
                DeletedDate = p46.DeletedDate
            };
        }
        
        private static AppAccessControlEntryReadModel funcMain61(AppAccessControlEntry p67)
        {
            return p67 == null ? null : new AppAccessControlEntryReadModel()
            {
                ResourcePattern = p67.ResourcePattern,
                PermissionPattern = p67.PermissionPattern,
                FeatureId = p67.FeatureId,
                Feature = funcMain62(p67.Feature),
                AppRoles = funcMain64(p67.AppRoles),
                AppUsers = funcMain72(p67.AppUsers),
                AppResource = p67.AppResource == null ? null : new AppResourceReadModel()
                {
                    Url = p67.AppResource.Url,
                    Description = p67.AppResource.Description,
                    ResourceType = p67.AppResource.ResourceType,
                    AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p67.AppResource.AccessControlEntries),
                    Id = p67.AppResource.Id,
                    CreatedBy = p67.AppResource.CreatedBy,
                    CreatedDate = p67.AppResource.CreatedDate,
                    ModifiedBy = p67.AppResource.ModifiedBy,
                    ModifiedDate = p67.AppResource.ModifiedDate,
                    IsDeleted = p67.AppResource.IsDeleted,
                    DeletedBy = p67.AppResource.DeletedBy,
                    DeletedDate = p67.AppResource.DeletedDate
                },
                ResourceId = p67.ResourceId,
                Id = p67.Id,
                CreatedBy = p67.CreatedBy,
                CreatedDate = p67.CreatedDate,
                ModifiedBy = p67.ModifiedBy,
                ModifiedDate = p67.ModifiedDate,
                IsDeleted = p67.IsDeleted,
                DeletedBy = p67.DeletedBy,
                DeletedDate = p67.DeletedDate
            };
        }
        
        private static AppFeatureFlagReadModel funcMain81(AppFeatureFlag p90)
        {
            return p90 == null ? null : new AppFeatureFlagReadModel()
            {
                FeatureId = p90.FeatureId,
                ScopeIdentifier = p90.ScopeIdentifier,
                IsEnabled = p90.IsEnabled,
                Feature = funcMain82(p90.Feature),
                Id = p90.Id,
                CreatedBy = p90.CreatedBy,
                CreatedDate = p90.CreatedDate,
                ModifiedBy = p90.ModifiedBy,
                ModifiedDate = p90.ModifiedDate,
                IsDeleted = p90.IsDeleted,
                DeletedBy = p90.DeletedBy,
                DeletedDate = p90.DeletedDate
            };
        }
        
        private static AppAccessControlEntryReadModel funcMain102(AppAccessControlEntry p112)
        {
            return p112 == null ? null : new AppAccessControlEntryReadModel()
            {
                ResourcePattern = p112.ResourcePattern,
                PermissionPattern = p112.PermissionPattern,
                FeatureId = p112.FeatureId,
                Feature = funcMain103(p112.Feature),
                AppRoles = funcMain105(p112.AppRoles),
                AppUsers = funcMain113(p112.AppUsers),
                AppResource = p112.AppResource == null ? null : new AppResourceReadModel()
                {
                    Url = p112.AppResource.Url,
                    Description = p112.AppResource.Description,
                    ResourceType = p112.AppResource.ResourceType,
                    AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p112.AppResource.AccessControlEntries),
                    Id = p112.AppResource.Id,
                    CreatedBy = p112.AppResource.CreatedBy,
                    CreatedDate = p112.AppResource.CreatedDate,
                    ModifiedBy = p112.AppResource.ModifiedBy,
                    ModifiedDate = p112.AppResource.ModifiedDate,
                    IsDeleted = p112.AppResource.IsDeleted,
                    DeletedBy = p112.AppResource.DeletedBy,
                    DeletedDate = p112.AppResource.DeletedDate
                },
                ResourceId = p112.ResourceId,
                Id = p112.Id,
                CreatedBy = p112.CreatedBy,
                CreatedDate = p112.CreatedDate,
                ModifiedBy = p112.ModifiedBy,
                ModifiedDate = p112.ModifiedDate,
                IsDeleted = p112.IsDeleted,
                DeletedBy = p112.DeletedBy,
                DeletedDate = p112.DeletedDate
            };
        }
        
        private static ICollection<AppRoleReadModel> funcMain4(ICollection<AppRole> p5)
        {
            if (p5 == null)
            {
                return null;
            }
            ICollection<AppRoleReadModel> result = new List<AppRoleReadModel>(p5.Count);
            
            IEnumerator<AppRole> enumerator = p5.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRole item = enumerator.Current;
                result.Add(funcMain5(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserReadModel> funcMain12(ICollection<AppUser> p13)
        {
            if (p13 == null)
            {
                return null;
            }
            ICollection<AppUserReadModel> result = new List<AppUserReadModel>(p13.Count);
            
            IEnumerator<AppUser> enumerator = p13.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUser item = enumerator.Current;
                result.Add(funcMain13(item));
            }
            return result;
            
        }
        
        private static ICollection<AppRoleReadModel> funcMain23(ICollection<AppRole> p28)
        {
            if (p28 == null)
            {
                return null;
            }
            ICollection<AppRoleReadModel> result = new List<AppRoleReadModel>(p28.Count);
            
            IEnumerator<AppRole> enumerator = p28.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRole item = enumerator.Current;
                result.Add(funcMain24(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserReadModel> funcMain31(ICollection<AppUser> p36)
        {
            if (p36 == null)
            {
                return null;
            }
            ICollection<AppUserReadModel> result = new List<AppUserReadModel>(p36.Count);
            
            IEnumerator<AppUser> enumerator = p36.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUser item = enumerator.Current;
                result.Add(funcMain32(item));
            }
            return result;
            
        }
        
        private static AppFeatureReadModel funcMain41(AppFeature p47)
        {
            return p47 == null ? null : new AppFeatureReadModel()
            {
                Name = p47.Name,
                Description = p47.Description,
                IsEnabled = p47.IsEnabled,
                Scope = p47.Scope,
                FeatureFlags = TypeAdapter<ICollection<AppFeatureFlag>, ICollection<AppFeatureFlagReadModel>>.Map.Invoke(p47.FeatureFlags),
                AccessControlEntries = funcMain42(p47.AccessControlEntries),
                Id = p47.Id,
                CreatedBy = p47.CreatedBy,
                CreatedDate = p47.CreatedDate,
                ModifiedBy = p47.ModifiedBy,
                ModifiedDate = p47.ModifiedDate,
                IsDeleted = p47.IsDeleted,
                DeletedBy = p47.DeletedBy,
                DeletedDate = p47.DeletedDate
            };
        }
        
        private static AppFeatureReadModel funcMain62(AppFeature p68)
        {
            return p68 == null ? null : new AppFeatureReadModel()
            {
                Name = p68.Name,
                Description = p68.Description,
                IsEnabled = p68.IsEnabled,
                Scope = p68.Scope,
                FeatureFlags = funcMain63(p68.FeatureFlags),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p68.AccessControlEntries),
                Id = p68.Id,
                CreatedBy = p68.CreatedBy,
                CreatedDate = p68.CreatedDate,
                ModifiedBy = p68.ModifiedBy,
                ModifiedDate = p68.ModifiedDate,
                IsDeleted = p68.IsDeleted,
                DeletedBy = p68.DeletedBy,
                DeletedDate = p68.DeletedDate
            };
        }
        
        private static ICollection<AppRoleReadModel> funcMain64(ICollection<AppRole> p70)
        {
            if (p70 == null)
            {
                return null;
            }
            ICollection<AppRoleReadModel> result = new List<AppRoleReadModel>(p70.Count);
            
            IEnumerator<AppRole> enumerator = p70.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRole item = enumerator.Current;
                result.Add(funcMain65(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserReadModel> funcMain72(ICollection<AppUser> p78)
        {
            if (p78 == null)
            {
                return null;
            }
            ICollection<AppUserReadModel> result = new List<AppUserReadModel>(p78.Count);
            
            IEnumerator<AppUser> enumerator = p78.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUser item = enumerator.Current;
                result.Add(funcMain73(item));
            }
            return result;
            
        }
        
        private static AppFeatureReadModel funcMain82(AppFeature p91)
        {
            return p91 == null ? null : new AppFeatureReadModel()
            {
                Name = p91.Name,
                Description = p91.Description,
                IsEnabled = p91.IsEnabled,
                Scope = p91.Scope,
                FeatureFlags = TypeAdapter<ICollection<AppFeatureFlag>, ICollection<AppFeatureFlagReadModel>>.Map.Invoke(p91.FeatureFlags),
                AccessControlEntries = funcMain83(p91.AccessControlEntries),
                Id = p91.Id,
                CreatedBy = p91.CreatedBy,
                CreatedDate = p91.CreatedDate,
                ModifiedBy = p91.ModifiedBy,
                ModifiedDate = p91.ModifiedDate,
                IsDeleted = p91.IsDeleted,
                DeletedBy = p91.DeletedBy,
                DeletedDate = p91.DeletedDate
            };
        }
        
        private static AppFeatureReadModel funcMain103(AppFeature p113)
        {
            return p113 == null ? null : new AppFeatureReadModel()
            {
                Name = p113.Name,
                Description = p113.Description,
                IsEnabled = p113.IsEnabled,
                Scope = p113.Scope,
                FeatureFlags = funcMain104(p113.FeatureFlags),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p113.AccessControlEntries),
                Id = p113.Id,
                CreatedBy = p113.CreatedBy,
                CreatedDate = p113.CreatedDate,
                ModifiedBy = p113.ModifiedBy,
                ModifiedDate = p113.ModifiedDate,
                IsDeleted = p113.IsDeleted,
                DeletedBy = p113.DeletedBy,
                DeletedDate = p113.DeletedDate
            };
        }
        
        private static ICollection<AppRoleReadModel> funcMain105(ICollection<AppRole> p115)
        {
            if (p115 == null)
            {
                return null;
            }
            ICollection<AppRoleReadModel> result = new List<AppRoleReadModel>(p115.Count);
            
            IEnumerator<AppRole> enumerator = p115.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRole item = enumerator.Current;
                result.Add(funcMain106(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserReadModel> funcMain113(ICollection<AppUser> p123)
        {
            if (p123 == null)
            {
                return null;
            }
            ICollection<AppUserReadModel> result = new List<AppUserReadModel>(p123.Count);
            
            IEnumerator<AppUser> enumerator = p123.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUser item = enumerator.Current;
                result.Add(funcMain114(item));
            }
            return result;
            
        }
        
        private static AppRoleReadModel funcMain5(AppRole p6)
        {
            return p6 == null ? null : new AppRoleReadModel()
            {
                CreatedBy = p6.CreatedBy,
                CreatedDate = p6.CreatedDate,
                ModifiedBy = p6.ModifiedBy,
                ModifiedDate = p6.ModifiedDate,
                IsDeleted = p6.IsDeleted,
                DeletedBy = p6.DeletedBy,
                DeletedDate = p6.DeletedDate,
                AppUserRoles = funcMain6(p6.AppUserRoles),
                AppRoleClaims = funcMain11(p6.AppRoleClaims),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p6.AccessControlEntries),
                Hash = p6.Hash,
                Id = p6.Id,
                Name = p6.Name,
                NormalizedName = p6.NormalizedName,
                ConcurrencyStamp = p6.ConcurrencyStamp
            };
        }
        
        private static AppUserReadModel funcMain13(AppUser p14)
        {
            return p14 == null ? null : new AppUserReadModel()
            {
                Hash = p14.Hash,
                FirstName = p14.FirstName,
                LastName = p14.LastName,
                Mobile = p14.Mobile,
                CountryCode = p14.CountryCode,
                TwoFactorMethod = p14.TwoFactorMethod,
                CreatedBy = p14.CreatedBy,
                CreatedDate = p14.CreatedDate,
                ModifiedBy = p14.ModifiedBy,
                ModifiedDate = p14.ModifiedDate,
                IsDeleted = p14.IsDeleted,
                DeletedBy = p14.DeletedBy,
                DeletedDate = p14.DeletedDate,
                MembershipType = p14.MembershipType,
                UserRoles = funcMain14(p14.UserRoles),
                UserTokens = funcMain18(p14.UserTokens),
                RefreshTokens = funcMain19(p14.RefreshTokens),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p14.AccessControlEntries),
                Id = p14.Id,
                UserName = p14.UserName,
                NormalizedUserName = p14.NormalizedUserName,
                Email = p14.Email,
                NormalizedEmail = p14.NormalizedEmail,
                EmailConfirmed = p14.EmailConfirmed,
                PasswordHash = p14.PasswordHash,
                SecurityStamp = p14.SecurityStamp,
                ConcurrencyStamp = p14.ConcurrencyStamp,
                PhoneNumber = p14.PhoneNumber,
                PhoneNumberConfirmed = p14.PhoneNumberConfirmed,
                TwoFactorEnabled = p14.TwoFactorEnabled,
                LockoutEnd = p14.LockoutEnd,
                LockoutEnabled = p14.LockoutEnabled,
                AccessFailedCount = p14.AccessFailedCount
            };
        }
        
        private static AppRoleReadModel funcMain24(AppRole p29)
        {
            return p29 == null ? null : new AppRoleReadModel()
            {
                CreatedBy = p29.CreatedBy,
                CreatedDate = p29.CreatedDate,
                ModifiedBy = p29.ModifiedBy,
                ModifiedDate = p29.ModifiedDate,
                IsDeleted = p29.IsDeleted,
                DeletedBy = p29.DeletedBy,
                DeletedDate = p29.DeletedDate,
                AppUserRoles = funcMain25(p29.AppUserRoles),
                AppRoleClaims = funcMain30(p29.AppRoleClaims),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p29.AccessControlEntries),
                Hash = p29.Hash,
                Id = p29.Id,
                Name = p29.Name,
                NormalizedName = p29.NormalizedName,
                ConcurrencyStamp = p29.ConcurrencyStamp
            };
        }
        
        private static AppUserReadModel funcMain32(AppUser p37)
        {
            return p37 == null ? null : new AppUserReadModel()
            {
                Hash = p37.Hash,
                FirstName = p37.FirstName,
                LastName = p37.LastName,
                Mobile = p37.Mobile,
                CountryCode = p37.CountryCode,
                TwoFactorMethod = p37.TwoFactorMethod,
                CreatedBy = p37.CreatedBy,
                CreatedDate = p37.CreatedDate,
                ModifiedBy = p37.ModifiedBy,
                ModifiedDate = p37.ModifiedDate,
                IsDeleted = p37.IsDeleted,
                DeletedBy = p37.DeletedBy,
                DeletedDate = p37.DeletedDate,
                MembershipType = p37.MembershipType,
                UserRoles = funcMain33(p37.UserRoles),
                UserTokens = funcMain37(p37.UserTokens),
                RefreshTokens = funcMain38(p37.RefreshTokens),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p37.AccessControlEntries),
                Id = p37.Id,
                UserName = p37.UserName,
                NormalizedUserName = p37.NormalizedUserName,
                Email = p37.Email,
                NormalizedEmail = p37.NormalizedEmail,
                EmailConfirmed = p37.EmailConfirmed,
                PasswordHash = p37.PasswordHash,
                SecurityStamp = p37.SecurityStamp,
                ConcurrencyStamp = p37.ConcurrencyStamp,
                PhoneNumber = p37.PhoneNumber,
                PhoneNumberConfirmed = p37.PhoneNumberConfirmed,
                TwoFactorEnabled = p37.TwoFactorEnabled,
                LockoutEnd = p37.LockoutEnd,
                LockoutEnabled = p37.LockoutEnabled,
                AccessFailedCount = p37.AccessFailedCount
            };
        }
        
        private static ICollection<AppAccessControlEntryReadModel> funcMain42(ICollection<AppAccessControlEntry> p48)
        {
            if (p48 == null)
            {
                return null;
            }
            ICollection<AppAccessControlEntryReadModel> result = new List<AppAccessControlEntryReadModel>(p48.Count);
            
            IEnumerator<AppAccessControlEntry> enumerator = p48.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppAccessControlEntry item = enumerator.Current;
                result.Add(funcMain43(item));
            }
            return result;
            
        }
        
        private static ICollection<AppFeatureFlagReadModel> funcMain63(ICollection<AppFeatureFlag> p69)
        {
            if (p69 == null)
            {
                return null;
            }
            ICollection<AppFeatureFlagReadModel> result = new List<AppFeatureFlagReadModel>(p69.Count);
            
            IEnumerator<AppFeatureFlag> enumerator = p69.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppFeatureFlag item = enumerator.Current;
                result.Add(item == null ? null : new AppFeatureFlagReadModel()
                {
                    FeatureId = item.FeatureId,
                    ScopeIdentifier = item.ScopeIdentifier,
                    IsEnabled = item.IsEnabled,
                    Feature = TypeAdapter<AppFeature, AppFeatureReadModel>.Map.Invoke(item.Feature),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static AppRoleReadModel funcMain65(AppRole p71)
        {
            return p71 == null ? null : new AppRoleReadModel()
            {
                CreatedBy = p71.CreatedBy,
                CreatedDate = p71.CreatedDate,
                ModifiedBy = p71.ModifiedBy,
                ModifiedDate = p71.ModifiedDate,
                IsDeleted = p71.IsDeleted,
                DeletedBy = p71.DeletedBy,
                DeletedDate = p71.DeletedDate,
                AppUserRoles = funcMain66(p71.AppUserRoles),
                AppRoleClaims = funcMain71(p71.AppRoleClaims),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p71.AccessControlEntries),
                Hash = p71.Hash,
                Id = p71.Id,
                Name = p71.Name,
                NormalizedName = p71.NormalizedName,
                ConcurrencyStamp = p71.ConcurrencyStamp
            };
        }
        
        private static AppUserReadModel funcMain73(AppUser p79)
        {
            return p79 == null ? null : new AppUserReadModel()
            {
                Hash = p79.Hash,
                FirstName = p79.FirstName,
                LastName = p79.LastName,
                Mobile = p79.Mobile,
                CountryCode = p79.CountryCode,
                TwoFactorMethod = p79.TwoFactorMethod,
                CreatedBy = p79.CreatedBy,
                CreatedDate = p79.CreatedDate,
                ModifiedBy = p79.ModifiedBy,
                ModifiedDate = p79.ModifiedDate,
                IsDeleted = p79.IsDeleted,
                DeletedBy = p79.DeletedBy,
                DeletedDate = p79.DeletedDate,
                MembershipType = p79.MembershipType,
                UserRoles = funcMain74(p79.UserRoles),
                UserTokens = funcMain78(p79.UserTokens),
                RefreshTokens = funcMain79(p79.RefreshTokens),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p79.AccessControlEntries),
                Id = p79.Id,
                UserName = p79.UserName,
                NormalizedUserName = p79.NormalizedUserName,
                Email = p79.Email,
                NormalizedEmail = p79.NormalizedEmail,
                EmailConfirmed = p79.EmailConfirmed,
                PasswordHash = p79.PasswordHash,
                SecurityStamp = p79.SecurityStamp,
                ConcurrencyStamp = p79.ConcurrencyStamp,
                PhoneNumber = p79.PhoneNumber,
                PhoneNumberConfirmed = p79.PhoneNumberConfirmed,
                TwoFactorEnabled = p79.TwoFactorEnabled,
                LockoutEnd = p79.LockoutEnd,
                LockoutEnabled = p79.LockoutEnabled,
                AccessFailedCount = p79.AccessFailedCount
            };
        }
        
        private static ICollection<AppAccessControlEntryReadModel> funcMain83(ICollection<AppAccessControlEntry> p92)
        {
            if (p92 == null)
            {
                return null;
            }
            ICollection<AppAccessControlEntryReadModel> result = new List<AppAccessControlEntryReadModel>(p92.Count);
            
            IEnumerator<AppAccessControlEntry> enumerator = p92.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppAccessControlEntry item = enumerator.Current;
                result.Add(funcMain84(item));
            }
            return result;
            
        }
        
        private static ICollection<AppFeatureFlagReadModel> funcMain104(ICollection<AppFeatureFlag> p114)
        {
            if (p114 == null)
            {
                return null;
            }
            ICollection<AppFeatureFlagReadModel> result = new List<AppFeatureFlagReadModel>(p114.Count);
            
            IEnumerator<AppFeatureFlag> enumerator = p114.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppFeatureFlag item = enumerator.Current;
                result.Add(item == null ? null : new AppFeatureFlagReadModel()
                {
                    FeatureId = item.FeatureId,
                    ScopeIdentifier = item.ScopeIdentifier,
                    IsEnabled = item.IsEnabled,
                    Feature = TypeAdapter<AppFeature, AppFeatureReadModel>.Map.Invoke(item.Feature),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static AppRoleReadModel funcMain106(AppRole p116)
        {
            return p116 == null ? null : new AppRoleReadModel()
            {
                CreatedBy = p116.CreatedBy,
                CreatedDate = p116.CreatedDate,
                ModifiedBy = p116.ModifiedBy,
                ModifiedDate = p116.ModifiedDate,
                IsDeleted = p116.IsDeleted,
                DeletedBy = p116.DeletedBy,
                DeletedDate = p116.DeletedDate,
                AppUserRoles = funcMain107(p116.AppUserRoles),
                AppRoleClaims = funcMain112(p116.AppRoleClaims),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p116.AccessControlEntries),
                Hash = p116.Hash,
                Id = p116.Id,
                Name = p116.Name,
                NormalizedName = p116.NormalizedName,
                ConcurrencyStamp = p116.ConcurrencyStamp
            };
        }
        
        private static AppUserReadModel funcMain114(AppUser p124)
        {
            return p124 == null ? null : new AppUserReadModel()
            {
                Hash = p124.Hash,
                FirstName = p124.FirstName,
                LastName = p124.LastName,
                Mobile = p124.Mobile,
                CountryCode = p124.CountryCode,
                TwoFactorMethod = p124.TwoFactorMethod,
                CreatedBy = p124.CreatedBy,
                CreatedDate = p124.CreatedDate,
                ModifiedBy = p124.ModifiedBy,
                ModifiedDate = p124.ModifiedDate,
                IsDeleted = p124.IsDeleted,
                DeletedBy = p124.DeletedBy,
                DeletedDate = p124.DeletedDate,
                MembershipType = p124.MembershipType,
                UserRoles = funcMain115(p124.UserRoles),
                UserTokens = funcMain119(p124.UserTokens),
                RefreshTokens = funcMain120(p124.RefreshTokens),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p124.AccessControlEntries),
                Id = p124.Id,
                UserName = p124.UserName,
                NormalizedUserName = p124.NormalizedUserName,
                Email = p124.Email,
                NormalizedEmail = p124.NormalizedEmail,
                EmailConfirmed = p124.EmailConfirmed,
                PasswordHash = p124.PasswordHash,
                SecurityStamp = p124.SecurityStamp,
                ConcurrencyStamp = p124.ConcurrencyStamp,
                PhoneNumber = p124.PhoneNumber,
                PhoneNumberConfirmed = p124.PhoneNumberConfirmed,
                TwoFactorEnabled = p124.TwoFactorEnabled,
                LockoutEnd = p124.LockoutEnd,
                LockoutEnabled = p124.LockoutEnabled,
                AccessFailedCount = p124.AccessFailedCount
            };
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain6(ICollection<AppUserRole> p7)
        {
            if (p7 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p7.Count);
            
            IEnumerator<AppUserRole> enumerator = p7.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(funcMain7(item));
            }
            return result;
            
        }
        
        private static ICollection<AppRoleClaimReadModel> funcMain11(ICollection<AppRoleClaim> p12)
        {
            if (p12 == null)
            {
                return null;
            }
            ICollection<AppRoleClaimReadModel> result = new List<AppRoleClaimReadModel>(p12.Count);
            
            IEnumerator<AppRoleClaim> enumerator = p12.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRoleClaim item = enumerator.Current;
                result.Add(item == null ? null : new AppRoleClaimReadModel()
                {
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Id = item.Id,
                    RoleId = item.RoleId,
                    ClaimType = item.ClaimType,
                    ClaimValue = item.ClaimValue
                });
            }
            return result;
            
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain14(ICollection<AppUserRole> p15)
        {
            if (p15 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p15.Count);
            
            IEnumerator<AppUserRole> enumerator = p15.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(funcMain15(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserTokenReadModel> funcMain18(ICollection<AppUserToken> p19)
        {
            if (p19 == null)
            {
                return null;
            }
            ICollection<AppUserTokenReadModel> result = new List<AppUserTokenReadModel>(p19.Count);
            
            IEnumerator<AppUserToken> enumerator = p19.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserToken item = enumerator.Current;
                result.Add(item == null ? null : new AppUserTokenReadModel()
                {
                    Token = item.Token,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    LoginProvider = item.LoginProvider,
                    Name = item.Name,
                    Value = item.Value
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRefreshTokenReadModel> funcMain19(ICollection<AppRefreshToken> p20)
        {
            if (p20 == null)
            {
                return null;
            }
            ICollection<AppRefreshTokenReadModel> result = new List<AppRefreshTokenReadModel>(p20.Count);
            
            IEnumerator<AppRefreshToken> enumerator = p20.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRefreshToken item = enumerator.Current;
                result.Add(item == null ? null : new AppRefreshTokenReadModel()
                {
                    UserId = item.UserId,
                    Token = item.Token,
                    JwtId = item.JwtId,
                    IsUsed = item.IsUsed,
                    IsRevoked = item.IsRevoked,
                    ExpiryDate = item.ExpiryDate,
                    Hash = item.Hash,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain25(ICollection<AppUserRole> p30)
        {
            if (p30 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p30.Count);
            
            IEnumerator<AppUserRole> enumerator = p30.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(funcMain26(item));
            }
            return result;
            
        }
        
        private static ICollection<AppRoleClaimReadModel> funcMain30(ICollection<AppRoleClaim> p35)
        {
            if (p35 == null)
            {
                return null;
            }
            ICollection<AppRoleClaimReadModel> result = new List<AppRoleClaimReadModel>(p35.Count);
            
            IEnumerator<AppRoleClaim> enumerator = p35.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRoleClaim item = enumerator.Current;
                result.Add(item == null ? null : new AppRoleClaimReadModel()
                {
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Id = item.Id,
                    RoleId = item.RoleId,
                    ClaimType = item.ClaimType,
                    ClaimValue = item.ClaimValue
                });
            }
            return result;
            
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain33(ICollection<AppUserRole> p38)
        {
            if (p38 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p38.Count);
            
            IEnumerator<AppUserRole> enumerator = p38.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(funcMain34(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserTokenReadModel> funcMain37(ICollection<AppUserToken> p42)
        {
            if (p42 == null)
            {
                return null;
            }
            ICollection<AppUserTokenReadModel> result = new List<AppUserTokenReadModel>(p42.Count);
            
            IEnumerator<AppUserToken> enumerator = p42.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserToken item = enumerator.Current;
                result.Add(item == null ? null : new AppUserTokenReadModel()
                {
                    Token = item.Token,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    LoginProvider = item.LoginProvider,
                    Name = item.Name,
                    Value = item.Value
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRefreshTokenReadModel> funcMain38(ICollection<AppRefreshToken> p43)
        {
            if (p43 == null)
            {
                return null;
            }
            ICollection<AppRefreshTokenReadModel> result = new List<AppRefreshTokenReadModel>(p43.Count);
            
            IEnumerator<AppRefreshToken> enumerator = p43.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRefreshToken item = enumerator.Current;
                result.Add(item == null ? null : new AppRefreshTokenReadModel()
                {
                    UserId = item.UserId,
                    Token = item.Token,
                    JwtId = item.JwtId,
                    IsUsed = item.IsUsed,
                    IsRevoked = item.IsRevoked,
                    ExpiryDate = item.ExpiryDate,
                    Hash = item.Hash,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static AppAccessControlEntryReadModel funcMain43(AppAccessControlEntry p49)
        {
            return p49 == null ? null : new AppAccessControlEntryReadModel()
            {
                ResourcePattern = p49.ResourcePattern,
                PermissionPattern = p49.PermissionPattern,
                FeatureId = p49.FeatureId,
                Feature = TypeAdapter<AppFeature, AppFeatureReadModel>.Map.Invoke(p49.Feature),
                AppRoles = funcMain44(p49.AppRoles),
                AppUsers = funcMain52(p49.AppUsers),
                AppResource = p49.AppResource == null ? null : new AppResourceReadModel()
                {
                    Url = p49.AppResource.Url,
                    Description = p49.AppResource.Description,
                    ResourceType = p49.AppResource.ResourceType,
                    AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p49.AppResource.AccessControlEntries),
                    Id = p49.AppResource.Id,
                    CreatedBy = p49.AppResource.CreatedBy,
                    CreatedDate = p49.AppResource.CreatedDate,
                    ModifiedBy = p49.AppResource.ModifiedBy,
                    ModifiedDate = p49.AppResource.ModifiedDate,
                    IsDeleted = p49.AppResource.IsDeleted,
                    DeletedBy = p49.AppResource.DeletedBy,
                    DeletedDate = p49.AppResource.DeletedDate
                },
                ResourceId = p49.ResourceId,
                Id = p49.Id,
                CreatedBy = p49.CreatedBy,
                CreatedDate = p49.CreatedDate,
                ModifiedBy = p49.ModifiedBy,
                ModifiedDate = p49.ModifiedDate,
                IsDeleted = p49.IsDeleted,
                DeletedBy = p49.DeletedBy,
                DeletedDate = p49.DeletedDate
            };
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain66(ICollection<AppUserRole> p72)
        {
            if (p72 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p72.Count);
            
            IEnumerator<AppUserRole> enumerator = p72.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(funcMain67(item));
            }
            return result;
            
        }
        
        private static ICollection<AppRoleClaimReadModel> funcMain71(ICollection<AppRoleClaim> p77)
        {
            if (p77 == null)
            {
                return null;
            }
            ICollection<AppRoleClaimReadModel> result = new List<AppRoleClaimReadModel>(p77.Count);
            
            IEnumerator<AppRoleClaim> enumerator = p77.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRoleClaim item = enumerator.Current;
                result.Add(item == null ? null : new AppRoleClaimReadModel()
                {
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Id = item.Id,
                    RoleId = item.RoleId,
                    ClaimType = item.ClaimType,
                    ClaimValue = item.ClaimValue
                });
            }
            return result;
            
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain74(ICollection<AppUserRole> p80)
        {
            if (p80 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p80.Count);
            
            IEnumerator<AppUserRole> enumerator = p80.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(funcMain75(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserTokenReadModel> funcMain78(ICollection<AppUserToken> p84)
        {
            if (p84 == null)
            {
                return null;
            }
            ICollection<AppUserTokenReadModel> result = new List<AppUserTokenReadModel>(p84.Count);
            
            IEnumerator<AppUserToken> enumerator = p84.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserToken item = enumerator.Current;
                result.Add(item == null ? null : new AppUserTokenReadModel()
                {
                    Token = item.Token,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    LoginProvider = item.LoginProvider,
                    Name = item.Name,
                    Value = item.Value
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRefreshTokenReadModel> funcMain79(ICollection<AppRefreshToken> p85)
        {
            if (p85 == null)
            {
                return null;
            }
            ICollection<AppRefreshTokenReadModel> result = new List<AppRefreshTokenReadModel>(p85.Count);
            
            IEnumerator<AppRefreshToken> enumerator = p85.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRefreshToken item = enumerator.Current;
                result.Add(item == null ? null : new AppRefreshTokenReadModel()
                {
                    UserId = item.UserId,
                    Token = item.Token,
                    JwtId = item.JwtId,
                    IsUsed = item.IsUsed,
                    IsRevoked = item.IsRevoked,
                    ExpiryDate = item.ExpiryDate,
                    Hash = item.Hash,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static AppAccessControlEntryReadModel funcMain84(AppAccessControlEntry p93)
        {
            return p93 == null ? null : new AppAccessControlEntryReadModel()
            {
                ResourcePattern = p93.ResourcePattern,
                PermissionPattern = p93.PermissionPattern,
                FeatureId = p93.FeatureId,
                Feature = TypeAdapter<AppFeature, AppFeatureReadModel>.Map.Invoke(p93.Feature),
                AppRoles = funcMain85(p93.AppRoles),
                AppUsers = funcMain93(p93.AppUsers),
                AppResource = p93.AppResource == null ? null : new AppResourceReadModel()
                {
                    Url = p93.AppResource.Url,
                    Description = p93.AppResource.Description,
                    ResourceType = p93.AppResource.ResourceType,
                    AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p93.AppResource.AccessControlEntries),
                    Id = p93.AppResource.Id,
                    CreatedBy = p93.AppResource.CreatedBy,
                    CreatedDate = p93.AppResource.CreatedDate,
                    ModifiedBy = p93.AppResource.ModifiedBy,
                    ModifiedDate = p93.AppResource.ModifiedDate,
                    IsDeleted = p93.AppResource.IsDeleted,
                    DeletedBy = p93.AppResource.DeletedBy,
                    DeletedDate = p93.AppResource.DeletedDate
                },
                ResourceId = p93.ResourceId,
                Id = p93.Id,
                CreatedBy = p93.CreatedBy,
                CreatedDate = p93.CreatedDate,
                ModifiedBy = p93.ModifiedBy,
                ModifiedDate = p93.ModifiedDate,
                IsDeleted = p93.IsDeleted,
                DeletedBy = p93.DeletedBy,
                DeletedDate = p93.DeletedDate
            };
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain107(ICollection<AppUserRole> p117)
        {
            if (p117 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p117.Count);
            
            IEnumerator<AppUserRole> enumerator = p117.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(funcMain108(item));
            }
            return result;
            
        }
        
        private static ICollection<AppRoleClaimReadModel> funcMain112(ICollection<AppRoleClaim> p122)
        {
            if (p122 == null)
            {
                return null;
            }
            ICollection<AppRoleClaimReadModel> result = new List<AppRoleClaimReadModel>(p122.Count);
            
            IEnumerator<AppRoleClaim> enumerator = p122.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRoleClaim item = enumerator.Current;
                result.Add(item == null ? null : new AppRoleClaimReadModel()
                {
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Id = item.Id,
                    RoleId = item.RoleId,
                    ClaimType = item.ClaimType,
                    ClaimValue = item.ClaimValue
                });
            }
            return result;
            
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain115(ICollection<AppUserRole> p125)
        {
            if (p125 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p125.Count);
            
            IEnumerator<AppUserRole> enumerator = p125.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(funcMain116(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserTokenReadModel> funcMain119(ICollection<AppUserToken> p129)
        {
            if (p129 == null)
            {
                return null;
            }
            ICollection<AppUserTokenReadModel> result = new List<AppUserTokenReadModel>(p129.Count);
            
            IEnumerator<AppUserToken> enumerator = p129.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserToken item = enumerator.Current;
                result.Add(item == null ? null : new AppUserTokenReadModel()
                {
                    Token = item.Token,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    LoginProvider = item.LoginProvider,
                    Name = item.Name,
                    Value = item.Value
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRefreshTokenReadModel> funcMain120(ICollection<AppRefreshToken> p130)
        {
            if (p130 == null)
            {
                return null;
            }
            ICollection<AppRefreshTokenReadModel> result = new List<AppRefreshTokenReadModel>(p130.Count);
            
            IEnumerator<AppRefreshToken> enumerator = p130.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRefreshToken item = enumerator.Current;
                result.Add(item == null ? null : new AppRefreshTokenReadModel()
                {
                    UserId = item.UserId,
                    Token = item.Token,
                    JwtId = item.JwtId,
                    IsUsed = item.IsUsed,
                    IsRevoked = item.IsRevoked,
                    ExpiryDate = item.ExpiryDate,
                    Hash = item.Hash,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static AppUserRoleReadModel funcMain7(AppUserRole p8)
        {
            return p8 == null ? null : new AppUserRoleReadModel()
            {
                AppUser = funcMain8(p8.AppUser),
                AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(p8.AppRole),
                Hash = p8.Hash,
                CreatedBy = p8.CreatedBy,
                CreatedDate = p8.CreatedDate,
                ModifiedBy = p8.ModifiedBy,
                ModifiedDate = p8.ModifiedDate,
                IsDeleted = p8.IsDeleted,
                DeletedBy = p8.DeletedBy,
                DeletedDate = p8.DeletedDate,
                UserId = p8.UserId,
                RoleId = p8.RoleId
            };
        }
        
        private static AppUserRoleReadModel funcMain15(AppUserRole p16)
        {
            return p16 == null ? null : new AppUserRoleReadModel()
            {
                AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(p16.AppUser),
                AppRole = funcMain16(p16.AppRole),
                Hash = p16.Hash,
                CreatedBy = p16.CreatedBy,
                CreatedDate = p16.CreatedDate,
                ModifiedBy = p16.ModifiedBy,
                ModifiedDate = p16.ModifiedDate,
                IsDeleted = p16.IsDeleted,
                DeletedBy = p16.DeletedBy,
                DeletedDate = p16.DeletedDate,
                UserId = p16.UserId,
                RoleId = p16.RoleId
            };
        }
        
        private static AppUserRoleReadModel funcMain26(AppUserRole p31)
        {
            return p31 == null ? null : new AppUserRoleReadModel()
            {
                AppUser = funcMain27(p31.AppUser),
                AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(p31.AppRole),
                Hash = p31.Hash,
                CreatedBy = p31.CreatedBy,
                CreatedDate = p31.CreatedDate,
                ModifiedBy = p31.ModifiedBy,
                ModifiedDate = p31.ModifiedDate,
                IsDeleted = p31.IsDeleted,
                DeletedBy = p31.DeletedBy,
                DeletedDate = p31.DeletedDate,
                UserId = p31.UserId,
                RoleId = p31.RoleId
            };
        }
        
        private static AppUserRoleReadModel funcMain34(AppUserRole p39)
        {
            return p39 == null ? null : new AppUserRoleReadModel()
            {
                AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(p39.AppUser),
                AppRole = funcMain35(p39.AppRole),
                Hash = p39.Hash,
                CreatedBy = p39.CreatedBy,
                CreatedDate = p39.CreatedDate,
                ModifiedBy = p39.ModifiedBy,
                ModifiedDate = p39.ModifiedDate,
                IsDeleted = p39.IsDeleted,
                DeletedBy = p39.DeletedBy,
                DeletedDate = p39.DeletedDate,
                UserId = p39.UserId,
                RoleId = p39.RoleId
            };
        }
        
        private static ICollection<AppRoleReadModel> funcMain44(ICollection<AppRole> p50)
        {
            if (p50 == null)
            {
                return null;
            }
            ICollection<AppRoleReadModel> result = new List<AppRoleReadModel>(p50.Count);
            
            IEnumerator<AppRole> enumerator = p50.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRole item = enumerator.Current;
                result.Add(funcMain45(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserReadModel> funcMain52(ICollection<AppUser> p58)
        {
            if (p58 == null)
            {
                return null;
            }
            ICollection<AppUserReadModel> result = new List<AppUserReadModel>(p58.Count);
            
            IEnumerator<AppUser> enumerator = p58.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUser item = enumerator.Current;
                result.Add(funcMain53(item));
            }
            return result;
            
        }
        
        private static AppUserRoleReadModel funcMain67(AppUserRole p73)
        {
            return p73 == null ? null : new AppUserRoleReadModel()
            {
                AppUser = funcMain68(p73.AppUser),
                AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(p73.AppRole),
                Hash = p73.Hash,
                CreatedBy = p73.CreatedBy,
                CreatedDate = p73.CreatedDate,
                ModifiedBy = p73.ModifiedBy,
                ModifiedDate = p73.ModifiedDate,
                IsDeleted = p73.IsDeleted,
                DeletedBy = p73.DeletedBy,
                DeletedDate = p73.DeletedDate,
                UserId = p73.UserId,
                RoleId = p73.RoleId
            };
        }
        
        private static AppUserRoleReadModel funcMain75(AppUserRole p81)
        {
            return p81 == null ? null : new AppUserRoleReadModel()
            {
                AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(p81.AppUser),
                AppRole = funcMain76(p81.AppRole),
                Hash = p81.Hash,
                CreatedBy = p81.CreatedBy,
                CreatedDate = p81.CreatedDate,
                ModifiedBy = p81.ModifiedBy,
                ModifiedDate = p81.ModifiedDate,
                IsDeleted = p81.IsDeleted,
                DeletedBy = p81.DeletedBy,
                DeletedDate = p81.DeletedDate,
                UserId = p81.UserId,
                RoleId = p81.RoleId
            };
        }
        
        private static ICollection<AppRoleReadModel> funcMain85(ICollection<AppRole> p94)
        {
            if (p94 == null)
            {
                return null;
            }
            ICollection<AppRoleReadModel> result = new List<AppRoleReadModel>(p94.Count);
            
            IEnumerator<AppRole> enumerator = p94.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRole item = enumerator.Current;
                result.Add(funcMain86(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserReadModel> funcMain93(ICollection<AppUser> p102)
        {
            if (p102 == null)
            {
                return null;
            }
            ICollection<AppUserReadModel> result = new List<AppUserReadModel>(p102.Count);
            
            IEnumerator<AppUser> enumerator = p102.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUser item = enumerator.Current;
                result.Add(funcMain94(item));
            }
            return result;
            
        }
        
        private static AppUserRoleReadModel funcMain108(AppUserRole p118)
        {
            return p118 == null ? null : new AppUserRoleReadModel()
            {
                AppUser = funcMain109(p118.AppUser),
                AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(p118.AppRole),
                Hash = p118.Hash,
                CreatedBy = p118.CreatedBy,
                CreatedDate = p118.CreatedDate,
                ModifiedBy = p118.ModifiedBy,
                ModifiedDate = p118.ModifiedDate,
                IsDeleted = p118.IsDeleted,
                DeletedBy = p118.DeletedBy,
                DeletedDate = p118.DeletedDate,
                UserId = p118.UserId,
                RoleId = p118.RoleId
            };
        }
        
        private static AppUserRoleReadModel funcMain116(AppUserRole p126)
        {
            return p126 == null ? null : new AppUserRoleReadModel()
            {
                AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(p126.AppUser),
                AppRole = funcMain117(p126.AppRole),
                Hash = p126.Hash,
                CreatedBy = p126.CreatedBy,
                CreatedDate = p126.CreatedDate,
                ModifiedBy = p126.ModifiedBy,
                ModifiedDate = p126.ModifiedDate,
                IsDeleted = p126.IsDeleted,
                DeletedBy = p126.DeletedBy,
                DeletedDate = p126.DeletedDate,
                UserId = p126.UserId,
                RoleId = p126.RoleId
            };
        }
        
        private static AppUserReadModel funcMain8(AppUser p9)
        {
            return p9 == null ? null : new AppUserReadModel()
            {
                Hash = p9.Hash,
                FirstName = p9.FirstName,
                LastName = p9.LastName,
                Mobile = p9.Mobile,
                CountryCode = p9.CountryCode,
                TwoFactorMethod = p9.TwoFactorMethod,
                CreatedBy = p9.CreatedBy,
                CreatedDate = p9.CreatedDate,
                ModifiedBy = p9.ModifiedBy,
                ModifiedDate = p9.ModifiedDate,
                IsDeleted = p9.IsDeleted,
                DeletedBy = p9.DeletedBy,
                DeletedDate = p9.DeletedDate,
                MembershipType = p9.MembershipType,
                UserRoles = TypeAdapter<ICollection<AppUserRole>, ICollection<AppUserRoleReadModel>>.Map.Invoke(p9.UserRoles),
                UserTokens = funcMain9(p9.UserTokens),
                RefreshTokens = funcMain10(p9.RefreshTokens),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p9.AccessControlEntries),
                Id = p9.Id,
                UserName = p9.UserName,
                NormalizedUserName = p9.NormalizedUserName,
                Email = p9.Email,
                NormalizedEmail = p9.NormalizedEmail,
                EmailConfirmed = p9.EmailConfirmed,
                PasswordHash = p9.PasswordHash,
                SecurityStamp = p9.SecurityStamp,
                ConcurrencyStamp = p9.ConcurrencyStamp,
                PhoneNumber = p9.PhoneNumber,
                PhoneNumberConfirmed = p9.PhoneNumberConfirmed,
                TwoFactorEnabled = p9.TwoFactorEnabled,
                LockoutEnd = p9.LockoutEnd,
                LockoutEnabled = p9.LockoutEnabled,
                AccessFailedCount = p9.AccessFailedCount
            };
        }
        
        private static AppRoleReadModel funcMain16(AppRole p17)
        {
            return p17 == null ? null : new AppRoleReadModel()
            {
                CreatedBy = p17.CreatedBy,
                CreatedDate = p17.CreatedDate,
                ModifiedBy = p17.ModifiedBy,
                ModifiedDate = p17.ModifiedDate,
                IsDeleted = p17.IsDeleted,
                DeletedBy = p17.DeletedBy,
                DeletedDate = p17.DeletedDate,
                AppUserRoles = TypeAdapter<ICollection<AppUserRole>, ICollection<AppUserRoleReadModel>>.Map.Invoke(p17.AppUserRoles),
                AppRoleClaims = funcMain17(p17.AppRoleClaims),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p17.AccessControlEntries),
                Hash = p17.Hash,
                Id = p17.Id,
                Name = p17.Name,
                NormalizedName = p17.NormalizedName,
                ConcurrencyStamp = p17.ConcurrencyStamp
            };
        }
        
        private static AppUserReadModel funcMain27(AppUser p32)
        {
            return p32 == null ? null : new AppUserReadModel()
            {
                Hash = p32.Hash,
                FirstName = p32.FirstName,
                LastName = p32.LastName,
                Mobile = p32.Mobile,
                CountryCode = p32.CountryCode,
                TwoFactorMethod = p32.TwoFactorMethod,
                CreatedBy = p32.CreatedBy,
                CreatedDate = p32.CreatedDate,
                ModifiedBy = p32.ModifiedBy,
                ModifiedDate = p32.ModifiedDate,
                IsDeleted = p32.IsDeleted,
                DeletedBy = p32.DeletedBy,
                DeletedDate = p32.DeletedDate,
                MembershipType = p32.MembershipType,
                UserRoles = TypeAdapter<ICollection<AppUserRole>, ICollection<AppUserRoleReadModel>>.Map.Invoke(p32.UserRoles),
                UserTokens = funcMain28(p32.UserTokens),
                RefreshTokens = funcMain29(p32.RefreshTokens),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p32.AccessControlEntries),
                Id = p32.Id,
                UserName = p32.UserName,
                NormalizedUserName = p32.NormalizedUserName,
                Email = p32.Email,
                NormalizedEmail = p32.NormalizedEmail,
                EmailConfirmed = p32.EmailConfirmed,
                PasswordHash = p32.PasswordHash,
                SecurityStamp = p32.SecurityStamp,
                ConcurrencyStamp = p32.ConcurrencyStamp,
                PhoneNumber = p32.PhoneNumber,
                PhoneNumberConfirmed = p32.PhoneNumberConfirmed,
                TwoFactorEnabled = p32.TwoFactorEnabled,
                LockoutEnd = p32.LockoutEnd,
                LockoutEnabled = p32.LockoutEnabled,
                AccessFailedCount = p32.AccessFailedCount
            };
        }
        
        private static AppRoleReadModel funcMain35(AppRole p40)
        {
            return p40 == null ? null : new AppRoleReadModel()
            {
                CreatedBy = p40.CreatedBy,
                CreatedDate = p40.CreatedDate,
                ModifiedBy = p40.ModifiedBy,
                ModifiedDate = p40.ModifiedDate,
                IsDeleted = p40.IsDeleted,
                DeletedBy = p40.DeletedBy,
                DeletedDate = p40.DeletedDate,
                AppUserRoles = TypeAdapter<ICollection<AppUserRole>, ICollection<AppUserRoleReadModel>>.Map.Invoke(p40.AppUserRoles),
                AppRoleClaims = funcMain36(p40.AppRoleClaims),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p40.AccessControlEntries),
                Hash = p40.Hash,
                Id = p40.Id,
                Name = p40.Name,
                NormalizedName = p40.NormalizedName,
                ConcurrencyStamp = p40.ConcurrencyStamp
            };
        }
        
        private static AppRoleReadModel funcMain45(AppRole p51)
        {
            return p51 == null ? null : new AppRoleReadModel()
            {
                CreatedBy = p51.CreatedBy,
                CreatedDate = p51.CreatedDate,
                ModifiedBy = p51.ModifiedBy,
                ModifiedDate = p51.ModifiedDate,
                IsDeleted = p51.IsDeleted,
                DeletedBy = p51.DeletedBy,
                DeletedDate = p51.DeletedDate,
                AppUserRoles = funcMain46(p51.AppUserRoles),
                AppRoleClaims = funcMain51(p51.AppRoleClaims),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p51.AccessControlEntries),
                Hash = p51.Hash,
                Id = p51.Id,
                Name = p51.Name,
                NormalizedName = p51.NormalizedName,
                ConcurrencyStamp = p51.ConcurrencyStamp
            };
        }
        
        private static AppUserReadModel funcMain53(AppUser p59)
        {
            return p59 == null ? null : new AppUserReadModel()
            {
                Hash = p59.Hash,
                FirstName = p59.FirstName,
                LastName = p59.LastName,
                Mobile = p59.Mobile,
                CountryCode = p59.CountryCode,
                TwoFactorMethod = p59.TwoFactorMethod,
                CreatedBy = p59.CreatedBy,
                CreatedDate = p59.CreatedDate,
                ModifiedBy = p59.ModifiedBy,
                ModifiedDate = p59.ModifiedDate,
                IsDeleted = p59.IsDeleted,
                DeletedBy = p59.DeletedBy,
                DeletedDate = p59.DeletedDate,
                MembershipType = p59.MembershipType,
                UserRoles = funcMain54(p59.UserRoles),
                UserTokens = funcMain58(p59.UserTokens),
                RefreshTokens = funcMain59(p59.RefreshTokens),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p59.AccessControlEntries),
                Id = p59.Id,
                UserName = p59.UserName,
                NormalizedUserName = p59.NormalizedUserName,
                Email = p59.Email,
                NormalizedEmail = p59.NormalizedEmail,
                EmailConfirmed = p59.EmailConfirmed,
                PasswordHash = p59.PasswordHash,
                SecurityStamp = p59.SecurityStamp,
                ConcurrencyStamp = p59.ConcurrencyStamp,
                PhoneNumber = p59.PhoneNumber,
                PhoneNumberConfirmed = p59.PhoneNumberConfirmed,
                TwoFactorEnabled = p59.TwoFactorEnabled,
                LockoutEnd = p59.LockoutEnd,
                LockoutEnabled = p59.LockoutEnabled,
                AccessFailedCount = p59.AccessFailedCount
            };
        }
        
        private static AppUserReadModel funcMain68(AppUser p74)
        {
            return p74 == null ? null : new AppUserReadModel()
            {
                Hash = p74.Hash,
                FirstName = p74.FirstName,
                LastName = p74.LastName,
                Mobile = p74.Mobile,
                CountryCode = p74.CountryCode,
                TwoFactorMethod = p74.TwoFactorMethod,
                CreatedBy = p74.CreatedBy,
                CreatedDate = p74.CreatedDate,
                ModifiedBy = p74.ModifiedBy,
                ModifiedDate = p74.ModifiedDate,
                IsDeleted = p74.IsDeleted,
                DeletedBy = p74.DeletedBy,
                DeletedDate = p74.DeletedDate,
                MembershipType = p74.MembershipType,
                UserRoles = TypeAdapter<ICollection<AppUserRole>, ICollection<AppUserRoleReadModel>>.Map.Invoke(p74.UserRoles),
                UserTokens = funcMain69(p74.UserTokens),
                RefreshTokens = funcMain70(p74.RefreshTokens),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p74.AccessControlEntries),
                Id = p74.Id,
                UserName = p74.UserName,
                NormalizedUserName = p74.NormalizedUserName,
                Email = p74.Email,
                NormalizedEmail = p74.NormalizedEmail,
                EmailConfirmed = p74.EmailConfirmed,
                PasswordHash = p74.PasswordHash,
                SecurityStamp = p74.SecurityStamp,
                ConcurrencyStamp = p74.ConcurrencyStamp,
                PhoneNumber = p74.PhoneNumber,
                PhoneNumberConfirmed = p74.PhoneNumberConfirmed,
                TwoFactorEnabled = p74.TwoFactorEnabled,
                LockoutEnd = p74.LockoutEnd,
                LockoutEnabled = p74.LockoutEnabled,
                AccessFailedCount = p74.AccessFailedCount
            };
        }
        
        private static AppRoleReadModel funcMain76(AppRole p82)
        {
            return p82 == null ? null : new AppRoleReadModel()
            {
                CreatedBy = p82.CreatedBy,
                CreatedDate = p82.CreatedDate,
                ModifiedBy = p82.ModifiedBy,
                ModifiedDate = p82.ModifiedDate,
                IsDeleted = p82.IsDeleted,
                DeletedBy = p82.DeletedBy,
                DeletedDate = p82.DeletedDate,
                AppUserRoles = TypeAdapter<ICollection<AppUserRole>, ICollection<AppUserRoleReadModel>>.Map.Invoke(p82.AppUserRoles),
                AppRoleClaims = funcMain77(p82.AppRoleClaims),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p82.AccessControlEntries),
                Hash = p82.Hash,
                Id = p82.Id,
                Name = p82.Name,
                NormalizedName = p82.NormalizedName,
                ConcurrencyStamp = p82.ConcurrencyStamp
            };
        }
        
        private static AppRoleReadModel funcMain86(AppRole p95)
        {
            return p95 == null ? null : new AppRoleReadModel()
            {
                CreatedBy = p95.CreatedBy,
                CreatedDate = p95.CreatedDate,
                ModifiedBy = p95.ModifiedBy,
                ModifiedDate = p95.ModifiedDate,
                IsDeleted = p95.IsDeleted,
                DeletedBy = p95.DeletedBy,
                DeletedDate = p95.DeletedDate,
                AppUserRoles = funcMain87(p95.AppUserRoles),
                AppRoleClaims = funcMain92(p95.AppRoleClaims),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p95.AccessControlEntries),
                Hash = p95.Hash,
                Id = p95.Id,
                Name = p95.Name,
                NormalizedName = p95.NormalizedName,
                ConcurrencyStamp = p95.ConcurrencyStamp
            };
        }
        
        private static AppUserReadModel funcMain94(AppUser p103)
        {
            return p103 == null ? null : new AppUserReadModel()
            {
                Hash = p103.Hash,
                FirstName = p103.FirstName,
                LastName = p103.LastName,
                Mobile = p103.Mobile,
                CountryCode = p103.CountryCode,
                TwoFactorMethod = p103.TwoFactorMethod,
                CreatedBy = p103.CreatedBy,
                CreatedDate = p103.CreatedDate,
                ModifiedBy = p103.ModifiedBy,
                ModifiedDate = p103.ModifiedDate,
                IsDeleted = p103.IsDeleted,
                DeletedBy = p103.DeletedBy,
                DeletedDate = p103.DeletedDate,
                MembershipType = p103.MembershipType,
                UserRoles = funcMain95(p103.UserRoles),
                UserTokens = funcMain99(p103.UserTokens),
                RefreshTokens = funcMain100(p103.RefreshTokens),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p103.AccessControlEntries),
                Id = p103.Id,
                UserName = p103.UserName,
                NormalizedUserName = p103.NormalizedUserName,
                Email = p103.Email,
                NormalizedEmail = p103.NormalizedEmail,
                EmailConfirmed = p103.EmailConfirmed,
                PasswordHash = p103.PasswordHash,
                SecurityStamp = p103.SecurityStamp,
                ConcurrencyStamp = p103.ConcurrencyStamp,
                PhoneNumber = p103.PhoneNumber,
                PhoneNumberConfirmed = p103.PhoneNumberConfirmed,
                TwoFactorEnabled = p103.TwoFactorEnabled,
                LockoutEnd = p103.LockoutEnd,
                LockoutEnabled = p103.LockoutEnabled,
                AccessFailedCount = p103.AccessFailedCount
            };
        }
        
        private static AppUserReadModel funcMain109(AppUser p119)
        {
            return p119 == null ? null : new AppUserReadModel()
            {
                Hash = p119.Hash,
                FirstName = p119.FirstName,
                LastName = p119.LastName,
                Mobile = p119.Mobile,
                CountryCode = p119.CountryCode,
                TwoFactorMethod = p119.TwoFactorMethod,
                CreatedBy = p119.CreatedBy,
                CreatedDate = p119.CreatedDate,
                ModifiedBy = p119.ModifiedBy,
                ModifiedDate = p119.ModifiedDate,
                IsDeleted = p119.IsDeleted,
                DeletedBy = p119.DeletedBy,
                DeletedDate = p119.DeletedDate,
                MembershipType = p119.MembershipType,
                UserRoles = TypeAdapter<ICollection<AppUserRole>, ICollection<AppUserRoleReadModel>>.Map.Invoke(p119.UserRoles),
                UserTokens = funcMain110(p119.UserTokens),
                RefreshTokens = funcMain111(p119.RefreshTokens),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p119.AccessControlEntries),
                Id = p119.Id,
                UserName = p119.UserName,
                NormalizedUserName = p119.NormalizedUserName,
                Email = p119.Email,
                NormalizedEmail = p119.NormalizedEmail,
                EmailConfirmed = p119.EmailConfirmed,
                PasswordHash = p119.PasswordHash,
                SecurityStamp = p119.SecurityStamp,
                ConcurrencyStamp = p119.ConcurrencyStamp,
                PhoneNumber = p119.PhoneNumber,
                PhoneNumberConfirmed = p119.PhoneNumberConfirmed,
                TwoFactorEnabled = p119.TwoFactorEnabled,
                LockoutEnd = p119.LockoutEnd,
                LockoutEnabled = p119.LockoutEnabled,
                AccessFailedCount = p119.AccessFailedCount
            };
        }
        
        private static AppRoleReadModel funcMain117(AppRole p127)
        {
            return p127 == null ? null : new AppRoleReadModel()
            {
                CreatedBy = p127.CreatedBy,
                CreatedDate = p127.CreatedDate,
                ModifiedBy = p127.ModifiedBy,
                ModifiedDate = p127.ModifiedDate,
                IsDeleted = p127.IsDeleted,
                DeletedBy = p127.DeletedBy,
                DeletedDate = p127.DeletedDate,
                AppUserRoles = TypeAdapter<ICollection<AppUserRole>, ICollection<AppUserRoleReadModel>>.Map.Invoke(p127.AppUserRoles),
                AppRoleClaims = funcMain118(p127.AppRoleClaims),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p127.AccessControlEntries),
                Hash = p127.Hash,
                Id = p127.Id,
                Name = p127.Name,
                NormalizedName = p127.NormalizedName,
                ConcurrencyStamp = p127.ConcurrencyStamp
            };
        }
        
        private static ICollection<AppUserTokenReadModel> funcMain9(ICollection<AppUserToken> p10)
        {
            if (p10 == null)
            {
                return null;
            }
            ICollection<AppUserTokenReadModel> result = new List<AppUserTokenReadModel>(p10.Count);
            
            IEnumerator<AppUserToken> enumerator = p10.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserToken item = enumerator.Current;
                result.Add(item == null ? null : new AppUserTokenReadModel()
                {
                    Token = item.Token,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    LoginProvider = item.LoginProvider,
                    Name = item.Name,
                    Value = item.Value
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRefreshTokenReadModel> funcMain10(ICollection<AppRefreshToken> p11)
        {
            if (p11 == null)
            {
                return null;
            }
            ICollection<AppRefreshTokenReadModel> result = new List<AppRefreshTokenReadModel>(p11.Count);
            
            IEnumerator<AppRefreshToken> enumerator = p11.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRefreshToken item = enumerator.Current;
                result.Add(item == null ? null : new AppRefreshTokenReadModel()
                {
                    UserId = item.UserId,
                    Token = item.Token,
                    JwtId = item.JwtId,
                    IsUsed = item.IsUsed,
                    IsRevoked = item.IsRevoked,
                    ExpiryDate = item.ExpiryDate,
                    Hash = item.Hash,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRoleClaimReadModel> funcMain17(ICollection<AppRoleClaim> p18)
        {
            if (p18 == null)
            {
                return null;
            }
            ICollection<AppRoleClaimReadModel> result = new List<AppRoleClaimReadModel>(p18.Count);
            
            IEnumerator<AppRoleClaim> enumerator = p18.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRoleClaim item = enumerator.Current;
                result.Add(item == null ? null : new AppRoleClaimReadModel()
                {
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Id = item.Id,
                    RoleId = item.RoleId,
                    ClaimType = item.ClaimType,
                    ClaimValue = item.ClaimValue
                });
            }
            return result;
            
        }
        
        private static ICollection<AppUserTokenReadModel> funcMain28(ICollection<AppUserToken> p33)
        {
            if (p33 == null)
            {
                return null;
            }
            ICollection<AppUserTokenReadModel> result = new List<AppUserTokenReadModel>(p33.Count);
            
            IEnumerator<AppUserToken> enumerator = p33.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserToken item = enumerator.Current;
                result.Add(item == null ? null : new AppUserTokenReadModel()
                {
                    Token = item.Token,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    LoginProvider = item.LoginProvider,
                    Name = item.Name,
                    Value = item.Value
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRefreshTokenReadModel> funcMain29(ICollection<AppRefreshToken> p34)
        {
            if (p34 == null)
            {
                return null;
            }
            ICollection<AppRefreshTokenReadModel> result = new List<AppRefreshTokenReadModel>(p34.Count);
            
            IEnumerator<AppRefreshToken> enumerator = p34.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRefreshToken item = enumerator.Current;
                result.Add(item == null ? null : new AppRefreshTokenReadModel()
                {
                    UserId = item.UserId,
                    Token = item.Token,
                    JwtId = item.JwtId,
                    IsUsed = item.IsUsed,
                    IsRevoked = item.IsRevoked,
                    ExpiryDate = item.ExpiryDate,
                    Hash = item.Hash,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRoleClaimReadModel> funcMain36(ICollection<AppRoleClaim> p41)
        {
            if (p41 == null)
            {
                return null;
            }
            ICollection<AppRoleClaimReadModel> result = new List<AppRoleClaimReadModel>(p41.Count);
            
            IEnumerator<AppRoleClaim> enumerator = p41.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRoleClaim item = enumerator.Current;
                result.Add(item == null ? null : new AppRoleClaimReadModel()
                {
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Id = item.Id,
                    RoleId = item.RoleId,
                    ClaimType = item.ClaimType,
                    ClaimValue = item.ClaimValue
                });
            }
            return result;
            
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain46(ICollection<AppUserRole> p52)
        {
            if (p52 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p52.Count);
            
            IEnumerator<AppUserRole> enumerator = p52.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(funcMain47(item));
            }
            return result;
            
        }
        
        private static ICollection<AppRoleClaimReadModel> funcMain51(ICollection<AppRoleClaim> p57)
        {
            if (p57 == null)
            {
                return null;
            }
            ICollection<AppRoleClaimReadModel> result = new List<AppRoleClaimReadModel>(p57.Count);
            
            IEnumerator<AppRoleClaim> enumerator = p57.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRoleClaim item = enumerator.Current;
                result.Add(item == null ? null : new AppRoleClaimReadModel()
                {
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Id = item.Id,
                    RoleId = item.RoleId,
                    ClaimType = item.ClaimType,
                    ClaimValue = item.ClaimValue
                });
            }
            return result;
            
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain54(ICollection<AppUserRole> p60)
        {
            if (p60 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p60.Count);
            
            IEnumerator<AppUserRole> enumerator = p60.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(funcMain55(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserTokenReadModel> funcMain58(ICollection<AppUserToken> p64)
        {
            if (p64 == null)
            {
                return null;
            }
            ICollection<AppUserTokenReadModel> result = new List<AppUserTokenReadModel>(p64.Count);
            
            IEnumerator<AppUserToken> enumerator = p64.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserToken item = enumerator.Current;
                result.Add(item == null ? null : new AppUserTokenReadModel()
                {
                    Token = item.Token,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    LoginProvider = item.LoginProvider,
                    Name = item.Name,
                    Value = item.Value
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRefreshTokenReadModel> funcMain59(ICollection<AppRefreshToken> p65)
        {
            if (p65 == null)
            {
                return null;
            }
            ICollection<AppRefreshTokenReadModel> result = new List<AppRefreshTokenReadModel>(p65.Count);
            
            IEnumerator<AppRefreshToken> enumerator = p65.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRefreshToken item = enumerator.Current;
                result.Add(item == null ? null : new AppRefreshTokenReadModel()
                {
                    UserId = item.UserId,
                    Token = item.Token,
                    JwtId = item.JwtId,
                    IsUsed = item.IsUsed,
                    IsRevoked = item.IsRevoked,
                    ExpiryDate = item.ExpiryDate,
                    Hash = item.Hash,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static ICollection<AppUserTokenReadModel> funcMain69(ICollection<AppUserToken> p75)
        {
            if (p75 == null)
            {
                return null;
            }
            ICollection<AppUserTokenReadModel> result = new List<AppUserTokenReadModel>(p75.Count);
            
            IEnumerator<AppUserToken> enumerator = p75.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserToken item = enumerator.Current;
                result.Add(item == null ? null : new AppUserTokenReadModel()
                {
                    Token = item.Token,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    LoginProvider = item.LoginProvider,
                    Name = item.Name,
                    Value = item.Value
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRefreshTokenReadModel> funcMain70(ICollection<AppRefreshToken> p76)
        {
            if (p76 == null)
            {
                return null;
            }
            ICollection<AppRefreshTokenReadModel> result = new List<AppRefreshTokenReadModel>(p76.Count);
            
            IEnumerator<AppRefreshToken> enumerator = p76.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRefreshToken item = enumerator.Current;
                result.Add(item == null ? null : new AppRefreshTokenReadModel()
                {
                    UserId = item.UserId,
                    Token = item.Token,
                    JwtId = item.JwtId,
                    IsUsed = item.IsUsed,
                    IsRevoked = item.IsRevoked,
                    ExpiryDate = item.ExpiryDate,
                    Hash = item.Hash,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRoleClaimReadModel> funcMain77(ICollection<AppRoleClaim> p83)
        {
            if (p83 == null)
            {
                return null;
            }
            ICollection<AppRoleClaimReadModel> result = new List<AppRoleClaimReadModel>(p83.Count);
            
            IEnumerator<AppRoleClaim> enumerator = p83.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRoleClaim item = enumerator.Current;
                result.Add(item == null ? null : new AppRoleClaimReadModel()
                {
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Id = item.Id,
                    RoleId = item.RoleId,
                    ClaimType = item.ClaimType,
                    ClaimValue = item.ClaimValue
                });
            }
            return result;
            
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain87(ICollection<AppUserRole> p96)
        {
            if (p96 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p96.Count);
            
            IEnumerator<AppUserRole> enumerator = p96.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(funcMain88(item));
            }
            return result;
            
        }
        
        private static ICollection<AppRoleClaimReadModel> funcMain92(ICollection<AppRoleClaim> p101)
        {
            if (p101 == null)
            {
                return null;
            }
            ICollection<AppRoleClaimReadModel> result = new List<AppRoleClaimReadModel>(p101.Count);
            
            IEnumerator<AppRoleClaim> enumerator = p101.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRoleClaim item = enumerator.Current;
                result.Add(item == null ? null : new AppRoleClaimReadModel()
                {
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Id = item.Id,
                    RoleId = item.RoleId,
                    ClaimType = item.ClaimType,
                    ClaimValue = item.ClaimValue
                });
            }
            return result;
            
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain95(ICollection<AppUserRole> p104)
        {
            if (p104 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p104.Count);
            
            IEnumerator<AppUserRole> enumerator = p104.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(funcMain96(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserTokenReadModel> funcMain99(ICollection<AppUserToken> p108)
        {
            if (p108 == null)
            {
                return null;
            }
            ICollection<AppUserTokenReadModel> result = new List<AppUserTokenReadModel>(p108.Count);
            
            IEnumerator<AppUserToken> enumerator = p108.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserToken item = enumerator.Current;
                result.Add(item == null ? null : new AppUserTokenReadModel()
                {
                    Token = item.Token,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    LoginProvider = item.LoginProvider,
                    Name = item.Name,
                    Value = item.Value
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRefreshTokenReadModel> funcMain100(ICollection<AppRefreshToken> p109)
        {
            if (p109 == null)
            {
                return null;
            }
            ICollection<AppRefreshTokenReadModel> result = new List<AppRefreshTokenReadModel>(p109.Count);
            
            IEnumerator<AppRefreshToken> enumerator = p109.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRefreshToken item = enumerator.Current;
                result.Add(item == null ? null : new AppRefreshTokenReadModel()
                {
                    UserId = item.UserId,
                    Token = item.Token,
                    JwtId = item.JwtId,
                    IsUsed = item.IsUsed,
                    IsRevoked = item.IsRevoked,
                    ExpiryDate = item.ExpiryDate,
                    Hash = item.Hash,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static ICollection<AppUserTokenReadModel> funcMain110(ICollection<AppUserToken> p120)
        {
            if (p120 == null)
            {
                return null;
            }
            ICollection<AppUserTokenReadModel> result = new List<AppUserTokenReadModel>(p120.Count);
            
            IEnumerator<AppUserToken> enumerator = p120.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserToken item = enumerator.Current;
                result.Add(item == null ? null : new AppUserTokenReadModel()
                {
                    Token = item.Token,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    LoginProvider = item.LoginProvider,
                    Name = item.Name,
                    Value = item.Value
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRefreshTokenReadModel> funcMain111(ICollection<AppRefreshToken> p121)
        {
            if (p121 == null)
            {
                return null;
            }
            ICollection<AppRefreshTokenReadModel> result = new List<AppRefreshTokenReadModel>(p121.Count);
            
            IEnumerator<AppRefreshToken> enumerator = p121.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRefreshToken item = enumerator.Current;
                result.Add(item == null ? null : new AppRefreshTokenReadModel()
                {
                    UserId = item.UserId,
                    Token = item.Token,
                    JwtId = item.JwtId,
                    IsUsed = item.IsUsed,
                    IsRevoked = item.IsRevoked,
                    ExpiryDate = item.ExpiryDate,
                    Hash = item.Hash,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRoleClaimReadModel> funcMain118(ICollection<AppRoleClaim> p128)
        {
            if (p128 == null)
            {
                return null;
            }
            ICollection<AppRoleClaimReadModel> result = new List<AppRoleClaimReadModel>(p128.Count);
            
            IEnumerator<AppRoleClaim> enumerator = p128.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRoleClaim item = enumerator.Current;
                result.Add(item == null ? null : new AppRoleClaimReadModel()
                {
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Id = item.Id,
                    RoleId = item.RoleId,
                    ClaimType = item.ClaimType,
                    ClaimValue = item.ClaimValue
                });
            }
            return result;
            
        }
        
        private static AppUserRoleReadModel funcMain47(AppUserRole p53)
        {
            return p53 == null ? null : new AppUserRoleReadModel()
            {
                AppUser = funcMain48(p53.AppUser),
                AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(p53.AppRole),
                Hash = p53.Hash,
                CreatedBy = p53.CreatedBy,
                CreatedDate = p53.CreatedDate,
                ModifiedBy = p53.ModifiedBy,
                ModifiedDate = p53.ModifiedDate,
                IsDeleted = p53.IsDeleted,
                DeletedBy = p53.DeletedBy,
                DeletedDate = p53.DeletedDate,
                UserId = p53.UserId,
                RoleId = p53.RoleId
            };
        }
        
        private static AppUserRoleReadModel funcMain55(AppUserRole p61)
        {
            return p61 == null ? null : new AppUserRoleReadModel()
            {
                AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(p61.AppUser),
                AppRole = funcMain56(p61.AppRole),
                Hash = p61.Hash,
                CreatedBy = p61.CreatedBy,
                CreatedDate = p61.CreatedDate,
                ModifiedBy = p61.ModifiedBy,
                ModifiedDate = p61.ModifiedDate,
                IsDeleted = p61.IsDeleted,
                DeletedBy = p61.DeletedBy,
                DeletedDate = p61.DeletedDate,
                UserId = p61.UserId,
                RoleId = p61.RoleId
            };
        }
        
        private static AppUserRoleReadModel funcMain88(AppUserRole p97)
        {
            return p97 == null ? null : new AppUserRoleReadModel()
            {
                AppUser = funcMain89(p97.AppUser),
                AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(p97.AppRole),
                Hash = p97.Hash,
                CreatedBy = p97.CreatedBy,
                CreatedDate = p97.CreatedDate,
                ModifiedBy = p97.ModifiedBy,
                ModifiedDate = p97.ModifiedDate,
                IsDeleted = p97.IsDeleted,
                DeletedBy = p97.DeletedBy,
                DeletedDate = p97.DeletedDate,
                UserId = p97.UserId,
                RoleId = p97.RoleId
            };
        }
        
        private static AppUserRoleReadModel funcMain96(AppUserRole p105)
        {
            return p105 == null ? null : new AppUserRoleReadModel()
            {
                AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(p105.AppUser),
                AppRole = funcMain97(p105.AppRole),
                Hash = p105.Hash,
                CreatedBy = p105.CreatedBy,
                CreatedDate = p105.CreatedDate,
                ModifiedBy = p105.ModifiedBy,
                ModifiedDate = p105.ModifiedDate,
                IsDeleted = p105.IsDeleted,
                DeletedBy = p105.DeletedBy,
                DeletedDate = p105.DeletedDate,
                UserId = p105.UserId,
                RoleId = p105.RoleId
            };
        }
        
        private static AppUserReadModel funcMain48(AppUser p54)
        {
            return p54 == null ? null : new AppUserReadModel()
            {
                Hash = p54.Hash,
                FirstName = p54.FirstName,
                LastName = p54.LastName,
                Mobile = p54.Mobile,
                CountryCode = p54.CountryCode,
                TwoFactorMethod = p54.TwoFactorMethod,
                CreatedBy = p54.CreatedBy,
                CreatedDate = p54.CreatedDate,
                ModifiedBy = p54.ModifiedBy,
                ModifiedDate = p54.ModifiedDate,
                IsDeleted = p54.IsDeleted,
                DeletedBy = p54.DeletedBy,
                DeletedDate = p54.DeletedDate,
                MembershipType = p54.MembershipType,
                UserRoles = TypeAdapter<ICollection<AppUserRole>, ICollection<AppUserRoleReadModel>>.Map.Invoke(p54.UserRoles),
                UserTokens = funcMain49(p54.UserTokens),
                RefreshTokens = funcMain50(p54.RefreshTokens),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p54.AccessControlEntries),
                Id = p54.Id,
                UserName = p54.UserName,
                NormalizedUserName = p54.NormalizedUserName,
                Email = p54.Email,
                NormalizedEmail = p54.NormalizedEmail,
                EmailConfirmed = p54.EmailConfirmed,
                PasswordHash = p54.PasswordHash,
                SecurityStamp = p54.SecurityStamp,
                ConcurrencyStamp = p54.ConcurrencyStamp,
                PhoneNumber = p54.PhoneNumber,
                PhoneNumberConfirmed = p54.PhoneNumberConfirmed,
                TwoFactorEnabled = p54.TwoFactorEnabled,
                LockoutEnd = p54.LockoutEnd,
                LockoutEnabled = p54.LockoutEnabled,
                AccessFailedCount = p54.AccessFailedCount
            };
        }
        
        private static AppRoleReadModel funcMain56(AppRole p62)
        {
            return p62 == null ? null : new AppRoleReadModel()
            {
                CreatedBy = p62.CreatedBy,
                CreatedDate = p62.CreatedDate,
                ModifiedBy = p62.ModifiedBy,
                ModifiedDate = p62.ModifiedDate,
                IsDeleted = p62.IsDeleted,
                DeletedBy = p62.DeletedBy,
                DeletedDate = p62.DeletedDate,
                AppUserRoles = TypeAdapter<ICollection<AppUserRole>, ICollection<AppUserRoleReadModel>>.Map.Invoke(p62.AppUserRoles),
                AppRoleClaims = funcMain57(p62.AppRoleClaims),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p62.AccessControlEntries),
                Hash = p62.Hash,
                Id = p62.Id,
                Name = p62.Name,
                NormalizedName = p62.NormalizedName,
                ConcurrencyStamp = p62.ConcurrencyStamp
            };
        }
        
        private static AppUserReadModel funcMain89(AppUser p98)
        {
            return p98 == null ? null : new AppUserReadModel()
            {
                Hash = p98.Hash,
                FirstName = p98.FirstName,
                LastName = p98.LastName,
                Mobile = p98.Mobile,
                CountryCode = p98.CountryCode,
                TwoFactorMethod = p98.TwoFactorMethod,
                CreatedBy = p98.CreatedBy,
                CreatedDate = p98.CreatedDate,
                ModifiedBy = p98.ModifiedBy,
                ModifiedDate = p98.ModifiedDate,
                IsDeleted = p98.IsDeleted,
                DeletedBy = p98.DeletedBy,
                DeletedDate = p98.DeletedDate,
                MembershipType = p98.MembershipType,
                UserRoles = TypeAdapter<ICollection<AppUserRole>, ICollection<AppUserRoleReadModel>>.Map.Invoke(p98.UserRoles),
                UserTokens = funcMain90(p98.UserTokens),
                RefreshTokens = funcMain91(p98.RefreshTokens),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p98.AccessControlEntries),
                Id = p98.Id,
                UserName = p98.UserName,
                NormalizedUserName = p98.NormalizedUserName,
                Email = p98.Email,
                NormalizedEmail = p98.NormalizedEmail,
                EmailConfirmed = p98.EmailConfirmed,
                PasswordHash = p98.PasswordHash,
                SecurityStamp = p98.SecurityStamp,
                ConcurrencyStamp = p98.ConcurrencyStamp,
                PhoneNumber = p98.PhoneNumber,
                PhoneNumberConfirmed = p98.PhoneNumberConfirmed,
                TwoFactorEnabled = p98.TwoFactorEnabled,
                LockoutEnd = p98.LockoutEnd,
                LockoutEnabled = p98.LockoutEnabled,
                AccessFailedCount = p98.AccessFailedCount
            };
        }
        
        private static AppRoleReadModel funcMain97(AppRole p106)
        {
            return p106 == null ? null : new AppRoleReadModel()
            {
                CreatedBy = p106.CreatedBy,
                CreatedDate = p106.CreatedDate,
                ModifiedBy = p106.ModifiedBy,
                ModifiedDate = p106.ModifiedDate,
                IsDeleted = p106.IsDeleted,
                DeletedBy = p106.DeletedBy,
                DeletedDate = p106.DeletedDate,
                AppUserRoles = TypeAdapter<ICollection<AppUserRole>, ICollection<AppUserRoleReadModel>>.Map.Invoke(p106.AppUserRoles),
                AppRoleClaims = funcMain98(p106.AppRoleClaims),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p106.AccessControlEntries),
                Hash = p106.Hash,
                Id = p106.Id,
                Name = p106.Name,
                NormalizedName = p106.NormalizedName,
                ConcurrencyStamp = p106.ConcurrencyStamp
            };
        }
        
        private static ICollection<AppUserTokenReadModel> funcMain49(ICollection<AppUserToken> p55)
        {
            if (p55 == null)
            {
                return null;
            }
            ICollection<AppUserTokenReadModel> result = new List<AppUserTokenReadModel>(p55.Count);
            
            IEnumerator<AppUserToken> enumerator = p55.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserToken item = enumerator.Current;
                result.Add(item == null ? null : new AppUserTokenReadModel()
                {
                    Token = item.Token,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    LoginProvider = item.LoginProvider,
                    Name = item.Name,
                    Value = item.Value
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRefreshTokenReadModel> funcMain50(ICollection<AppRefreshToken> p56)
        {
            if (p56 == null)
            {
                return null;
            }
            ICollection<AppRefreshTokenReadModel> result = new List<AppRefreshTokenReadModel>(p56.Count);
            
            IEnumerator<AppRefreshToken> enumerator = p56.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRefreshToken item = enumerator.Current;
                result.Add(item == null ? null : new AppRefreshTokenReadModel()
                {
                    UserId = item.UserId,
                    Token = item.Token,
                    JwtId = item.JwtId,
                    IsUsed = item.IsUsed,
                    IsRevoked = item.IsRevoked,
                    ExpiryDate = item.ExpiryDate,
                    Hash = item.Hash,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRoleClaimReadModel> funcMain57(ICollection<AppRoleClaim> p63)
        {
            if (p63 == null)
            {
                return null;
            }
            ICollection<AppRoleClaimReadModel> result = new List<AppRoleClaimReadModel>(p63.Count);
            
            IEnumerator<AppRoleClaim> enumerator = p63.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRoleClaim item = enumerator.Current;
                result.Add(item == null ? null : new AppRoleClaimReadModel()
                {
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Id = item.Id,
                    RoleId = item.RoleId,
                    ClaimType = item.ClaimType,
                    ClaimValue = item.ClaimValue
                });
            }
            return result;
            
        }
        
        private static ICollection<AppUserTokenReadModel> funcMain90(ICollection<AppUserToken> p99)
        {
            if (p99 == null)
            {
                return null;
            }
            ICollection<AppUserTokenReadModel> result = new List<AppUserTokenReadModel>(p99.Count);
            
            IEnumerator<AppUserToken> enumerator = p99.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserToken item = enumerator.Current;
                result.Add(item == null ? null : new AppUserTokenReadModel()
                {
                    Token = item.Token,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    LoginProvider = item.LoginProvider,
                    Name = item.Name,
                    Value = item.Value
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRefreshTokenReadModel> funcMain91(ICollection<AppRefreshToken> p100)
        {
            if (p100 == null)
            {
                return null;
            }
            ICollection<AppRefreshTokenReadModel> result = new List<AppRefreshTokenReadModel>(p100.Count);
            
            IEnumerator<AppRefreshToken> enumerator = p100.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRefreshToken item = enumerator.Current;
                result.Add(item == null ? null : new AppRefreshTokenReadModel()
                {
                    UserId = item.UserId,
                    Token = item.Token,
                    JwtId = item.JwtId,
                    IsUsed = item.IsUsed,
                    IsRevoked = item.IsRevoked,
                    ExpiryDate = item.ExpiryDate,
                    Hash = item.Hash,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRoleClaimReadModel> funcMain98(ICollection<AppRoleClaim> p107)
        {
            if (p107 == null)
            {
                return null;
            }
            ICollection<AppRoleClaimReadModel> result = new List<AppRoleClaimReadModel>(p107.Count);
            
            IEnumerator<AppRoleClaim> enumerator = p107.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRoleClaim item = enumerator.Current;
                result.Add(item == null ? null : new AppRoleClaimReadModel()
                {
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Id = item.Id,
                    RoleId = item.RoleId,
                    ClaimType = item.ClaimType,
                    ClaimValue = item.ClaimValue
                });
            }
            return result;
            
        }
    }
}