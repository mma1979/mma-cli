using System;
using System.Collections.Generic;
using AxialSystem.Covaluse.Core.Database.Identity;
using AxialSystem.Covaluse.Core.Enums;

namespace AxialSystem.Covaluse.Core.Database.Identity
{
    public partial class AppFeatureModifyModel
    {
        public string Name { get; set; }
        public string Description { get; set; }
        public bool IsEnabled { get; set; }
        public FeatureScope Scope { get; set; }
        public ICollection<AppFeatureFlagReadModel> FeatureFlags { get; set; }
        public ICollection<AppAccessControlEntryReadModel> AccessControlEntries { get; set; }
        public Guid Id { get; set; }
        public Guid? CreatedBy { get; set; }
        public DateTime? CreatedDate { get; set; }
        public Guid? ModifiedBy { get; set; }
        public DateTime? ModifiedDate { get; set; }
        public bool? IsDeleted { get; set; }
        public Guid? DeletedBy { get; set; }
        public DateTime? DeletedDate { get; set; }
    }
}