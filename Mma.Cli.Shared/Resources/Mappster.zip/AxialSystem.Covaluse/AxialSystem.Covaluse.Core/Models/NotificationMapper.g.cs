using System.Collections.Generic;
using AxialSystem.Covaluse.Core.Database.Identity;
using AxialSystem.Covaluse.Core.Database.Notifications;
using Mapster;

namespace AxialSystem.Covaluse.Core.Database.Notifications
{
    public static partial class NotificationMapper
    {
        public static NotificationReadModel AdaptToReadModel(this Notification p1)
        {
            return p1 == null ? null : new NotificationReadModel()
            {
                UserId = p1.UserId,
                Message = p1.Message,
                User = funcMain1(p1.User),
                NotificationStatus = p1.NotificationStatus,
                NotificationType = p1.NotificationType,
                IsRead = p1.IsRead,
                Periority = p1.Periority,
                ExpireTime = p1.ExpireTime,
                Id = p1.Id,
                CreatedBy = p1.CreatedBy,
                CreatedDate = p1.CreatedDate,
                ModifiedBy = p1.ModifiedBy,
                ModifiedDate = p1.ModifiedDate,
                IsDeleted = p1.IsDeleted,
                DeletedBy = p1.DeletedBy,
                DeletedDate = p1.DeletedDate
            };
        }
        public static NotificationReadModel AdaptTo(this Notification p24, NotificationReadModel p25)
        {
            if (p24 == null)
            {
                return null;
            }
            NotificationReadModel result = p25 ?? new NotificationReadModel();
            
            result.UserId = p24.UserId;
            result.Message = p24.Message;
            result.User = funcMain23(p24.User, result.User);
            result.NotificationStatus = p24.NotificationStatus;
            result.NotificationType = p24.NotificationType;
            result.IsRead = p24.IsRead;
            result.Periority = p24.Periority;
            result.ExpireTime = p24.ExpireTime;
            result.Id = p24.Id;
            result.CreatedBy = p24.CreatedBy;
            result.CreatedDate = p24.CreatedDate;
            result.ModifiedBy = p24.ModifiedBy;
            result.ModifiedDate = p24.ModifiedDate;
            result.IsDeleted = p24.IsDeleted;
            result.DeletedBy = p24.DeletedBy;
            result.DeletedDate = p24.DeletedDate;
            return result;
            
        }
        public static NotificationModifyModel AdaptToModifyModel(this Notification p53)
        {
            return p53 == null ? null : new NotificationModifyModel()
            {
                UserId = p53.UserId,
                Message = p53.Message,
                User = funcMain45(p53.User),
                NotificationStatus = p53.NotificationStatus,
                NotificationType = p53.NotificationType,
                IsRead = p53.IsRead,
                Periority = p53.Periority,
                ExpireTime = p53.ExpireTime,
                Id = p53.Id,
                CreatedBy = p53.CreatedBy,
                CreatedDate = p53.CreatedDate,
                ModifiedBy = p53.ModifiedBy,
                ModifiedDate = p53.ModifiedDate,
                IsDeleted = p53.IsDeleted,
                DeletedBy = p53.DeletedBy,
                DeletedDate = p53.DeletedDate
            };
        }
        public static NotificationModifyModel AdaptTo(this Notification p76, NotificationModifyModel p77)
        {
            if (p76 == null)
            {
                return null;
            }
            NotificationModifyModel result = p77 ?? new NotificationModifyModel();
            
            result.UserId = p76.UserId;
            result.Message = p76.Message;
            result.User = funcMain67(p76.User, result.User);
            result.NotificationStatus = p76.NotificationStatus;
            result.NotificationType = p76.NotificationType;
            result.IsRead = p76.IsRead;
            result.Periority = p76.Periority;
            result.ExpireTime = p76.ExpireTime;
            result.Id = p76.Id;
            result.CreatedBy = p76.CreatedBy;
            result.CreatedDate = p76.CreatedDate;
            result.ModifiedBy = p76.ModifiedBy;
            result.ModifiedDate = p76.ModifiedDate;
            result.IsDeleted = p76.IsDeleted;
            result.DeletedBy = p76.DeletedBy;
            result.DeletedDate = p76.DeletedDate;
            return result;
            
        }
        
        private static AppUserReadModel funcMain1(AppUser p2)
        {
            return p2 == null ? null : new AppUserReadModel()
            {
                Hash = p2.Hash,
                FirstName = p2.FirstName,
                LastName = p2.LastName,
                Mobile = p2.Mobile,
                CountryCode = p2.CountryCode,
                TwoFactorMethod = p2.TwoFactorMethod,
                CreatedBy = p2.CreatedBy,
                CreatedDate = p2.CreatedDate,
                ModifiedBy = p2.ModifiedBy,
                ModifiedDate = p2.ModifiedDate,
                IsDeleted = p2.IsDeleted,
                DeletedBy = p2.DeletedBy,
                DeletedDate = p2.DeletedDate,
                MembershipType = p2.MembershipType,
                UserRoles = funcMain2(p2.UserRoles),
                UserTokens = funcMain12(p2.UserTokens),
                RefreshTokens = funcMain13(p2.RefreshTokens),
                AccessControlEntries = funcMain14(p2.AccessControlEntries),
                Id = p2.Id,
                UserName = p2.UserName,
                NormalizedUserName = p2.NormalizedUserName,
                Email = p2.Email,
                NormalizedEmail = p2.NormalizedEmail,
                EmailConfirmed = p2.EmailConfirmed,
                PasswordHash = p2.PasswordHash,
                SecurityStamp = p2.SecurityStamp,
                ConcurrencyStamp = p2.ConcurrencyStamp,
                PhoneNumber = p2.PhoneNumber,
                PhoneNumberConfirmed = p2.PhoneNumberConfirmed,
                TwoFactorEnabled = p2.TwoFactorEnabled,
                LockoutEnd = p2.LockoutEnd,
                LockoutEnabled = p2.LockoutEnabled,
                AccessFailedCount = p2.AccessFailedCount
            };
        }
        
        private static AppUserReadModel funcMain23(AppUser p26, AppUserReadModel p27)
        {
            if (p26 == null)
            {
                return null;
            }
            AppUserReadModel result = p27 ?? new AppUserReadModel();
            
            result.Hash = p26.Hash;
            result.FirstName = p26.FirstName;
            result.LastName = p26.LastName;
            result.Mobile = p26.Mobile;
            result.CountryCode = p26.CountryCode;
            result.TwoFactorMethod = p26.TwoFactorMethod;
            result.CreatedBy = p26.CreatedBy;
            result.CreatedDate = p26.CreatedDate;
            result.ModifiedBy = p26.ModifiedBy;
            result.ModifiedDate = p26.ModifiedDate;
            result.IsDeleted = p26.IsDeleted;
            result.DeletedBy = p26.DeletedBy;
            result.DeletedDate = p26.DeletedDate;
            result.MembershipType = p26.MembershipType;
            result.UserRoles = funcMain24(p26.UserRoles, result.UserRoles);
            result.UserTokens = funcMain34(p26.UserTokens, result.UserTokens);
            result.RefreshTokens = funcMain35(p26.RefreshTokens, result.RefreshTokens);
            result.AccessControlEntries = funcMain36(p26.AccessControlEntries, result.AccessControlEntries);
            result.Id = p26.Id;
            result.UserName = p26.UserName;
            result.NormalizedUserName = p26.NormalizedUserName;
            result.Email = p26.Email;
            result.NormalizedEmail = p26.NormalizedEmail;
            result.EmailConfirmed = p26.EmailConfirmed;
            result.PasswordHash = p26.PasswordHash;
            result.SecurityStamp = p26.SecurityStamp;
            result.ConcurrencyStamp = p26.ConcurrencyStamp;
            result.PhoneNumber = p26.PhoneNumber;
            result.PhoneNumberConfirmed = p26.PhoneNumberConfirmed;
            result.TwoFactorEnabled = p26.TwoFactorEnabled;
            result.LockoutEnd = p26.LockoutEnd;
            result.LockoutEnabled = p26.LockoutEnabled;
            result.AccessFailedCount = p26.AccessFailedCount;
            return result;
            
        }
        
        private static AppUserReadModel funcMain45(AppUser p54)
        {
            return p54 == null ? null : new AppUserReadModel()
            {
                Hash = p54.Hash,
                FirstName = p54.FirstName,
                LastName = p54.LastName,
                Mobile = p54.Mobile,
                CountryCode = p54.CountryCode,
                TwoFactorMethod = p54.TwoFactorMethod,
                CreatedBy = p54.CreatedBy,
                CreatedDate = p54.CreatedDate,
                ModifiedBy = p54.ModifiedBy,
                ModifiedDate = p54.ModifiedDate,
                IsDeleted = p54.IsDeleted,
                DeletedBy = p54.DeletedBy,
                DeletedDate = p54.DeletedDate,
                MembershipType = p54.MembershipType,
                UserRoles = funcMain46(p54.UserRoles),
                UserTokens = funcMain56(p54.UserTokens),
                RefreshTokens = funcMain57(p54.RefreshTokens),
                AccessControlEntries = funcMain58(p54.AccessControlEntries),
                Id = p54.Id,
                UserName = p54.UserName,
                NormalizedUserName = p54.NormalizedUserName,
                Email = p54.Email,
                NormalizedEmail = p54.NormalizedEmail,
                EmailConfirmed = p54.EmailConfirmed,
                PasswordHash = p54.PasswordHash,
                SecurityStamp = p54.SecurityStamp,
                ConcurrencyStamp = p54.ConcurrencyStamp,
                PhoneNumber = p54.PhoneNumber,
                PhoneNumberConfirmed = p54.PhoneNumberConfirmed,
                TwoFactorEnabled = p54.TwoFactorEnabled,
                LockoutEnd = p54.LockoutEnd,
                LockoutEnabled = p54.LockoutEnabled,
                AccessFailedCount = p54.AccessFailedCount
            };
        }
        
        private static AppUserReadModel funcMain67(AppUser p78, AppUserReadModel p79)
        {
            if (p78 == null)
            {
                return null;
            }
            AppUserReadModel result = p79 ?? new AppUserReadModel();
            
            result.Hash = p78.Hash;
            result.FirstName = p78.FirstName;
            result.LastName = p78.LastName;
            result.Mobile = p78.Mobile;
            result.CountryCode = p78.CountryCode;
            result.TwoFactorMethod = p78.TwoFactorMethod;
            result.CreatedBy = p78.CreatedBy;
            result.CreatedDate = p78.CreatedDate;
            result.ModifiedBy = p78.ModifiedBy;
            result.ModifiedDate = p78.ModifiedDate;
            result.IsDeleted = p78.IsDeleted;
            result.DeletedBy = p78.DeletedBy;
            result.DeletedDate = p78.DeletedDate;
            result.MembershipType = p78.MembershipType;
            result.UserRoles = funcMain68(p78.UserRoles, result.UserRoles);
            result.UserTokens = funcMain78(p78.UserTokens, result.UserTokens);
            result.RefreshTokens = funcMain79(p78.RefreshTokens, result.RefreshTokens);
            result.AccessControlEntries = funcMain80(p78.AccessControlEntries, result.AccessControlEntries);
            result.Id = p78.Id;
            result.UserName = p78.UserName;
            result.NormalizedUserName = p78.NormalizedUserName;
            result.Email = p78.Email;
            result.NormalizedEmail = p78.NormalizedEmail;
            result.EmailConfirmed = p78.EmailConfirmed;
            result.PasswordHash = p78.PasswordHash;
            result.SecurityStamp = p78.SecurityStamp;
            result.ConcurrencyStamp = p78.ConcurrencyStamp;
            result.PhoneNumber = p78.PhoneNumber;
            result.PhoneNumberConfirmed = p78.PhoneNumberConfirmed;
            result.TwoFactorEnabled = p78.TwoFactorEnabled;
            result.LockoutEnd = p78.LockoutEnd;
            result.LockoutEnabled = p78.LockoutEnabled;
            result.AccessFailedCount = p78.AccessFailedCount;
            return result;
            
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain2(ICollection<AppUserRole> p3)
        {
            if (p3 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p3.Count);
            
            IEnumerator<AppUserRole> enumerator = p3.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(funcMain3(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserTokenReadModel> funcMain12(ICollection<AppUserToken> p13)
        {
            if (p13 == null)
            {
                return null;
            }
            ICollection<AppUserTokenReadModel> result = new List<AppUserTokenReadModel>(p13.Count);
            
            IEnumerator<AppUserToken> enumerator = p13.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserToken item = enumerator.Current;
                result.Add(item == null ? null : new AppUserTokenReadModel()
                {
                    Token = item.Token,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    LoginProvider = item.LoginProvider,
                    Name = item.Name,
                    Value = item.Value
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRefreshTokenReadModel> funcMain13(ICollection<AppRefreshToken> p14)
        {
            if (p14 == null)
            {
                return null;
            }
            ICollection<AppRefreshTokenReadModel> result = new List<AppRefreshTokenReadModel>(p14.Count);
            
            IEnumerator<AppRefreshToken> enumerator = p14.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRefreshToken item = enumerator.Current;
                result.Add(item == null ? null : new AppRefreshTokenReadModel()
                {
                    UserId = item.UserId,
                    Token = item.Token,
                    JwtId = item.JwtId,
                    IsUsed = item.IsUsed,
                    IsRevoked = item.IsRevoked,
                    ExpiryDate = item.ExpiryDate,
                    Hash = item.Hash,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static ICollection<AppAccessControlEntryReadModel> funcMain14(ICollection<AppAccessControlEntry> p15)
        {
            if (p15 == null)
            {
                return null;
            }
            ICollection<AppAccessControlEntryReadModel> result = new List<AppAccessControlEntryReadModel>(p15.Count);
            
            IEnumerator<AppAccessControlEntry> enumerator = p15.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppAccessControlEntry item = enumerator.Current;
                result.Add(funcMain15(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain24(ICollection<AppUserRole> p28, ICollection<AppUserRoleReadModel> p29)
        {
            if (p28 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p28.Count);
            
            IEnumerator<AppUserRole> enumerator = p28.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(funcMain25(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserTokenReadModel> funcMain34(ICollection<AppUserToken> p39, ICollection<AppUserTokenReadModel> p40)
        {
            if (p39 == null)
            {
                return null;
            }
            ICollection<AppUserTokenReadModel> result = new List<AppUserTokenReadModel>(p39.Count);
            
            IEnumerator<AppUserToken> enumerator = p39.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserToken item = enumerator.Current;
                result.Add(item == null ? null : new AppUserTokenReadModel()
                {
                    Token = item.Token,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    LoginProvider = item.LoginProvider,
                    Name = item.Name,
                    Value = item.Value
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRefreshTokenReadModel> funcMain35(ICollection<AppRefreshToken> p41, ICollection<AppRefreshTokenReadModel> p42)
        {
            if (p41 == null)
            {
                return null;
            }
            ICollection<AppRefreshTokenReadModel> result = new List<AppRefreshTokenReadModel>(p41.Count);
            
            IEnumerator<AppRefreshToken> enumerator = p41.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRefreshToken item = enumerator.Current;
                result.Add(item == null ? null : new AppRefreshTokenReadModel()
                {
                    UserId = item.UserId,
                    Token = item.Token,
                    JwtId = item.JwtId,
                    IsUsed = item.IsUsed,
                    IsRevoked = item.IsRevoked,
                    ExpiryDate = item.ExpiryDate,
                    Hash = item.Hash,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static ICollection<AppAccessControlEntryReadModel> funcMain36(ICollection<AppAccessControlEntry> p43, ICollection<AppAccessControlEntryReadModel> p44)
        {
            if (p43 == null)
            {
                return null;
            }
            ICollection<AppAccessControlEntryReadModel> result = new List<AppAccessControlEntryReadModel>(p43.Count);
            
            IEnumerator<AppAccessControlEntry> enumerator = p43.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppAccessControlEntry item = enumerator.Current;
                result.Add(funcMain37(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain46(ICollection<AppUserRole> p55)
        {
            if (p55 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p55.Count);
            
            IEnumerator<AppUserRole> enumerator = p55.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(funcMain47(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserTokenReadModel> funcMain56(ICollection<AppUserToken> p65)
        {
            if (p65 == null)
            {
                return null;
            }
            ICollection<AppUserTokenReadModel> result = new List<AppUserTokenReadModel>(p65.Count);
            
            IEnumerator<AppUserToken> enumerator = p65.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserToken item = enumerator.Current;
                result.Add(item == null ? null : new AppUserTokenReadModel()
                {
                    Token = item.Token,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    LoginProvider = item.LoginProvider,
                    Name = item.Name,
                    Value = item.Value
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRefreshTokenReadModel> funcMain57(ICollection<AppRefreshToken> p66)
        {
            if (p66 == null)
            {
                return null;
            }
            ICollection<AppRefreshTokenReadModel> result = new List<AppRefreshTokenReadModel>(p66.Count);
            
            IEnumerator<AppRefreshToken> enumerator = p66.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRefreshToken item = enumerator.Current;
                result.Add(item == null ? null : new AppRefreshTokenReadModel()
                {
                    UserId = item.UserId,
                    Token = item.Token,
                    JwtId = item.JwtId,
                    IsUsed = item.IsUsed,
                    IsRevoked = item.IsRevoked,
                    ExpiryDate = item.ExpiryDate,
                    Hash = item.Hash,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static ICollection<AppAccessControlEntryReadModel> funcMain58(ICollection<AppAccessControlEntry> p67)
        {
            if (p67 == null)
            {
                return null;
            }
            ICollection<AppAccessControlEntryReadModel> result = new List<AppAccessControlEntryReadModel>(p67.Count);
            
            IEnumerator<AppAccessControlEntry> enumerator = p67.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppAccessControlEntry item = enumerator.Current;
                result.Add(funcMain59(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain68(ICollection<AppUserRole> p80, ICollection<AppUserRoleReadModel> p81)
        {
            if (p80 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p80.Count);
            
            IEnumerator<AppUserRole> enumerator = p80.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(funcMain69(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserTokenReadModel> funcMain78(ICollection<AppUserToken> p91, ICollection<AppUserTokenReadModel> p92)
        {
            if (p91 == null)
            {
                return null;
            }
            ICollection<AppUserTokenReadModel> result = new List<AppUserTokenReadModel>(p91.Count);
            
            IEnumerator<AppUserToken> enumerator = p91.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserToken item = enumerator.Current;
                result.Add(item == null ? null : new AppUserTokenReadModel()
                {
                    Token = item.Token,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    LoginProvider = item.LoginProvider,
                    Name = item.Name,
                    Value = item.Value
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRefreshTokenReadModel> funcMain79(ICollection<AppRefreshToken> p93, ICollection<AppRefreshTokenReadModel> p94)
        {
            if (p93 == null)
            {
                return null;
            }
            ICollection<AppRefreshTokenReadModel> result = new List<AppRefreshTokenReadModel>(p93.Count);
            
            IEnumerator<AppRefreshToken> enumerator = p93.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRefreshToken item = enumerator.Current;
                result.Add(item == null ? null : new AppRefreshTokenReadModel()
                {
                    UserId = item.UserId,
                    Token = item.Token,
                    JwtId = item.JwtId,
                    IsUsed = item.IsUsed,
                    IsRevoked = item.IsRevoked,
                    ExpiryDate = item.ExpiryDate,
                    Hash = item.Hash,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static ICollection<AppAccessControlEntryReadModel> funcMain80(ICollection<AppAccessControlEntry> p95, ICollection<AppAccessControlEntryReadModel> p96)
        {
            if (p95 == null)
            {
                return null;
            }
            ICollection<AppAccessControlEntryReadModel> result = new List<AppAccessControlEntryReadModel>(p95.Count);
            
            IEnumerator<AppAccessControlEntry> enumerator = p95.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppAccessControlEntry item = enumerator.Current;
                result.Add(funcMain81(item));
            }
            return result;
            
        }
        
        private static AppUserRoleReadModel funcMain3(AppUserRole p4)
        {
            return p4 == null ? null : new AppUserRoleReadModel()
            {
                AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(p4.AppUser),
                AppRole = funcMain4(p4.AppRole),
                Hash = p4.Hash,
                CreatedBy = p4.CreatedBy,
                CreatedDate = p4.CreatedDate,
                ModifiedBy = p4.ModifiedBy,
                ModifiedDate = p4.ModifiedDate,
                IsDeleted = p4.IsDeleted,
                DeletedBy = p4.DeletedBy,
                DeletedDate = p4.DeletedDate,
                UserId = p4.UserId,
                RoleId = p4.RoleId
            };
        }
        
        private static AppAccessControlEntryReadModel funcMain15(AppAccessControlEntry p16)
        {
            return p16 == null ? null : new AppAccessControlEntryReadModel()
            {
                ResourcePattern = p16.ResourcePattern,
                PermissionPattern = p16.PermissionPattern,
                FeatureId = p16.FeatureId,
                Feature = funcMain16(p16.Feature),
                AppRoles = funcMain18(p16.AppRoles),
                AppUsers = funcMain22(p16.AppUsers),
                AppResource = p16.AppResource == null ? null : new AppResourceReadModel()
                {
                    Url = p16.AppResource.Url,
                    Description = p16.AppResource.Description,
                    ResourceType = p16.AppResource.ResourceType,
                    AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p16.AppResource.AccessControlEntries),
                    Id = p16.AppResource.Id,
                    CreatedBy = p16.AppResource.CreatedBy,
                    CreatedDate = p16.AppResource.CreatedDate,
                    ModifiedBy = p16.AppResource.ModifiedBy,
                    ModifiedDate = p16.AppResource.ModifiedDate,
                    IsDeleted = p16.AppResource.IsDeleted,
                    DeletedBy = p16.AppResource.DeletedBy,
                    DeletedDate = p16.AppResource.DeletedDate
                },
                ResourceId = p16.ResourceId,
                Id = p16.Id,
                CreatedBy = p16.CreatedBy,
                CreatedDate = p16.CreatedDate,
                ModifiedBy = p16.ModifiedBy,
                ModifiedDate = p16.ModifiedDate,
                IsDeleted = p16.IsDeleted,
                DeletedBy = p16.DeletedBy,
                DeletedDate = p16.DeletedDate
            };
        }
        
        private static AppUserRoleReadModel funcMain25(AppUserRole p30)
        {
            return p30 == null ? null : new AppUserRoleReadModel()
            {
                AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(p30.AppUser),
                AppRole = funcMain26(p30.AppRole),
                Hash = p30.Hash,
                CreatedBy = p30.CreatedBy,
                CreatedDate = p30.CreatedDate,
                ModifiedBy = p30.ModifiedBy,
                ModifiedDate = p30.ModifiedDate,
                IsDeleted = p30.IsDeleted,
                DeletedBy = p30.DeletedBy,
                DeletedDate = p30.DeletedDate,
                UserId = p30.UserId,
                RoleId = p30.RoleId
            };
        }
        
        private static AppAccessControlEntryReadModel funcMain37(AppAccessControlEntry p45)
        {
            return p45 == null ? null : new AppAccessControlEntryReadModel()
            {
                ResourcePattern = p45.ResourcePattern,
                PermissionPattern = p45.PermissionPattern,
                FeatureId = p45.FeatureId,
                Feature = funcMain38(p45.Feature),
                AppRoles = funcMain40(p45.AppRoles),
                AppUsers = funcMain44(p45.AppUsers),
                AppResource = p45.AppResource == null ? null : new AppResourceReadModel()
                {
                    Url = p45.AppResource.Url,
                    Description = p45.AppResource.Description,
                    ResourceType = p45.AppResource.ResourceType,
                    AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p45.AppResource.AccessControlEntries),
                    Id = p45.AppResource.Id,
                    CreatedBy = p45.AppResource.CreatedBy,
                    CreatedDate = p45.AppResource.CreatedDate,
                    ModifiedBy = p45.AppResource.ModifiedBy,
                    ModifiedDate = p45.AppResource.ModifiedDate,
                    IsDeleted = p45.AppResource.IsDeleted,
                    DeletedBy = p45.AppResource.DeletedBy,
                    DeletedDate = p45.AppResource.DeletedDate
                },
                ResourceId = p45.ResourceId,
                Id = p45.Id,
                CreatedBy = p45.CreatedBy,
                CreatedDate = p45.CreatedDate,
                ModifiedBy = p45.ModifiedBy,
                ModifiedDate = p45.ModifiedDate,
                IsDeleted = p45.IsDeleted,
                DeletedBy = p45.DeletedBy,
                DeletedDate = p45.DeletedDate
            };
        }
        
        private static AppUserRoleReadModel funcMain47(AppUserRole p56)
        {
            return p56 == null ? null : new AppUserRoleReadModel()
            {
                AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(p56.AppUser),
                AppRole = funcMain48(p56.AppRole),
                Hash = p56.Hash,
                CreatedBy = p56.CreatedBy,
                CreatedDate = p56.CreatedDate,
                ModifiedBy = p56.ModifiedBy,
                ModifiedDate = p56.ModifiedDate,
                IsDeleted = p56.IsDeleted,
                DeletedBy = p56.DeletedBy,
                DeletedDate = p56.DeletedDate,
                UserId = p56.UserId,
                RoleId = p56.RoleId
            };
        }
        
        private static AppAccessControlEntryReadModel funcMain59(AppAccessControlEntry p68)
        {
            return p68 == null ? null : new AppAccessControlEntryReadModel()
            {
                ResourcePattern = p68.ResourcePattern,
                PermissionPattern = p68.PermissionPattern,
                FeatureId = p68.FeatureId,
                Feature = funcMain60(p68.Feature),
                AppRoles = funcMain62(p68.AppRoles),
                AppUsers = funcMain66(p68.AppUsers),
                AppResource = p68.AppResource == null ? null : new AppResourceReadModel()
                {
                    Url = p68.AppResource.Url,
                    Description = p68.AppResource.Description,
                    ResourceType = p68.AppResource.ResourceType,
                    AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p68.AppResource.AccessControlEntries),
                    Id = p68.AppResource.Id,
                    CreatedBy = p68.AppResource.CreatedBy,
                    CreatedDate = p68.AppResource.CreatedDate,
                    ModifiedBy = p68.AppResource.ModifiedBy,
                    ModifiedDate = p68.AppResource.ModifiedDate,
                    IsDeleted = p68.AppResource.IsDeleted,
                    DeletedBy = p68.AppResource.DeletedBy,
                    DeletedDate = p68.AppResource.DeletedDate
                },
                ResourceId = p68.ResourceId,
                Id = p68.Id,
                CreatedBy = p68.CreatedBy,
                CreatedDate = p68.CreatedDate,
                ModifiedBy = p68.ModifiedBy,
                ModifiedDate = p68.ModifiedDate,
                IsDeleted = p68.IsDeleted,
                DeletedBy = p68.DeletedBy,
                DeletedDate = p68.DeletedDate
            };
        }
        
        private static AppUserRoleReadModel funcMain69(AppUserRole p82)
        {
            return p82 == null ? null : new AppUserRoleReadModel()
            {
                AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(p82.AppUser),
                AppRole = funcMain70(p82.AppRole),
                Hash = p82.Hash,
                CreatedBy = p82.CreatedBy,
                CreatedDate = p82.CreatedDate,
                ModifiedBy = p82.ModifiedBy,
                ModifiedDate = p82.ModifiedDate,
                IsDeleted = p82.IsDeleted,
                DeletedBy = p82.DeletedBy,
                DeletedDate = p82.DeletedDate,
                UserId = p82.UserId,
                RoleId = p82.RoleId
            };
        }
        
        private static AppAccessControlEntryReadModel funcMain81(AppAccessControlEntry p97)
        {
            return p97 == null ? null : new AppAccessControlEntryReadModel()
            {
                ResourcePattern = p97.ResourcePattern,
                PermissionPattern = p97.PermissionPattern,
                FeatureId = p97.FeatureId,
                Feature = funcMain82(p97.Feature),
                AppRoles = funcMain84(p97.AppRoles),
                AppUsers = funcMain88(p97.AppUsers),
                AppResource = p97.AppResource == null ? null : new AppResourceReadModel()
                {
                    Url = p97.AppResource.Url,
                    Description = p97.AppResource.Description,
                    ResourceType = p97.AppResource.ResourceType,
                    AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p97.AppResource.AccessControlEntries),
                    Id = p97.AppResource.Id,
                    CreatedBy = p97.AppResource.CreatedBy,
                    CreatedDate = p97.AppResource.CreatedDate,
                    ModifiedBy = p97.AppResource.ModifiedBy,
                    ModifiedDate = p97.AppResource.ModifiedDate,
                    IsDeleted = p97.AppResource.IsDeleted,
                    DeletedBy = p97.AppResource.DeletedBy,
                    DeletedDate = p97.AppResource.DeletedDate
                },
                ResourceId = p97.ResourceId,
                Id = p97.Id,
                CreatedBy = p97.CreatedBy,
                CreatedDate = p97.CreatedDate,
                ModifiedBy = p97.ModifiedBy,
                ModifiedDate = p97.ModifiedDate,
                IsDeleted = p97.IsDeleted,
                DeletedBy = p97.DeletedBy,
                DeletedDate = p97.DeletedDate
            };
        }
        
        private static AppRoleReadModel funcMain4(AppRole p5)
        {
            return p5 == null ? null : new AppRoleReadModel()
            {
                CreatedBy = p5.CreatedBy,
                CreatedDate = p5.CreatedDate,
                ModifiedBy = p5.ModifiedBy,
                ModifiedDate = p5.ModifiedDate,
                IsDeleted = p5.IsDeleted,
                DeletedBy = p5.DeletedBy,
                DeletedDate = p5.DeletedDate,
                AppUserRoles = TypeAdapter<ICollection<AppUserRole>, ICollection<AppUserRoleReadModel>>.Map.Invoke(p5.AppUserRoles),
                AppRoleClaims = funcMain5(p5.AppRoleClaims),
                AccessControlEntries = funcMain6(p5.AccessControlEntries),
                Hash = p5.Hash,
                Id = p5.Id,
                Name = p5.Name,
                NormalizedName = p5.NormalizedName,
                ConcurrencyStamp = p5.ConcurrencyStamp
            };
        }
        
        private static AppFeatureReadModel funcMain16(AppFeature p17)
        {
            return p17 == null ? null : new AppFeatureReadModel()
            {
                Name = p17.Name,
                Description = p17.Description,
                IsEnabled = p17.IsEnabled,
                Scope = p17.Scope,
                FeatureFlags = funcMain17(p17.FeatureFlags),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p17.AccessControlEntries),
                Id = p17.Id,
                CreatedBy = p17.CreatedBy,
                CreatedDate = p17.CreatedDate,
                ModifiedBy = p17.ModifiedBy,
                ModifiedDate = p17.ModifiedDate,
                IsDeleted = p17.IsDeleted,
                DeletedBy = p17.DeletedBy,
                DeletedDate = p17.DeletedDate
            };
        }
        
        private static ICollection<AppRoleReadModel> funcMain18(ICollection<AppRole> p19)
        {
            if (p19 == null)
            {
                return null;
            }
            ICollection<AppRoleReadModel> result = new List<AppRoleReadModel>(p19.Count);
            
            IEnumerator<AppRole> enumerator = p19.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRole item = enumerator.Current;
                result.Add(funcMain19(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserReadModel> funcMain22(ICollection<AppUser> p23)
        {
            if (p23 == null)
            {
                return null;
            }
            ICollection<AppUserReadModel> result = new List<AppUserReadModel>(p23.Count);
            
            IEnumerator<AppUser> enumerator = p23.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUser item = enumerator.Current;
                result.Add(TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static AppRoleReadModel funcMain26(AppRole p31)
        {
            return p31 == null ? null : new AppRoleReadModel()
            {
                CreatedBy = p31.CreatedBy,
                CreatedDate = p31.CreatedDate,
                ModifiedBy = p31.ModifiedBy,
                ModifiedDate = p31.ModifiedDate,
                IsDeleted = p31.IsDeleted,
                DeletedBy = p31.DeletedBy,
                DeletedDate = p31.DeletedDate,
                AppUserRoles = TypeAdapter<ICollection<AppUserRole>, ICollection<AppUserRoleReadModel>>.Map.Invoke(p31.AppUserRoles),
                AppRoleClaims = funcMain27(p31.AppRoleClaims),
                AccessControlEntries = funcMain28(p31.AccessControlEntries),
                Hash = p31.Hash,
                Id = p31.Id,
                Name = p31.Name,
                NormalizedName = p31.NormalizedName,
                ConcurrencyStamp = p31.ConcurrencyStamp
            };
        }
        
        private static AppFeatureReadModel funcMain38(AppFeature p46)
        {
            return p46 == null ? null : new AppFeatureReadModel()
            {
                Name = p46.Name,
                Description = p46.Description,
                IsEnabled = p46.IsEnabled,
                Scope = p46.Scope,
                FeatureFlags = funcMain39(p46.FeatureFlags),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p46.AccessControlEntries),
                Id = p46.Id,
                CreatedBy = p46.CreatedBy,
                CreatedDate = p46.CreatedDate,
                ModifiedBy = p46.ModifiedBy,
                ModifiedDate = p46.ModifiedDate,
                IsDeleted = p46.IsDeleted,
                DeletedBy = p46.DeletedBy,
                DeletedDate = p46.DeletedDate
            };
        }
        
        private static ICollection<AppRoleReadModel> funcMain40(ICollection<AppRole> p48)
        {
            if (p48 == null)
            {
                return null;
            }
            ICollection<AppRoleReadModel> result = new List<AppRoleReadModel>(p48.Count);
            
            IEnumerator<AppRole> enumerator = p48.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRole item = enumerator.Current;
                result.Add(funcMain41(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserReadModel> funcMain44(ICollection<AppUser> p52)
        {
            if (p52 == null)
            {
                return null;
            }
            ICollection<AppUserReadModel> result = new List<AppUserReadModel>(p52.Count);
            
            IEnumerator<AppUser> enumerator = p52.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUser item = enumerator.Current;
                result.Add(TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static AppRoleReadModel funcMain48(AppRole p57)
        {
            return p57 == null ? null : new AppRoleReadModel()
            {
                CreatedBy = p57.CreatedBy,
                CreatedDate = p57.CreatedDate,
                ModifiedBy = p57.ModifiedBy,
                ModifiedDate = p57.ModifiedDate,
                IsDeleted = p57.IsDeleted,
                DeletedBy = p57.DeletedBy,
                DeletedDate = p57.DeletedDate,
                AppUserRoles = TypeAdapter<ICollection<AppUserRole>, ICollection<AppUserRoleReadModel>>.Map.Invoke(p57.AppUserRoles),
                AppRoleClaims = funcMain49(p57.AppRoleClaims),
                AccessControlEntries = funcMain50(p57.AccessControlEntries),
                Hash = p57.Hash,
                Id = p57.Id,
                Name = p57.Name,
                NormalizedName = p57.NormalizedName,
                ConcurrencyStamp = p57.ConcurrencyStamp
            };
        }
        
        private static AppFeatureReadModel funcMain60(AppFeature p69)
        {
            return p69 == null ? null : new AppFeatureReadModel()
            {
                Name = p69.Name,
                Description = p69.Description,
                IsEnabled = p69.IsEnabled,
                Scope = p69.Scope,
                FeatureFlags = funcMain61(p69.FeatureFlags),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p69.AccessControlEntries),
                Id = p69.Id,
                CreatedBy = p69.CreatedBy,
                CreatedDate = p69.CreatedDate,
                ModifiedBy = p69.ModifiedBy,
                ModifiedDate = p69.ModifiedDate,
                IsDeleted = p69.IsDeleted,
                DeletedBy = p69.DeletedBy,
                DeletedDate = p69.DeletedDate
            };
        }
        
        private static ICollection<AppRoleReadModel> funcMain62(ICollection<AppRole> p71)
        {
            if (p71 == null)
            {
                return null;
            }
            ICollection<AppRoleReadModel> result = new List<AppRoleReadModel>(p71.Count);
            
            IEnumerator<AppRole> enumerator = p71.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRole item = enumerator.Current;
                result.Add(funcMain63(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserReadModel> funcMain66(ICollection<AppUser> p75)
        {
            if (p75 == null)
            {
                return null;
            }
            ICollection<AppUserReadModel> result = new List<AppUserReadModel>(p75.Count);
            
            IEnumerator<AppUser> enumerator = p75.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUser item = enumerator.Current;
                result.Add(TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static AppRoleReadModel funcMain70(AppRole p83)
        {
            return p83 == null ? null : new AppRoleReadModel()
            {
                CreatedBy = p83.CreatedBy,
                CreatedDate = p83.CreatedDate,
                ModifiedBy = p83.ModifiedBy,
                ModifiedDate = p83.ModifiedDate,
                IsDeleted = p83.IsDeleted,
                DeletedBy = p83.DeletedBy,
                DeletedDate = p83.DeletedDate,
                AppUserRoles = TypeAdapter<ICollection<AppUserRole>, ICollection<AppUserRoleReadModel>>.Map.Invoke(p83.AppUserRoles),
                AppRoleClaims = funcMain71(p83.AppRoleClaims),
                AccessControlEntries = funcMain72(p83.AccessControlEntries),
                Hash = p83.Hash,
                Id = p83.Id,
                Name = p83.Name,
                NormalizedName = p83.NormalizedName,
                ConcurrencyStamp = p83.ConcurrencyStamp
            };
        }
        
        private static AppFeatureReadModel funcMain82(AppFeature p98)
        {
            return p98 == null ? null : new AppFeatureReadModel()
            {
                Name = p98.Name,
                Description = p98.Description,
                IsEnabled = p98.IsEnabled,
                Scope = p98.Scope,
                FeatureFlags = funcMain83(p98.FeatureFlags),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p98.AccessControlEntries),
                Id = p98.Id,
                CreatedBy = p98.CreatedBy,
                CreatedDate = p98.CreatedDate,
                ModifiedBy = p98.ModifiedBy,
                ModifiedDate = p98.ModifiedDate,
                IsDeleted = p98.IsDeleted,
                DeletedBy = p98.DeletedBy,
                DeletedDate = p98.DeletedDate
            };
        }
        
        private static ICollection<AppRoleReadModel> funcMain84(ICollection<AppRole> p100)
        {
            if (p100 == null)
            {
                return null;
            }
            ICollection<AppRoleReadModel> result = new List<AppRoleReadModel>(p100.Count);
            
            IEnumerator<AppRole> enumerator = p100.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRole item = enumerator.Current;
                result.Add(funcMain85(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserReadModel> funcMain88(ICollection<AppUser> p104)
        {
            if (p104 == null)
            {
                return null;
            }
            ICollection<AppUserReadModel> result = new List<AppUserReadModel>(p104.Count);
            
            IEnumerator<AppUser> enumerator = p104.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUser item = enumerator.Current;
                result.Add(TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static ICollection<AppRoleClaimReadModel> funcMain5(ICollection<AppRoleClaim> p6)
        {
            if (p6 == null)
            {
                return null;
            }
            ICollection<AppRoleClaimReadModel> result = new List<AppRoleClaimReadModel>(p6.Count);
            
            IEnumerator<AppRoleClaim> enumerator = p6.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRoleClaim item = enumerator.Current;
                result.Add(item == null ? null : new AppRoleClaimReadModel()
                {
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Id = item.Id,
                    RoleId = item.RoleId,
                    ClaimType = item.ClaimType,
                    ClaimValue = item.ClaimValue
                });
            }
            return result;
            
        }
        
        private static ICollection<AppAccessControlEntryReadModel> funcMain6(ICollection<AppAccessControlEntry> p7)
        {
            if (p7 == null)
            {
                return null;
            }
            ICollection<AppAccessControlEntryReadModel> result = new List<AppAccessControlEntryReadModel>(p7.Count);
            
            IEnumerator<AppAccessControlEntry> enumerator = p7.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppAccessControlEntry item = enumerator.Current;
                result.Add(funcMain7(item));
            }
            return result;
            
        }
        
        private static ICollection<AppFeatureFlagReadModel> funcMain17(ICollection<AppFeatureFlag> p18)
        {
            if (p18 == null)
            {
                return null;
            }
            ICollection<AppFeatureFlagReadModel> result = new List<AppFeatureFlagReadModel>(p18.Count);
            
            IEnumerator<AppFeatureFlag> enumerator = p18.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppFeatureFlag item = enumerator.Current;
                result.Add(item == null ? null : new AppFeatureFlagReadModel()
                {
                    FeatureId = item.FeatureId,
                    ScopeIdentifier = item.ScopeIdentifier,
                    IsEnabled = item.IsEnabled,
                    Feature = TypeAdapter<AppFeature, AppFeatureReadModel>.Map.Invoke(item.Feature),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static AppRoleReadModel funcMain19(AppRole p20)
        {
            return p20 == null ? null : new AppRoleReadModel()
            {
                CreatedBy = p20.CreatedBy,
                CreatedDate = p20.CreatedDate,
                ModifiedBy = p20.ModifiedBy,
                ModifiedDate = p20.ModifiedDate,
                IsDeleted = p20.IsDeleted,
                DeletedBy = p20.DeletedBy,
                DeletedDate = p20.DeletedDate,
                AppUserRoles = funcMain20(p20.AppUserRoles),
                AppRoleClaims = funcMain21(p20.AppRoleClaims),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p20.AccessControlEntries),
                Hash = p20.Hash,
                Id = p20.Id,
                Name = p20.Name,
                NormalizedName = p20.NormalizedName,
                ConcurrencyStamp = p20.ConcurrencyStamp
            };
        }
        
        private static ICollection<AppRoleClaimReadModel> funcMain27(ICollection<AppRoleClaim> p32)
        {
            if (p32 == null)
            {
                return null;
            }
            ICollection<AppRoleClaimReadModel> result = new List<AppRoleClaimReadModel>(p32.Count);
            
            IEnumerator<AppRoleClaim> enumerator = p32.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRoleClaim item = enumerator.Current;
                result.Add(item == null ? null : new AppRoleClaimReadModel()
                {
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Id = item.Id,
                    RoleId = item.RoleId,
                    ClaimType = item.ClaimType,
                    ClaimValue = item.ClaimValue
                });
            }
            return result;
            
        }
        
        private static ICollection<AppAccessControlEntryReadModel> funcMain28(ICollection<AppAccessControlEntry> p33)
        {
            if (p33 == null)
            {
                return null;
            }
            ICollection<AppAccessControlEntryReadModel> result = new List<AppAccessControlEntryReadModel>(p33.Count);
            
            IEnumerator<AppAccessControlEntry> enumerator = p33.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppAccessControlEntry item = enumerator.Current;
                result.Add(funcMain29(item));
            }
            return result;
            
        }
        
        private static ICollection<AppFeatureFlagReadModel> funcMain39(ICollection<AppFeatureFlag> p47)
        {
            if (p47 == null)
            {
                return null;
            }
            ICollection<AppFeatureFlagReadModel> result = new List<AppFeatureFlagReadModel>(p47.Count);
            
            IEnumerator<AppFeatureFlag> enumerator = p47.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppFeatureFlag item = enumerator.Current;
                result.Add(item == null ? null : new AppFeatureFlagReadModel()
                {
                    FeatureId = item.FeatureId,
                    ScopeIdentifier = item.ScopeIdentifier,
                    IsEnabled = item.IsEnabled,
                    Feature = TypeAdapter<AppFeature, AppFeatureReadModel>.Map.Invoke(item.Feature),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static AppRoleReadModel funcMain41(AppRole p49)
        {
            return p49 == null ? null : new AppRoleReadModel()
            {
                CreatedBy = p49.CreatedBy,
                CreatedDate = p49.CreatedDate,
                ModifiedBy = p49.ModifiedBy,
                ModifiedDate = p49.ModifiedDate,
                IsDeleted = p49.IsDeleted,
                DeletedBy = p49.DeletedBy,
                DeletedDate = p49.DeletedDate,
                AppUserRoles = funcMain42(p49.AppUserRoles),
                AppRoleClaims = funcMain43(p49.AppRoleClaims),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p49.AccessControlEntries),
                Hash = p49.Hash,
                Id = p49.Id,
                Name = p49.Name,
                NormalizedName = p49.NormalizedName,
                ConcurrencyStamp = p49.ConcurrencyStamp
            };
        }
        
        private static ICollection<AppRoleClaimReadModel> funcMain49(ICollection<AppRoleClaim> p58)
        {
            if (p58 == null)
            {
                return null;
            }
            ICollection<AppRoleClaimReadModel> result = new List<AppRoleClaimReadModel>(p58.Count);
            
            IEnumerator<AppRoleClaim> enumerator = p58.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRoleClaim item = enumerator.Current;
                result.Add(item == null ? null : new AppRoleClaimReadModel()
                {
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Id = item.Id,
                    RoleId = item.RoleId,
                    ClaimType = item.ClaimType,
                    ClaimValue = item.ClaimValue
                });
            }
            return result;
            
        }
        
        private static ICollection<AppAccessControlEntryReadModel> funcMain50(ICollection<AppAccessControlEntry> p59)
        {
            if (p59 == null)
            {
                return null;
            }
            ICollection<AppAccessControlEntryReadModel> result = new List<AppAccessControlEntryReadModel>(p59.Count);
            
            IEnumerator<AppAccessControlEntry> enumerator = p59.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppAccessControlEntry item = enumerator.Current;
                result.Add(funcMain51(item));
            }
            return result;
            
        }
        
        private static ICollection<AppFeatureFlagReadModel> funcMain61(ICollection<AppFeatureFlag> p70)
        {
            if (p70 == null)
            {
                return null;
            }
            ICollection<AppFeatureFlagReadModel> result = new List<AppFeatureFlagReadModel>(p70.Count);
            
            IEnumerator<AppFeatureFlag> enumerator = p70.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppFeatureFlag item = enumerator.Current;
                result.Add(item == null ? null : new AppFeatureFlagReadModel()
                {
                    FeatureId = item.FeatureId,
                    ScopeIdentifier = item.ScopeIdentifier,
                    IsEnabled = item.IsEnabled,
                    Feature = TypeAdapter<AppFeature, AppFeatureReadModel>.Map.Invoke(item.Feature),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static AppRoleReadModel funcMain63(AppRole p72)
        {
            return p72 == null ? null : new AppRoleReadModel()
            {
                CreatedBy = p72.CreatedBy,
                CreatedDate = p72.CreatedDate,
                ModifiedBy = p72.ModifiedBy,
                ModifiedDate = p72.ModifiedDate,
                IsDeleted = p72.IsDeleted,
                DeletedBy = p72.DeletedBy,
                DeletedDate = p72.DeletedDate,
                AppUserRoles = funcMain64(p72.AppUserRoles),
                AppRoleClaims = funcMain65(p72.AppRoleClaims),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p72.AccessControlEntries),
                Hash = p72.Hash,
                Id = p72.Id,
                Name = p72.Name,
                NormalizedName = p72.NormalizedName,
                ConcurrencyStamp = p72.ConcurrencyStamp
            };
        }
        
        private static ICollection<AppRoleClaimReadModel> funcMain71(ICollection<AppRoleClaim> p84)
        {
            if (p84 == null)
            {
                return null;
            }
            ICollection<AppRoleClaimReadModel> result = new List<AppRoleClaimReadModel>(p84.Count);
            
            IEnumerator<AppRoleClaim> enumerator = p84.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRoleClaim item = enumerator.Current;
                result.Add(item == null ? null : new AppRoleClaimReadModel()
                {
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Id = item.Id,
                    RoleId = item.RoleId,
                    ClaimType = item.ClaimType,
                    ClaimValue = item.ClaimValue
                });
            }
            return result;
            
        }
        
        private static ICollection<AppAccessControlEntryReadModel> funcMain72(ICollection<AppAccessControlEntry> p85)
        {
            if (p85 == null)
            {
                return null;
            }
            ICollection<AppAccessControlEntryReadModel> result = new List<AppAccessControlEntryReadModel>(p85.Count);
            
            IEnumerator<AppAccessControlEntry> enumerator = p85.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppAccessControlEntry item = enumerator.Current;
                result.Add(funcMain73(item));
            }
            return result;
            
        }
        
        private static ICollection<AppFeatureFlagReadModel> funcMain83(ICollection<AppFeatureFlag> p99)
        {
            if (p99 == null)
            {
                return null;
            }
            ICollection<AppFeatureFlagReadModel> result = new List<AppFeatureFlagReadModel>(p99.Count);
            
            IEnumerator<AppFeatureFlag> enumerator = p99.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppFeatureFlag item = enumerator.Current;
                result.Add(item == null ? null : new AppFeatureFlagReadModel()
                {
                    FeatureId = item.FeatureId,
                    ScopeIdentifier = item.ScopeIdentifier,
                    IsEnabled = item.IsEnabled,
                    Feature = TypeAdapter<AppFeature, AppFeatureReadModel>.Map.Invoke(item.Feature),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static AppRoleReadModel funcMain85(AppRole p101)
        {
            return p101 == null ? null : new AppRoleReadModel()
            {
                CreatedBy = p101.CreatedBy,
                CreatedDate = p101.CreatedDate,
                ModifiedBy = p101.ModifiedBy,
                ModifiedDate = p101.ModifiedDate,
                IsDeleted = p101.IsDeleted,
                DeletedBy = p101.DeletedBy,
                DeletedDate = p101.DeletedDate,
                AppUserRoles = funcMain86(p101.AppUserRoles),
                AppRoleClaims = funcMain87(p101.AppRoleClaims),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p101.AccessControlEntries),
                Hash = p101.Hash,
                Id = p101.Id,
                Name = p101.Name,
                NormalizedName = p101.NormalizedName,
                ConcurrencyStamp = p101.ConcurrencyStamp
            };
        }
        
        private static AppAccessControlEntryReadModel funcMain7(AppAccessControlEntry p8)
        {
            return p8 == null ? null : new AppAccessControlEntryReadModel()
            {
                ResourcePattern = p8.ResourcePattern,
                PermissionPattern = p8.PermissionPattern,
                FeatureId = p8.FeatureId,
                Feature = funcMain8(p8.Feature),
                AppRoles = funcMain10(p8.AppRoles),
                AppUsers = funcMain11(p8.AppUsers),
                AppResource = p8.AppResource == null ? null : new AppResourceReadModel()
                {
                    Url = p8.AppResource.Url,
                    Description = p8.AppResource.Description,
                    ResourceType = p8.AppResource.ResourceType,
                    AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p8.AppResource.AccessControlEntries),
                    Id = p8.AppResource.Id,
                    CreatedBy = p8.AppResource.CreatedBy,
                    CreatedDate = p8.AppResource.CreatedDate,
                    ModifiedBy = p8.AppResource.ModifiedBy,
                    ModifiedDate = p8.AppResource.ModifiedDate,
                    IsDeleted = p8.AppResource.IsDeleted,
                    DeletedBy = p8.AppResource.DeletedBy,
                    DeletedDate = p8.AppResource.DeletedDate
                },
                ResourceId = p8.ResourceId,
                Id = p8.Id,
                CreatedBy = p8.CreatedBy,
                CreatedDate = p8.CreatedDate,
                ModifiedBy = p8.ModifiedBy,
                ModifiedDate = p8.ModifiedDate,
                IsDeleted = p8.IsDeleted,
                DeletedBy = p8.DeletedBy,
                DeletedDate = p8.DeletedDate
            };
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain20(ICollection<AppUserRole> p21)
        {
            if (p21 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p21.Count);
            
            IEnumerator<AppUserRole> enumerator = p21.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(item == null ? null : new AppUserRoleReadModel()
                {
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Hash = item.Hash,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    RoleId = item.RoleId
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRoleClaimReadModel> funcMain21(ICollection<AppRoleClaim> p22)
        {
            if (p22 == null)
            {
                return null;
            }
            ICollection<AppRoleClaimReadModel> result = new List<AppRoleClaimReadModel>(p22.Count);
            
            IEnumerator<AppRoleClaim> enumerator = p22.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRoleClaim item = enumerator.Current;
                result.Add(item == null ? null : new AppRoleClaimReadModel()
                {
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Id = item.Id,
                    RoleId = item.RoleId,
                    ClaimType = item.ClaimType,
                    ClaimValue = item.ClaimValue
                });
            }
            return result;
            
        }
        
        private static AppAccessControlEntryReadModel funcMain29(AppAccessControlEntry p34)
        {
            return p34 == null ? null : new AppAccessControlEntryReadModel()
            {
                ResourcePattern = p34.ResourcePattern,
                PermissionPattern = p34.PermissionPattern,
                FeatureId = p34.FeatureId,
                Feature = funcMain30(p34.Feature),
                AppRoles = funcMain32(p34.AppRoles),
                AppUsers = funcMain33(p34.AppUsers),
                AppResource = p34.AppResource == null ? null : new AppResourceReadModel()
                {
                    Url = p34.AppResource.Url,
                    Description = p34.AppResource.Description,
                    ResourceType = p34.AppResource.ResourceType,
                    AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p34.AppResource.AccessControlEntries),
                    Id = p34.AppResource.Id,
                    CreatedBy = p34.AppResource.CreatedBy,
                    CreatedDate = p34.AppResource.CreatedDate,
                    ModifiedBy = p34.AppResource.ModifiedBy,
                    ModifiedDate = p34.AppResource.ModifiedDate,
                    IsDeleted = p34.AppResource.IsDeleted,
                    DeletedBy = p34.AppResource.DeletedBy,
                    DeletedDate = p34.AppResource.DeletedDate
                },
                ResourceId = p34.ResourceId,
                Id = p34.Id,
                CreatedBy = p34.CreatedBy,
                CreatedDate = p34.CreatedDate,
                ModifiedBy = p34.ModifiedBy,
                ModifiedDate = p34.ModifiedDate,
                IsDeleted = p34.IsDeleted,
                DeletedBy = p34.DeletedBy,
                DeletedDate = p34.DeletedDate
            };
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain42(ICollection<AppUserRole> p50)
        {
            if (p50 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p50.Count);
            
            IEnumerator<AppUserRole> enumerator = p50.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(item == null ? null : new AppUserRoleReadModel()
                {
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Hash = item.Hash,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    RoleId = item.RoleId
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRoleClaimReadModel> funcMain43(ICollection<AppRoleClaim> p51)
        {
            if (p51 == null)
            {
                return null;
            }
            ICollection<AppRoleClaimReadModel> result = new List<AppRoleClaimReadModel>(p51.Count);
            
            IEnumerator<AppRoleClaim> enumerator = p51.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRoleClaim item = enumerator.Current;
                result.Add(item == null ? null : new AppRoleClaimReadModel()
                {
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Id = item.Id,
                    RoleId = item.RoleId,
                    ClaimType = item.ClaimType,
                    ClaimValue = item.ClaimValue
                });
            }
            return result;
            
        }
        
        private static AppAccessControlEntryReadModel funcMain51(AppAccessControlEntry p60)
        {
            return p60 == null ? null : new AppAccessControlEntryReadModel()
            {
                ResourcePattern = p60.ResourcePattern,
                PermissionPattern = p60.PermissionPattern,
                FeatureId = p60.FeatureId,
                Feature = funcMain52(p60.Feature),
                AppRoles = funcMain54(p60.AppRoles),
                AppUsers = funcMain55(p60.AppUsers),
                AppResource = p60.AppResource == null ? null : new AppResourceReadModel()
                {
                    Url = p60.AppResource.Url,
                    Description = p60.AppResource.Description,
                    ResourceType = p60.AppResource.ResourceType,
                    AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p60.AppResource.AccessControlEntries),
                    Id = p60.AppResource.Id,
                    CreatedBy = p60.AppResource.CreatedBy,
                    CreatedDate = p60.AppResource.CreatedDate,
                    ModifiedBy = p60.AppResource.ModifiedBy,
                    ModifiedDate = p60.AppResource.ModifiedDate,
                    IsDeleted = p60.AppResource.IsDeleted,
                    DeletedBy = p60.AppResource.DeletedBy,
                    DeletedDate = p60.AppResource.DeletedDate
                },
                ResourceId = p60.ResourceId,
                Id = p60.Id,
                CreatedBy = p60.CreatedBy,
                CreatedDate = p60.CreatedDate,
                ModifiedBy = p60.ModifiedBy,
                ModifiedDate = p60.ModifiedDate,
                IsDeleted = p60.IsDeleted,
                DeletedBy = p60.DeletedBy,
                DeletedDate = p60.DeletedDate
            };
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain64(ICollection<AppUserRole> p73)
        {
            if (p73 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p73.Count);
            
            IEnumerator<AppUserRole> enumerator = p73.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(item == null ? null : new AppUserRoleReadModel()
                {
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Hash = item.Hash,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    RoleId = item.RoleId
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRoleClaimReadModel> funcMain65(ICollection<AppRoleClaim> p74)
        {
            if (p74 == null)
            {
                return null;
            }
            ICollection<AppRoleClaimReadModel> result = new List<AppRoleClaimReadModel>(p74.Count);
            
            IEnumerator<AppRoleClaim> enumerator = p74.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRoleClaim item = enumerator.Current;
                result.Add(item == null ? null : new AppRoleClaimReadModel()
                {
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Id = item.Id,
                    RoleId = item.RoleId,
                    ClaimType = item.ClaimType,
                    ClaimValue = item.ClaimValue
                });
            }
            return result;
            
        }
        
        private static AppAccessControlEntryReadModel funcMain73(AppAccessControlEntry p86)
        {
            return p86 == null ? null : new AppAccessControlEntryReadModel()
            {
                ResourcePattern = p86.ResourcePattern,
                PermissionPattern = p86.PermissionPattern,
                FeatureId = p86.FeatureId,
                Feature = funcMain74(p86.Feature),
                AppRoles = funcMain76(p86.AppRoles),
                AppUsers = funcMain77(p86.AppUsers),
                AppResource = p86.AppResource == null ? null : new AppResourceReadModel()
                {
                    Url = p86.AppResource.Url,
                    Description = p86.AppResource.Description,
                    ResourceType = p86.AppResource.ResourceType,
                    AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p86.AppResource.AccessControlEntries),
                    Id = p86.AppResource.Id,
                    CreatedBy = p86.AppResource.CreatedBy,
                    CreatedDate = p86.AppResource.CreatedDate,
                    ModifiedBy = p86.AppResource.ModifiedBy,
                    ModifiedDate = p86.AppResource.ModifiedDate,
                    IsDeleted = p86.AppResource.IsDeleted,
                    DeletedBy = p86.AppResource.DeletedBy,
                    DeletedDate = p86.AppResource.DeletedDate
                },
                ResourceId = p86.ResourceId,
                Id = p86.Id,
                CreatedBy = p86.CreatedBy,
                CreatedDate = p86.CreatedDate,
                ModifiedBy = p86.ModifiedBy,
                ModifiedDate = p86.ModifiedDate,
                IsDeleted = p86.IsDeleted,
                DeletedBy = p86.DeletedBy,
                DeletedDate = p86.DeletedDate
            };
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain86(ICollection<AppUserRole> p102)
        {
            if (p102 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p102.Count);
            
            IEnumerator<AppUserRole> enumerator = p102.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(item == null ? null : new AppUserRoleReadModel()
                {
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Hash = item.Hash,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    RoleId = item.RoleId
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRoleClaimReadModel> funcMain87(ICollection<AppRoleClaim> p103)
        {
            if (p103 == null)
            {
                return null;
            }
            ICollection<AppRoleClaimReadModel> result = new List<AppRoleClaimReadModel>(p103.Count);
            
            IEnumerator<AppRoleClaim> enumerator = p103.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRoleClaim item = enumerator.Current;
                result.Add(item == null ? null : new AppRoleClaimReadModel()
                {
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Id = item.Id,
                    RoleId = item.RoleId,
                    ClaimType = item.ClaimType,
                    ClaimValue = item.ClaimValue
                });
            }
            return result;
            
        }
        
        private static AppFeatureReadModel funcMain8(AppFeature p9)
        {
            return p9 == null ? null : new AppFeatureReadModel()
            {
                Name = p9.Name,
                Description = p9.Description,
                IsEnabled = p9.IsEnabled,
                Scope = p9.Scope,
                FeatureFlags = funcMain9(p9.FeatureFlags),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p9.AccessControlEntries),
                Id = p9.Id,
                CreatedBy = p9.CreatedBy,
                CreatedDate = p9.CreatedDate,
                ModifiedBy = p9.ModifiedBy,
                ModifiedDate = p9.ModifiedDate,
                IsDeleted = p9.IsDeleted,
                DeletedBy = p9.DeletedBy,
                DeletedDate = p9.DeletedDate
            };
        }
        
        private static ICollection<AppRoleReadModel> funcMain10(ICollection<AppRole> p11)
        {
            if (p11 == null)
            {
                return null;
            }
            ICollection<AppRoleReadModel> result = new List<AppRoleReadModel>(p11.Count);
            
            IEnumerator<AppRole> enumerator = p11.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRole item = enumerator.Current;
                result.Add(TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserReadModel> funcMain11(ICollection<AppUser> p12)
        {
            if (p12 == null)
            {
                return null;
            }
            ICollection<AppUserReadModel> result = new List<AppUserReadModel>(p12.Count);
            
            IEnumerator<AppUser> enumerator = p12.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUser item = enumerator.Current;
                result.Add(TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static AppFeatureReadModel funcMain30(AppFeature p35)
        {
            return p35 == null ? null : new AppFeatureReadModel()
            {
                Name = p35.Name,
                Description = p35.Description,
                IsEnabled = p35.IsEnabled,
                Scope = p35.Scope,
                FeatureFlags = funcMain31(p35.FeatureFlags),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p35.AccessControlEntries),
                Id = p35.Id,
                CreatedBy = p35.CreatedBy,
                CreatedDate = p35.CreatedDate,
                ModifiedBy = p35.ModifiedBy,
                ModifiedDate = p35.ModifiedDate,
                IsDeleted = p35.IsDeleted,
                DeletedBy = p35.DeletedBy,
                DeletedDate = p35.DeletedDate
            };
        }
        
        private static ICollection<AppRoleReadModel> funcMain32(ICollection<AppRole> p37)
        {
            if (p37 == null)
            {
                return null;
            }
            ICollection<AppRoleReadModel> result = new List<AppRoleReadModel>(p37.Count);
            
            IEnumerator<AppRole> enumerator = p37.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRole item = enumerator.Current;
                result.Add(TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserReadModel> funcMain33(ICollection<AppUser> p38)
        {
            if (p38 == null)
            {
                return null;
            }
            ICollection<AppUserReadModel> result = new List<AppUserReadModel>(p38.Count);
            
            IEnumerator<AppUser> enumerator = p38.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUser item = enumerator.Current;
                result.Add(TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static AppFeatureReadModel funcMain52(AppFeature p61)
        {
            return p61 == null ? null : new AppFeatureReadModel()
            {
                Name = p61.Name,
                Description = p61.Description,
                IsEnabled = p61.IsEnabled,
                Scope = p61.Scope,
                FeatureFlags = funcMain53(p61.FeatureFlags),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p61.AccessControlEntries),
                Id = p61.Id,
                CreatedBy = p61.CreatedBy,
                CreatedDate = p61.CreatedDate,
                ModifiedBy = p61.ModifiedBy,
                ModifiedDate = p61.ModifiedDate,
                IsDeleted = p61.IsDeleted,
                DeletedBy = p61.DeletedBy,
                DeletedDate = p61.DeletedDate
            };
        }
        
        private static ICollection<AppRoleReadModel> funcMain54(ICollection<AppRole> p63)
        {
            if (p63 == null)
            {
                return null;
            }
            ICollection<AppRoleReadModel> result = new List<AppRoleReadModel>(p63.Count);
            
            IEnumerator<AppRole> enumerator = p63.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRole item = enumerator.Current;
                result.Add(TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserReadModel> funcMain55(ICollection<AppUser> p64)
        {
            if (p64 == null)
            {
                return null;
            }
            ICollection<AppUserReadModel> result = new List<AppUserReadModel>(p64.Count);
            
            IEnumerator<AppUser> enumerator = p64.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUser item = enumerator.Current;
                result.Add(TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static AppFeatureReadModel funcMain74(AppFeature p87)
        {
            return p87 == null ? null : new AppFeatureReadModel()
            {
                Name = p87.Name,
                Description = p87.Description,
                IsEnabled = p87.IsEnabled,
                Scope = p87.Scope,
                FeatureFlags = funcMain75(p87.FeatureFlags),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p87.AccessControlEntries),
                Id = p87.Id,
                CreatedBy = p87.CreatedBy,
                CreatedDate = p87.CreatedDate,
                ModifiedBy = p87.ModifiedBy,
                ModifiedDate = p87.ModifiedDate,
                IsDeleted = p87.IsDeleted,
                DeletedBy = p87.DeletedBy,
                DeletedDate = p87.DeletedDate
            };
        }
        
        private static ICollection<AppRoleReadModel> funcMain76(ICollection<AppRole> p89)
        {
            if (p89 == null)
            {
                return null;
            }
            ICollection<AppRoleReadModel> result = new List<AppRoleReadModel>(p89.Count);
            
            IEnumerator<AppRole> enumerator = p89.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRole item = enumerator.Current;
                result.Add(TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserReadModel> funcMain77(ICollection<AppUser> p90)
        {
            if (p90 == null)
            {
                return null;
            }
            ICollection<AppUserReadModel> result = new List<AppUserReadModel>(p90.Count);
            
            IEnumerator<AppUser> enumerator = p90.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUser item = enumerator.Current;
                result.Add(TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static ICollection<AppFeatureFlagReadModel> funcMain9(ICollection<AppFeatureFlag> p10)
        {
            if (p10 == null)
            {
                return null;
            }
            ICollection<AppFeatureFlagReadModel> result = new List<AppFeatureFlagReadModel>(p10.Count);
            
            IEnumerator<AppFeatureFlag> enumerator = p10.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppFeatureFlag item = enumerator.Current;
                result.Add(item == null ? null : new AppFeatureFlagReadModel()
                {
                    FeatureId = item.FeatureId,
                    ScopeIdentifier = item.ScopeIdentifier,
                    IsEnabled = item.IsEnabled,
                    Feature = TypeAdapter<AppFeature, AppFeatureReadModel>.Map.Invoke(item.Feature),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static ICollection<AppFeatureFlagReadModel> funcMain31(ICollection<AppFeatureFlag> p36)
        {
            if (p36 == null)
            {
                return null;
            }
            ICollection<AppFeatureFlagReadModel> result = new List<AppFeatureFlagReadModel>(p36.Count);
            
            IEnumerator<AppFeatureFlag> enumerator = p36.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppFeatureFlag item = enumerator.Current;
                result.Add(item == null ? null : new AppFeatureFlagReadModel()
                {
                    FeatureId = item.FeatureId,
                    ScopeIdentifier = item.ScopeIdentifier,
                    IsEnabled = item.IsEnabled,
                    Feature = TypeAdapter<AppFeature, AppFeatureReadModel>.Map.Invoke(item.Feature),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static ICollection<AppFeatureFlagReadModel> funcMain53(ICollection<AppFeatureFlag> p62)
        {
            if (p62 == null)
            {
                return null;
            }
            ICollection<AppFeatureFlagReadModel> result = new List<AppFeatureFlagReadModel>(p62.Count);
            
            IEnumerator<AppFeatureFlag> enumerator = p62.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppFeatureFlag item = enumerator.Current;
                result.Add(item == null ? null : new AppFeatureFlagReadModel()
                {
                    FeatureId = item.FeatureId,
                    ScopeIdentifier = item.ScopeIdentifier,
                    IsEnabled = item.IsEnabled,
                    Feature = TypeAdapter<AppFeature, AppFeatureReadModel>.Map.Invoke(item.Feature),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static ICollection<AppFeatureFlagReadModel> funcMain75(ICollection<AppFeatureFlag> p88)
        {
            if (p88 == null)
            {
                return null;
            }
            ICollection<AppFeatureFlagReadModel> result = new List<AppFeatureFlagReadModel>(p88.Count);
            
            IEnumerator<AppFeatureFlag> enumerator = p88.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppFeatureFlag item = enumerator.Current;
                result.Add(item == null ? null : new AppFeatureFlagReadModel()
                {
                    FeatureId = item.FeatureId,
                    ScopeIdentifier = item.ScopeIdentifier,
                    IsEnabled = item.IsEnabled,
                    Feature = TypeAdapter<AppFeature, AppFeatureReadModel>.Map.Invoke(item.Feature),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
    }
}