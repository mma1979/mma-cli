using System.Collections.Generic;
using AxialSystem.Covaluse.Core.Database.Identity;
using Mapster;

namespace AxialSystem.Covaluse.Core.Database.Identity
{
    public static partial class UserRoleMapper
    {
        public static UserRoleDto AdaptToDto(this UserRole p1)
        {
            return p1 == null ? null : new UserRoleDto()
            {
                AppUser = funcMain1(p1.AppUser),
                Role = funcMain5(p1.Role),
                CreatedBy = p1.CreatedBy,
                CreatedDate = p1.CreatedDate,
                ModifiedBy = p1.ModifiedBy,
                ModifiedDate = p1.ModifiedDate,
                IsDeleted = p1.IsDeleted,
                DeletedBy = p1.DeletedBy,
                DeletedDate = p1.DeletedDate,
                UserId = p1.UserId,
                RoleId = p1.RoleId
            };
        }
        public static UserRoleDto AdaptTo(this UserRole p8, UserRoleDto p9)
        {
            if (p8 == null)
            {
                return null;
            }
            UserRoleDto result = p9 ?? new UserRoleDto();
            
            result.AppUser = funcMain7(p8.AppUser, result.AppUser);
            result.Role = funcMain11(p8.Role, result.Role);
            result.CreatedBy = p8.CreatedBy;
            result.CreatedDate = p8.CreatedDate;
            result.ModifiedBy = p8.ModifiedBy;
            result.ModifiedDate = p8.ModifiedDate;
            result.IsDeleted = p8.IsDeleted;
            result.DeletedBy = p8.DeletedBy;
            result.DeletedDate = p8.DeletedDate;
            result.UserId = p8.UserId;
            result.RoleId = p8.RoleId;
            return result;
            
        }
        
        private static AppUserDto funcMain1(AppUser p2)
        {
            return p2 == null ? null : new AppUserDto()
            {
                Hash = p2.Hash,
                FirstName = p2.FirstName,
                LastName = p2.LastName,
                Mobile = p2.Mobile,
                CountryCode = p2.CountryCode,
                TwoFactorMethod = p2.TwoFactorMethod,
                CreatedBy = p2.CreatedBy,
                CreatedDate = p2.CreatedDate,
                ModifiedBy = p2.ModifiedBy,
                ModifiedDate = p2.ModifiedDate,
                IsDeleted = p2.IsDeleted,
                DeletedBy = p2.DeletedBy,
                DeletedDate = p2.DeletedDate,
                MembershipType = p2.MembershipType,
                UserRoles = funcMain2(p2.UserRoles),
                UserTokens = funcMain3(p2.UserTokens),
                RefreshTokens = funcMain4(p2.RefreshTokens),
                Id = p2.Id,
                UserName = p2.UserName,
                NormalizedUserName = p2.NormalizedUserName,
                Email = p2.Email,
                NormalizedEmail = p2.NormalizedEmail,
                EmailConfirmed = p2.EmailConfirmed,
                PasswordHash = p2.PasswordHash,
                SecurityStamp = p2.SecurityStamp,
                ConcurrencyStamp = p2.ConcurrencyStamp,
                PhoneNumber = p2.PhoneNumber,
                PhoneNumberConfirmed = p2.PhoneNumberConfirmed,
                TwoFactorEnabled = p2.TwoFactorEnabled,
                LockoutEnd = p2.LockoutEnd,
                LockoutEnabled = p2.LockoutEnabled,
                AccessFailedCount = p2.AccessFailedCount
            };
        }
        
        private static RoleDto funcMain5(Role p6)
        {
            return p6 == null ? null : new RoleDto()
            {
                CreatedBy = p6.CreatedBy,
                CreatedDate = p6.CreatedDate,
                ModifiedBy = p6.ModifiedBy,
                ModifiedDate = p6.ModifiedDate,
                IsDeleted = p6.IsDeleted,
                DeletedBy = p6.DeletedBy,
                DeletedDate = p6.DeletedDate,
                UserRoles = funcMain6(p6.UserRoles),
                Id = p6.Id,
                Name = p6.Name,
                NormalizedName = p6.NormalizedName,
                ConcurrencyStamp = p6.ConcurrencyStamp
            };
        }
        
        private static AppUserDto funcMain7(AppUser p10, AppUserDto p11)
        {
            if (p10 == null)
            {
                return null;
            }
            AppUserDto result = p11 ?? new AppUserDto();
            
            result.Hash = p10.Hash;
            result.FirstName = p10.FirstName;
            result.LastName = p10.LastName;
            result.Mobile = p10.Mobile;
            result.CountryCode = p10.CountryCode;
            result.TwoFactorMethod = p10.TwoFactorMethod;
            result.CreatedBy = p10.CreatedBy;
            result.CreatedDate = p10.CreatedDate;
            result.ModifiedBy = p10.ModifiedBy;
            result.ModifiedDate = p10.ModifiedDate;
            result.IsDeleted = p10.IsDeleted;
            result.DeletedBy = p10.DeletedBy;
            result.DeletedDate = p10.DeletedDate;
            result.MembershipType = p10.MembershipType;
            result.UserRoles = funcMain8(p10.UserRoles, result.UserRoles);
            result.UserTokens = funcMain9(p10.UserTokens, result.UserTokens);
            result.RefreshTokens = funcMain10(p10.RefreshTokens, result.RefreshTokens);
            result.Id = p10.Id;
            result.UserName = p10.UserName;
            result.NormalizedUserName = p10.NormalizedUserName;
            result.Email = p10.Email;
            result.NormalizedEmail = p10.NormalizedEmail;
            result.EmailConfirmed = p10.EmailConfirmed;
            result.PasswordHash = p10.PasswordHash;
            result.SecurityStamp = p10.SecurityStamp;
            result.ConcurrencyStamp = p10.ConcurrencyStamp;
            result.PhoneNumber = p10.PhoneNumber;
            result.PhoneNumberConfirmed = p10.PhoneNumberConfirmed;
            result.TwoFactorEnabled = p10.TwoFactorEnabled;
            result.LockoutEnd = p10.LockoutEnd;
            result.LockoutEnabled = p10.LockoutEnabled;
            result.AccessFailedCount = p10.AccessFailedCount;
            return result;
            
        }
        
        private static RoleDto funcMain11(Role p18, RoleDto p19)
        {
            if (p18 == null)
            {
                return null;
            }
            RoleDto result = p19 ?? new RoleDto();
            
            result.CreatedBy = p18.CreatedBy;
            result.CreatedDate = p18.CreatedDate;
            result.ModifiedBy = p18.ModifiedBy;
            result.ModifiedDate = p18.ModifiedDate;
            result.IsDeleted = p18.IsDeleted;
            result.DeletedBy = p18.DeletedBy;
            result.DeletedDate = p18.DeletedDate;
            result.UserRoles = funcMain12(p18.UserRoles, result.UserRoles);
            result.Id = p18.Id;
            result.Name = p18.Name;
            result.NormalizedName = p18.NormalizedName;
            result.ConcurrencyStamp = p18.ConcurrencyStamp;
            return result;
            
        }
        
        private static ICollection<UserRoleDto> funcMain2(ICollection<UserRole> p3)
        {
            if (p3 == null)
            {
                return null;
            }
            ICollection<UserRoleDto> result = new List<UserRoleDto>(p3.Count);
            
            IEnumerator<UserRole> enumerator = p3.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                UserRole item = enumerator.Current;
                result.Add(TypeAdapter<UserRole, UserRoleDto>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static ICollection<UserTokenDto> funcMain3(ICollection<UserToken> p4)
        {
            if (p4 == null)
            {
                return null;
            }
            ICollection<UserTokenDto> result = new List<UserTokenDto>(p4.Count);
            
            IEnumerator<UserToken> enumerator = p4.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                UserToken item = enumerator.Current;
                result.Add(item == null ? null : new UserTokenDto()
                {
                    Token = item.Token,
                    AppUser = TypeAdapter<AppUser, AppUserDto>.Map.Invoke(item.AppUser),
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    LoginProvider = item.LoginProvider,
                    Name = item.Name,
                    Value = item.Value
                });
            }
            return result;
            
        }
        
        private static ICollection<RefreshTokenDto> funcMain4(ICollection<RefreshToken> p5)
        {
            if (p5 == null)
            {
                return null;
            }
            ICollection<RefreshTokenDto> result = new List<RefreshTokenDto>(p5.Count);
            
            IEnumerator<RefreshToken> enumerator = p5.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                RefreshToken item = enumerator.Current;
                result.Add(item == null ? null : new RefreshTokenDto()
                {
                    UserId = item.UserId,
                    Token = item.Token,
                    JwtId = item.JwtId,
                    IsUsed = item.IsUsed,
                    IsRevoked = item.IsRevoked,
                    ExpiryDate = item.ExpiryDate,
                    Hash = item.Hash,
                    AppUser = TypeAdapter<AppUser, AppUserDto>.Map.Invoke(item.AppUser),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static ICollection<UserRoleDto> funcMain6(ICollection<UserRole> p7)
        {
            if (p7 == null)
            {
                return null;
            }
            ICollection<UserRoleDto> result = new List<UserRoleDto>(p7.Count);
            
            IEnumerator<UserRole> enumerator = p7.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                UserRole item = enumerator.Current;
                result.Add(TypeAdapter<UserRole, UserRoleDto>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static ICollection<UserRoleDto> funcMain8(ICollection<UserRole> p12, ICollection<UserRoleDto> p13)
        {
            if (p12 == null)
            {
                return null;
            }
            ICollection<UserRoleDto> result = new List<UserRoleDto>(p12.Count);
            
            IEnumerator<UserRole> enumerator = p12.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                UserRole item = enumerator.Current;
                result.Add(TypeAdapter<UserRole, UserRoleDto>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static ICollection<UserTokenDto> funcMain9(ICollection<UserToken> p14, ICollection<UserTokenDto> p15)
        {
            if (p14 == null)
            {
                return null;
            }
            ICollection<UserTokenDto> result = new List<UserTokenDto>(p14.Count);
            
            IEnumerator<UserToken> enumerator = p14.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                UserToken item = enumerator.Current;
                result.Add(item == null ? null : new UserTokenDto()
                {
                    Token = item.Token,
                    AppUser = TypeAdapter<AppUser, AppUserDto>.Map.Invoke(item.AppUser),
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    LoginProvider = item.LoginProvider,
                    Name = item.Name,
                    Value = item.Value
                });
            }
            return result;
            
        }
        
        private static ICollection<RefreshTokenDto> funcMain10(ICollection<RefreshToken> p16, ICollection<RefreshTokenDto> p17)
        {
            if (p16 == null)
            {
                return null;
            }
            ICollection<RefreshTokenDto> result = new List<RefreshTokenDto>(p16.Count);
            
            IEnumerator<RefreshToken> enumerator = p16.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                RefreshToken item = enumerator.Current;
                result.Add(item == null ? null : new RefreshTokenDto()
                {
                    UserId = item.UserId,
                    Token = item.Token,
                    JwtId = item.JwtId,
                    IsUsed = item.IsUsed,
                    IsRevoked = item.IsRevoked,
                    ExpiryDate = item.ExpiryDate,
                    Hash = item.Hash,
                    AppUser = TypeAdapter<AppUser, AppUserDto>.Map.Invoke(item.AppUser),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static ICollection<UserRoleDto> funcMain12(ICollection<UserRole> p20, ICollection<UserRoleDto> p21)
        {
            if (p20 == null)
            {
                return null;
            }
            ICollection<UserRoleDto> result = new List<UserRoleDto>(p20.Count);
            
            IEnumerator<UserRole> enumerator = p20.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                UserRole item = enumerator.Current;
                result.Add(TypeAdapter<UserRole, UserRoleDto>.Map.Invoke(item));
            }
            return result;
            
        }
    }
}