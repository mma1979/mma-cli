using AxialSystem.Covaluse.Core.Database.Tables;

namespace AxialSystem.Covaluse.Core.Database.Tables
{
    public static partial class AttachmentMapper
    {
        public static AttachmentDto AdaptToDto(this Attachment p1)
        {
            return p1 == null ? null : new AttachmentDto()
            {
                AttachmentName = p1.AttachmentName,
                FilePath = p1.FilePath,
                FileSize = p1.FileSize,
                ContentType = p1.ContentType,
                KeyId = p1.KeyId,
                Id = p1.Id,
                CreatedBy = p1.CreatedBy,
                CreatedDate = p1.CreatedDate,
                ModifiedBy = p1.ModifiedBy,
                ModifiedDate = p1.ModifiedDate,
                IsDeleted = p1.IsDeleted,
                DeletedBy = p1.DeletedBy,
                DeletedDate = p1.DeletedDate
            };
        }
        public static AttachmentDto AdaptTo(this Attachment p2, AttachmentDto p3)
        {
            if (p2 == null)
            {
                return null;
            }
            AttachmentDto result = p3 ?? new AttachmentDto();
            
            result.AttachmentName = p2.AttachmentName;
            result.FilePath = p2.FilePath;
            result.FileSize = p2.FileSize;
            result.ContentType = p2.ContentType;
            result.KeyId = p2.KeyId;
            result.Id = p2.Id;
            result.CreatedBy = p2.CreatedBy;
            result.CreatedDate = p2.CreatedDate;
            result.ModifiedBy = p2.ModifiedBy;
            result.ModifiedDate = p2.ModifiedDate;
            result.IsDeleted = p2.IsDeleted;
            result.DeletedBy = p2.DeletedBy;
            result.DeletedDate = p2.DeletedDate;
            return result;
            
        }
    }
}