using AxialSystem.Covaluse.Core.Database.Tables;

namespace AxialSystem.Covaluse.Core.Database.Tables
{
    public static partial class AttachmentMapper
    {
        public static AttachmentReadModel AdaptToReadModel(this Attachment p1)
        {
            return p1 == null ? null : new AttachmentReadModel()
            {
                AttachmentName = p1.AttachmentName,
                FilePath = p1.FilePath,
                FileSize = p1.FileSize,
                ContentType = p1.ContentType,
                Key = p1.Key,
                Id = p1.Id,
                CreatedBy = p1.CreatedBy,
                CreatedDate = p1.CreatedDate,
                ModifiedBy = p1.ModifiedBy,
                ModifiedDate = p1.ModifiedDate,
                IsDeleted = p1.IsDeleted,
                DeletedBy = p1.DeletedBy,
                DeletedDate = p1.DeletedDate
            };
        }
        public static AttachmentReadModel AdaptTo(this Attachment p2, AttachmentReadModel p3)
        {
            if (p2 == null)
            {
                return null;
            }
            AttachmentReadModel result = p3 ?? new AttachmentReadModel();
            
            result.AttachmentName = p2.AttachmentName;
            result.FilePath = p2.FilePath;
            result.FileSize = p2.FileSize;
            result.ContentType = p2.ContentType;
            result.Key = p2.Key;
            result.Id = p2.Id;
            result.CreatedBy = p2.CreatedBy;
            result.CreatedDate = p2.CreatedDate;
            result.ModifiedBy = p2.ModifiedBy;
            result.ModifiedDate = p2.ModifiedDate;
            result.IsDeleted = p2.IsDeleted;
            result.DeletedBy = p2.DeletedBy;
            result.DeletedDate = p2.DeletedDate;
            return result;
            
        }
        public static AttachmentModifyModel AdaptToModifyModel(this Attachment p4)
        {
            return p4 == null ? null : new AttachmentModifyModel()
            {
                AttachmentName = p4.AttachmentName,
                FilePath = p4.FilePath,
                FileSize = p4.FileSize,
                ContentType = p4.ContentType,
                Key = p4.Key,
                Id = p4.Id,
                CreatedBy = p4.CreatedBy,
                CreatedDate = p4.CreatedDate,
                ModifiedBy = p4.ModifiedBy,
                ModifiedDate = p4.ModifiedDate,
                IsDeleted = p4.IsDeleted,
                DeletedBy = p4.DeletedBy,
                DeletedDate = p4.DeletedDate
            };
        }
        public static AttachmentModifyModel AdaptTo(this Attachment p5, AttachmentModifyModel p6)
        {
            if (p5 == null)
            {
                return null;
            }
            AttachmentModifyModel result = p6 ?? new AttachmentModifyModel();
            
            result.AttachmentName = p5.AttachmentName;
            result.FilePath = p5.FilePath;
            result.FileSize = p5.FileSize;
            result.ContentType = p5.ContentType;
            result.Key = p5.Key;
            result.Id = p5.Id;
            result.CreatedBy = p5.CreatedBy;
            result.CreatedDate = p5.CreatedDate;
            result.ModifiedBy = p5.ModifiedBy;
            result.ModifiedDate = p5.ModifiedDate;
            result.IsDeleted = p5.IsDeleted;
            result.DeletedBy = p5.DeletedBy;
            result.DeletedDate = p5.DeletedDate;
            return result;
            
        }
    }
}