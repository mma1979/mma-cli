using System.Collections.Generic;
using AxialSystem.Covaluse.Core.Database.Identity;
using Mapster;

namespace AxialSystem.Covaluse.Core.Database.Identity
{
    public static partial class AppResourceMapper
    {
        public static AppResourceReadModel AdaptToReadModel(this AppResource p1)
        {
            return p1 == null ? null : new AppResourceReadModel()
            {
                Url = p1.Url,
                Description = p1.Description,
                ResourceType = p1.ResourceType,
                AccessControlEntries = funcMain1(p1.AccessControlEntries),
                Id = p1.Id,
                CreatedBy = p1.CreatedBy,
                CreatedDate = p1.CreatedDate,
                ModifiedBy = p1.ModifiedBy,
                ModifiedDate = p1.ModifiedDate,
                IsDeleted = p1.IsDeleted,
                DeletedBy = p1.DeletedBy,
                DeletedDate = p1.DeletedDate
            };
        }
        public static AppResourceReadModel AdaptTo(this AppResource p22, AppResourceReadModel p23)
        {
            if (p22 == null)
            {
                return null;
            }
            AppResourceReadModel result = p23 ?? new AppResourceReadModel();
            
            result.Url = p22.Url;
            result.Description = p22.Description;
            result.ResourceType = p22.ResourceType;
            result.AccessControlEntries = funcMain21(p22.AccessControlEntries, result.AccessControlEntries);
            result.Id = p22.Id;
            result.CreatedBy = p22.CreatedBy;
            result.CreatedDate = p22.CreatedDate;
            result.ModifiedBy = p22.ModifiedBy;
            result.ModifiedDate = p22.ModifiedDate;
            result.IsDeleted = p22.IsDeleted;
            result.DeletedBy = p22.DeletedBy;
            result.DeletedDate = p22.DeletedDate;
            return result;
            
        }
        public static AppResourceModifyModel AdaptToModifyModel(this AppResource p45)
        {
            return p45 == null ? null : new AppResourceModifyModel()
            {
                Url = p45.Url,
                Description = p45.Description,
                ResourceType = p45.ResourceType,
                AccessControlEntries = funcMain41(p45.AccessControlEntries),
                Id = p45.Id,
                CreatedBy = p45.CreatedBy,
                CreatedDate = p45.CreatedDate,
                ModifiedBy = p45.ModifiedBy,
                ModifiedDate = p45.ModifiedDate,
                IsDeleted = p45.IsDeleted,
                DeletedBy = p45.DeletedBy,
                DeletedDate = p45.DeletedDate
            };
        }
        public static AppResourceModifyModel AdaptTo(this AppResource p66, AppResourceModifyModel p67)
        {
            if (p66 == null)
            {
                return null;
            }
            AppResourceModifyModel result = p67 ?? new AppResourceModifyModel();
            
            result.Url = p66.Url;
            result.Description = p66.Description;
            result.ResourceType = p66.ResourceType;
            result.AccessControlEntries = funcMain61(p66.AccessControlEntries, result.AccessControlEntries);
            result.Id = p66.Id;
            result.CreatedBy = p66.CreatedBy;
            result.CreatedDate = p66.CreatedDate;
            result.ModifiedBy = p66.ModifiedBy;
            result.ModifiedDate = p66.ModifiedDate;
            result.IsDeleted = p66.IsDeleted;
            result.DeletedBy = p66.DeletedBy;
            result.DeletedDate = p66.DeletedDate;
            return result;
            
        }
        
        private static ICollection<AppAccessControlEntryReadModel> funcMain1(ICollection<AppAccessControlEntry> p2)
        {
            if (p2 == null)
            {
                return null;
            }
            ICollection<AppAccessControlEntryReadModel> result = new List<AppAccessControlEntryReadModel>(p2.Count);
            
            IEnumerator<AppAccessControlEntry> enumerator = p2.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppAccessControlEntry item = enumerator.Current;
                result.Add(funcMain2(item));
            }
            return result;
            
        }
        
        private static ICollection<AppAccessControlEntryReadModel> funcMain21(ICollection<AppAccessControlEntry> p24, ICollection<AppAccessControlEntryReadModel> p25)
        {
            if (p24 == null)
            {
                return null;
            }
            ICollection<AppAccessControlEntryReadModel> result = new List<AppAccessControlEntryReadModel>(p24.Count);
            
            IEnumerator<AppAccessControlEntry> enumerator = p24.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppAccessControlEntry item = enumerator.Current;
                result.Add(funcMain22(item));
            }
            return result;
            
        }
        
        private static ICollection<AppAccessControlEntryReadModel> funcMain41(ICollection<AppAccessControlEntry> p46)
        {
            if (p46 == null)
            {
                return null;
            }
            ICollection<AppAccessControlEntryReadModel> result = new List<AppAccessControlEntryReadModel>(p46.Count);
            
            IEnumerator<AppAccessControlEntry> enumerator = p46.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppAccessControlEntry item = enumerator.Current;
                result.Add(funcMain42(item));
            }
            return result;
            
        }
        
        private static ICollection<AppAccessControlEntryReadModel> funcMain61(ICollection<AppAccessControlEntry> p68, ICollection<AppAccessControlEntryReadModel> p69)
        {
            if (p68 == null)
            {
                return null;
            }
            ICollection<AppAccessControlEntryReadModel> result = new List<AppAccessControlEntryReadModel>(p68.Count);
            
            IEnumerator<AppAccessControlEntry> enumerator = p68.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppAccessControlEntry item = enumerator.Current;
                result.Add(funcMain62(item));
            }
            return result;
            
        }
        
        private static AppAccessControlEntryReadModel funcMain2(AppAccessControlEntry p3)
        {
            return p3 == null ? null : new AppAccessControlEntryReadModel()
            {
                ResourcePattern = p3.ResourcePattern,
                PermissionPattern = p3.PermissionPattern,
                FeatureId = p3.FeatureId,
                Feature = funcMain3(p3.Feature),
                AppRoles = funcMain5(p3.AppRoles),
                AppUsers = funcMain13(p3.AppUsers),
                AppResource = TypeAdapter<AppResource, AppResourceReadModel>.Map.Invoke(p3.AppResource),
                ResourceId = p3.ResourceId,
                Id = p3.Id,
                CreatedBy = p3.CreatedBy,
                CreatedDate = p3.CreatedDate,
                ModifiedBy = p3.ModifiedBy,
                ModifiedDate = p3.ModifiedDate,
                IsDeleted = p3.IsDeleted,
                DeletedBy = p3.DeletedBy,
                DeletedDate = p3.DeletedDate
            };
        }
        
        private static AppAccessControlEntryReadModel funcMain22(AppAccessControlEntry p26)
        {
            return p26 == null ? null : new AppAccessControlEntryReadModel()
            {
                ResourcePattern = p26.ResourcePattern,
                PermissionPattern = p26.PermissionPattern,
                FeatureId = p26.FeatureId,
                Feature = funcMain23(p26.Feature),
                AppRoles = funcMain25(p26.AppRoles),
                AppUsers = funcMain33(p26.AppUsers),
                AppResource = TypeAdapter<AppResource, AppResourceReadModel>.Map.Invoke(p26.AppResource),
                ResourceId = p26.ResourceId,
                Id = p26.Id,
                CreatedBy = p26.CreatedBy,
                CreatedDate = p26.CreatedDate,
                ModifiedBy = p26.ModifiedBy,
                ModifiedDate = p26.ModifiedDate,
                IsDeleted = p26.IsDeleted,
                DeletedBy = p26.DeletedBy,
                DeletedDate = p26.DeletedDate
            };
        }
        
        private static AppAccessControlEntryReadModel funcMain42(AppAccessControlEntry p47)
        {
            return p47 == null ? null : new AppAccessControlEntryReadModel()
            {
                ResourcePattern = p47.ResourcePattern,
                PermissionPattern = p47.PermissionPattern,
                FeatureId = p47.FeatureId,
                Feature = funcMain43(p47.Feature),
                AppRoles = funcMain45(p47.AppRoles),
                AppUsers = funcMain53(p47.AppUsers),
                AppResource = p47.AppResource == null ? null : new AppResourceReadModel()
                {
                    Url = p47.AppResource.Url,
                    Description = p47.AppResource.Description,
                    ResourceType = p47.AppResource.ResourceType,
                    AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p47.AppResource.AccessControlEntries),
                    Id = p47.AppResource.Id,
                    CreatedBy = p47.AppResource.CreatedBy,
                    CreatedDate = p47.AppResource.CreatedDate,
                    ModifiedBy = p47.AppResource.ModifiedBy,
                    ModifiedDate = p47.AppResource.ModifiedDate,
                    IsDeleted = p47.AppResource.IsDeleted,
                    DeletedBy = p47.AppResource.DeletedBy,
                    DeletedDate = p47.AppResource.DeletedDate
                },
                ResourceId = p47.ResourceId,
                Id = p47.Id,
                CreatedBy = p47.CreatedBy,
                CreatedDate = p47.CreatedDate,
                ModifiedBy = p47.ModifiedBy,
                ModifiedDate = p47.ModifiedDate,
                IsDeleted = p47.IsDeleted,
                DeletedBy = p47.DeletedBy,
                DeletedDate = p47.DeletedDate
            };
        }
        
        private static AppAccessControlEntryReadModel funcMain62(AppAccessControlEntry p70)
        {
            return p70 == null ? null : new AppAccessControlEntryReadModel()
            {
                ResourcePattern = p70.ResourcePattern,
                PermissionPattern = p70.PermissionPattern,
                FeatureId = p70.FeatureId,
                Feature = funcMain63(p70.Feature),
                AppRoles = funcMain65(p70.AppRoles),
                AppUsers = funcMain73(p70.AppUsers),
                AppResource = p70.AppResource == null ? null : new AppResourceReadModel()
                {
                    Url = p70.AppResource.Url,
                    Description = p70.AppResource.Description,
                    ResourceType = p70.AppResource.ResourceType,
                    AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p70.AppResource.AccessControlEntries),
                    Id = p70.AppResource.Id,
                    CreatedBy = p70.AppResource.CreatedBy,
                    CreatedDate = p70.AppResource.CreatedDate,
                    ModifiedBy = p70.AppResource.ModifiedBy,
                    ModifiedDate = p70.AppResource.ModifiedDate,
                    IsDeleted = p70.AppResource.IsDeleted,
                    DeletedBy = p70.AppResource.DeletedBy,
                    DeletedDate = p70.AppResource.DeletedDate
                },
                ResourceId = p70.ResourceId,
                Id = p70.Id,
                CreatedBy = p70.CreatedBy,
                CreatedDate = p70.CreatedDate,
                ModifiedBy = p70.ModifiedBy,
                ModifiedDate = p70.ModifiedDate,
                IsDeleted = p70.IsDeleted,
                DeletedBy = p70.DeletedBy,
                DeletedDate = p70.DeletedDate
            };
        }
        
        private static AppFeatureReadModel funcMain3(AppFeature p4)
        {
            return p4 == null ? null : new AppFeatureReadModel()
            {
                Name = p4.Name,
                Description = p4.Description,
                IsEnabled = p4.IsEnabled,
                Scope = p4.Scope,
                FeatureFlags = funcMain4(p4.FeatureFlags),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p4.AccessControlEntries),
                Id = p4.Id,
                CreatedBy = p4.CreatedBy,
                CreatedDate = p4.CreatedDate,
                ModifiedBy = p4.ModifiedBy,
                ModifiedDate = p4.ModifiedDate,
                IsDeleted = p4.IsDeleted,
                DeletedBy = p4.DeletedBy,
                DeletedDate = p4.DeletedDate
            };
        }
        
        private static ICollection<AppRoleReadModel> funcMain5(ICollection<AppRole> p6)
        {
            if (p6 == null)
            {
                return null;
            }
            ICollection<AppRoleReadModel> result = new List<AppRoleReadModel>(p6.Count);
            
            IEnumerator<AppRole> enumerator = p6.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRole item = enumerator.Current;
                result.Add(funcMain6(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserReadModel> funcMain13(ICollection<AppUser> p14)
        {
            if (p14 == null)
            {
                return null;
            }
            ICollection<AppUserReadModel> result = new List<AppUserReadModel>(p14.Count);
            
            IEnumerator<AppUser> enumerator = p14.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUser item = enumerator.Current;
                result.Add(funcMain14(item));
            }
            return result;
            
        }
        
        private static AppFeatureReadModel funcMain23(AppFeature p27)
        {
            return p27 == null ? null : new AppFeatureReadModel()
            {
                Name = p27.Name,
                Description = p27.Description,
                IsEnabled = p27.IsEnabled,
                Scope = p27.Scope,
                FeatureFlags = funcMain24(p27.FeatureFlags),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p27.AccessControlEntries),
                Id = p27.Id,
                CreatedBy = p27.CreatedBy,
                CreatedDate = p27.CreatedDate,
                ModifiedBy = p27.ModifiedBy,
                ModifiedDate = p27.ModifiedDate,
                IsDeleted = p27.IsDeleted,
                DeletedBy = p27.DeletedBy,
                DeletedDate = p27.DeletedDate
            };
        }
        
        private static ICollection<AppRoleReadModel> funcMain25(ICollection<AppRole> p29)
        {
            if (p29 == null)
            {
                return null;
            }
            ICollection<AppRoleReadModel> result = new List<AppRoleReadModel>(p29.Count);
            
            IEnumerator<AppRole> enumerator = p29.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRole item = enumerator.Current;
                result.Add(funcMain26(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserReadModel> funcMain33(ICollection<AppUser> p37)
        {
            if (p37 == null)
            {
                return null;
            }
            ICollection<AppUserReadModel> result = new List<AppUserReadModel>(p37.Count);
            
            IEnumerator<AppUser> enumerator = p37.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUser item = enumerator.Current;
                result.Add(funcMain34(item));
            }
            return result;
            
        }
        
        private static AppFeatureReadModel funcMain43(AppFeature p48)
        {
            return p48 == null ? null : new AppFeatureReadModel()
            {
                Name = p48.Name,
                Description = p48.Description,
                IsEnabled = p48.IsEnabled,
                Scope = p48.Scope,
                FeatureFlags = funcMain44(p48.FeatureFlags),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p48.AccessControlEntries),
                Id = p48.Id,
                CreatedBy = p48.CreatedBy,
                CreatedDate = p48.CreatedDate,
                ModifiedBy = p48.ModifiedBy,
                ModifiedDate = p48.ModifiedDate,
                IsDeleted = p48.IsDeleted,
                DeletedBy = p48.DeletedBy,
                DeletedDate = p48.DeletedDate
            };
        }
        
        private static ICollection<AppRoleReadModel> funcMain45(ICollection<AppRole> p50)
        {
            if (p50 == null)
            {
                return null;
            }
            ICollection<AppRoleReadModel> result = new List<AppRoleReadModel>(p50.Count);
            
            IEnumerator<AppRole> enumerator = p50.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRole item = enumerator.Current;
                result.Add(funcMain46(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserReadModel> funcMain53(ICollection<AppUser> p58)
        {
            if (p58 == null)
            {
                return null;
            }
            ICollection<AppUserReadModel> result = new List<AppUserReadModel>(p58.Count);
            
            IEnumerator<AppUser> enumerator = p58.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUser item = enumerator.Current;
                result.Add(funcMain54(item));
            }
            return result;
            
        }
        
        private static AppFeatureReadModel funcMain63(AppFeature p71)
        {
            return p71 == null ? null : new AppFeatureReadModel()
            {
                Name = p71.Name,
                Description = p71.Description,
                IsEnabled = p71.IsEnabled,
                Scope = p71.Scope,
                FeatureFlags = funcMain64(p71.FeatureFlags),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p71.AccessControlEntries),
                Id = p71.Id,
                CreatedBy = p71.CreatedBy,
                CreatedDate = p71.CreatedDate,
                ModifiedBy = p71.ModifiedBy,
                ModifiedDate = p71.ModifiedDate,
                IsDeleted = p71.IsDeleted,
                DeletedBy = p71.DeletedBy,
                DeletedDate = p71.DeletedDate
            };
        }
        
        private static ICollection<AppRoleReadModel> funcMain65(ICollection<AppRole> p73)
        {
            if (p73 == null)
            {
                return null;
            }
            ICollection<AppRoleReadModel> result = new List<AppRoleReadModel>(p73.Count);
            
            IEnumerator<AppRole> enumerator = p73.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRole item = enumerator.Current;
                result.Add(funcMain66(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserReadModel> funcMain73(ICollection<AppUser> p81)
        {
            if (p81 == null)
            {
                return null;
            }
            ICollection<AppUserReadModel> result = new List<AppUserReadModel>(p81.Count);
            
            IEnumerator<AppUser> enumerator = p81.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUser item = enumerator.Current;
                result.Add(funcMain74(item));
            }
            return result;
            
        }
        
        private static ICollection<AppFeatureFlagReadModel> funcMain4(ICollection<AppFeatureFlag> p5)
        {
            if (p5 == null)
            {
                return null;
            }
            ICollection<AppFeatureFlagReadModel> result = new List<AppFeatureFlagReadModel>(p5.Count);
            
            IEnumerator<AppFeatureFlag> enumerator = p5.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppFeatureFlag item = enumerator.Current;
                result.Add(item == null ? null : new AppFeatureFlagReadModel()
                {
                    FeatureId = item.FeatureId,
                    ScopeIdentifier = item.ScopeIdentifier,
                    IsEnabled = item.IsEnabled,
                    Feature = TypeAdapter<AppFeature, AppFeatureReadModel>.Map.Invoke(item.Feature),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static AppRoleReadModel funcMain6(AppRole p7)
        {
            return p7 == null ? null : new AppRoleReadModel()
            {
                CreatedBy = p7.CreatedBy,
                CreatedDate = p7.CreatedDate,
                ModifiedBy = p7.ModifiedBy,
                ModifiedDate = p7.ModifiedDate,
                IsDeleted = p7.IsDeleted,
                DeletedBy = p7.DeletedBy,
                DeletedDate = p7.DeletedDate,
                AppUserRoles = funcMain7(p7.AppUserRoles),
                AppRoleClaims = funcMain12(p7.AppRoleClaims),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p7.AccessControlEntries),
                Hash = p7.Hash,
                Id = p7.Id,
                Name = p7.Name,
                NormalizedName = p7.NormalizedName,
                ConcurrencyStamp = p7.ConcurrencyStamp
            };
        }
        
        private static AppUserReadModel funcMain14(AppUser p15)
        {
            return p15 == null ? null : new AppUserReadModel()
            {
                Hash = p15.Hash,
                FirstName = p15.FirstName,
                LastName = p15.LastName,
                Mobile = p15.Mobile,
                CountryCode = p15.CountryCode,
                TwoFactorMethod = p15.TwoFactorMethod,
                CreatedBy = p15.CreatedBy,
                CreatedDate = p15.CreatedDate,
                ModifiedBy = p15.ModifiedBy,
                ModifiedDate = p15.ModifiedDate,
                IsDeleted = p15.IsDeleted,
                DeletedBy = p15.DeletedBy,
                DeletedDate = p15.DeletedDate,
                MembershipType = p15.MembershipType,
                UserRoles = funcMain15(p15.UserRoles),
                UserTokens = funcMain19(p15.UserTokens),
                RefreshTokens = funcMain20(p15.RefreshTokens),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p15.AccessControlEntries),
                Id = p15.Id,
                UserName = p15.UserName,
                NormalizedUserName = p15.NormalizedUserName,
                Email = p15.Email,
                NormalizedEmail = p15.NormalizedEmail,
                EmailConfirmed = p15.EmailConfirmed,
                PasswordHash = p15.PasswordHash,
                SecurityStamp = p15.SecurityStamp,
                ConcurrencyStamp = p15.ConcurrencyStamp,
                PhoneNumber = p15.PhoneNumber,
                PhoneNumberConfirmed = p15.PhoneNumberConfirmed,
                TwoFactorEnabled = p15.TwoFactorEnabled,
                LockoutEnd = p15.LockoutEnd,
                LockoutEnabled = p15.LockoutEnabled,
                AccessFailedCount = p15.AccessFailedCount
            };
        }
        
        private static ICollection<AppFeatureFlagReadModel> funcMain24(ICollection<AppFeatureFlag> p28)
        {
            if (p28 == null)
            {
                return null;
            }
            ICollection<AppFeatureFlagReadModel> result = new List<AppFeatureFlagReadModel>(p28.Count);
            
            IEnumerator<AppFeatureFlag> enumerator = p28.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppFeatureFlag item = enumerator.Current;
                result.Add(item == null ? null : new AppFeatureFlagReadModel()
                {
                    FeatureId = item.FeatureId,
                    ScopeIdentifier = item.ScopeIdentifier,
                    IsEnabled = item.IsEnabled,
                    Feature = TypeAdapter<AppFeature, AppFeatureReadModel>.Map.Invoke(item.Feature),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static AppRoleReadModel funcMain26(AppRole p30)
        {
            return p30 == null ? null : new AppRoleReadModel()
            {
                CreatedBy = p30.CreatedBy,
                CreatedDate = p30.CreatedDate,
                ModifiedBy = p30.ModifiedBy,
                ModifiedDate = p30.ModifiedDate,
                IsDeleted = p30.IsDeleted,
                DeletedBy = p30.DeletedBy,
                DeletedDate = p30.DeletedDate,
                AppUserRoles = funcMain27(p30.AppUserRoles),
                AppRoleClaims = funcMain32(p30.AppRoleClaims),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p30.AccessControlEntries),
                Hash = p30.Hash,
                Id = p30.Id,
                Name = p30.Name,
                NormalizedName = p30.NormalizedName,
                ConcurrencyStamp = p30.ConcurrencyStamp
            };
        }
        
        private static AppUserReadModel funcMain34(AppUser p38)
        {
            return p38 == null ? null : new AppUserReadModel()
            {
                Hash = p38.Hash,
                FirstName = p38.FirstName,
                LastName = p38.LastName,
                Mobile = p38.Mobile,
                CountryCode = p38.CountryCode,
                TwoFactorMethod = p38.TwoFactorMethod,
                CreatedBy = p38.CreatedBy,
                CreatedDate = p38.CreatedDate,
                ModifiedBy = p38.ModifiedBy,
                ModifiedDate = p38.ModifiedDate,
                IsDeleted = p38.IsDeleted,
                DeletedBy = p38.DeletedBy,
                DeletedDate = p38.DeletedDate,
                MembershipType = p38.MembershipType,
                UserRoles = funcMain35(p38.UserRoles),
                UserTokens = funcMain39(p38.UserTokens),
                RefreshTokens = funcMain40(p38.RefreshTokens),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p38.AccessControlEntries),
                Id = p38.Id,
                UserName = p38.UserName,
                NormalizedUserName = p38.NormalizedUserName,
                Email = p38.Email,
                NormalizedEmail = p38.NormalizedEmail,
                EmailConfirmed = p38.EmailConfirmed,
                PasswordHash = p38.PasswordHash,
                SecurityStamp = p38.SecurityStamp,
                ConcurrencyStamp = p38.ConcurrencyStamp,
                PhoneNumber = p38.PhoneNumber,
                PhoneNumberConfirmed = p38.PhoneNumberConfirmed,
                TwoFactorEnabled = p38.TwoFactorEnabled,
                LockoutEnd = p38.LockoutEnd,
                LockoutEnabled = p38.LockoutEnabled,
                AccessFailedCount = p38.AccessFailedCount
            };
        }
        
        private static ICollection<AppFeatureFlagReadModel> funcMain44(ICollection<AppFeatureFlag> p49)
        {
            if (p49 == null)
            {
                return null;
            }
            ICollection<AppFeatureFlagReadModel> result = new List<AppFeatureFlagReadModel>(p49.Count);
            
            IEnumerator<AppFeatureFlag> enumerator = p49.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppFeatureFlag item = enumerator.Current;
                result.Add(item == null ? null : new AppFeatureFlagReadModel()
                {
                    FeatureId = item.FeatureId,
                    ScopeIdentifier = item.ScopeIdentifier,
                    IsEnabled = item.IsEnabled,
                    Feature = TypeAdapter<AppFeature, AppFeatureReadModel>.Map.Invoke(item.Feature),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static AppRoleReadModel funcMain46(AppRole p51)
        {
            return p51 == null ? null : new AppRoleReadModel()
            {
                CreatedBy = p51.CreatedBy,
                CreatedDate = p51.CreatedDate,
                ModifiedBy = p51.ModifiedBy,
                ModifiedDate = p51.ModifiedDate,
                IsDeleted = p51.IsDeleted,
                DeletedBy = p51.DeletedBy,
                DeletedDate = p51.DeletedDate,
                AppUserRoles = funcMain47(p51.AppUserRoles),
                AppRoleClaims = funcMain52(p51.AppRoleClaims),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p51.AccessControlEntries),
                Hash = p51.Hash,
                Id = p51.Id,
                Name = p51.Name,
                NormalizedName = p51.NormalizedName,
                ConcurrencyStamp = p51.ConcurrencyStamp
            };
        }
        
        private static AppUserReadModel funcMain54(AppUser p59)
        {
            return p59 == null ? null : new AppUserReadModel()
            {
                Hash = p59.Hash,
                FirstName = p59.FirstName,
                LastName = p59.LastName,
                Mobile = p59.Mobile,
                CountryCode = p59.CountryCode,
                TwoFactorMethod = p59.TwoFactorMethod,
                CreatedBy = p59.CreatedBy,
                CreatedDate = p59.CreatedDate,
                ModifiedBy = p59.ModifiedBy,
                ModifiedDate = p59.ModifiedDate,
                IsDeleted = p59.IsDeleted,
                DeletedBy = p59.DeletedBy,
                DeletedDate = p59.DeletedDate,
                MembershipType = p59.MembershipType,
                UserRoles = funcMain55(p59.UserRoles),
                UserTokens = funcMain59(p59.UserTokens),
                RefreshTokens = funcMain60(p59.RefreshTokens),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p59.AccessControlEntries),
                Id = p59.Id,
                UserName = p59.UserName,
                NormalizedUserName = p59.NormalizedUserName,
                Email = p59.Email,
                NormalizedEmail = p59.NormalizedEmail,
                EmailConfirmed = p59.EmailConfirmed,
                PasswordHash = p59.PasswordHash,
                SecurityStamp = p59.SecurityStamp,
                ConcurrencyStamp = p59.ConcurrencyStamp,
                PhoneNumber = p59.PhoneNumber,
                PhoneNumberConfirmed = p59.PhoneNumberConfirmed,
                TwoFactorEnabled = p59.TwoFactorEnabled,
                LockoutEnd = p59.LockoutEnd,
                LockoutEnabled = p59.LockoutEnabled,
                AccessFailedCount = p59.AccessFailedCount
            };
        }
        
        private static ICollection<AppFeatureFlagReadModel> funcMain64(ICollection<AppFeatureFlag> p72)
        {
            if (p72 == null)
            {
                return null;
            }
            ICollection<AppFeatureFlagReadModel> result = new List<AppFeatureFlagReadModel>(p72.Count);
            
            IEnumerator<AppFeatureFlag> enumerator = p72.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppFeatureFlag item = enumerator.Current;
                result.Add(item == null ? null : new AppFeatureFlagReadModel()
                {
                    FeatureId = item.FeatureId,
                    ScopeIdentifier = item.ScopeIdentifier,
                    IsEnabled = item.IsEnabled,
                    Feature = TypeAdapter<AppFeature, AppFeatureReadModel>.Map.Invoke(item.Feature),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static AppRoleReadModel funcMain66(AppRole p74)
        {
            return p74 == null ? null : new AppRoleReadModel()
            {
                CreatedBy = p74.CreatedBy,
                CreatedDate = p74.CreatedDate,
                ModifiedBy = p74.ModifiedBy,
                ModifiedDate = p74.ModifiedDate,
                IsDeleted = p74.IsDeleted,
                DeletedBy = p74.DeletedBy,
                DeletedDate = p74.DeletedDate,
                AppUserRoles = funcMain67(p74.AppUserRoles),
                AppRoleClaims = funcMain72(p74.AppRoleClaims),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p74.AccessControlEntries),
                Hash = p74.Hash,
                Id = p74.Id,
                Name = p74.Name,
                NormalizedName = p74.NormalizedName,
                ConcurrencyStamp = p74.ConcurrencyStamp
            };
        }
        
        private static AppUserReadModel funcMain74(AppUser p82)
        {
            return p82 == null ? null : new AppUserReadModel()
            {
                Hash = p82.Hash,
                FirstName = p82.FirstName,
                LastName = p82.LastName,
                Mobile = p82.Mobile,
                CountryCode = p82.CountryCode,
                TwoFactorMethod = p82.TwoFactorMethod,
                CreatedBy = p82.CreatedBy,
                CreatedDate = p82.CreatedDate,
                ModifiedBy = p82.ModifiedBy,
                ModifiedDate = p82.ModifiedDate,
                IsDeleted = p82.IsDeleted,
                DeletedBy = p82.DeletedBy,
                DeletedDate = p82.DeletedDate,
                MembershipType = p82.MembershipType,
                UserRoles = funcMain75(p82.UserRoles),
                UserTokens = funcMain79(p82.UserTokens),
                RefreshTokens = funcMain80(p82.RefreshTokens),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p82.AccessControlEntries),
                Id = p82.Id,
                UserName = p82.UserName,
                NormalizedUserName = p82.NormalizedUserName,
                Email = p82.Email,
                NormalizedEmail = p82.NormalizedEmail,
                EmailConfirmed = p82.EmailConfirmed,
                PasswordHash = p82.PasswordHash,
                SecurityStamp = p82.SecurityStamp,
                ConcurrencyStamp = p82.ConcurrencyStamp,
                PhoneNumber = p82.PhoneNumber,
                PhoneNumberConfirmed = p82.PhoneNumberConfirmed,
                TwoFactorEnabled = p82.TwoFactorEnabled,
                LockoutEnd = p82.LockoutEnd,
                LockoutEnabled = p82.LockoutEnabled,
                AccessFailedCount = p82.AccessFailedCount
            };
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain7(ICollection<AppUserRole> p8)
        {
            if (p8 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p8.Count);
            
            IEnumerator<AppUserRole> enumerator = p8.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(funcMain8(item));
            }
            return result;
            
        }
        
        private static ICollection<AppRoleClaimReadModel> funcMain12(ICollection<AppRoleClaim> p13)
        {
            if (p13 == null)
            {
                return null;
            }
            ICollection<AppRoleClaimReadModel> result = new List<AppRoleClaimReadModel>(p13.Count);
            
            IEnumerator<AppRoleClaim> enumerator = p13.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRoleClaim item = enumerator.Current;
                result.Add(item == null ? null : new AppRoleClaimReadModel()
                {
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Id = item.Id,
                    RoleId = item.RoleId,
                    ClaimType = item.ClaimType,
                    ClaimValue = item.ClaimValue
                });
            }
            return result;
            
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain15(ICollection<AppUserRole> p16)
        {
            if (p16 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p16.Count);
            
            IEnumerator<AppUserRole> enumerator = p16.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(funcMain16(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserTokenReadModel> funcMain19(ICollection<AppUserToken> p20)
        {
            if (p20 == null)
            {
                return null;
            }
            ICollection<AppUserTokenReadModel> result = new List<AppUserTokenReadModel>(p20.Count);
            
            IEnumerator<AppUserToken> enumerator = p20.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserToken item = enumerator.Current;
                result.Add(item == null ? null : new AppUserTokenReadModel()
                {
                    Token = item.Token,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    LoginProvider = item.LoginProvider,
                    Name = item.Name,
                    Value = item.Value
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRefreshTokenReadModel> funcMain20(ICollection<AppRefreshToken> p21)
        {
            if (p21 == null)
            {
                return null;
            }
            ICollection<AppRefreshTokenReadModel> result = new List<AppRefreshTokenReadModel>(p21.Count);
            
            IEnumerator<AppRefreshToken> enumerator = p21.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRefreshToken item = enumerator.Current;
                result.Add(item == null ? null : new AppRefreshTokenReadModel()
                {
                    UserId = item.UserId,
                    Token = item.Token,
                    JwtId = item.JwtId,
                    IsUsed = item.IsUsed,
                    IsRevoked = item.IsRevoked,
                    ExpiryDate = item.ExpiryDate,
                    Hash = item.Hash,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain27(ICollection<AppUserRole> p31)
        {
            if (p31 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p31.Count);
            
            IEnumerator<AppUserRole> enumerator = p31.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(funcMain28(item));
            }
            return result;
            
        }
        
        private static ICollection<AppRoleClaimReadModel> funcMain32(ICollection<AppRoleClaim> p36)
        {
            if (p36 == null)
            {
                return null;
            }
            ICollection<AppRoleClaimReadModel> result = new List<AppRoleClaimReadModel>(p36.Count);
            
            IEnumerator<AppRoleClaim> enumerator = p36.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRoleClaim item = enumerator.Current;
                result.Add(item == null ? null : new AppRoleClaimReadModel()
                {
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Id = item.Id,
                    RoleId = item.RoleId,
                    ClaimType = item.ClaimType,
                    ClaimValue = item.ClaimValue
                });
            }
            return result;
            
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain35(ICollection<AppUserRole> p39)
        {
            if (p39 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p39.Count);
            
            IEnumerator<AppUserRole> enumerator = p39.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(funcMain36(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserTokenReadModel> funcMain39(ICollection<AppUserToken> p43)
        {
            if (p43 == null)
            {
                return null;
            }
            ICollection<AppUserTokenReadModel> result = new List<AppUserTokenReadModel>(p43.Count);
            
            IEnumerator<AppUserToken> enumerator = p43.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserToken item = enumerator.Current;
                result.Add(item == null ? null : new AppUserTokenReadModel()
                {
                    Token = item.Token,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    LoginProvider = item.LoginProvider,
                    Name = item.Name,
                    Value = item.Value
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRefreshTokenReadModel> funcMain40(ICollection<AppRefreshToken> p44)
        {
            if (p44 == null)
            {
                return null;
            }
            ICollection<AppRefreshTokenReadModel> result = new List<AppRefreshTokenReadModel>(p44.Count);
            
            IEnumerator<AppRefreshToken> enumerator = p44.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRefreshToken item = enumerator.Current;
                result.Add(item == null ? null : new AppRefreshTokenReadModel()
                {
                    UserId = item.UserId,
                    Token = item.Token,
                    JwtId = item.JwtId,
                    IsUsed = item.IsUsed,
                    IsRevoked = item.IsRevoked,
                    ExpiryDate = item.ExpiryDate,
                    Hash = item.Hash,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain47(ICollection<AppUserRole> p52)
        {
            if (p52 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p52.Count);
            
            IEnumerator<AppUserRole> enumerator = p52.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(funcMain48(item));
            }
            return result;
            
        }
        
        private static ICollection<AppRoleClaimReadModel> funcMain52(ICollection<AppRoleClaim> p57)
        {
            if (p57 == null)
            {
                return null;
            }
            ICollection<AppRoleClaimReadModel> result = new List<AppRoleClaimReadModel>(p57.Count);
            
            IEnumerator<AppRoleClaim> enumerator = p57.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRoleClaim item = enumerator.Current;
                result.Add(item == null ? null : new AppRoleClaimReadModel()
                {
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Id = item.Id,
                    RoleId = item.RoleId,
                    ClaimType = item.ClaimType,
                    ClaimValue = item.ClaimValue
                });
            }
            return result;
            
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain55(ICollection<AppUserRole> p60)
        {
            if (p60 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p60.Count);
            
            IEnumerator<AppUserRole> enumerator = p60.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(funcMain56(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserTokenReadModel> funcMain59(ICollection<AppUserToken> p64)
        {
            if (p64 == null)
            {
                return null;
            }
            ICollection<AppUserTokenReadModel> result = new List<AppUserTokenReadModel>(p64.Count);
            
            IEnumerator<AppUserToken> enumerator = p64.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserToken item = enumerator.Current;
                result.Add(item == null ? null : new AppUserTokenReadModel()
                {
                    Token = item.Token,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    LoginProvider = item.LoginProvider,
                    Name = item.Name,
                    Value = item.Value
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRefreshTokenReadModel> funcMain60(ICollection<AppRefreshToken> p65)
        {
            if (p65 == null)
            {
                return null;
            }
            ICollection<AppRefreshTokenReadModel> result = new List<AppRefreshTokenReadModel>(p65.Count);
            
            IEnumerator<AppRefreshToken> enumerator = p65.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRefreshToken item = enumerator.Current;
                result.Add(item == null ? null : new AppRefreshTokenReadModel()
                {
                    UserId = item.UserId,
                    Token = item.Token,
                    JwtId = item.JwtId,
                    IsUsed = item.IsUsed,
                    IsRevoked = item.IsRevoked,
                    ExpiryDate = item.ExpiryDate,
                    Hash = item.Hash,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain67(ICollection<AppUserRole> p75)
        {
            if (p75 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p75.Count);
            
            IEnumerator<AppUserRole> enumerator = p75.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(funcMain68(item));
            }
            return result;
            
        }
        
        private static ICollection<AppRoleClaimReadModel> funcMain72(ICollection<AppRoleClaim> p80)
        {
            if (p80 == null)
            {
                return null;
            }
            ICollection<AppRoleClaimReadModel> result = new List<AppRoleClaimReadModel>(p80.Count);
            
            IEnumerator<AppRoleClaim> enumerator = p80.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRoleClaim item = enumerator.Current;
                result.Add(item == null ? null : new AppRoleClaimReadModel()
                {
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Id = item.Id,
                    RoleId = item.RoleId,
                    ClaimType = item.ClaimType,
                    ClaimValue = item.ClaimValue
                });
            }
            return result;
            
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain75(ICollection<AppUserRole> p83)
        {
            if (p83 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p83.Count);
            
            IEnumerator<AppUserRole> enumerator = p83.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(funcMain76(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserTokenReadModel> funcMain79(ICollection<AppUserToken> p87)
        {
            if (p87 == null)
            {
                return null;
            }
            ICollection<AppUserTokenReadModel> result = new List<AppUserTokenReadModel>(p87.Count);
            
            IEnumerator<AppUserToken> enumerator = p87.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserToken item = enumerator.Current;
                result.Add(item == null ? null : new AppUserTokenReadModel()
                {
                    Token = item.Token,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    LoginProvider = item.LoginProvider,
                    Name = item.Name,
                    Value = item.Value
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRefreshTokenReadModel> funcMain80(ICollection<AppRefreshToken> p88)
        {
            if (p88 == null)
            {
                return null;
            }
            ICollection<AppRefreshTokenReadModel> result = new List<AppRefreshTokenReadModel>(p88.Count);
            
            IEnumerator<AppRefreshToken> enumerator = p88.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRefreshToken item = enumerator.Current;
                result.Add(item == null ? null : new AppRefreshTokenReadModel()
                {
                    UserId = item.UserId,
                    Token = item.Token,
                    JwtId = item.JwtId,
                    IsUsed = item.IsUsed,
                    IsRevoked = item.IsRevoked,
                    ExpiryDate = item.ExpiryDate,
                    Hash = item.Hash,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static AppUserRoleReadModel funcMain8(AppUserRole p9)
        {
            return p9 == null ? null : new AppUserRoleReadModel()
            {
                AppUser = funcMain9(p9.AppUser),
                AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(p9.AppRole),
                Hash = p9.Hash,
                CreatedBy = p9.CreatedBy,
                CreatedDate = p9.CreatedDate,
                ModifiedBy = p9.ModifiedBy,
                ModifiedDate = p9.ModifiedDate,
                IsDeleted = p9.IsDeleted,
                DeletedBy = p9.DeletedBy,
                DeletedDate = p9.DeletedDate,
                UserId = p9.UserId,
                RoleId = p9.RoleId
            };
        }
        
        private static AppUserRoleReadModel funcMain16(AppUserRole p17)
        {
            return p17 == null ? null : new AppUserRoleReadModel()
            {
                AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(p17.AppUser),
                AppRole = funcMain17(p17.AppRole),
                Hash = p17.Hash,
                CreatedBy = p17.CreatedBy,
                CreatedDate = p17.CreatedDate,
                ModifiedBy = p17.ModifiedBy,
                ModifiedDate = p17.ModifiedDate,
                IsDeleted = p17.IsDeleted,
                DeletedBy = p17.DeletedBy,
                DeletedDate = p17.DeletedDate,
                UserId = p17.UserId,
                RoleId = p17.RoleId
            };
        }
        
        private static AppUserRoleReadModel funcMain28(AppUserRole p32)
        {
            return p32 == null ? null : new AppUserRoleReadModel()
            {
                AppUser = funcMain29(p32.AppUser),
                AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(p32.AppRole),
                Hash = p32.Hash,
                CreatedBy = p32.CreatedBy,
                CreatedDate = p32.CreatedDate,
                ModifiedBy = p32.ModifiedBy,
                ModifiedDate = p32.ModifiedDate,
                IsDeleted = p32.IsDeleted,
                DeletedBy = p32.DeletedBy,
                DeletedDate = p32.DeletedDate,
                UserId = p32.UserId,
                RoleId = p32.RoleId
            };
        }
        
        private static AppUserRoleReadModel funcMain36(AppUserRole p40)
        {
            return p40 == null ? null : new AppUserRoleReadModel()
            {
                AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(p40.AppUser),
                AppRole = funcMain37(p40.AppRole),
                Hash = p40.Hash,
                CreatedBy = p40.CreatedBy,
                CreatedDate = p40.CreatedDate,
                ModifiedBy = p40.ModifiedBy,
                ModifiedDate = p40.ModifiedDate,
                IsDeleted = p40.IsDeleted,
                DeletedBy = p40.DeletedBy,
                DeletedDate = p40.DeletedDate,
                UserId = p40.UserId,
                RoleId = p40.RoleId
            };
        }
        
        private static AppUserRoleReadModel funcMain48(AppUserRole p53)
        {
            return p53 == null ? null : new AppUserRoleReadModel()
            {
                AppUser = funcMain49(p53.AppUser),
                AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(p53.AppRole),
                Hash = p53.Hash,
                CreatedBy = p53.CreatedBy,
                CreatedDate = p53.CreatedDate,
                ModifiedBy = p53.ModifiedBy,
                ModifiedDate = p53.ModifiedDate,
                IsDeleted = p53.IsDeleted,
                DeletedBy = p53.DeletedBy,
                DeletedDate = p53.DeletedDate,
                UserId = p53.UserId,
                RoleId = p53.RoleId
            };
        }
        
        private static AppUserRoleReadModel funcMain56(AppUserRole p61)
        {
            return p61 == null ? null : new AppUserRoleReadModel()
            {
                AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(p61.AppUser),
                AppRole = funcMain57(p61.AppRole),
                Hash = p61.Hash,
                CreatedBy = p61.CreatedBy,
                CreatedDate = p61.CreatedDate,
                ModifiedBy = p61.ModifiedBy,
                ModifiedDate = p61.ModifiedDate,
                IsDeleted = p61.IsDeleted,
                DeletedBy = p61.DeletedBy,
                DeletedDate = p61.DeletedDate,
                UserId = p61.UserId,
                RoleId = p61.RoleId
            };
        }
        
        private static AppUserRoleReadModel funcMain68(AppUserRole p76)
        {
            return p76 == null ? null : new AppUserRoleReadModel()
            {
                AppUser = funcMain69(p76.AppUser),
                AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(p76.AppRole),
                Hash = p76.Hash,
                CreatedBy = p76.CreatedBy,
                CreatedDate = p76.CreatedDate,
                ModifiedBy = p76.ModifiedBy,
                ModifiedDate = p76.ModifiedDate,
                IsDeleted = p76.IsDeleted,
                DeletedBy = p76.DeletedBy,
                DeletedDate = p76.DeletedDate,
                UserId = p76.UserId,
                RoleId = p76.RoleId
            };
        }
        
        private static AppUserRoleReadModel funcMain76(AppUserRole p84)
        {
            return p84 == null ? null : new AppUserRoleReadModel()
            {
                AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(p84.AppUser),
                AppRole = funcMain77(p84.AppRole),
                Hash = p84.Hash,
                CreatedBy = p84.CreatedBy,
                CreatedDate = p84.CreatedDate,
                ModifiedBy = p84.ModifiedBy,
                ModifiedDate = p84.ModifiedDate,
                IsDeleted = p84.IsDeleted,
                DeletedBy = p84.DeletedBy,
                DeletedDate = p84.DeletedDate,
                UserId = p84.UserId,
                RoleId = p84.RoleId
            };
        }
        
        private static AppUserReadModel funcMain9(AppUser p10)
        {
            return p10 == null ? null : new AppUserReadModel()
            {
                Hash = p10.Hash,
                FirstName = p10.FirstName,
                LastName = p10.LastName,
                Mobile = p10.Mobile,
                CountryCode = p10.CountryCode,
                TwoFactorMethod = p10.TwoFactorMethod,
                CreatedBy = p10.CreatedBy,
                CreatedDate = p10.CreatedDate,
                ModifiedBy = p10.ModifiedBy,
                ModifiedDate = p10.ModifiedDate,
                IsDeleted = p10.IsDeleted,
                DeletedBy = p10.DeletedBy,
                DeletedDate = p10.DeletedDate,
                MembershipType = p10.MembershipType,
                UserRoles = TypeAdapter<ICollection<AppUserRole>, ICollection<AppUserRoleReadModel>>.Map.Invoke(p10.UserRoles),
                UserTokens = funcMain10(p10.UserTokens),
                RefreshTokens = funcMain11(p10.RefreshTokens),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p10.AccessControlEntries),
                Id = p10.Id,
                UserName = p10.UserName,
                NormalizedUserName = p10.NormalizedUserName,
                Email = p10.Email,
                NormalizedEmail = p10.NormalizedEmail,
                EmailConfirmed = p10.EmailConfirmed,
                PasswordHash = p10.PasswordHash,
                SecurityStamp = p10.SecurityStamp,
                ConcurrencyStamp = p10.ConcurrencyStamp,
                PhoneNumber = p10.PhoneNumber,
                PhoneNumberConfirmed = p10.PhoneNumberConfirmed,
                TwoFactorEnabled = p10.TwoFactorEnabled,
                LockoutEnd = p10.LockoutEnd,
                LockoutEnabled = p10.LockoutEnabled,
                AccessFailedCount = p10.AccessFailedCount
            };
        }
        
        private static AppRoleReadModel funcMain17(AppRole p18)
        {
            return p18 == null ? null : new AppRoleReadModel()
            {
                CreatedBy = p18.CreatedBy,
                CreatedDate = p18.CreatedDate,
                ModifiedBy = p18.ModifiedBy,
                ModifiedDate = p18.ModifiedDate,
                IsDeleted = p18.IsDeleted,
                DeletedBy = p18.DeletedBy,
                DeletedDate = p18.DeletedDate,
                AppUserRoles = TypeAdapter<ICollection<AppUserRole>, ICollection<AppUserRoleReadModel>>.Map.Invoke(p18.AppUserRoles),
                AppRoleClaims = funcMain18(p18.AppRoleClaims),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p18.AccessControlEntries),
                Hash = p18.Hash,
                Id = p18.Id,
                Name = p18.Name,
                NormalizedName = p18.NormalizedName,
                ConcurrencyStamp = p18.ConcurrencyStamp
            };
        }
        
        private static AppUserReadModel funcMain29(AppUser p33)
        {
            return p33 == null ? null : new AppUserReadModel()
            {
                Hash = p33.Hash,
                FirstName = p33.FirstName,
                LastName = p33.LastName,
                Mobile = p33.Mobile,
                CountryCode = p33.CountryCode,
                TwoFactorMethod = p33.TwoFactorMethod,
                CreatedBy = p33.CreatedBy,
                CreatedDate = p33.CreatedDate,
                ModifiedBy = p33.ModifiedBy,
                ModifiedDate = p33.ModifiedDate,
                IsDeleted = p33.IsDeleted,
                DeletedBy = p33.DeletedBy,
                DeletedDate = p33.DeletedDate,
                MembershipType = p33.MembershipType,
                UserRoles = TypeAdapter<ICollection<AppUserRole>, ICollection<AppUserRoleReadModel>>.Map.Invoke(p33.UserRoles),
                UserTokens = funcMain30(p33.UserTokens),
                RefreshTokens = funcMain31(p33.RefreshTokens),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p33.AccessControlEntries),
                Id = p33.Id,
                UserName = p33.UserName,
                NormalizedUserName = p33.NormalizedUserName,
                Email = p33.Email,
                NormalizedEmail = p33.NormalizedEmail,
                EmailConfirmed = p33.EmailConfirmed,
                PasswordHash = p33.PasswordHash,
                SecurityStamp = p33.SecurityStamp,
                ConcurrencyStamp = p33.ConcurrencyStamp,
                PhoneNumber = p33.PhoneNumber,
                PhoneNumberConfirmed = p33.PhoneNumberConfirmed,
                TwoFactorEnabled = p33.TwoFactorEnabled,
                LockoutEnd = p33.LockoutEnd,
                LockoutEnabled = p33.LockoutEnabled,
                AccessFailedCount = p33.AccessFailedCount
            };
        }
        
        private static AppRoleReadModel funcMain37(AppRole p41)
        {
            return p41 == null ? null : new AppRoleReadModel()
            {
                CreatedBy = p41.CreatedBy,
                CreatedDate = p41.CreatedDate,
                ModifiedBy = p41.ModifiedBy,
                ModifiedDate = p41.ModifiedDate,
                IsDeleted = p41.IsDeleted,
                DeletedBy = p41.DeletedBy,
                DeletedDate = p41.DeletedDate,
                AppUserRoles = TypeAdapter<ICollection<AppUserRole>, ICollection<AppUserRoleReadModel>>.Map.Invoke(p41.AppUserRoles),
                AppRoleClaims = funcMain38(p41.AppRoleClaims),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p41.AccessControlEntries),
                Hash = p41.Hash,
                Id = p41.Id,
                Name = p41.Name,
                NormalizedName = p41.NormalizedName,
                ConcurrencyStamp = p41.ConcurrencyStamp
            };
        }
        
        private static AppUserReadModel funcMain49(AppUser p54)
        {
            return p54 == null ? null : new AppUserReadModel()
            {
                Hash = p54.Hash,
                FirstName = p54.FirstName,
                LastName = p54.LastName,
                Mobile = p54.Mobile,
                CountryCode = p54.CountryCode,
                TwoFactorMethod = p54.TwoFactorMethod,
                CreatedBy = p54.CreatedBy,
                CreatedDate = p54.CreatedDate,
                ModifiedBy = p54.ModifiedBy,
                ModifiedDate = p54.ModifiedDate,
                IsDeleted = p54.IsDeleted,
                DeletedBy = p54.DeletedBy,
                DeletedDate = p54.DeletedDate,
                MembershipType = p54.MembershipType,
                UserRoles = TypeAdapter<ICollection<AppUserRole>, ICollection<AppUserRoleReadModel>>.Map.Invoke(p54.UserRoles),
                UserTokens = funcMain50(p54.UserTokens),
                RefreshTokens = funcMain51(p54.RefreshTokens),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p54.AccessControlEntries),
                Id = p54.Id,
                UserName = p54.UserName,
                NormalizedUserName = p54.NormalizedUserName,
                Email = p54.Email,
                NormalizedEmail = p54.NormalizedEmail,
                EmailConfirmed = p54.EmailConfirmed,
                PasswordHash = p54.PasswordHash,
                SecurityStamp = p54.SecurityStamp,
                ConcurrencyStamp = p54.ConcurrencyStamp,
                PhoneNumber = p54.PhoneNumber,
                PhoneNumberConfirmed = p54.PhoneNumberConfirmed,
                TwoFactorEnabled = p54.TwoFactorEnabled,
                LockoutEnd = p54.LockoutEnd,
                LockoutEnabled = p54.LockoutEnabled,
                AccessFailedCount = p54.AccessFailedCount
            };
        }
        
        private static AppRoleReadModel funcMain57(AppRole p62)
        {
            return p62 == null ? null : new AppRoleReadModel()
            {
                CreatedBy = p62.CreatedBy,
                CreatedDate = p62.CreatedDate,
                ModifiedBy = p62.ModifiedBy,
                ModifiedDate = p62.ModifiedDate,
                IsDeleted = p62.IsDeleted,
                DeletedBy = p62.DeletedBy,
                DeletedDate = p62.DeletedDate,
                AppUserRoles = TypeAdapter<ICollection<AppUserRole>, ICollection<AppUserRoleReadModel>>.Map.Invoke(p62.AppUserRoles),
                AppRoleClaims = funcMain58(p62.AppRoleClaims),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p62.AccessControlEntries),
                Hash = p62.Hash,
                Id = p62.Id,
                Name = p62.Name,
                NormalizedName = p62.NormalizedName,
                ConcurrencyStamp = p62.ConcurrencyStamp
            };
        }
        
        private static AppUserReadModel funcMain69(AppUser p77)
        {
            return p77 == null ? null : new AppUserReadModel()
            {
                Hash = p77.Hash,
                FirstName = p77.FirstName,
                LastName = p77.LastName,
                Mobile = p77.Mobile,
                CountryCode = p77.CountryCode,
                TwoFactorMethod = p77.TwoFactorMethod,
                CreatedBy = p77.CreatedBy,
                CreatedDate = p77.CreatedDate,
                ModifiedBy = p77.ModifiedBy,
                ModifiedDate = p77.ModifiedDate,
                IsDeleted = p77.IsDeleted,
                DeletedBy = p77.DeletedBy,
                DeletedDate = p77.DeletedDate,
                MembershipType = p77.MembershipType,
                UserRoles = TypeAdapter<ICollection<AppUserRole>, ICollection<AppUserRoleReadModel>>.Map.Invoke(p77.UserRoles),
                UserTokens = funcMain70(p77.UserTokens),
                RefreshTokens = funcMain71(p77.RefreshTokens),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p77.AccessControlEntries),
                Id = p77.Id,
                UserName = p77.UserName,
                NormalizedUserName = p77.NormalizedUserName,
                Email = p77.Email,
                NormalizedEmail = p77.NormalizedEmail,
                EmailConfirmed = p77.EmailConfirmed,
                PasswordHash = p77.PasswordHash,
                SecurityStamp = p77.SecurityStamp,
                ConcurrencyStamp = p77.ConcurrencyStamp,
                PhoneNumber = p77.PhoneNumber,
                PhoneNumberConfirmed = p77.PhoneNumberConfirmed,
                TwoFactorEnabled = p77.TwoFactorEnabled,
                LockoutEnd = p77.LockoutEnd,
                LockoutEnabled = p77.LockoutEnabled,
                AccessFailedCount = p77.AccessFailedCount
            };
        }
        
        private static AppRoleReadModel funcMain77(AppRole p85)
        {
            return p85 == null ? null : new AppRoleReadModel()
            {
                CreatedBy = p85.CreatedBy,
                CreatedDate = p85.CreatedDate,
                ModifiedBy = p85.ModifiedBy,
                ModifiedDate = p85.ModifiedDate,
                IsDeleted = p85.IsDeleted,
                DeletedBy = p85.DeletedBy,
                DeletedDate = p85.DeletedDate,
                AppUserRoles = TypeAdapter<ICollection<AppUserRole>, ICollection<AppUserRoleReadModel>>.Map.Invoke(p85.AppUserRoles),
                AppRoleClaims = funcMain78(p85.AppRoleClaims),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p85.AccessControlEntries),
                Hash = p85.Hash,
                Id = p85.Id,
                Name = p85.Name,
                NormalizedName = p85.NormalizedName,
                ConcurrencyStamp = p85.ConcurrencyStamp
            };
        }
        
        private static ICollection<AppUserTokenReadModel> funcMain10(ICollection<AppUserToken> p11)
        {
            if (p11 == null)
            {
                return null;
            }
            ICollection<AppUserTokenReadModel> result = new List<AppUserTokenReadModel>(p11.Count);
            
            IEnumerator<AppUserToken> enumerator = p11.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserToken item = enumerator.Current;
                result.Add(item == null ? null : new AppUserTokenReadModel()
                {
                    Token = item.Token,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    LoginProvider = item.LoginProvider,
                    Name = item.Name,
                    Value = item.Value
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRefreshTokenReadModel> funcMain11(ICollection<AppRefreshToken> p12)
        {
            if (p12 == null)
            {
                return null;
            }
            ICollection<AppRefreshTokenReadModel> result = new List<AppRefreshTokenReadModel>(p12.Count);
            
            IEnumerator<AppRefreshToken> enumerator = p12.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRefreshToken item = enumerator.Current;
                result.Add(item == null ? null : new AppRefreshTokenReadModel()
                {
                    UserId = item.UserId,
                    Token = item.Token,
                    JwtId = item.JwtId,
                    IsUsed = item.IsUsed,
                    IsRevoked = item.IsRevoked,
                    ExpiryDate = item.ExpiryDate,
                    Hash = item.Hash,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRoleClaimReadModel> funcMain18(ICollection<AppRoleClaim> p19)
        {
            if (p19 == null)
            {
                return null;
            }
            ICollection<AppRoleClaimReadModel> result = new List<AppRoleClaimReadModel>(p19.Count);
            
            IEnumerator<AppRoleClaim> enumerator = p19.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRoleClaim item = enumerator.Current;
                result.Add(item == null ? null : new AppRoleClaimReadModel()
                {
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Id = item.Id,
                    RoleId = item.RoleId,
                    ClaimType = item.ClaimType,
                    ClaimValue = item.ClaimValue
                });
            }
            return result;
            
        }
        
        private static ICollection<AppUserTokenReadModel> funcMain30(ICollection<AppUserToken> p34)
        {
            if (p34 == null)
            {
                return null;
            }
            ICollection<AppUserTokenReadModel> result = new List<AppUserTokenReadModel>(p34.Count);
            
            IEnumerator<AppUserToken> enumerator = p34.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserToken item = enumerator.Current;
                result.Add(item == null ? null : new AppUserTokenReadModel()
                {
                    Token = item.Token,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    LoginProvider = item.LoginProvider,
                    Name = item.Name,
                    Value = item.Value
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRefreshTokenReadModel> funcMain31(ICollection<AppRefreshToken> p35)
        {
            if (p35 == null)
            {
                return null;
            }
            ICollection<AppRefreshTokenReadModel> result = new List<AppRefreshTokenReadModel>(p35.Count);
            
            IEnumerator<AppRefreshToken> enumerator = p35.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRefreshToken item = enumerator.Current;
                result.Add(item == null ? null : new AppRefreshTokenReadModel()
                {
                    UserId = item.UserId,
                    Token = item.Token,
                    JwtId = item.JwtId,
                    IsUsed = item.IsUsed,
                    IsRevoked = item.IsRevoked,
                    ExpiryDate = item.ExpiryDate,
                    Hash = item.Hash,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRoleClaimReadModel> funcMain38(ICollection<AppRoleClaim> p42)
        {
            if (p42 == null)
            {
                return null;
            }
            ICollection<AppRoleClaimReadModel> result = new List<AppRoleClaimReadModel>(p42.Count);
            
            IEnumerator<AppRoleClaim> enumerator = p42.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRoleClaim item = enumerator.Current;
                result.Add(item == null ? null : new AppRoleClaimReadModel()
                {
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Id = item.Id,
                    RoleId = item.RoleId,
                    ClaimType = item.ClaimType,
                    ClaimValue = item.ClaimValue
                });
            }
            return result;
            
        }
        
        private static ICollection<AppUserTokenReadModel> funcMain50(ICollection<AppUserToken> p55)
        {
            if (p55 == null)
            {
                return null;
            }
            ICollection<AppUserTokenReadModel> result = new List<AppUserTokenReadModel>(p55.Count);
            
            IEnumerator<AppUserToken> enumerator = p55.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserToken item = enumerator.Current;
                result.Add(item == null ? null : new AppUserTokenReadModel()
                {
                    Token = item.Token,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    LoginProvider = item.LoginProvider,
                    Name = item.Name,
                    Value = item.Value
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRefreshTokenReadModel> funcMain51(ICollection<AppRefreshToken> p56)
        {
            if (p56 == null)
            {
                return null;
            }
            ICollection<AppRefreshTokenReadModel> result = new List<AppRefreshTokenReadModel>(p56.Count);
            
            IEnumerator<AppRefreshToken> enumerator = p56.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRefreshToken item = enumerator.Current;
                result.Add(item == null ? null : new AppRefreshTokenReadModel()
                {
                    UserId = item.UserId,
                    Token = item.Token,
                    JwtId = item.JwtId,
                    IsUsed = item.IsUsed,
                    IsRevoked = item.IsRevoked,
                    ExpiryDate = item.ExpiryDate,
                    Hash = item.Hash,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRoleClaimReadModel> funcMain58(ICollection<AppRoleClaim> p63)
        {
            if (p63 == null)
            {
                return null;
            }
            ICollection<AppRoleClaimReadModel> result = new List<AppRoleClaimReadModel>(p63.Count);
            
            IEnumerator<AppRoleClaim> enumerator = p63.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRoleClaim item = enumerator.Current;
                result.Add(item == null ? null : new AppRoleClaimReadModel()
                {
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Id = item.Id,
                    RoleId = item.RoleId,
                    ClaimType = item.ClaimType,
                    ClaimValue = item.ClaimValue
                });
            }
            return result;
            
        }
        
        private static ICollection<AppUserTokenReadModel> funcMain70(ICollection<AppUserToken> p78)
        {
            if (p78 == null)
            {
                return null;
            }
            ICollection<AppUserTokenReadModel> result = new List<AppUserTokenReadModel>(p78.Count);
            
            IEnumerator<AppUserToken> enumerator = p78.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserToken item = enumerator.Current;
                result.Add(item == null ? null : new AppUserTokenReadModel()
                {
                    Token = item.Token,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    LoginProvider = item.LoginProvider,
                    Name = item.Name,
                    Value = item.Value
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRefreshTokenReadModel> funcMain71(ICollection<AppRefreshToken> p79)
        {
            if (p79 == null)
            {
                return null;
            }
            ICollection<AppRefreshTokenReadModel> result = new List<AppRefreshTokenReadModel>(p79.Count);
            
            IEnumerator<AppRefreshToken> enumerator = p79.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRefreshToken item = enumerator.Current;
                result.Add(item == null ? null : new AppRefreshTokenReadModel()
                {
                    UserId = item.UserId,
                    Token = item.Token,
                    JwtId = item.JwtId,
                    IsUsed = item.IsUsed,
                    IsRevoked = item.IsRevoked,
                    ExpiryDate = item.ExpiryDate,
                    Hash = item.Hash,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRoleClaimReadModel> funcMain78(ICollection<AppRoleClaim> p86)
        {
            if (p86 == null)
            {
                return null;
            }
            ICollection<AppRoleClaimReadModel> result = new List<AppRoleClaimReadModel>(p86.Count);
            
            IEnumerator<AppRoleClaim> enumerator = p86.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRoleClaim item = enumerator.Current;
                result.Add(item == null ? null : new AppRoleClaimReadModel()
                {
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Id = item.Id,
                    RoleId = item.RoleId,
                    ClaimType = item.ClaimType,
                    ClaimValue = item.ClaimValue
                });
            }
            return result;
            
        }
    }
}