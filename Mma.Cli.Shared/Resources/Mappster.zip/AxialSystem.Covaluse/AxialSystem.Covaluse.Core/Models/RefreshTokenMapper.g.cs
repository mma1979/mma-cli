using System.Collections.Generic;
using AxialSystem.Covaluse.Core.Database.Identity;
using Mapster;

namespace AxialSystem.Covaluse.Core.Database.Identity
{
    public static partial class RefreshTokenMapper
    {
        public static RefreshTokenDto AdaptToDto(this RefreshToken p1)
        {
            return p1 == null ? null : new RefreshTokenDto()
            {
                UserId = p1.UserId,
                Token = p1.Token,
                JwtId = p1.JwtId,
                IsUsed = p1.IsUsed,
                IsRevoked = p1.IsRevoked,
                ExpiryDate = p1.ExpiryDate,
                Hash = p1.Hash,
                AppUser = funcMain1(p1.AppUser),
                Id = p1.Id,
                CreatedBy = p1.CreatedBy,
                CreatedDate = p1.CreatedDate,
                ModifiedBy = p1.ModifiedBy,
                ModifiedDate = p1.ModifiedDate,
                IsDeleted = p1.IsDeleted,
                DeletedBy = p1.DeletedBy,
                DeletedDate = p1.DeletedDate
            };
        }
        public static RefreshTokenDto AdaptTo(this RefreshToken p6, RefreshTokenDto p7)
        {
            if (p6 == null)
            {
                return null;
            }
            RefreshTokenDto result = p7 ?? new RefreshTokenDto();
            
            result.UserId = p6.UserId;
            result.Token = p6.Token;
            result.JwtId = p6.JwtId;
            result.IsUsed = p6.IsUsed;
            result.IsRevoked = p6.IsRevoked;
            result.ExpiryDate = p6.ExpiryDate;
            result.Hash = p6.Hash;
            result.AppUser = funcMain5(p6.AppUser, result.AppUser);
            result.Id = p6.Id;
            result.CreatedBy = p6.CreatedBy;
            result.CreatedDate = p6.CreatedDate;
            result.ModifiedBy = p6.ModifiedBy;
            result.ModifiedDate = p6.ModifiedDate;
            result.IsDeleted = p6.IsDeleted;
            result.DeletedBy = p6.DeletedBy;
            result.DeletedDate = p6.DeletedDate;
            return result;
            
        }
        
        private static AppUserDto funcMain1(AppUser p2)
        {
            return p2 == null ? null : new AppUserDto()
            {
                Hash = p2.Hash,
                FirstName = p2.FirstName,
                LastName = p2.LastName,
                Mobile = p2.Mobile,
                CountryCode = p2.CountryCode,
                TwoFactorMethod = p2.TwoFactorMethod,
                CreatedBy = p2.CreatedBy,
                CreatedDate = p2.CreatedDate,
                ModifiedBy = p2.ModifiedBy,
                ModifiedDate = p2.ModifiedDate,
                IsDeleted = p2.IsDeleted,
                DeletedBy = p2.DeletedBy,
                DeletedDate = p2.DeletedDate,
                MembershipType = p2.MembershipType,
                UserRoles = funcMain2(p2.UserRoles),
                UserTokens = funcMain3(p2.UserTokens),
                RefreshTokens = funcMain4(p2.RefreshTokens),
                Id = p2.Id,
                UserName = p2.UserName,
                NormalizedUserName = p2.NormalizedUserName,
                Email = p2.Email,
                NormalizedEmail = p2.NormalizedEmail,
                EmailConfirmed = p2.EmailConfirmed,
                PasswordHash = p2.PasswordHash,
                SecurityStamp = p2.SecurityStamp,
                ConcurrencyStamp = p2.ConcurrencyStamp,
                PhoneNumber = p2.PhoneNumber,
                PhoneNumberConfirmed = p2.PhoneNumberConfirmed,
                TwoFactorEnabled = p2.TwoFactorEnabled,
                LockoutEnd = p2.LockoutEnd,
                LockoutEnabled = p2.LockoutEnabled,
                AccessFailedCount = p2.AccessFailedCount
            };
        }
        
        private static AppUserDto funcMain5(AppUser p8, AppUserDto p9)
        {
            if (p8 == null)
            {
                return null;
            }
            AppUserDto result = p9 ?? new AppUserDto();
            
            result.Hash = p8.Hash;
            result.FirstName = p8.FirstName;
            result.LastName = p8.LastName;
            result.Mobile = p8.Mobile;
            result.CountryCode = p8.CountryCode;
            result.TwoFactorMethod = p8.TwoFactorMethod;
            result.CreatedBy = p8.CreatedBy;
            result.CreatedDate = p8.CreatedDate;
            result.ModifiedBy = p8.ModifiedBy;
            result.ModifiedDate = p8.ModifiedDate;
            result.IsDeleted = p8.IsDeleted;
            result.DeletedBy = p8.DeletedBy;
            result.DeletedDate = p8.DeletedDate;
            result.MembershipType = p8.MembershipType;
            result.UserRoles = funcMain6(p8.UserRoles, result.UserRoles);
            result.UserTokens = funcMain7(p8.UserTokens, result.UserTokens);
            result.RefreshTokens = funcMain8(p8.RefreshTokens, result.RefreshTokens);
            result.Id = p8.Id;
            result.UserName = p8.UserName;
            result.NormalizedUserName = p8.NormalizedUserName;
            result.Email = p8.Email;
            result.NormalizedEmail = p8.NormalizedEmail;
            result.EmailConfirmed = p8.EmailConfirmed;
            result.PasswordHash = p8.PasswordHash;
            result.SecurityStamp = p8.SecurityStamp;
            result.ConcurrencyStamp = p8.ConcurrencyStamp;
            result.PhoneNumber = p8.PhoneNumber;
            result.PhoneNumberConfirmed = p8.PhoneNumberConfirmed;
            result.TwoFactorEnabled = p8.TwoFactorEnabled;
            result.LockoutEnd = p8.LockoutEnd;
            result.LockoutEnabled = p8.LockoutEnabled;
            result.AccessFailedCount = p8.AccessFailedCount;
            return result;
            
        }
        
        private static ICollection<UserRoleDto> funcMain2(ICollection<UserRole> p3)
        {
            if (p3 == null)
            {
                return null;
            }
            ICollection<UserRoleDto> result = new List<UserRoleDto>(p3.Count);
            
            IEnumerator<UserRole> enumerator = p3.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                UserRole item = enumerator.Current;
                result.Add(item == null ? null : new UserRoleDto()
                {
                    AppUser = TypeAdapter<AppUser, AppUserDto>.Map.Invoke(item.AppUser),
                    Role = item.Role == null ? null : new RoleDto()
                    {
                        CreatedBy = item.Role.CreatedBy,
                        CreatedDate = item.Role.CreatedDate,
                        ModifiedBy = item.Role.ModifiedBy,
                        ModifiedDate = item.Role.ModifiedDate,
                        IsDeleted = item.Role.IsDeleted,
                        DeletedBy = item.Role.DeletedBy,
                        DeletedDate = item.Role.DeletedDate,
                        UserRoles = TypeAdapter<ICollection<UserRole>, ICollection<UserRoleDto>>.Map.Invoke(item.Role.UserRoles),
                        Id = item.Role.Id,
                        Name = item.Role.Name,
                        NormalizedName = item.Role.NormalizedName,
                        ConcurrencyStamp = item.Role.ConcurrencyStamp
                    },
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    RoleId = item.RoleId
                });
            }
            return result;
            
        }
        
        private static ICollection<UserTokenDto> funcMain3(ICollection<UserToken> p4)
        {
            if (p4 == null)
            {
                return null;
            }
            ICollection<UserTokenDto> result = new List<UserTokenDto>(p4.Count);
            
            IEnumerator<UserToken> enumerator = p4.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                UserToken item = enumerator.Current;
                result.Add(item == null ? null : new UserTokenDto()
                {
                    Token = item.Token,
                    AppUser = TypeAdapter<AppUser, AppUserDto>.Map.Invoke(item.AppUser),
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    LoginProvider = item.LoginProvider,
                    Name = item.Name,
                    Value = item.Value
                });
            }
            return result;
            
        }
        
        private static ICollection<RefreshTokenDto> funcMain4(ICollection<RefreshToken> p5)
        {
            if (p5 == null)
            {
                return null;
            }
            ICollection<RefreshTokenDto> result = new List<RefreshTokenDto>(p5.Count);
            
            IEnumerator<RefreshToken> enumerator = p5.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                RefreshToken item = enumerator.Current;
                result.Add(TypeAdapter<RefreshToken, RefreshTokenDto>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static ICollection<UserRoleDto> funcMain6(ICollection<UserRole> p10, ICollection<UserRoleDto> p11)
        {
            if (p10 == null)
            {
                return null;
            }
            ICollection<UserRoleDto> result = new List<UserRoleDto>(p10.Count);
            
            IEnumerator<UserRole> enumerator = p10.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                UserRole item = enumerator.Current;
                result.Add(item == null ? null : new UserRoleDto()
                {
                    AppUser = TypeAdapter<AppUser, AppUserDto>.Map.Invoke(item.AppUser),
                    Role = item.Role == null ? null : new RoleDto()
                    {
                        CreatedBy = item.Role.CreatedBy,
                        CreatedDate = item.Role.CreatedDate,
                        ModifiedBy = item.Role.ModifiedBy,
                        ModifiedDate = item.Role.ModifiedDate,
                        IsDeleted = item.Role.IsDeleted,
                        DeletedBy = item.Role.DeletedBy,
                        DeletedDate = item.Role.DeletedDate,
                        UserRoles = TypeAdapter<ICollection<UserRole>, ICollection<UserRoleDto>>.Map.Invoke(item.Role.UserRoles),
                        Id = item.Role.Id,
                        Name = item.Role.Name,
                        NormalizedName = item.Role.NormalizedName,
                        ConcurrencyStamp = item.Role.ConcurrencyStamp
                    },
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    RoleId = item.RoleId
                });
            }
            return result;
            
        }
        
        private static ICollection<UserTokenDto> funcMain7(ICollection<UserToken> p12, ICollection<UserTokenDto> p13)
        {
            if (p12 == null)
            {
                return null;
            }
            ICollection<UserTokenDto> result = new List<UserTokenDto>(p12.Count);
            
            IEnumerator<UserToken> enumerator = p12.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                UserToken item = enumerator.Current;
                result.Add(item == null ? null : new UserTokenDto()
                {
                    Token = item.Token,
                    AppUser = TypeAdapter<AppUser, AppUserDto>.Map.Invoke(item.AppUser),
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    LoginProvider = item.LoginProvider,
                    Name = item.Name,
                    Value = item.Value
                });
            }
            return result;
            
        }
        
        private static ICollection<RefreshTokenDto> funcMain8(ICollection<RefreshToken> p14, ICollection<RefreshTokenDto> p15)
        {
            if (p14 == null)
            {
                return null;
            }
            ICollection<RefreshTokenDto> result = new List<RefreshTokenDto>(p14.Count);
            
            IEnumerator<RefreshToken> enumerator = p14.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                RefreshToken item = enumerator.Current;
                result.Add(TypeAdapter<RefreshToken, RefreshTokenDto>.Map.Invoke(item));
            }
            return result;
            
        }
    }
}