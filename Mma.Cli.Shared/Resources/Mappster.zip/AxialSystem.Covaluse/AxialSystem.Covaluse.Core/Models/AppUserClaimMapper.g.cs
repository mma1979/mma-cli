using AxialSystem.Covaluse.Core.Database.Identity;

namespace AxialSystem.Covaluse.Core.Database.Identity
{
    public static partial class AppUserClaimMapper
    {
        public static AppUserClaimReadModel AdaptToReadModel(this AppUserClaim p1)
        {
            return p1 == null ? null : new AppUserClaimReadModel()
            {
                CreatedBy = p1.CreatedBy,
                CreatedDate = p1.CreatedDate,
                ModifiedBy = p1.ModifiedBy,
                ModifiedDate = p1.ModifiedDate,
                IsDeleted = p1.IsDeleted,
                DeletedBy = p1.DeletedBy,
                DeletedDate = p1.DeletedDate,
                Id = p1.Id,
                UserId = p1.UserId,
                ClaimType = p1.ClaimType,
                ClaimValue = p1.ClaimValue
            };
        }
        public static AppUserClaimReadModel AdaptTo(this AppUserClaim p2, AppUserClaimReadModel p3)
        {
            if (p2 == null)
            {
                return null;
            }
            AppUserClaimReadModel result = p3 ?? new AppUserClaimReadModel();
            
            result.CreatedBy = p2.CreatedBy;
            result.CreatedDate = p2.CreatedDate;
            result.ModifiedBy = p2.ModifiedBy;
            result.ModifiedDate = p2.ModifiedDate;
            result.IsDeleted = p2.IsDeleted;
            result.DeletedBy = p2.DeletedBy;
            result.DeletedDate = p2.DeletedDate;
            result.Id = p2.Id;
            result.UserId = p2.UserId;
            result.ClaimType = p2.ClaimType;
            result.ClaimValue = p2.ClaimValue;
            return result;
            
        }
        public static AppUserClaimModifyModel AdaptToModifyModel(this AppUserClaim p4)
        {
            return p4 == null ? null : new AppUserClaimModifyModel()
            {
                CreatedBy = p4.CreatedBy,
                CreatedDate = p4.CreatedDate,
                ModifiedBy = p4.ModifiedBy,
                ModifiedDate = p4.ModifiedDate,
                IsDeleted = p4.IsDeleted,
                DeletedBy = p4.DeletedBy,
                DeletedDate = p4.DeletedDate,
                Id = p4.Id,
                UserId = p4.UserId,
                ClaimType = p4.ClaimType,
                ClaimValue = p4.ClaimValue
            };
        }
        public static AppUserClaimModifyModel AdaptTo(this AppUserClaim p5, AppUserClaimModifyModel p6)
        {
            if (p5 == null)
            {
                return null;
            }
            AppUserClaimModifyModel result = p6 ?? new AppUserClaimModifyModel();
            
            result.CreatedBy = p5.CreatedBy;
            result.CreatedDate = p5.CreatedDate;
            result.ModifiedBy = p5.ModifiedBy;
            result.ModifiedDate = p5.ModifiedDate;
            result.IsDeleted = p5.IsDeleted;
            result.DeletedBy = p5.DeletedBy;
            result.DeletedDate = p5.DeletedDate;
            result.Id = p5.Id;
            result.UserId = p5.UserId;
            result.ClaimType = p5.ClaimType;
            result.ClaimValue = p5.ClaimValue;
            return result;
            
        }
    }
}