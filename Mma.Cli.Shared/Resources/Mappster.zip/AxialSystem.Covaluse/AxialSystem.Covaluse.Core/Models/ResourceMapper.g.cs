using System.Collections.Generic;
using AxialSystem.Covaluse.Core.Database.Localization;
using Mapster;

namespace AxialSystem.Covaluse.Core.Database.Localization
{
    public static partial class ResourceMapper
    {
        public static ResourceReadModel AdaptToReadModel(this Resource p1)
        {
            return p1 == null ? null : new ResourceReadModel()
            {
                Id = p1.Id,
                LanguageId = p1.LanguageId,
                Key = p1.Key,
                Value = p1.Value,
                Language = funcMain1(p1.Language)
            };
        }
        public static ResourceReadModel AdaptTo(this Resource p4, ResourceReadModel p5)
        {
            if (p4 == null)
            {
                return null;
            }
            ResourceReadModel result = p5 ?? new ResourceReadModel();
            
            result.Id = p4.Id;
            result.LanguageId = p4.LanguageId;
            result.Key = p4.Key;
            result.Value = p4.Value;
            result.Language = funcMain3(p4.Language, result.Language);
            return result;
            
        }
        public static ResourceModifyModel AdaptToModifyModel(this Resource p10)
        {
            return p10 == null ? null : new ResourceModifyModel()
            {
                Id = p10.Id,
                LanguageId = p10.LanguageId,
                Key = p10.Key,
                Value = p10.Value,
                Language = funcMain5(p10.Language)
            };
        }
        public static ResourceModifyModel AdaptTo(this Resource p13, ResourceModifyModel p14)
        {
            if (p13 == null)
            {
                return null;
            }
            ResourceModifyModel result = p14 ?? new ResourceModifyModel();
            
            result.Id = p13.Id;
            result.LanguageId = p13.LanguageId;
            result.Key = p13.Key;
            result.Value = p13.Value;
            result.Language = funcMain7(p13.Language, result.Language);
            return result;
            
        }
        
        private static LanguageReadModel funcMain1(Language p2)
        {
            return p2 == null ? null : new LanguageReadModel()
            {
                Id = p2.Id,
                LanguageCode = p2.LanguageCode,
                LanguageName = p2.LanguageName,
                Resources = funcMain2(p2.Resources)
            };
        }
        
        private static LanguageReadModel funcMain3(Language p6, LanguageReadModel p7)
        {
            if (p6 == null)
            {
                return null;
            }
            LanguageReadModel result = p7 ?? new LanguageReadModel();
            
            result.Id = p6.Id;
            result.LanguageCode = p6.LanguageCode;
            result.LanguageName = p6.LanguageName;
            result.Resources = funcMain4(p6.Resources, result.Resources);
            return result;
            
        }
        
        private static LanguageReadModel funcMain5(Language p11)
        {
            return p11 == null ? null : new LanguageReadModel()
            {
                Id = p11.Id,
                LanguageCode = p11.LanguageCode,
                LanguageName = p11.LanguageName,
                Resources = funcMain6(p11.Resources)
            };
        }
        
        private static LanguageReadModel funcMain7(Language p15, LanguageReadModel p16)
        {
            if (p15 == null)
            {
                return null;
            }
            LanguageReadModel result = p16 ?? new LanguageReadModel();
            
            result.Id = p15.Id;
            result.LanguageCode = p15.LanguageCode;
            result.LanguageName = p15.LanguageName;
            result.Resources = funcMain8(p15.Resources, result.Resources);
            return result;
            
        }
        
        private static ICollection<ResourceReadModel> funcMain2(ICollection<Resource> p3)
        {
            if (p3 == null)
            {
                return null;
            }
            ICollection<ResourceReadModel> result = new List<ResourceReadModel>(p3.Count);
            
            IEnumerator<Resource> enumerator = p3.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                Resource item = enumerator.Current;
                result.Add(TypeAdapter<Resource, ResourceReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static ICollection<ResourceReadModel> funcMain4(ICollection<Resource> p8, ICollection<ResourceReadModel> p9)
        {
            if (p8 == null)
            {
                return null;
            }
            ICollection<ResourceReadModel> result = new List<ResourceReadModel>(p8.Count);
            
            IEnumerator<Resource> enumerator = p8.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                Resource item = enumerator.Current;
                result.Add(TypeAdapter<Resource, ResourceReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static ICollection<ResourceReadModel> funcMain6(ICollection<Resource> p12)
        {
            if (p12 == null)
            {
                return null;
            }
            ICollection<ResourceReadModel> result = new List<ResourceReadModel>(p12.Count);
            
            IEnumerator<Resource> enumerator = p12.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                Resource item = enumerator.Current;
                result.Add(item == null ? null : new ResourceReadModel()
                {
                    Id = item.Id,
                    LanguageId = item.LanguageId,
                    Key = item.Key,
                    Value = item.Value,
                    Language = TypeAdapter<Language, LanguageReadModel>.Map.Invoke(item.Language)
                });
            }
            return result;
            
        }
        
        private static ICollection<ResourceReadModel> funcMain8(ICollection<Resource> p17, ICollection<ResourceReadModel> p18)
        {
            if (p17 == null)
            {
                return null;
            }
            ICollection<ResourceReadModel> result = new List<ResourceReadModel>(p17.Count);
            
            IEnumerator<Resource> enumerator = p17.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                Resource item = enumerator.Current;
                result.Add(item == null ? null : new ResourceReadModel()
                {
                    Id = item.Id,
                    LanguageId = item.LanguageId,
                    Key = item.Key,
                    Value = item.Value,
                    Language = TypeAdapter<Language, LanguageReadModel>.Map.Invoke(item.Language)
                });
            }
            return result;
            
        }
    }
}