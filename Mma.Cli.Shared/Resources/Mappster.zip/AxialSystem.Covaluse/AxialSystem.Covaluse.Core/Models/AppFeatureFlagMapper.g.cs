using System.Collections.Generic;
using AxialSystem.Covaluse.Core.Database.Identity;
using Mapster;

namespace AxialSystem.Covaluse.Core.Database.Identity
{
    public static partial class AppFeatureFlagMapper
    {
        public static AppFeatureFlagReadModel AdaptToReadModel(this AppFeatureFlag p1)
        {
            return p1 == null ? null : new AppFeatureFlagReadModel()
            {
                FeatureId = p1.FeatureId,
                ScopeIdentifier = p1.ScopeIdentifier,
                IsEnabled = p1.IsEnabled,
                Feature = funcMain1(p1.Feature),
                Id = p1.Id,
                CreatedBy = p1.CreatedBy,
                CreatedDate = p1.CreatedDate,
                ModifiedBy = p1.ModifiedBy,
                ModifiedDate = p1.ModifiedDate,
                IsDeleted = p1.IsDeleted,
                DeletedBy = p1.DeletedBy,
                DeletedDate = p1.DeletedDate
            };
        }
        public static AppFeatureFlagReadModel AdaptTo(this AppFeatureFlag p22, AppFeatureFlagReadModel p23)
        {
            if (p22 == null)
            {
                return null;
            }
            AppFeatureFlagReadModel result = p23 ?? new AppFeatureFlagReadModel();
            
            result.FeatureId = p22.FeatureId;
            result.ScopeIdentifier = p22.ScopeIdentifier;
            result.IsEnabled = p22.IsEnabled;
            result.Feature = funcMain21(p22.Feature, result.Feature);
            result.Id = p22.Id;
            result.CreatedBy = p22.CreatedBy;
            result.CreatedDate = p22.CreatedDate;
            result.ModifiedBy = p22.ModifiedBy;
            result.ModifiedDate = p22.ModifiedDate;
            result.IsDeleted = p22.IsDeleted;
            result.DeletedBy = p22.DeletedBy;
            result.DeletedDate = p22.DeletedDate;
            return result;
            
        }
        public static AppFeatureFlagModifyModel AdaptToModifyModel(this AppFeatureFlag p47)
        {
            return p47 == null ? null : new AppFeatureFlagModifyModel()
            {
                FeatureId = p47.FeatureId,
                ScopeIdentifier = p47.ScopeIdentifier,
                IsEnabled = p47.IsEnabled,
                Feature = funcMain41(p47.Feature),
                Id = p47.Id,
                CreatedBy = p47.CreatedBy,
                CreatedDate = p47.CreatedDate,
                ModifiedBy = p47.ModifiedBy,
                ModifiedDate = p47.ModifiedDate,
                IsDeleted = p47.IsDeleted,
                DeletedBy = p47.DeletedBy,
                DeletedDate = p47.DeletedDate
            };
        }
        public static AppFeatureFlagModifyModel AdaptTo(this AppFeatureFlag p68, AppFeatureFlagModifyModel p69)
        {
            if (p68 == null)
            {
                return null;
            }
            AppFeatureFlagModifyModel result = p69 ?? new AppFeatureFlagModifyModel();
            
            result.FeatureId = p68.FeatureId;
            result.ScopeIdentifier = p68.ScopeIdentifier;
            result.IsEnabled = p68.IsEnabled;
            result.Feature = funcMain61(p68.Feature, result.Feature);
            result.Id = p68.Id;
            result.CreatedBy = p68.CreatedBy;
            result.CreatedDate = p68.CreatedDate;
            result.ModifiedBy = p68.ModifiedBy;
            result.ModifiedDate = p68.ModifiedDate;
            result.IsDeleted = p68.IsDeleted;
            result.DeletedBy = p68.DeletedBy;
            result.DeletedDate = p68.DeletedDate;
            return result;
            
        }
        
        private static AppFeatureReadModel funcMain1(AppFeature p2)
        {
            return p2 == null ? null : new AppFeatureReadModel()
            {
                Name = p2.Name,
                Description = p2.Description,
                IsEnabled = p2.IsEnabled,
                Scope = p2.Scope,
                FeatureFlags = funcMain2(p2.FeatureFlags),
                AccessControlEntries = funcMain3(p2.AccessControlEntries),
                Id = p2.Id,
                CreatedBy = p2.CreatedBy,
                CreatedDate = p2.CreatedDate,
                ModifiedBy = p2.ModifiedBy,
                ModifiedDate = p2.ModifiedDate,
                IsDeleted = p2.IsDeleted,
                DeletedBy = p2.DeletedBy,
                DeletedDate = p2.DeletedDate
            };
        }
        
        private static AppFeatureReadModel funcMain21(AppFeature p24, AppFeatureReadModel p25)
        {
            if (p24 == null)
            {
                return null;
            }
            AppFeatureReadModel result = p25 ?? new AppFeatureReadModel();
            
            result.Name = p24.Name;
            result.Description = p24.Description;
            result.IsEnabled = p24.IsEnabled;
            result.Scope = p24.Scope;
            result.FeatureFlags = funcMain22(p24.FeatureFlags, result.FeatureFlags);
            result.AccessControlEntries = funcMain23(p24.AccessControlEntries, result.AccessControlEntries);
            result.Id = p24.Id;
            result.CreatedBy = p24.CreatedBy;
            result.CreatedDate = p24.CreatedDate;
            result.ModifiedBy = p24.ModifiedBy;
            result.ModifiedDate = p24.ModifiedDate;
            result.IsDeleted = p24.IsDeleted;
            result.DeletedBy = p24.DeletedBy;
            result.DeletedDate = p24.DeletedDate;
            return result;
            
        }
        
        private static AppFeatureReadModel funcMain41(AppFeature p48)
        {
            return p48 == null ? null : new AppFeatureReadModel()
            {
                Name = p48.Name,
                Description = p48.Description,
                IsEnabled = p48.IsEnabled,
                Scope = p48.Scope,
                FeatureFlags = funcMain42(p48.FeatureFlags),
                AccessControlEntries = funcMain43(p48.AccessControlEntries),
                Id = p48.Id,
                CreatedBy = p48.CreatedBy,
                CreatedDate = p48.CreatedDate,
                ModifiedBy = p48.ModifiedBy,
                ModifiedDate = p48.ModifiedDate,
                IsDeleted = p48.IsDeleted,
                DeletedBy = p48.DeletedBy,
                DeletedDate = p48.DeletedDate
            };
        }
        
        private static AppFeatureReadModel funcMain61(AppFeature p70, AppFeatureReadModel p71)
        {
            if (p70 == null)
            {
                return null;
            }
            AppFeatureReadModel result = p71 ?? new AppFeatureReadModel();
            
            result.Name = p70.Name;
            result.Description = p70.Description;
            result.IsEnabled = p70.IsEnabled;
            result.Scope = p70.Scope;
            result.FeatureFlags = funcMain62(p70.FeatureFlags, result.FeatureFlags);
            result.AccessControlEntries = funcMain63(p70.AccessControlEntries, result.AccessControlEntries);
            result.Id = p70.Id;
            result.CreatedBy = p70.CreatedBy;
            result.CreatedDate = p70.CreatedDate;
            result.ModifiedBy = p70.ModifiedBy;
            result.ModifiedDate = p70.ModifiedDate;
            result.IsDeleted = p70.IsDeleted;
            result.DeletedBy = p70.DeletedBy;
            result.DeletedDate = p70.DeletedDate;
            return result;
            
        }
        
        private static ICollection<AppFeatureFlagReadModel> funcMain2(ICollection<AppFeatureFlag> p3)
        {
            if (p3 == null)
            {
                return null;
            }
            ICollection<AppFeatureFlagReadModel> result = new List<AppFeatureFlagReadModel>(p3.Count);
            
            IEnumerator<AppFeatureFlag> enumerator = p3.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppFeatureFlag item = enumerator.Current;
                result.Add(TypeAdapter<AppFeatureFlag, AppFeatureFlagReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static ICollection<AppAccessControlEntryReadModel> funcMain3(ICollection<AppAccessControlEntry> p4)
        {
            if (p4 == null)
            {
                return null;
            }
            ICollection<AppAccessControlEntryReadModel> result = new List<AppAccessControlEntryReadModel>(p4.Count);
            
            IEnumerator<AppAccessControlEntry> enumerator = p4.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppAccessControlEntry item = enumerator.Current;
                result.Add(funcMain4(item));
            }
            return result;
            
        }
        
        private static ICollection<AppFeatureFlagReadModel> funcMain22(ICollection<AppFeatureFlag> p26, ICollection<AppFeatureFlagReadModel> p27)
        {
            if (p26 == null)
            {
                return null;
            }
            ICollection<AppFeatureFlagReadModel> result = new List<AppFeatureFlagReadModel>(p26.Count);
            
            IEnumerator<AppFeatureFlag> enumerator = p26.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppFeatureFlag item = enumerator.Current;
                result.Add(TypeAdapter<AppFeatureFlag, AppFeatureFlagReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static ICollection<AppAccessControlEntryReadModel> funcMain23(ICollection<AppAccessControlEntry> p28, ICollection<AppAccessControlEntryReadModel> p29)
        {
            if (p28 == null)
            {
                return null;
            }
            ICollection<AppAccessControlEntryReadModel> result = new List<AppAccessControlEntryReadModel>(p28.Count);
            
            IEnumerator<AppAccessControlEntry> enumerator = p28.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppAccessControlEntry item = enumerator.Current;
                result.Add(funcMain24(item));
            }
            return result;
            
        }
        
        private static ICollection<AppFeatureFlagReadModel> funcMain42(ICollection<AppFeatureFlag> p49)
        {
            if (p49 == null)
            {
                return null;
            }
            ICollection<AppFeatureFlagReadModel> result = new List<AppFeatureFlagReadModel>(p49.Count);
            
            IEnumerator<AppFeatureFlag> enumerator = p49.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppFeatureFlag item = enumerator.Current;
                result.Add(item == null ? null : new AppFeatureFlagReadModel()
                {
                    FeatureId = item.FeatureId,
                    ScopeIdentifier = item.ScopeIdentifier,
                    IsEnabled = item.IsEnabled,
                    Feature = TypeAdapter<AppFeature, AppFeatureReadModel>.Map.Invoke(item.Feature),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static ICollection<AppAccessControlEntryReadModel> funcMain43(ICollection<AppAccessControlEntry> p50)
        {
            if (p50 == null)
            {
                return null;
            }
            ICollection<AppAccessControlEntryReadModel> result = new List<AppAccessControlEntryReadModel>(p50.Count);
            
            IEnumerator<AppAccessControlEntry> enumerator = p50.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppAccessControlEntry item = enumerator.Current;
                result.Add(funcMain44(item));
            }
            return result;
            
        }
        
        private static ICollection<AppFeatureFlagReadModel> funcMain62(ICollection<AppFeatureFlag> p72, ICollection<AppFeatureFlagReadModel> p73)
        {
            if (p72 == null)
            {
                return null;
            }
            ICollection<AppFeatureFlagReadModel> result = new List<AppFeatureFlagReadModel>(p72.Count);
            
            IEnumerator<AppFeatureFlag> enumerator = p72.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppFeatureFlag item = enumerator.Current;
                result.Add(item == null ? null : new AppFeatureFlagReadModel()
                {
                    FeatureId = item.FeatureId,
                    ScopeIdentifier = item.ScopeIdentifier,
                    IsEnabled = item.IsEnabled,
                    Feature = TypeAdapter<AppFeature, AppFeatureReadModel>.Map.Invoke(item.Feature),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static ICollection<AppAccessControlEntryReadModel> funcMain63(ICollection<AppAccessControlEntry> p74, ICollection<AppAccessControlEntryReadModel> p75)
        {
            if (p74 == null)
            {
                return null;
            }
            ICollection<AppAccessControlEntryReadModel> result = new List<AppAccessControlEntryReadModel>(p74.Count);
            
            IEnumerator<AppAccessControlEntry> enumerator = p74.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppAccessControlEntry item = enumerator.Current;
                result.Add(funcMain64(item));
            }
            return result;
            
        }
        
        private static AppAccessControlEntryReadModel funcMain4(AppAccessControlEntry p5)
        {
            return p5 == null ? null : new AppAccessControlEntryReadModel()
            {
                ResourcePattern = p5.ResourcePattern,
                PermissionPattern = p5.PermissionPattern,
                FeatureId = p5.FeatureId,
                Feature = TypeAdapter<AppFeature, AppFeatureReadModel>.Map.Invoke(p5.Feature),
                AppRoles = funcMain5(p5.AppRoles),
                AppUsers = funcMain13(p5.AppUsers),
                AppResource = p5.AppResource == null ? null : new AppResourceReadModel()
                {
                    Url = p5.AppResource.Url,
                    Description = p5.AppResource.Description,
                    ResourceType = p5.AppResource.ResourceType,
                    AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p5.AppResource.AccessControlEntries),
                    Id = p5.AppResource.Id,
                    CreatedBy = p5.AppResource.CreatedBy,
                    CreatedDate = p5.AppResource.CreatedDate,
                    ModifiedBy = p5.AppResource.ModifiedBy,
                    ModifiedDate = p5.AppResource.ModifiedDate,
                    IsDeleted = p5.AppResource.IsDeleted,
                    DeletedBy = p5.AppResource.DeletedBy,
                    DeletedDate = p5.AppResource.DeletedDate
                },
                ResourceId = p5.ResourceId,
                Id = p5.Id,
                CreatedBy = p5.CreatedBy,
                CreatedDate = p5.CreatedDate,
                ModifiedBy = p5.ModifiedBy,
                ModifiedDate = p5.ModifiedDate,
                IsDeleted = p5.IsDeleted,
                DeletedBy = p5.DeletedBy,
                DeletedDate = p5.DeletedDate
            };
        }
        
        private static AppAccessControlEntryReadModel funcMain24(AppAccessControlEntry p30)
        {
            return p30 == null ? null : new AppAccessControlEntryReadModel()
            {
                ResourcePattern = p30.ResourcePattern,
                PermissionPattern = p30.PermissionPattern,
                FeatureId = p30.FeatureId,
                Feature = TypeAdapter<AppFeature, AppFeatureReadModel>.Map.Invoke(p30.Feature),
                AppRoles = funcMain25(p30.AppRoles),
                AppUsers = funcMain33(p30.AppUsers),
                AppResource = p30.AppResource == null ? null : new AppResourceReadModel()
                {
                    Url = p30.AppResource.Url,
                    Description = p30.AppResource.Description,
                    ResourceType = p30.AppResource.ResourceType,
                    AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p30.AppResource.AccessControlEntries),
                    Id = p30.AppResource.Id,
                    CreatedBy = p30.AppResource.CreatedBy,
                    CreatedDate = p30.AppResource.CreatedDate,
                    ModifiedBy = p30.AppResource.ModifiedBy,
                    ModifiedDate = p30.AppResource.ModifiedDate,
                    IsDeleted = p30.AppResource.IsDeleted,
                    DeletedBy = p30.AppResource.DeletedBy,
                    DeletedDate = p30.AppResource.DeletedDate
                },
                ResourceId = p30.ResourceId,
                Id = p30.Id,
                CreatedBy = p30.CreatedBy,
                CreatedDate = p30.CreatedDate,
                ModifiedBy = p30.ModifiedBy,
                ModifiedDate = p30.ModifiedDate,
                IsDeleted = p30.IsDeleted,
                DeletedBy = p30.DeletedBy,
                DeletedDate = p30.DeletedDate
            };
        }
        
        private static AppAccessControlEntryReadModel funcMain44(AppAccessControlEntry p51)
        {
            return p51 == null ? null : new AppAccessControlEntryReadModel()
            {
                ResourcePattern = p51.ResourcePattern,
                PermissionPattern = p51.PermissionPattern,
                FeatureId = p51.FeatureId,
                Feature = TypeAdapter<AppFeature, AppFeatureReadModel>.Map.Invoke(p51.Feature),
                AppRoles = funcMain45(p51.AppRoles),
                AppUsers = funcMain53(p51.AppUsers),
                AppResource = p51.AppResource == null ? null : new AppResourceReadModel()
                {
                    Url = p51.AppResource.Url,
                    Description = p51.AppResource.Description,
                    ResourceType = p51.AppResource.ResourceType,
                    AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p51.AppResource.AccessControlEntries),
                    Id = p51.AppResource.Id,
                    CreatedBy = p51.AppResource.CreatedBy,
                    CreatedDate = p51.AppResource.CreatedDate,
                    ModifiedBy = p51.AppResource.ModifiedBy,
                    ModifiedDate = p51.AppResource.ModifiedDate,
                    IsDeleted = p51.AppResource.IsDeleted,
                    DeletedBy = p51.AppResource.DeletedBy,
                    DeletedDate = p51.AppResource.DeletedDate
                },
                ResourceId = p51.ResourceId,
                Id = p51.Id,
                CreatedBy = p51.CreatedBy,
                CreatedDate = p51.CreatedDate,
                ModifiedBy = p51.ModifiedBy,
                ModifiedDate = p51.ModifiedDate,
                IsDeleted = p51.IsDeleted,
                DeletedBy = p51.DeletedBy,
                DeletedDate = p51.DeletedDate
            };
        }
        
        private static AppAccessControlEntryReadModel funcMain64(AppAccessControlEntry p76)
        {
            return p76 == null ? null : new AppAccessControlEntryReadModel()
            {
                ResourcePattern = p76.ResourcePattern,
                PermissionPattern = p76.PermissionPattern,
                FeatureId = p76.FeatureId,
                Feature = TypeAdapter<AppFeature, AppFeatureReadModel>.Map.Invoke(p76.Feature),
                AppRoles = funcMain65(p76.AppRoles),
                AppUsers = funcMain73(p76.AppUsers),
                AppResource = p76.AppResource == null ? null : new AppResourceReadModel()
                {
                    Url = p76.AppResource.Url,
                    Description = p76.AppResource.Description,
                    ResourceType = p76.AppResource.ResourceType,
                    AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p76.AppResource.AccessControlEntries),
                    Id = p76.AppResource.Id,
                    CreatedBy = p76.AppResource.CreatedBy,
                    CreatedDate = p76.AppResource.CreatedDate,
                    ModifiedBy = p76.AppResource.ModifiedBy,
                    ModifiedDate = p76.AppResource.ModifiedDate,
                    IsDeleted = p76.AppResource.IsDeleted,
                    DeletedBy = p76.AppResource.DeletedBy,
                    DeletedDate = p76.AppResource.DeletedDate
                },
                ResourceId = p76.ResourceId,
                Id = p76.Id,
                CreatedBy = p76.CreatedBy,
                CreatedDate = p76.CreatedDate,
                ModifiedBy = p76.ModifiedBy,
                ModifiedDate = p76.ModifiedDate,
                IsDeleted = p76.IsDeleted,
                DeletedBy = p76.DeletedBy,
                DeletedDate = p76.DeletedDate
            };
        }
        
        private static ICollection<AppRoleReadModel> funcMain5(ICollection<AppRole> p6)
        {
            if (p6 == null)
            {
                return null;
            }
            ICollection<AppRoleReadModel> result = new List<AppRoleReadModel>(p6.Count);
            
            IEnumerator<AppRole> enumerator = p6.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRole item = enumerator.Current;
                result.Add(funcMain6(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserReadModel> funcMain13(ICollection<AppUser> p14)
        {
            if (p14 == null)
            {
                return null;
            }
            ICollection<AppUserReadModel> result = new List<AppUserReadModel>(p14.Count);
            
            IEnumerator<AppUser> enumerator = p14.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUser item = enumerator.Current;
                result.Add(funcMain14(item));
            }
            return result;
            
        }
        
        private static ICollection<AppRoleReadModel> funcMain25(ICollection<AppRole> p31)
        {
            if (p31 == null)
            {
                return null;
            }
            ICollection<AppRoleReadModel> result = new List<AppRoleReadModel>(p31.Count);
            
            IEnumerator<AppRole> enumerator = p31.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRole item = enumerator.Current;
                result.Add(funcMain26(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserReadModel> funcMain33(ICollection<AppUser> p39)
        {
            if (p39 == null)
            {
                return null;
            }
            ICollection<AppUserReadModel> result = new List<AppUserReadModel>(p39.Count);
            
            IEnumerator<AppUser> enumerator = p39.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUser item = enumerator.Current;
                result.Add(funcMain34(item));
            }
            return result;
            
        }
        
        private static ICollection<AppRoleReadModel> funcMain45(ICollection<AppRole> p52)
        {
            if (p52 == null)
            {
                return null;
            }
            ICollection<AppRoleReadModel> result = new List<AppRoleReadModel>(p52.Count);
            
            IEnumerator<AppRole> enumerator = p52.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRole item = enumerator.Current;
                result.Add(funcMain46(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserReadModel> funcMain53(ICollection<AppUser> p60)
        {
            if (p60 == null)
            {
                return null;
            }
            ICollection<AppUserReadModel> result = new List<AppUserReadModel>(p60.Count);
            
            IEnumerator<AppUser> enumerator = p60.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUser item = enumerator.Current;
                result.Add(funcMain54(item));
            }
            return result;
            
        }
        
        private static ICollection<AppRoleReadModel> funcMain65(ICollection<AppRole> p77)
        {
            if (p77 == null)
            {
                return null;
            }
            ICollection<AppRoleReadModel> result = new List<AppRoleReadModel>(p77.Count);
            
            IEnumerator<AppRole> enumerator = p77.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRole item = enumerator.Current;
                result.Add(funcMain66(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserReadModel> funcMain73(ICollection<AppUser> p85)
        {
            if (p85 == null)
            {
                return null;
            }
            ICollection<AppUserReadModel> result = new List<AppUserReadModel>(p85.Count);
            
            IEnumerator<AppUser> enumerator = p85.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUser item = enumerator.Current;
                result.Add(funcMain74(item));
            }
            return result;
            
        }
        
        private static AppRoleReadModel funcMain6(AppRole p7)
        {
            return p7 == null ? null : new AppRoleReadModel()
            {
                CreatedBy = p7.CreatedBy,
                CreatedDate = p7.CreatedDate,
                ModifiedBy = p7.ModifiedBy,
                ModifiedDate = p7.ModifiedDate,
                IsDeleted = p7.IsDeleted,
                DeletedBy = p7.DeletedBy,
                DeletedDate = p7.DeletedDate,
                AppUserRoles = funcMain7(p7.AppUserRoles),
                AppRoleClaims = funcMain12(p7.AppRoleClaims),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p7.AccessControlEntries),
                Hash = p7.Hash,
                Id = p7.Id,
                Name = p7.Name,
                NormalizedName = p7.NormalizedName,
                ConcurrencyStamp = p7.ConcurrencyStamp
            };
        }
        
        private static AppUserReadModel funcMain14(AppUser p15)
        {
            return p15 == null ? null : new AppUserReadModel()
            {
                Hash = p15.Hash,
                FirstName = p15.FirstName,
                LastName = p15.LastName,
                Mobile = p15.Mobile,
                CountryCode = p15.CountryCode,
                TwoFactorMethod = p15.TwoFactorMethod,
                CreatedBy = p15.CreatedBy,
                CreatedDate = p15.CreatedDate,
                ModifiedBy = p15.ModifiedBy,
                ModifiedDate = p15.ModifiedDate,
                IsDeleted = p15.IsDeleted,
                DeletedBy = p15.DeletedBy,
                DeletedDate = p15.DeletedDate,
                MembershipType = p15.MembershipType,
                UserRoles = funcMain15(p15.UserRoles),
                UserTokens = funcMain19(p15.UserTokens),
                RefreshTokens = funcMain20(p15.RefreshTokens),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p15.AccessControlEntries),
                Id = p15.Id,
                UserName = p15.UserName,
                NormalizedUserName = p15.NormalizedUserName,
                Email = p15.Email,
                NormalizedEmail = p15.NormalizedEmail,
                EmailConfirmed = p15.EmailConfirmed,
                PasswordHash = p15.PasswordHash,
                SecurityStamp = p15.SecurityStamp,
                ConcurrencyStamp = p15.ConcurrencyStamp,
                PhoneNumber = p15.PhoneNumber,
                PhoneNumberConfirmed = p15.PhoneNumberConfirmed,
                TwoFactorEnabled = p15.TwoFactorEnabled,
                LockoutEnd = p15.LockoutEnd,
                LockoutEnabled = p15.LockoutEnabled,
                AccessFailedCount = p15.AccessFailedCount
            };
        }
        
        private static AppRoleReadModel funcMain26(AppRole p32)
        {
            return p32 == null ? null : new AppRoleReadModel()
            {
                CreatedBy = p32.CreatedBy,
                CreatedDate = p32.CreatedDate,
                ModifiedBy = p32.ModifiedBy,
                ModifiedDate = p32.ModifiedDate,
                IsDeleted = p32.IsDeleted,
                DeletedBy = p32.DeletedBy,
                DeletedDate = p32.DeletedDate,
                AppUserRoles = funcMain27(p32.AppUserRoles),
                AppRoleClaims = funcMain32(p32.AppRoleClaims),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p32.AccessControlEntries),
                Hash = p32.Hash,
                Id = p32.Id,
                Name = p32.Name,
                NormalizedName = p32.NormalizedName,
                ConcurrencyStamp = p32.ConcurrencyStamp
            };
        }
        
        private static AppUserReadModel funcMain34(AppUser p40)
        {
            return p40 == null ? null : new AppUserReadModel()
            {
                Hash = p40.Hash,
                FirstName = p40.FirstName,
                LastName = p40.LastName,
                Mobile = p40.Mobile,
                CountryCode = p40.CountryCode,
                TwoFactorMethod = p40.TwoFactorMethod,
                CreatedBy = p40.CreatedBy,
                CreatedDate = p40.CreatedDate,
                ModifiedBy = p40.ModifiedBy,
                ModifiedDate = p40.ModifiedDate,
                IsDeleted = p40.IsDeleted,
                DeletedBy = p40.DeletedBy,
                DeletedDate = p40.DeletedDate,
                MembershipType = p40.MembershipType,
                UserRoles = funcMain35(p40.UserRoles),
                UserTokens = funcMain39(p40.UserTokens),
                RefreshTokens = funcMain40(p40.RefreshTokens),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p40.AccessControlEntries),
                Id = p40.Id,
                UserName = p40.UserName,
                NormalizedUserName = p40.NormalizedUserName,
                Email = p40.Email,
                NormalizedEmail = p40.NormalizedEmail,
                EmailConfirmed = p40.EmailConfirmed,
                PasswordHash = p40.PasswordHash,
                SecurityStamp = p40.SecurityStamp,
                ConcurrencyStamp = p40.ConcurrencyStamp,
                PhoneNumber = p40.PhoneNumber,
                PhoneNumberConfirmed = p40.PhoneNumberConfirmed,
                TwoFactorEnabled = p40.TwoFactorEnabled,
                LockoutEnd = p40.LockoutEnd,
                LockoutEnabled = p40.LockoutEnabled,
                AccessFailedCount = p40.AccessFailedCount
            };
        }
        
        private static AppRoleReadModel funcMain46(AppRole p53)
        {
            return p53 == null ? null : new AppRoleReadModel()
            {
                CreatedBy = p53.CreatedBy,
                CreatedDate = p53.CreatedDate,
                ModifiedBy = p53.ModifiedBy,
                ModifiedDate = p53.ModifiedDate,
                IsDeleted = p53.IsDeleted,
                DeletedBy = p53.DeletedBy,
                DeletedDate = p53.DeletedDate,
                AppUserRoles = funcMain47(p53.AppUserRoles),
                AppRoleClaims = funcMain52(p53.AppRoleClaims),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p53.AccessControlEntries),
                Hash = p53.Hash,
                Id = p53.Id,
                Name = p53.Name,
                NormalizedName = p53.NormalizedName,
                ConcurrencyStamp = p53.ConcurrencyStamp
            };
        }
        
        private static AppUserReadModel funcMain54(AppUser p61)
        {
            return p61 == null ? null : new AppUserReadModel()
            {
                Hash = p61.Hash,
                FirstName = p61.FirstName,
                LastName = p61.LastName,
                Mobile = p61.Mobile,
                CountryCode = p61.CountryCode,
                TwoFactorMethod = p61.TwoFactorMethod,
                CreatedBy = p61.CreatedBy,
                CreatedDate = p61.CreatedDate,
                ModifiedBy = p61.ModifiedBy,
                ModifiedDate = p61.ModifiedDate,
                IsDeleted = p61.IsDeleted,
                DeletedBy = p61.DeletedBy,
                DeletedDate = p61.DeletedDate,
                MembershipType = p61.MembershipType,
                UserRoles = funcMain55(p61.UserRoles),
                UserTokens = funcMain59(p61.UserTokens),
                RefreshTokens = funcMain60(p61.RefreshTokens),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p61.AccessControlEntries),
                Id = p61.Id,
                UserName = p61.UserName,
                NormalizedUserName = p61.NormalizedUserName,
                Email = p61.Email,
                NormalizedEmail = p61.NormalizedEmail,
                EmailConfirmed = p61.EmailConfirmed,
                PasswordHash = p61.PasswordHash,
                SecurityStamp = p61.SecurityStamp,
                ConcurrencyStamp = p61.ConcurrencyStamp,
                PhoneNumber = p61.PhoneNumber,
                PhoneNumberConfirmed = p61.PhoneNumberConfirmed,
                TwoFactorEnabled = p61.TwoFactorEnabled,
                LockoutEnd = p61.LockoutEnd,
                LockoutEnabled = p61.LockoutEnabled,
                AccessFailedCount = p61.AccessFailedCount
            };
        }
        
        private static AppRoleReadModel funcMain66(AppRole p78)
        {
            return p78 == null ? null : new AppRoleReadModel()
            {
                CreatedBy = p78.CreatedBy,
                CreatedDate = p78.CreatedDate,
                ModifiedBy = p78.ModifiedBy,
                ModifiedDate = p78.ModifiedDate,
                IsDeleted = p78.IsDeleted,
                DeletedBy = p78.DeletedBy,
                DeletedDate = p78.DeletedDate,
                AppUserRoles = funcMain67(p78.AppUserRoles),
                AppRoleClaims = funcMain72(p78.AppRoleClaims),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p78.AccessControlEntries),
                Hash = p78.Hash,
                Id = p78.Id,
                Name = p78.Name,
                NormalizedName = p78.NormalizedName,
                ConcurrencyStamp = p78.ConcurrencyStamp
            };
        }
        
        private static AppUserReadModel funcMain74(AppUser p86)
        {
            return p86 == null ? null : new AppUserReadModel()
            {
                Hash = p86.Hash,
                FirstName = p86.FirstName,
                LastName = p86.LastName,
                Mobile = p86.Mobile,
                CountryCode = p86.CountryCode,
                TwoFactorMethod = p86.TwoFactorMethod,
                CreatedBy = p86.CreatedBy,
                CreatedDate = p86.CreatedDate,
                ModifiedBy = p86.ModifiedBy,
                ModifiedDate = p86.ModifiedDate,
                IsDeleted = p86.IsDeleted,
                DeletedBy = p86.DeletedBy,
                DeletedDate = p86.DeletedDate,
                MembershipType = p86.MembershipType,
                UserRoles = funcMain75(p86.UserRoles),
                UserTokens = funcMain79(p86.UserTokens),
                RefreshTokens = funcMain80(p86.RefreshTokens),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p86.AccessControlEntries),
                Id = p86.Id,
                UserName = p86.UserName,
                NormalizedUserName = p86.NormalizedUserName,
                Email = p86.Email,
                NormalizedEmail = p86.NormalizedEmail,
                EmailConfirmed = p86.EmailConfirmed,
                PasswordHash = p86.PasswordHash,
                SecurityStamp = p86.SecurityStamp,
                ConcurrencyStamp = p86.ConcurrencyStamp,
                PhoneNumber = p86.PhoneNumber,
                PhoneNumberConfirmed = p86.PhoneNumberConfirmed,
                TwoFactorEnabled = p86.TwoFactorEnabled,
                LockoutEnd = p86.LockoutEnd,
                LockoutEnabled = p86.LockoutEnabled,
                AccessFailedCount = p86.AccessFailedCount
            };
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain7(ICollection<AppUserRole> p8)
        {
            if (p8 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p8.Count);
            
            IEnumerator<AppUserRole> enumerator = p8.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(funcMain8(item));
            }
            return result;
            
        }
        
        private static ICollection<AppRoleClaimReadModel> funcMain12(ICollection<AppRoleClaim> p13)
        {
            if (p13 == null)
            {
                return null;
            }
            ICollection<AppRoleClaimReadModel> result = new List<AppRoleClaimReadModel>(p13.Count);
            
            IEnumerator<AppRoleClaim> enumerator = p13.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRoleClaim item = enumerator.Current;
                result.Add(item == null ? null : new AppRoleClaimReadModel()
                {
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Id = item.Id,
                    RoleId = item.RoleId,
                    ClaimType = item.ClaimType,
                    ClaimValue = item.ClaimValue
                });
            }
            return result;
            
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain15(ICollection<AppUserRole> p16)
        {
            if (p16 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p16.Count);
            
            IEnumerator<AppUserRole> enumerator = p16.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(funcMain16(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserTokenReadModel> funcMain19(ICollection<AppUserToken> p20)
        {
            if (p20 == null)
            {
                return null;
            }
            ICollection<AppUserTokenReadModel> result = new List<AppUserTokenReadModel>(p20.Count);
            
            IEnumerator<AppUserToken> enumerator = p20.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserToken item = enumerator.Current;
                result.Add(item == null ? null : new AppUserTokenReadModel()
                {
                    Token = item.Token,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    LoginProvider = item.LoginProvider,
                    Name = item.Name,
                    Value = item.Value
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRefreshTokenReadModel> funcMain20(ICollection<AppRefreshToken> p21)
        {
            if (p21 == null)
            {
                return null;
            }
            ICollection<AppRefreshTokenReadModel> result = new List<AppRefreshTokenReadModel>(p21.Count);
            
            IEnumerator<AppRefreshToken> enumerator = p21.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRefreshToken item = enumerator.Current;
                result.Add(item == null ? null : new AppRefreshTokenReadModel()
                {
                    UserId = item.UserId,
                    Token = item.Token,
                    JwtId = item.JwtId,
                    IsUsed = item.IsUsed,
                    IsRevoked = item.IsRevoked,
                    ExpiryDate = item.ExpiryDate,
                    Hash = item.Hash,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain27(ICollection<AppUserRole> p33)
        {
            if (p33 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p33.Count);
            
            IEnumerator<AppUserRole> enumerator = p33.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(funcMain28(item));
            }
            return result;
            
        }
        
        private static ICollection<AppRoleClaimReadModel> funcMain32(ICollection<AppRoleClaim> p38)
        {
            if (p38 == null)
            {
                return null;
            }
            ICollection<AppRoleClaimReadModel> result = new List<AppRoleClaimReadModel>(p38.Count);
            
            IEnumerator<AppRoleClaim> enumerator = p38.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRoleClaim item = enumerator.Current;
                result.Add(item == null ? null : new AppRoleClaimReadModel()
                {
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Id = item.Id,
                    RoleId = item.RoleId,
                    ClaimType = item.ClaimType,
                    ClaimValue = item.ClaimValue
                });
            }
            return result;
            
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain35(ICollection<AppUserRole> p41)
        {
            if (p41 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p41.Count);
            
            IEnumerator<AppUserRole> enumerator = p41.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(funcMain36(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserTokenReadModel> funcMain39(ICollection<AppUserToken> p45)
        {
            if (p45 == null)
            {
                return null;
            }
            ICollection<AppUserTokenReadModel> result = new List<AppUserTokenReadModel>(p45.Count);
            
            IEnumerator<AppUserToken> enumerator = p45.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserToken item = enumerator.Current;
                result.Add(item == null ? null : new AppUserTokenReadModel()
                {
                    Token = item.Token,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    LoginProvider = item.LoginProvider,
                    Name = item.Name,
                    Value = item.Value
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRefreshTokenReadModel> funcMain40(ICollection<AppRefreshToken> p46)
        {
            if (p46 == null)
            {
                return null;
            }
            ICollection<AppRefreshTokenReadModel> result = new List<AppRefreshTokenReadModel>(p46.Count);
            
            IEnumerator<AppRefreshToken> enumerator = p46.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRefreshToken item = enumerator.Current;
                result.Add(item == null ? null : new AppRefreshTokenReadModel()
                {
                    UserId = item.UserId,
                    Token = item.Token,
                    JwtId = item.JwtId,
                    IsUsed = item.IsUsed,
                    IsRevoked = item.IsRevoked,
                    ExpiryDate = item.ExpiryDate,
                    Hash = item.Hash,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain47(ICollection<AppUserRole> p54)
        {
            if (p54 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p54.Count);
            
            IEnumerator<AppUserRole> enumerator = p54.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(funcMain48(item));
            }
            return result;
            
        }
        
        private static ICollection<AppRoleClaimReadModel> funcMain52(ICollection<AppRoleClaim> p59)
        {
            if (p59 == null)
            {
                return null;
            }
            ICollection<AppRoleClaimReadModel> result = new List<AppRoleClaimReadModel>(p59.Count);
            
            IEnumerator<AppRoleClaim> enumerator = p59.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRoleClaim item = enumerator.Current;
                result.Add(item == null ? null : new AppRoleClaimReadModel()
                {
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Id = item.Id,
                    RoleId = item.RoleId,
                    ClaimType = item.ClaimType,
                    ClaimValue = item.ClaimValue
                });
            }
            return result;
            
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain55(ICollection<AppUserRole> p62)
        {
            if (p62 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p62.Count);
            
            IEnumerator<AppUserRole> enumerator = p62.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(funcMain56(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserTokenReadModel> funcMain59(ICollection<AppUserToken> p66)
        {
            if (p66 == null)
            {
                return null;
            }
            ICollection<AppUserTokenReadModel> result = new List<AppUserTokenReadModel>(p66.Count);
            
            IEnumerator<AppUserToken> enumerator = p66.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserToken item = enumerator.Current;
                result.Add(item == null ? null : new AppUserTokenReadModel()
                {
                    Token = item.Token,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    LoginProvider = item.LoginProvider,
                    Name = item.Name,
                    Value = item.Value
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRefreshTokenReadModel> funcMain60(ICollection<AppRefreshToken> p67)
        {
            if (p67 == null)
            {
                return null;
            }
            ICollection<AppRefreshTokenReadModel> result = new List<AppRefreshTokenReadModel>(p67.Count);
            
            IEnumerator<AppRefreshToken> enumerator = p67.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRefreshToken item = enumerator.Current;
                result.Add(item == null ? null : new AppRefreshTokenReadModel()
                {
                    UserId = item.UserId,
                    Token = item.Token,
                    JwtId = item.JwtId,
                    IsUsed = item.IsUsed,
                    IsRevoked = item.IsRevoked,
                    ExpiryDate = item.ExpiryDate,
                    Hash = item.Hash,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain67(ICollection<AppUserRole> p79)
        {
            if (p79 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p79.Count);
            
            IEnumerator<AppUserRole> enumerator = p79.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(funcMain68(item));
            }
            return result;
            
        }
        
        private static ICollection<AppRoleClaimReadModel> funcMain72(ICollection<AppRoleClaim> p84)
        {
            if (p84 == null)
            {
                return null;
            }
            ICollection<AppRoleClaimReadModel> result = new List<AppRoleClaimReadModel>(p84.Count);
            
            IEnumerator<AppRoleClaim> enumerator = p84.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRoleClaim item = enumerator.Current;
                result.Add(item == null ? null : new AppRoleClaimReadModel()
                {
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Id = item.Id,
                    RoleId = item.RoleId,
                    ClaimType = item.ClaimType,
                    ClaimValue = item.ClaimValue
                });
            }
            return result;
            
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain75(ICollection<AppUserRole> p87)
        {
            if (p87 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p87.Count);
            
            IEnumerator<AppUserRole> enumerator = p87.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(funcMain76(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserTokenReadModel> funcMain79(ICollection<AppUserToken> p91)
        {
            if (p91 == null)
            {
                return null;
            }
            ICollection<AppUserTokenReadModel> result = new List<AppUserTokenReadModel>(p91.Count);
            
            IEnumerator<AppUserToken> enumerator = p91.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserToken item = enumerator.Current;
                result.Add(item == null ? null : new AppUserTokenReadModel()
                {
                    Token = item.Token,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    LoginProvider = item.LoginProvider,
                    Name = item.Name,
                    Value = item.Value
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRefreshTokenReadModel> funcMain80(ICollection<AppRefreshToken> p92)
        {
            if (p92 == null)
            {
                return null;
            }
            ICollection<AppRefreshTokenReadModel> result = new List<AppRefreshTokenReadModel>(p92.Count);
            
            IEnumerator<AppRefreshToken> enumerator = p92.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRefreshToken item = enumerator.Current;
                result.Add(item == null ? null : new AppRefreshTokenReadModel()
                {
                    UserId = item.UserId,
                    Token = item.Token,
                    JwtId = item.JwtId,
                    IsUsed = item.IsUsed,
                    IsRevoked = item.IsRevoked,
                    ExpiryDate = item.ExpiryDate,
                    Hash = item.Hash,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static AppUserRoleReadModel funcMain8(AppUserRole p9)
        {
            return p9 == null ? null : new AppUserRoleReadModel()
            {
                AppUser = funcMain9(p9.AppUser),
                AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(p9.AppRole),
                Hash = p9.Hash,
                CreatedBy = p9.CreatedBy,
                CreatedDate = p9.CreatedDate,
                ModifiedBy = p9.ModifiedBy,
                ModifiedDate = p9.ModifiedDate,
                IsDeleted = p9.IsDeleted,
                DeletedBy = p9.DeletedBy,
                DeletedDate = p9.DeletedDate,
                UserId = p9.UserId,
                RoleId = p9.RoleId
            };
        }
        
        private static AppUserRoleReadModel funcMain16(AppUserRole p17)
        {
            return p17 == null ? null : new AppUserRoleReadModel()
            {
                AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(p17.AppUser),
                AppRole = funcMain17(p17.AppRole),
                Hash = p17.Hash,
                CreatedBy = p17.CreatedBy,
                CreatedDate = p17.CreatedDate,
                ModifiedBy = p17.ModifiedBy,
                ModifiedDate = p17.ModifiedDate,
                IsDeleted = p17.IsDeleted,
                DeletedBy = p17.DeletedBy,
                DeletedDate = p17.DeletedDate,
                UserId = p17.UserId,
                RoleId = p17.RoleId
            };
        }
        
        private static AppUserRoleReadModel funcMain28(AppUserRole p34)
        {
            return p34 == null ? null : new AppUserRoleReadModel()
            {
                AppUser = funcMain29(p34.AppUser),
                AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(p34.AppRole),
                Hash = p34.Hash,
                CreatedBy = p34.CreatedBy,
                CreatedDate = p34.CreatedDate,
                ModifiedBy = p34.ModifiedBy,
                ModifiedDate = p34.ModifiedDate,
                IsDeleted = p34.IsDeleted,
                DeletedBy = p34.DeletedBy,
                DeletedDate = p34.DeletedDate,
                UserId = p34.UserId,
                RoleId = p34.RoleId
            };
        }
        
        private static AppUserRoleReadModel funcMain36(AppUserRole p42)
        {
            return p42 == null ? null : new AppUserRoleReadModel()
            {
                AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(p42.AppUser),
                AppRole = funcMain37(p42.AppRole),
                Hash = p42.Hash,
                CreatedBy = p42.CreatedBy,
                CreatedDate = p42.CreatedDate,
                ModifiedBy = p42.ModifiedBy,
                ModifiedDate = p42.ModifiedDate,
                IsDeleted = p42.IsDeleted,
                DeletedBy = p42.DeletedBy,
                DeletedDate = p42.DeletedDate,
                UserId = p42.UserId,
                RoleId = p42.RoleId
            };
        }
        
        private static AppUserRoleReadModel funcMain48(AppUserRole p55)
        {
            return p55 == null ? null : new AppUserRoleReadModel()
            {
                AppUser = funcMain49(p55.AppUser),
                AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(p55.AppRole),
                Hash = p55.Hash,
                CreatedBy = p55.CreatedBy,
                CreatedDate = p55.CreatedDate,
                ModifiedBy = p55.ModifiedBy,
                ModifiedDate = p55.ModifiedDate,
                IsDeleted = p55.IsDeleted,
                DeletedBy = p55.DeletedBy,
                DeletedDate = p55.DeletedDate,
                UserId = p55.UserId,
                RoleId = p55.RoleId
            };
        }
        
        private static AppUserRoleReadModel funcMain56(AppUserRole p63)
        {
            return p63 == null ? null : new AppUserRoleReadModel()
            {
                AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(p63.AppUser),
                AppRole = funcMain57(p63.AppRole),
                Hash = p63.Hash,
                CreatedBy = p63.CreatedBy,
                CreatedDate = p63.CreatedDate,
                ModifiedBy = p63.ModifiedBy,
                ModifiedDate = p63.ModifiedDate,
                IsDeleted = p63.IsDeleted,
                DeletedBy = p63.DeletedBy,
                DeletedDate = p63.DeletedDate,
                UserId = p63.UserId,
                RoleId = p63.RoleId
            };
        }
        
        private static AppUserRoleReadModel funcMain68(AppUserRole p80)
        {
            return p80 == null ? null : new AppUserRoleReadModel()
            {
                AppUser = funcMain69(p80.AppUser),
                AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(p80.AppRole),
                Hash = p80.Hash,
                CreatedBy = p80.CreatedBy,
                CreatedDate = p80.CreatedDate,
                ModifiedBy = p80.ModifiedBy,
                ModifiedDate = p80.ModifiedDate,
                IsDeleted = p80.IsDeleted,
                DeletedBy = p80.DeletedBy,
                DeletedDate = p80.DeletedDate,
                UserId = p80.UserId,
                RoleId = p80.RoleId
            };
        }
        
        private static AppUserRoleReadModel funcMain76(AppUserRole p88)
        {
            return p88 == null ? null : new AppUserRoleReadModel()
            {
                AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(p88.AppUser),
                AppRole = funcMain77(p88.AppRole),
                Hash = p88.Hash,
                CreatedBy = p88.CreatedBy,
                CreatedDate = p88.CreatedDate,
                ModifiedBy = p88.ModifiedBy,
                ModifiedDate = p88.ModifiedDate,
                IsDeleted = p88.IsDeleted,
                DeletedBy = p88.DeletedBy,
                DeletedDate = p88.DeletedDate,
                UserId = p88.UserId,
                RoleId = p88.RoleId
            };
        }
        
        private static AppUserReadModel funcMain9(AppUser p10)
        {
            return p10 == null ? null : new AppUserReadModel()
            {
                Hash = p10.Hash,
                FirstName = p10.FirstName,
                LastName = p10.LastName,
                Mobile = p10.Mobile,
                CountryCode = p10.CountryCode,
                TwoFactorMethod = p10.TwoFactorMethod,
                CreatedBy = p10.CreatedBy,
                CreatedDate = p10.CreatedDate,
                ModifiedBy = p10.ModifiedBy,
                ModifiedDate = p10.ModifiedDate,
                IsDeleted = p10.IsDeleted,
                DeletedBy = p10.DeletedBy,
                DeletedDate = p10.DeletedDate,
                MembershipType = p10.MembershipType,
                UserRoles = TypeAdapter<ICollection<AppUserRole>, ICollection<AppUserRoleReadModel>>.Map.Invoke(p10.UserRoles),
                UserTokens = funcMain10(p10.UserTokens),
                RefreshTokens = funcMain11(p10.RefreshTokens),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p10.AccessControlEntries),
                Id = p10.Id,
                UserName = p10.UserName,
                NormalizedUserName = p10.NormalizedUserName,
                Email = p10.Email,
                NormalizedEmail = p10.NormalizedEmail,
                EmailConfirmed = p10.EmailConfirmed,
                PasswordHash = p10.PasswordHash,
                SecurityStamp = p10.SecurityStamp,
                ConcurrencyStamp = p10.ConcurrencyStamp,
                PhoneNumber = p10.PhoneNumber,
                PhoneNumberConfirmed = p10.PhoneNumberConfirmed,
                TwoFactorEnabled = p10.TwoFactorEnabled,
                LockoutEnd = p10.LockoutEnd,
                LockoutEnabled = p10.LockoutEnabled,
                AccessFailedCount = p10.AccessFailedCount
            };
        }
        
        private static AppRoleReadModel funcMain17(AppRole p18)
        {
            return p18 == null ? null : new AppRoleReadModel()
            {
                CreatedBy = p18.CreatedBy,
                CreatedDate = p18.CreatedDate,
                ModifiedBy = p18.ModifiedBy,
                ModifiedDate = p18.ModifiedDate,
                IsDeleted = p18.IsDeleted,
                DeletedBy = p18.DeletedBy,
                DeletedDate = p18.DeletedDate,
                AppUserRoles = TypeAdapter<ICollection<AppUserRole>, ICollection<AppUserRoleReadModel>>.Map.Invoke(p18.AppUserRoles),
                AppRoleClaims = funcMain18(p18.AppRoleClaims),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p18.AccessControlEntries),
                Hash = p18.Hash,
                Id = p18.Id,
                Name = p18.Name,
                NormalizedName = p18.NormalizedName,
                ConcurrencyStamp = p18.ConcurrencyStamp
            };
        }
        
        private static AppUserReadModel funcMain29(AppUser p35)
        {
            return p35 == null ? null : new AppUserReadModel()
            {
                Hash = p35.Hash,
                FirstName = p35.FirstName,
                LastName = p35.LastName,
                Mobile = p35.Mobile,
                CountryCode = p35.CountryCode,
                TwoFactorMethod = p35.TwoFactorMethod,
                CreatedBy = p35.CreatedBy,
                CreatedDate = p35.CreatedDate,
                ModifiedBy = p35.ModifiedBy,
                ModifiedDate = p35.ModifiedDate,
                IsDeleted = p35.IsDeleted,
                DeletedBy = p35.DeletedBy,
                DeletedDate = p35.DeletedDate,
                MembershipType = p35.MembershipType,
                UserRoles = TypeAdapter<ICollection<AppUserRole>, ICollection<AppUserRoleReadModel>>.Map.Invoke(p35.UserRoles),
                UserTokens = funcMain30(p35.UserTokens),
                RefreshTokens = funcMain31(p35.RefreshTokens),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p35.AccessControlEntries),
                Id = p35.Id,
                UserName = p35.UserName,
                NormalizedUserName = p35.NormalizedUserName,
                Email = p35.Email,
                NormalizedEmail = p35.NormalizedEmail,
                EmailConfirmed = p35.EmailConfirmed,
                PasswordHash = p35.PasswordHash,
                SecurityStamp = p35.SecurityStamp,
                ConcurrencyStamp = p35.ConcurrencyStamp,
                PhoneNumber = p35.PhoneNumber,
                PhoneNumberConfirmed = p35.PhoneNumberConfirmed,
                TwoFactorEnabled = p35.TwoFactorEnabled,
                LockoutEnd = p35.LockoutEnd,
                LockoutEnabled = p35.LockoutEnabled,
                AccessFailedCount = p35.AccessFailedCount
            };
        }
        
        private static AppRoleReadModel funcMain37(AppRole p43)
        {
            return p43 == null ? null : new AppRoleReadModel()
            {
                CreatedBy = p43.CreatedBy,
                CreatedDate = p43.CreatedDate,
                ModifiedBy = p43.ModifiedBy,
                ModifiedDate = p43.ModifiedDate,
                IsDeleted = p43.IsDeleted,
                DeletedBy = p43.DeletedBy,
                DeletedDate = p43.DeletedDate,
                AppUserRoles = TypeAdapter<ICollection<AppUserRole>, ICollection<AppUserRoleReadModel>>.Map.Invoke(p43.AppUserRoles),
                AppRoleClaims = funcMain38(p43.AppRoleClaims),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p43.AccessControlEntries),
                Hash = p43.Hash,
                Id = p43.Id,
                Name = p43.Name,
                NormalizedName = p43.NormalizedName,
                ConcurrencyStamp = p43.ConcurrencyStamp
            };
        }
        
        private static AppUserReadModel funcMain49(AppUser p56)
        {
            return p56 == null ? null : new AppUserReadModel()
            {
                Hash = p56.Hash,
                FirstName = p56.FirstName,
                LastName = p56.LastName,
                Mobile = p56.Mobile,
                CountryCode = p56.CountryCode,
                TwoFactorMethod = p56.TwoFactorMethod,
                CreatedBy = p56.CreatedBy,
                CreatedDate = p56.CreatedDate,
                ModifiedBy = p56.ModifiedBy,
                ModifiedDate = p56.ModifiedDate,
                IsDeleted = p56.IsDeleted,
                DeletedBy = p56.DeletedBy,
                DeletedDate = p56.DeletedDate,
                MembershipType = p56.MembershipType,
                UserRoles = TypeAdapter<ICollection<AppUserRole>, ICollection<AppUserRoleReadModel>>.Map.Invoke(p56.UserRoles),
                UserTokens = funcMain50(p56.UserTokens),
                RefreshTokens = funcMain51(p56.RefreshTokens),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p56.AccessControlEntries),
                Id = p56.Id,
                UserName = p56.UserName,
                NormalizedUserName = p56.NormalizedUserName,
                Email = p56.Email,
                NormalizedEmail = p56.NormalizedEmail,
                EmailConfirmed = p56.EmailConfirmed,
                PasswordHash = p56.PasswordHash,
                SecurityStamp = p56.SecurityStamp,
                ConcurrencyStamp = p56.ConcurrencyStamp,
                PhoneNumber = p56.PhoneNumber,
                PhoneNumberConfirmed = p56.PhoneNumberConfirmed,
                TwoFactorEnabled = p56.TwoFactorEnabled,
                LockoutEnd = p56.LockoutEnd,
                LockoutEnabled = p56.LockoutEnabled,
                AccessFailedCount = p56.AccessFailedCount
            };
        }
        
        private static AppRoleReadModel funcMain57(AppRole p64)
        {
            return p64 == null ? null : new AppRoleReadModel()
            {
                CreatedBy = p64.CreatedBy,
                CreatedDate = p64.CreatedDate,
                ModifiedBy = p64.ModifiedBy,
                ModifiedDate = p64.ModifiedDate,
                IsDeleted = p64.IsDeleted,
                DeletedBy = p64.DeletedBy,
                DeletedDate = p64.DeletedDate,
                AppUserRoles = TypeAdapter<ICollection<AppUserRole>, ICollection<AppUserRoleReadModel>>.Map.Invoke(p64.AppUserRoles),
                AppRoleClaims = funcMain58(p64.AppRoleClaims),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p64.AccessControlEntries),
                Hash = p64.Hash,
                Id = p64.Id,
                Name = p64.Name,
                NormalizedName = p64.NormalizedName,
                ConcurrencyStamp = p64.ConcurrencyStamp
            };
        }
        
        private static AppUserReadModel funcMain69(AppUser p81)
        {
            return p81 == null ? null : new AppUserReadModel()
            {
                Hash = p81.Hash,
                FirstName = p81.FirstName,
                LastName = p81.LastName,
                Mobile = p81.Mobile,
                CountryCode = p81.CountryCode,
                TwoFactorMethod = p81.TwoFactorMethod,
                CreatedBy = p81.CreatedBy,
                CreatedDate = p81.CreatedDate,
                ModifiedBy = p81.ModifiedBy,
                ModifiedDate = p81.ModifiedDate,
                IsDeleted = p81.IsDeleted,
                DeletedBy = p81.DeletedBy,
                DeletedDate = p81.DeletedDate,
                MembershipType = p81.MembershipType,
                UserRoles = TypeAdapter<ICollection<AppUserRole>, ICollection<AppUserRoleReadModel>>.Map.Invoke(p81.UserRoles),
                UserTokens = funcMain70(p81.UserTokens),
                RefreshTokens = funcMain71(p81.RefreshTokens),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p81.AccessControlEntries),
                Id = p81.Id,
                UserName = p81.UserName,
                NormalizedUserName = p81.NormalizedUserName,
                Email = p81.Email,
                NormalizedEmail = p81.NormalizedEmail,
                EmailConfirmed = p81.EmailConfirmed,
                PasswordHash = p81.PasswordHash,
                SecurityStamp = p81.SecurityStamp,
                ConcurrencyStamp = p81.ConcurrencyStamp,
                PhoneNumber = p81.PhoneNumber,
                PhoneNumberConfirmed = p81.PhoneNumberConfirmed,
                TwoFactorEnabled = p81.TwoFactorEnabled,
                LockoutEnd = p81.LockoutEnd,
                LockoutEnabled = p81.LockoutEnabled,
                AccessFailedCount = p81.AccessFailedCount
            };
        }
        
        private static AppRoleReadModel funcMain77(AppRole p89)
        {
            return p89 == null ? null : new AppRoleReadModel()
            {
                CreatedBy = p89.CreatedBy,
                CreatedDate = p89.CreatedDate,
                ModifiedBy = p89.ModifiedBy,
                ModifiedDate = p89.ModifiedDate,
                IsDeleted = p89.IsDeleted,
                DeletedBy = p89.DeletedBy,
                DeletedDate = p89.DeletedDate,
                AppUserRoles = TypeAdapter<ICollection<AppUserRole>, ICollection<AppUserRoleReadModel>>.Map.Invoke(p89.AppUserRoles),
                AppRoleClaims = funcMain78(p89.AppRoleClaims),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p89.AccessControlEntries),
                Hash = p89.Hash,
                Id = p89.Id,
                Name = p89.Name,
                NormalizedName = p89.NormalizedName,
                ConcurrencyStamp = p89.ConcurrencyStamp
            };
        }
        
        private static ICollection<AppUserTokenReadModel> funcMain10(ICollection<AppUserToken> p11)
        {
            if (p11 == null)
            {
                return null;
            }
            ICollection<AppUserTokenReadModel> result = new List<AppUserTokenReadModel>(p11.Count);
            
            IEnumerator<AppUserToken> enumerator = p11.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserToken item = enumerator.Current;
                result.Add(item == null ? null : new AppUserTokenReadModel()
                {
                    Token = item.Token,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    LoginProvider = item.LoginProvider,
                    Name = item.Name,
                    Value = item.Value
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRefreshTokenReadModel> funcMain11(ICollection<AppRefreshToken> p12)
        {
            if (p12 == null)
            {
                return null;
            }
            ICollection<AppRefreshTokenReadModel> result = new List<AppRefreshTokenReadModel>(p12.Count);
            
            IEnumerator<AppRefreshToken> enumerator = p12.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRefreshToken item = enumerator.Current;
                result.Add(item == null ? null : new AppRefreshTokenReadModel()
                {
                    UserId = item.UserId,
                    Token = item.Token,
                    JwtId = item.JwtId,
                    IsUsed = item.IsUsed,
                    IsRevoked = item.IsRevoked,
                    ExpiryDate = item.ExpiryDate,
                    Hash = item.Hash,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRoleClaimReadModel> funcMain18(ICollection<AppRoleClaim> p19)
        {
            if (p19 == null)
            {
                return null;
            }
            ICollection<AppRoleClaimReadModel> result = new List<AppRoleClaimReadModel>(p19.Count);
            
            IEnumerator<AppRoleClaim> enumerator = p19.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRoleClaim item = enumerator.Current;
                result.Add(item == null ? null : new AppRoleClaimReadModel()
                {
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Id = item.Id,
                    RoleId = item.RoleId,
                    ClaimType = item.ClaimType,
                    ClaimValue = item.ClaimValue
                });
            }
            return result;
            
        }
        
        private static ICollection<AppUserTokenReadModel> funcMain30(ICollection<AppUserToken> p36)
        {
            if (p36 == null)
            {
                return null;
            }
            ICollection<AppUserTokenReadModel> result = new List<AppUserTokenReadModel>(p36.Count);
            
            IEnumerator<AppUserToken> enumerator = p36.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserToken item = enumerator.Current;
                result.Add(item == null ? null : new AppUserTokenReadModel()
                {
                    Token = item.Token,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    LoginProvider = item.LoginProvider,
                    Name = item.Name,
                    Value = item.Value
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRefreshTokenReadModel> funcMain31(ICollection<AppRefreshToken> p37)
        {
            if (p37 == null)
            {
                return null;
            }
            ICollection<AppRefreshTokenReadModel> result = new List<AppRefreshTokenReadModel>(p37.Count);
            
            IEnumerator<AppRefreshToken> enumerator = p37.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRefreshToken item = enumerator.Current;
                result.Add(item == null ? null : new AppRefreshTokenReadModel()
                {
                    UserId = item.UserId,
                    Token = item.Token,
                    JwtId = item.JwtId,
                    IsUsed = item.IsUsed,
                    IsRevoked = item.IsRevoked,
                    ExpiryDate = item.ExpiryDate,
                    Hash = item.Hash,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRoleClaimReadModel> funcMain38(ICollection<AppRoleClaim> p44)
        {
            if (p44 == null)
            {
                return null;
            }
            ICollection<AppRoleClaimReadModel> result = new List<AppRoleClaimReadModel>(p44.Count);
            
            IEnumerator<AppRoleClaim> enumerator = p44.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRoleClaim item = enumerator.Current;
                result.Add(item == null ? null : new AppRoleClaimReadModel()
                {
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Id = item.Id,
                    RoleId = item.RoleId,
                    ClaimType = item.ClaimType,
                    ClaimValue = item.ClaimValue
                });
            }
            return result;
            
        }
        
        private static ICollection<AppUserTokenReadModel> funcMain50(ICollection<AppUserToken> p57)
        {
            if (p57 == null)
            {
                return null;
            }
            ICollection<AppUserTokenReadModel> result = new List<AppUserTokenReadModel>(p57.Count);
            
            IEnumerator<AppUserToken> enumerator = p57.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserToken item = enumerator.Current;
                result.Add(item == null ? null : new AppUserTokenReadModel()
                {
                    Token = item.Token,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    LoginProvider = item.LoginProvider,
                    Name = item.Name,
                    Value = item.Value
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRefreshTokenReadModel> funcMain51(ICollection<AppRefreshToken> p58)
        {
            if (p58 == null)
            {
                return null;
            }
            ICollection<AppRefreshTokenReadModel> result = new List<AppRefreshTokenReadModel>(p58.Count);
            
            IEnumerator<AppRefreshToken> enumerator = p58.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRefreshToken item = enumerator.Current;
                result.Add(item == null ? null : new AppRefreshTokenReadModel()
                {
                    UserId = item.UserId,
                    Token = item.Token,
                    JwtId = item.JwtId,
                    IsUsed = item.IsUsed,
                    IsRevoked = item.IsRevoked,
                    ExpiryDate = item.ExpiryDate,
                    Hash = item.Hash,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRoleClaimReadModel> funcMain58(ICollection<AppRoleClaim> p65)
        {
            if (p65 == null)
            {
                return null;
            }
            ICollection<AppRoleClaimReadModel> result = new List<AppRoleClaimReadModel>(p65.Count);
            
            IEnumerator<AppRoleClaim> enumerator = p65.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRoleClaim item = enumerator.Current;
                result.Add(item == null ? null : new AppRoleClaimReadModel()
                {
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Id = item.Id,
                    RoleId = item.RoleId,
                    ClaimType = item.ClaimType,
                    ClaimValue = item.ClaimValue
                });
            }
            return result;
            
        }
        
        private static ICollection<AppUserTokenReadModel> funcMain70(ICollection<AppUserToken> p82)
        {
            if (p82 == null)
            {
                return null;
            }
            ICollection<AppUserTokenReadModel> result = new List<AppUserTokenReadModel>(p82.Count);
            
            IEnumerator<AppUserToken> enumerator = p82.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserToken item = enumerator.Current;
                result.Add(item == null ? null : new AppUserTokenReadModel()
                {
                    Token = item.Token,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    LoginProvider = item.LoginProvider,
                    Name = item.Name,
                    Value = item.Value
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRefreshTokenReadModel> funcMain71(ICollection<AppRefreshToken> p83)
        {
            if (p83 == null)
            {
                return null;
            }
            ICollection<AppRefreshTokenReadModel> result = new List<AppRefreshTokenReadModel>(p83.Count);
            
            IEnumerator<AppRefreshToken> enumerator = p83.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRefreshToken item = enumerator.Current;
                result.Add(item == null ? null : new AppRefreshTokenReadModel()
                {
                    UserId = item.UserId,
                    Token = item.Token,
                    JwtId = item.JwtId,
                    IsUsed = item.IsUsed,
                    IsRevoked = item.IsRevoked,
                    ExpiryDate = item.ExpiryDate,
                    Hash = item.Hash,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRoleClaimReadModel> funcMain78(ICollection<AppRoleClaim> p90)
        {
            if (p90 == null)
            {
                return null;
            }
            ICollection<AppRoleClaimReadModel> result = new List<AppRoleClaimReadModel>(p90.Count);
            
            IEnumerator<AppRoleClaim> enumerator = p90.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRoleClaim item = enumerator.Current;
                result.Add(item == null ? null : new AppRoleClaimReadModel()
                {
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Id = item.Id,
                    RoleId = item.RoleId,
                    ClaimType = item.ClaimType,
                    ClaimValue = item.ClaimValue
                });
            }
            return result;
            
        }
    }
}