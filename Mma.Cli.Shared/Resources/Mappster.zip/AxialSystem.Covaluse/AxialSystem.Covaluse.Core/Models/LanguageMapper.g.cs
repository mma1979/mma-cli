using System.Collections.Generic;
using AxialSystem.Covaluse.Core.Database.Localization;
using Mapster;

namespace AxialSystem.Covaluse.Core.Database.Localization
{
    public static partial class LanguageMapper
    {
        public static LanguageReadModel AdaptToReadModel(this Language p1)
        {
            return p1 == null ? null : new LanguageReadModel()
            {
                Id = p1.Id,
                LanguageCode = p1.LanguageCode,
                LanguageName = p1.LanguageName,
                Resources = funcMain1(p1.Resources)
            };
        }
        public static LanguageReadModel AdaptTo(this Language p3, LanguageReadModel p4)
        {
            if (p3 == null)
            {
                return null;
            }
            LanguageReadModel result = p4 ?? new LanguageReadModel();
            
            result.Id = p3.Id;
            result.LanguageCode = p3.LanguageCode;
            result.LanguageName = p3.LanguageName;
            result.Resources = funcMain2(p3.Resources, result.Resources);
            return result;
            
        }
        public static LanguageModifyModel AdaptToModifyModel(this Language p7)
        {
            return p7 == null ? null : new LanguageModifyModel()
            {
                Id = p7.Id,
                LanguageCode = p7.LanguageCode,
                LanguageName = p7.LanguageName,
                Resources = funcMain3(p7.Resources)
            };
        }
        public static LanguageModifyModel AdaptTo(this Language p9, LanguageModifyModel p10)
        {
            if (p9 == null)
            {
                return null;
            }
            LanguageModifyModel result = p10 ?? new LanguageModifyModel();
            
            result.Id = p9.Id;
            result.LanguageCode = p9.LanguageCode;
            result.LanguageName = p9.LanguageName;
            result.Resources = funcMain4(p9.Resources, result.Resources);
            return result;
            
        }
        
        private static ICollection<ResourceReadModel> funcMain1(ICollection<Resource> p2)
        {
            if (p2 == null)
            {
                return null;
            }
            ICollection<ResourceReadModel> result = new List<ResourceReadModel>(p2.Count);
            
            IEnumerator<Resource> enumerator = p2.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                Resource item = enumerator.Current;
                result.Add(item == null ? null : new ResourceReadModel()
                {
                    Id = item.Id,
                    LanguageId = item.LanguageId,
                    Key = item.Key,
                    Value = item.Value,
                    Language = TypeAdapter<Language, LanguageReadModel>.Map.Invoke(item.Language)
                });
            }
            return result;
            
        }
        
        private static ICollection<ResourceReadModel> funcMain2(ICollection<Resource> p5, ICollection<ResourceReadModel> p6)
        {
            if (p5 == null)
            {
                return null;
            }
            ICollection<ResourceReadModel> result = new List<ResourceReadModel>(p5.Count);
            
            IEnumerator<Resource> enumerator = p5.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                Resource item = enumerator.Current;
                result.Add(item == null ? null : new ResourceReadModel()
                {
                    Id = item.Id,
                    LanguageId = item.LanguageId,
                    Key = item.Key,
                    Value = item.Value,
                    Language = TypeAdapter<Language, LanguageReadModel>.Map.Invoke(item.Language)
                });
            }
            return result;
            
        }
        
        private static ICollection<ResourceReadModel> funcMain3(ICollection<Resource> p8)
        {
            if (p8 == null)
            {
                return null;
            }
            ICollection<ResourceReadModel> result = new List<ResourceReadModel>(p8.Count);
            
            IEnumerator<Resource> enumerator = p8.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                Resource item = enumerator.Current;
                result.Add(item == null ? null : new ResourceReadModel()
                {
                    Id = item.Id,
                    LanguageId = item.LanguageId,
                    Key = item.Key,
                    Value = item.Value,
                    Language = item.Language == null ? null : new LanguageReadModel()
                    {
                        Id = item.Language.Id,
                        LanguageCode = item.Language.LanguageCode,
                        LanguageName = item.Language.LanguageName,
                        Resources = TypeAdapter<ICollection<Resource>, ICollection<ResourceReadModel>>.Map.Invoke(item.Language.Resources)
                    }
                });
            }
            return result;
            
        }
        
        private static ICollection<ResourceReadModel> funcMain4(ICollection<Resource> p11, ICollection<ResourceReadModel> p12)
        {
            if (p11 == null)
            {
                return null;
            }
            ICollection<ResourceReadModel> result = new List<ResourceReadModel>(p11.Count);
            
            IEnumerator<Resource> enumerator = p11.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                Resource item = enumerator.Current;
                result.Add(item == null ? null : new ResourceReadModel()
                {
                    Id = item.Id,
                    LanguageId = item.LanguageId,
                    Key = item.Key,
                    Value = item.Value,
                    Language = item.Language == null ? null : new LanguageReadModel()
                    {
                        Id = item.Language.Id,
                        LanguageCode = item.Language.LanguageCode,
                        LanguageName = item.Language.LanguageName,
                        Resources = TypeAdapter<ICollection<Resource>, ICollection<ResourceReadModel>>.Map.Invoke(item.Language.Resources)
                    }
                });
            }
            return result;
            
        }
    }
}