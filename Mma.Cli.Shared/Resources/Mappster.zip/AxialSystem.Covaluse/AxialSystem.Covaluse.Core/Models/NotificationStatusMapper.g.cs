using AxialSystem.Covaluse.Core.Database.Notifications;

namespace AxialSystem.Covaluse.Core.Database.Notifications
{
    public static partial class NotificationStatusMapper
    {
        public static NotificationStatusReadModel AdaptToReadModel(this NotificationStatus p1)
        {
            return p1 == null ? null : new NotificationStatusReadModel()
            {
                Name = p1.Name,
                Description = p1.Description,
                Hash = p1.Hash,
                Id = p1.Id,
                CreatedBy = p1.CreatedBy,
                CreatedDate = p1.CreatedDate,
                ModifiedBy = p1.ModifiedBy,
                ModifiedDate = p1.ModifiedDate,
                IsDeleted = p1.IsDeleted,
                DeletedBy = p1.DeletedBy,
                DeletedDate = p1.DeletedDate
            };
        }
        public static NotificationStatusReadModel AdaptTo(this NotificationStatus p2, NotificationStatusReadModel p3)
        {
            if (p2 == null)
            {
                return null;
            }
            NotificationStatusReadModel result = p3 ?? new NotificationStatusReadModel();
            
            result.Name = p2.Name;
            result.Description = p2.Description;
            result.Hash = p2.Hash;
            result.Id = p2.Id;
            result.CreatedBy = p2.CreatedBy;
            result.CreatedDate = p2.CreatedDate;
            result.ModifiedBy = p2.ModifiedBy;
            result.ModifiedDate = p2.ModifiedDate;
            result.IsDeleted = p2.IsDeleted;
            result.DeletedBy = p2.DeletedBy;
            result.DeletedDate = p2.DeletedDate;
            return result;
            
        }
        public static NotificationStatusModifyModel AdaptToModifyModel(this NotificationStatus p4)
        {
            return p4 == null ? null : new NotificationStatusModifyModel()
            {
                Name = p4.Name,
                Description = p4.Description,
                Hash = p4.Hash,
                Id = p4.Id,
                CreatedBy = p4.CreatedBy,
                CreatedDate = p4.CreatedDate,
                ModifiedBy = p4.ModifiedBy,
                ModifiedDate = p4.ModifiedDate,
                IsDeleted = p4.IsDeleted,
                DeletedBy = p4.DeletedBy,
                DeletedDate = p4.DeletedDate
            };
        }
        public static NotificationStatusModifyModel AdaptTo(this NotificationStatus p5, NotificationStatusModifyModel p6)
        {
            if (p5 == null)
            {
                return null;
            }
            NotificationStatusModifyModel result = p6 ?? new NotificationStatusModifyModel();
            
            result.Name = p5.Name;
            result.Description = p5.Description;
            result.Hash = p5.Hash;
            result.Id = p5.Id;
            result.CreatedBy = p5.CreatedBy;
            result.CreatedDate = p5.CreatedDate;
            result.ModifiedBy = p5.ModifiedBy;
            result.ModifiedDate = p5.ModifiedDate;
            result.IsDeleted = p5.IsDeleted;
            result.DeletedBy = p5.DeletedBy;
            result.DeletedDate = p5.DeletedDate;
            return result;
            
        }
    }
}