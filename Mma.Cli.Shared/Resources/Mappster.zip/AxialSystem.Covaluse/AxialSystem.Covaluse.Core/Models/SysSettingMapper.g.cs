using AxialSystem.Covaluse.Core.Database.Tables;

namespace AxialSystem.Covaluse.Core.Database.Tables
{
    public static partial class SysSettingMapper
    {
        public static SysSettingReadModel AdaptToReadModel(this SysSetting p1)
        {
            return p1 == null ? null : new SysSettingReadModel()
            {
                SysKey = p1.SysKey,
                SysValue = p1.SysValue,
                Id = p1.Id,
                CreatedBy = p1.CreatedBy,
                CreatedDate = p1.CreatedDate,
                ModifiedBy = p1.ModifiedBy,
                ModifiedDate = p1.ModifiedDate,
                IsDeleted = p1.IsDeleted,
                DeletedBy = p1.DeletedBy,
                DeletedDate = p1.DeletedDate
            };
        }
        public static SysSettingReadModel AdaptTo(this SysSetting p2, SysSettingReadModel p3)
        {
            if (p2 == null)
            {
                return null;
            }
            SysSettingReadModel result = p3 ?? new SysSettingReadModel();
            
            result.SysKey = p2.SysKey;
            result.SysValue = p2.SysValue;
            result.Id = p2.Id;
            result.CreatedBy = p2.CreatedBy;
            result.CreatedDate = p2.CreatedDate;
            result.ModifiedBy = p2.ModifiedBy;
            result.ModifiedDate = p2.ModifiedDate;
            result.IsDeleted = p2.IsDeleted;
            result.DeletedBy = p2.DeletedBy;
            result.DeletedDate = p2.DeletedDate;
            return result;
            
        }
        public static SysSettingModifyModel AdaptToModifyModel(this SysSetting p4)
        {
            return p4 == null ? null : new SysSettingModifyModel()
            {
                SysKey = p4.SysKey,
                SysValue = p4.SysValue,
                Id = p4.Id,
                CreatedBy = p4.CreatedBy,
                CreatedDate = p4.CreatedDate,
                ModifiedBy = p4.ModifiedBy,
                ModifiedDate = p4.ModifiedDate,
                IsDeleted = p4.IsDeleted,
                DeletedBy = p4.DeletedBy,
                DeletedDate = p4.DeletedDate
            };
        }
        public static SysSettingModifyModel AdaptTo(this SysSetting p5, SysSettingModifyModel p6)
        {
            if (p5 == null)
            {
                return null;
            }
            SysSettingModifyModel result = p6 ?? new SysSettingModifyModel();
            
            result.SysKey = p5.SysKey;
            result.SysValue = p5.SysValue;
            result.Id = p5.Id;
            result.CreatedBy = p5.CreatedBy;
            result.CreatedDate = p5.CreatedDate;
            result.ModifiedBy = p5.ModifiedBy;
            result.ModifiedDate = p5.ModifiedDate;
            result.IsDeleted = p5.IsDeleted;
            result.DeletedBy = p5.DeletedBy;
            result.DeletedDate = p5.DeletedDate;
            return result;
            
        }
    }
}