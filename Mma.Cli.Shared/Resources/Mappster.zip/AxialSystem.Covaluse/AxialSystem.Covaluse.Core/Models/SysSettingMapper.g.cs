using AxialSystem.Covaluse.Core.Database.Tables;

namespace AxialSystem.Covaluse.Core.Database.Tables
{
    public static partial class SysSettingMapper
    {
        public static SysSettingDto AdaptToDto(this SysSetting p1)
        {
            return p1 == null ? null : new SysSettingDto()
            {
                SysKey = p1.SysKey,
                SysValue = p1.SysValue,
                Enviroment = p1.Enviroment,
                Id = p1.Id,
                CreatedBy = p1.CreatedBy,
                CreatedDate = p1.CreatedDate,
                ModifiedBy = p1.ModifiedBy,
                ModifiedDate = p1.ModifiedDate,
                IsDeleted = p1.IsDeleted,
                DeletedBy = p1.DeletedBy,
                DeletedDate = p1.DeletedDate
            };
        }
        public static SysSettingDto AdaptTo(this SysSetting p2, SysSettingDto p3)
        {
            if (p2 == null)
            {
                return null;
            }
            SysSettingDto result = p3 ?? new SysSettingDto();
            
            result.SysKey = p2.SysKey;
            result.SysValue = p2.SysValue;
            result.Enviroment = p2.Enviroment;
            result.Id = p2.Id;
            result.CreatedBy = p2.CreatedBy;
            result.CreatedDate = p2.CreatedDate;
            result.ModifiedBy = p2.ModifiedBy;
            result.ModifiedDate = p2.ModifiedDate;
            result.IsDeleted = p2.IsDeleted;
            result.DeletedBy = p2.DeletedBy;
            result.DeletedDate = p2.DeletedDate;
            return result;
            
        }
    }
}