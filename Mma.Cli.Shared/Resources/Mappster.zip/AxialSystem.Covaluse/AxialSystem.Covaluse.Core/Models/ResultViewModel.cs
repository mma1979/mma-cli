﻿using System.Collections.Generic;

namespace AxialSystem.Covaluse.Core.Models
{
    public class ResultViewModel<T>
    {
        public long Total { get; set; }
        public int PageNumber { get; set; }
        public int PageSize { get; set; }
        public string Filter { get; set; }
        public T Data { get; set; }
        public List<string> Messages { get; set; }
        public bool IsSuccess { get; set; }
        public int StatusCode { get; set; }
        public ResultViewModel()
        {
            Messages = new List<string>();
        }
    }

    public class AcknowledgeViewModel
    {
        public List<string> Messages { get; set; }
        public bool IsSuccess { get; set; }
        public int StatusCode { get; set; }
        public AcknowledgeViewModel()
        {
            Messages = new List<string>();
        }
    }
}
