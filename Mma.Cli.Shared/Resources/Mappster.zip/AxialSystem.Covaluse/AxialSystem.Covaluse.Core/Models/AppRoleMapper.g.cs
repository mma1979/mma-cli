using System.Collections.Generic;
using AxialSystem.Covaluse.Core.Database.Identity;
using Mapster;

namespace AxialSystem.Covaluse.Core.Database.Identity
{
    public static partial class AppRoleMapper
    {
        public static AppRoleReadModel AdaptToReadModel(this AppRole p1)
        {
            return p1 == null ? null : new AppRoleReadModel()
            {
                CreatedBy = p1.CreatedBy,
                CreatedDate = p1.CreatedDate,
                ModifiedBy = p1.ModifiedBy,
                ModifiedDate = p1.ModifiedDate,
                IsDeleted = p1.IsDeleted,
                DeletedBy = p1.DeletedBy,
                DeletedDate = p1.DeletedDate,
                AppUserRoles = funcMain1(p1.AppUserRoles),
                AppRoleClaims = funcMain12(p1.AppRoleClaims),
                AccessControlEntries = funcMain13(p1.AccessControlEntries),
                Hash = p1.Hash,
                Id = p1.Id,
                Name = p1.Name,
                NormalizedName = p1.NormalizedName,
                ConcurrencyStamp = p1.ConcurrencyStamp
            };
        }
        public static AppRoleReadModel AdaptTo(this AppRole p24, AppRoleReadModel p25)
        {
            if (p24 == null)
            {
                return null;
            }
            AppRoleReadModel result = p25 ?? new AppRoleReadModel();
            
            result.CreatedBy = p24.CreatedBy;
            result.CreatedDate = p24.CreatedDate;
            result.ModifiedBy = p24.ModifiedBy;
            result.ModifiedDate = p24.ModifiedDate;
            result.IsDeleted = p24.IsDeleted;
            result.DeletedBy = p24.DeletedBy;
            result.DeletedDate = p24.DeletedDate;
            result.AppUserRoles = funcMain23(p24.AppUserRoles, result.AppUserRoles);
            result.AppRoleClaims = funcMain34(p24.AppRoleClaims, result.AppRoleClaims);
            result.AccessControlEntries = funcMain35(p24.AccessControlEntries, result.AccessControlEntries);
            result.Hash = p24.Hash;
            result.Id = p24.Id;
            result.Name = p24.Name;
            result.NormalizedName = p24.NormalizedName;
            result.ConcurrencyStamp = p24.ConcurrencyStamp;
            return result;
            
        }
        public static AppRoleModifyModel AdaptToModifyModel(this AppRole p51)
        {
            return p51 == null ? null : new AppRoleModifyModel()
            {
                CreatedBy = p51.CreatedBy,
                CreatedDate = p51.CreatedDate,
                ModifiedBy = p51.ModifiedBy,
                ModifiedDate = p51.ModifiedDate,
                IsDeleted = p51.IsDeleted,
                DeletedBy = p51.DeletedBy,
                DeletedDate = p51.DeletedDate,
                AppUserRoles = funcMain45(p51.AppUserRoles),
                AppRoleClaims = funcMain69(p51.AppRoleClaims),
                AccessControlEntries = funcMain93(p51.AccessControlEntries),
                Hash = p51.Hash,
                Id = p51.Id,
                Name = p51.Name,
                NormalizedName = p51.NormalizedName,
                ConcurrencyStamp = p51.ConcurrencyStamp
            };
        }
        public static AppRoleModifyModel AdaptTo(this AppRole p120, AppRoleModifyModel p121)
        {
            if (p120 == null)
            {
                return null;
            }
            AppRoleModifyModel result = p121 ?? new AppRoleModifyModel();
            
            result.CreatedBy = p120.CreatedBy;
            result.CreatedDate = p120.CreatedDate;
            result.ModifiedBy = p120.ModifiedBy;
            result.ModifiedDate = p120.ModifiedDate;
            result.IsDeleted = p120.IsDeleted;
            result.DeletedBy = p120.DeletedBy;
            result.DeletedDate = p120.DeletedDate;
            result.AppUserRoles = funcMain113(p120.AppUserRoles, result.AppUserRoles);
            result.AppRoleClaims = funcMain137(p120.AppRoleClaims, result.AppRoleClaims);
            result.AccessControlEntries = funcMain161(p120.AccessControlEntries, result.AccessControlEntries);
            result.Hash = p120.Hash;
            result.Id = p120.Id;
            result.Name = p120.Name;
            result.NormalizedName = p120.NormalizedName;
            result.ConcurrencyStamp = p120.ConcurrencyStamp;
            return result;
            
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain1(ICollection<AppUserRole> p2)
        {
            if (p2 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p2.Count);
            
            IEnumerator<AppUserRole> enumerator = p2.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(funcMain2(item));
            }
            return result;
            
        }
        
        private static ICollection<AppRoleClaimReadModel> funcMain12(ICollection<AppRoleClaim> p13)
        {
            if (p13 == null)
            {
                return null;
            }
            ICollection<AppRoleClaimReadModel> result = new List<AppRoleClaimReadModel>(p13.Count);
            
            IEnumerator<AppRoleClaim> enumerator = p13.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRoleClaim item = enumerator.Current;
                result.Add(item == null ? null : new AppRoleClaimReadModel()
                {
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Id = item.Id,
                    RoleId = item.RoleId,
                    ClaimType = item.ClaimType,
                    ClaimValue = item.ClaimValue
                });
            }
            return result;
            
        }
        
        private static ICollection<AppAccessControlEntryReadModel> funcMain13(ICollection<AppAccessControlEntry> p14)
        {
            if (p14 == null)
            {
                return null;
            }
            ICollection<AppAccessControlEntryReadModel> result = new List<AppAccessControlEntryReadModel>(p14.Count);
            
            IEnumerator<AppAccessControlEntry> enumerator = p14.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppAccessControlEntry item = enumerator.Current;
                result.Add(funcMain14(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain23(ICollection<AppUserRole> p26, ICollection<AppUserRoleReadModel> p27)
        {
            if (p26 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p26.Count);
            
            IEnumerator<AppUserRole> enumerator = p26.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(funcMain24(item));
            }
            return result;
            
        }
        
        private static ICollection<AppRoleClaimReadModel> funcMain34(ICollection<AppRoleClaim> p38, ICollection<AppRoleClaimReadModel> p39)
        {
            if (p38 == null)
            {
                return null;
            }
            ICollection<AppRoleClaimReadModel> result = new List<AppRoleClaimReadModel>(p38.Count);
            
            IEnumerator<AppRoleClaim> enumerator = p38.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRoleClaim item = enumerator.Current;
                result.Add(item == null ? null : new AppRoleClaimReadModel()
                {
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Id = item.Id,
                    RoleId = item.RoleId,
                    ClaimType = item.ClaimType,
                    ClaimValue = item.ClaimValue
                });
            }
            return result;
            
        }
        
        private static ICollection<AppAccessControlEntryReadModel> funcMain35(ICollection<AppAccessControlEntry> p40, ICollection<AppAccessControlEntryReadModel> p41)
        {
            if (p40 == null)
            {
                return null;
            }
            ICollection<AppAccessControlEntryReadModel> result = new List<AppAccessControlEntryReadModel>(p40.Count);
            
            IEnumerator<AppAccessControlEntry> enumerator = p40.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppAccessControlEntry item = enumerator.Current;
                result.Add(funcMain36(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain45(ICollection<AppUserRole> p52)
        {
            if (p52 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p52.Count);
            
            IEnumerator<AppUserRole> enumerator = p52.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(funcMain46(item));
            }
            return result;
            
        }
        
        private static ICollection<AppRoleClaimReadModel> funcMain69(ICollection<AppRoleClaim> p76)
        {
            if (p76 == null)
            {
                return null;
            }
            ICollection<AppRoleClaimReadModel> result = new List<AppRoleClaimReadModel>(p76.Count);
            
            IEnumerator<AppRoleClaim> enumerator = p76.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRoleClaim item = enumerator.Current;
                result.Add(funcMain70(item));
            }
            return result;
            
        }
        
        private static ICollection<AppAccessControlEntryReadModel> funcMain93(ICollection<AppAccessControlEntry> p100)
        {
            if (p100 == null)
            {
                return null;
            }
            ICollection<AppAccessControlEntryReadModel> result = new List<AppAccessControlEntryReadModel>(p100.Count);
            
            IEnumerator<AppAccessControlEntry> enumerator = p100.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppAccessControlEntry item = enumerator.Current;
                result.Add(funcMain94(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain113(ICollection<AppUserRole> p122, ICollection<AppUserRoleReadModel> p123)
        {
            if (p122 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p122.Count);
            
            IEnumerator<AppUserRole> enumerator = p122.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(funcMain114(item));
            }
            return result;
            
        }
        
        private static ICollection<AppRoleClaimReadModel> funcMain137(ICollection<AppRoleClaim> p147, ICollection<AppRoleClaimReadModel> p148)
        {
            if (p147 == null)
            {
                return null;
            }
            ICollection<AppRoleClaimReadModel> result = new List<AppRoleClaimReadModel>(p147.Count);
            
            IEnumerator<AppRoleClaim> enumerator = p147.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRoleClaim item = enumerator.Current;
                result.Add(funcMain138(item));
            }
            return result;
            
        }
        
        private static ICollection<AppAccessControlEntryReadModel> funcMain161(ICollection<AppAccessControlEntry> p172, ICollection<AppAccessControlEntryReadModel> p173)
        {
            if (p172 == null)
            {
                return null;
            }
            ICollection<AppAccessControlEntryReadModel> result = new List<AppAccessControlEntryReadModel>(p172.Count);
            
            IEnumerator<AppAccessControlEntry> enumerator = p172.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppAccessControlEntry item = enumerator.Current;
                result.Add(funcMain162(item));
            }
            return result;
            
        }
        
        private static AppUserRoleReadModel funcMain2(AppUserRole p3)
        {
            return p3 == null ? null : new AppUserRoleReadModel()
            {
                AppUser = funcMain3(p3.AppUser),
                AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(p3.AppRole),
                Hash = p3.Hash,
                CreatedBy = p3.CreatedBy,
                CreatedDate = p3.CreatedDate,
                ModifiedBy = p3.ModifiedBy,
                ModifiedDate = p3.ModifiedDate,
                IsDeleted = p3.IsDeleted,
                DeletedBy = p3.DeletedBy,
                DeletedDate = p3.DeletedDate,
                UserId = p3.UserId,
                RoleId = p3.RoleId
            };
        }
        
        private static AppAccessControlEntryReadModel funcMain14(AppAccessControlEntry p15)
        {
            return p15 == null ? null : new AppAccessControlEntryReadModel()
            {
                ResourcePattern = p15.ResourcePattern,
                PermissionPattern = p15.PermissionPattern,
                FeatureId = p15.FeatureId,
                Feature = funcMain15(p15.Feature),
                AppRoles = funcMain17(p15.AppRoles),
                AppUsers = funcMain18(p15.AppUsers),
                AppResource = p15.AppResource == null ? null : new AppResourceReadModel()
                {
                    Url = p15.AppResource.Url,
                    Description = p15.AppResource.Description,
                    ResourceType = p15.AppResource.ResourceType,
                    AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p15.AppResource.AccessControlEntries),
                    Id = p15.AppResource.Id,
                    CreatedBy = p15.AppResource.CreatedBy,
                    CreatedDate = p15.AppResource.CreatedDate,
                    ModifiedBy = p15.AppResource.ModifiedBy,
                    ModifiedDate = p15.AppResource.ModifiedDate,
                    IsDeleted = p15.AppResource.IsDeleted,
                    DeletedBy = p15.AppResource.DeletedBy,
                    DeletedDate = p15.AppResource.DeletedDate
                },
                ResourceId = p15.ResourceId,
                Id = p15.Id,
                CreatedBy = p15.CreatedBy,
                CreatedDate = p15.CreatedDate,
                ModifiedBy = p15.ModifiedBy,
                ModifiedDate = p15.ModifiedDate,
                IsDeleted = p15.IsDeleted,
                DeletedBy = p15.DeletedBy,
                DeletedDate = p15.DeletedDate
            };
        }
        
        private static AppUserRoleReadModel funcMain24(AppUserRole p28)
        {
            return p28 == null ? null : new AppUserRoleReadModel()
            {
                AppUser = funcMain25(p28.AppUser),
                AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(p28.AppRole),
                Hash = p28.Hash,
                CreatedBy = p28.CreatedBy,
                CreatedDate = p28.CreatedDate,
                ModifiedBy = p28.ModifiedBy,
                ModifiedDate = p28.ModifiedDate,
                IsDeleted = p28.IsDeleted,
                DeletedBy = p28.DeletedBy,
                DeletedDate = p28.DeletedDate,
                UserId = p28.UserId,
                RoleId = p28.RoleId
            };
        }
        
        private static AppAccessControlEntryReadModel funcMain36(AppAccessControlEntry p42)
        {
            return p42 == null ? null : new AppAccessControlEntryReadModel()
            {
                ResourcePattern = p42.ResourcePattern,
                PermissionPattern = p42.PermissionPattern,
                FeatureId = p42.FeatureId,
                Feature = funcMain37(p42.Feature),
                AppRoles = funcMain39(p42.AppRoles),
                AppUsers = funcMain40(p42.AppUsers),
                AppResource = p42.AppResource == null ? null : new AppResourceReadModel()
                {
                    Url = p42.AppResource.Url,
                    Description = p42.AppResource.Description,
                    ResourceType = p42.AppResource.ResourceType,
                    AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p42.AppResource.AccessControlEntries),
                    Id = p42.AppResource.Id,
                    CreatedBy = p42.AppResource.CreatedBy,
                    CreatedDate = p42.AppResource.CreatedDate,
                    ModifiedBy = p42.AppResource.ModifiedBy,
                    ModifiedDate = p42.AppResource.ModifiedDate,
                    IsDeleted = p42.AppResource.IsDeleted,
                    DeletedBy = p42.AppResource.DeletedBy,
                    DeletedDate = p42.AppResource.DeletedDate
                },
                ResourceId = p42.ResourceId,
                Id = p42.Id,
                CreatedBy = p42.CreatedBy,
                CreatedDate = p42.CreatedDate,
                ModifiedBy = p42.ModifiedBy,
                ModifiedDate = p42.ModifiedDate,
                IsDeleted = p42.IsDeleted,
                DeletedBy = p42.DeletedBy,
                DeletedDate = p42.DeletedDate
            };
        }
        
        private static AppUserRoleReadModel funcMain46(AppUserRole p53)
        {
            return p53 == null ? null : new AppUserRoleReadModel()
            {
                AppUser = funcMain47(p53.AppUser),
                AppRole = funcMain58(p53.AppRole),
                Hash = p53.Hash,
                CreatedBy = p53.CreatedBy,
                CreatedDate = p53.CreatedDate,
                ModifiedBy = p53.ModifiedBy,
                ModifiedDate = p53.ModifiedDate,
                IsDeleted = p53.IsDeleted,
                DeletedBy = p53.DeletedBy,
                DeletedDate = p53.DeletedDate,
                UserId = p53.UserId,
                RoleId = p53.RoleId
            };
        }
        
        private static AppRoleClaimReadModel funcMain70(AppRoleClaim p77)
        {
            return p77 == null ? null : new AppRoleClaimReadModel()
            {
                CreatedBy = p77.CreatedBy,
                CreatedDate = p77.CreatedDate,
                ModifiedBy = p77.ModifiedBy,
                ModifiedDate = p77.ModifiedDate,
                IsDeleted = p77.IsDeleted,
                DeletedBy = p77.DeletedBy,
                DeletedDate = p77.DeletedDate,
                AppRole = funcMain71(p77.AppRole),
                Id = p77.Id,
                RoleId = p77.RoleId,
                ClaimType = p77.ClaimType,
                ClaimValue = p77.ClaimValue
            };
        }
        
        private static AppAccessControlEntryReadModel funcMain94(AppAccessControlEntry p101)
        {
            return p101 == null ? null : new AppAccessControlEntryReadModel()
            {
                ResourcePattern = p101.ResourcePattern,
                PermissionPattern = p101.PermissionPattern,
                FeatureId = p101.FeatureId,
                Feature = funcMain95(p101.Feature),
                AppRoles = funcMain97(p101.AppRoles),
                AppUsers = funcMain105(p101.AppUsers),
                AppResource = p101.AppResource == null ? null : new AppResourceReadModel()
                {
                    Url = p101.AppResource.Url,
                    Description = p101.AppResource.Description,
                    ResourceType = p101.AppResource.ResourceType,
                    AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p101.AppResource.AccessControlEntries),
                    Id = p101.AppResource.Id,
                    CreatedBy = p101.AppResource.CreatedBy,
                    CreatedDate = p101.AppResource.CreatedDate,
                    ModifiedBy = p101.AppResource.ModifiedBy,
                    ModifiedDate = p101.AppResource.ModifiedDate,
                    IsDeleted = p101.AppResource.IsDeleted,
                    DeletedBy = p101.AppResource.DeletedBy,
                    DeletedDate = p101.AppResource.DeletedDate
                },
                ResourceId = p101.ResourceId,
                Id = p101.Id,
                CreatedBy = p101.CreatedBy,
                CreatedDate = p101.CreatedDate,
                ModifiedBy = p101.ModifiedBy,
                ModifiedDate = p101.ModifiedDate,
                IsDeleted = p101.IsDeleted,
                DeletedBy = p101.DeletedBy,
                DeletedDate = p101.DeletedDate
            };
        }
        
        private static AppUserRoleReadModel funcMain114(AppUserRole p124)
        {
            return p124 == null ? null : new AppUserRoleReadModel()
            {
                AppUser = funcMain115(p124.AppUser),
                AppRole = funcMain126(p124.AppRole),
                Hash = p124.Hash,
                CreatedBy = p124.CreatedBy,
                CreatedDate = p124.CreatedDate,
                ModifiedBy = p124.ModifiedBy,
                ModifiedDate = p124.ModifiedDate,
                IsDeleted = p124.IsDeleted,
                DeletedBy = p124.DeletedBy,
                DeletedDate = p124.DeletedDate,
                UserId = p124.UserId,
                RoleId = p124.RoleId
            };
        }
        
        private static AppRoleClaimReadModel funcMain138(AppRoleClaim p149)
        {
            return p149 == null ? null : new AppRoleClaimReadModel()
            {
                CreatedBy = p149.CreatedBy,
                CreatedDate = p149.CreatedDate,
                ModifiedBy = p149.ModifiedBy,
                ModifiedDate = p149.ModifiedDate,
                IsDeleted = p149.IsDeleted,
                DeletedBy = p149.DeletedBy,
                DeletedDate = p149.DeletedDate,
                AppRole = funcMain139(p149.AppRole),
                Id = p149.Id,
                RoleId = p149.RoleId,
                ClaimType = p149.ClaimType,
                ClaimValue = p149.ClaimValue
            };
        }
        
        private static AppAccessControlEntryReadModel funcMain162(AppAccessControlEntry p174)
        {
            return p174 == null ? null : new AppAccessControlEntryReadModel()
            {
                ResourcePattern = p174.ResourcePattern,
                PermissionPattern = p174.PermissionPattern,
                FeatureId = p174.FeatureId,
                Feature = funcMain163(p174.Feature),
                AppRoles = funcMain165(p174.AppRoles),
                AppUsers = funcMain173(p174.AppUsers),
                AppResource = p174.AppResource == null ? null : new AppResourceReadModel()
                {
                    Url = p174.AppResource.Url,
                    Description = p174.AppResource.Description,
                    ResourceType = p174.AppResource.ResourceType,
                    AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p174.AppResource.AccessControlEntries),
                    Id = p174.AppResource.Id,
                    CreatedBy = p174.AppResource.CreatedBy,
                    CreatedDate = p174.AppResource.CreatedDate,
                    ModifiedBy = p174.AppResource.ModifiedBy,
                    ModifiedDate = p174.AppResource.ModifiedDate,
                    IsDeleted = p174.AppResource.IsDeleted,
                    DeletedBy = p174.AppResource.DeletedBy,
                    DeletedDate = p174.AppResource.DeletedDate
                },
                ResourceId = p174.ResourceId,
                Id = p174.Id,
                CreatedBy = p174.CreatedBy,
                CreatedDate = p174.CreatedDate,
                ModifiedBy = p174.ModifiedBy,
                ModifiedDate = p174.ModifiedDate,
                IsDeleted = p174.IsDeleted,
                DeletedBy = p174.DeletedBy,
                DeletedDate = p174.DeletedDate
            };
        }
        
        private static AppUserReadModel funcMain3(AppUser p4)
        {
            return p4 == null ? null : new AppUserReadModel()
            {
                Hash = p4.Hash,
                FirstName = p4.FirstName,
                LastName = p4.LastName,
                Mobile = p4.Mobile,
                CountryCode = p4.CountryCode,
                TwoFactorMethod = p4.TwoFactorMethod,
                CreatedBy = p4.CreatedBy,
                CreatedDate = p4.CreatedDate,
                ModifiedBy = p4.ModifiedBy,
                ModifiedDate = p4.ModifiedDate,
                IsDeleted = p4.IsDeleted,
                DeletedBy = p4.DeletedBy,
                DeletedDate = p4.DeletedDate,
                MembershipType = p4.MembershipType,
                UserRoles = TypeAdapter<ICollection<AppUserRole>, ICollection<AppUserRoleReadModel>>.Map.Invoke(p4.UserRoles),
                UserTokens = funcMain4(p4.UserTokens),
                RefreshTokens = funcMain5(p4.RefreshTokens),
                AccessControlEntries = funcMain6(p4.AccessControlEntries),
                Id = p4.Id,
                UserName = p4.UserName,
                NormalizedUserName = p4.NormalizedUserName,
                Email = p4.Email,
                NormalizedEmail = p4.NormalizedEmail,
                EmailConfirmed = p4.EmailConfirmed,
                PasswordHash = p4.PasswordHash,
                SecurityStamp = p4.SecurityStamp,
                ConcurrencyStamp = p4.ConcurrencyStamp,
                PhoneNumber = p4.PhoneNumber,
                PhoneNumberConfirmed = p4.PhoneNumberConfirmed,
                TwoFactorEnabled = p4.TwoFactorEnabled,
                LockoutEnd = p4.LockoutEnd,
                LockoutEnabled = p4.LockoutEnabled,
                AccessFailedCount = p4.AccessFailedCount
            };
        }
        
        private static AppFeatureReadModel funcMain15(AppFeature p16)
        {
            return p16 == null ? null : new AppFeatureReadModel()
            {
                Name = p16.Name,
                Description = p16.Description,
                IsEnabled = p16.IsEnabled,
                Scope = p16.Scope,
                FeatureFlags = funcMain16(p16.FeatureFlags),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p16.AccessControlEntries),
                Id = p16.Id,
                CreatedBy = p16.CreatedBy,
                CreatedDate = p16.CreatedDate,
                ModifiedBy = p16.ModifiedBy,
                ModifiedDate = p16.ModifiedDate,
                IsDeleted = p16.IsDeleted,
                DeletedBy = p16.DeletedBy,
                DeletedDate = p16.DeletedDate
            };
        }
        
        private static ICollection<AppRoleReadModel> funcMain17(ICollection<AppRole> p18)
        {
            if (p18 == null)
            {
                return null;
            }
            ICollection<AppRoleReadModel> result = new List<AppRoleReadModel>(p18.Count);
            
            IEnumerator<AppRole> enumerator = p18.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRole item = enumerator.Current;
                result.Add(TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserReadModel> funcMain18(ICollection<AppUser> p19)
        {
            if (p19 == null)
            {
                return null;
            }
            ICollection<AppUserReadModel> result = new List<AppUserReadModel>(p19.Count);
            
            IEnumerator<AppUser> enumerator = p19.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUser item = enumerator.Current;
                result.Add(funcMain19(item));
            }
            return result;
            
        }
        
        private static AppUserReadModel funcMain25(AppUser p29)
        {
            return p29 == null ? null : new AppUserReadModel()
            {
                Hash = p29.Hash,
                FirstName = p29.FirstName,
                LastName = p29.LastName,
                Mobile = p29.Mobile,
                CountryCode = p29.CountryCode,
                TwoFactorMethod = p29.TwoFactorMethod,
                CreatedBy = p29.CreatedBy,
                CreatedDate = p29.CreatedDate,
                ModifiedBy = p29.ModifiedBy,
                ModifiedDate = p29.ModifiedDate,
                IsDeleted = p29.IsDeleted,
                DeletedBy = p29.DeletedBy,
                DeletedDate = p29.DeletedDate,
                MembershipType = p29.MembershipType,
                UserRoles = TypeAdapter<ICollection<AppUserRole>, ICollection<AppUserRoleReadModel>>.Map.Invoke(p29.UserRoles),
                UserTokens = funcMain26(p29.UserTokens),
                RefreshTokens = funcMain27(p29.RefreshTokens),
                AccessControlEntries = funcMain28(p29.AccessControlEntries),
                Id = p29.Id,
                UserName = p29.UserName,
                NormalizedUserName = p29.NormalizedUserName,
                Email = p29.Email,
                NormalizedEmail = p29.NormalizedEmail,
                EmailConfirmed = p29.EmailConfirmed,
                PasswordHash = p29.PasswordHash,
                SecurityStamp = p29.SecurityStamp,
                ConcurrencyStamp = p29.ConcurrencyStamp,
                PhoneNumber = p29.PhoneNumber,
                PhoneNumberConfirmed = p29.PhoneNumberConfirmed,
                TwoFactorEnabled = p29.TwoFactorEnabled,
                LockoutEnd = p29.LockoutEnd,
                LockoutEnabled = p29.LockoutEnabled,
                AccessFailedCount = p29.AccessFailedCount
            };
        }
        
        private static AppFeatureReadModel funcMain37(AppFeature p43)
        {
            return p43 == null ? null : new AppFeatureReadModel()
            {
                Name = p43.Name,
                Description = p43.Description,
                IsEnabled = p43.IsEnabled,
                Scope = p43.Scope,
                FeatureFlags = funcMain38(p43.FeatureFlags),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p43.AccessControlEntries),
                Id = p43.Id,
                CreatedBy = p43.CreatedBy,
                CreatedDate = p43.CreatedDate,
                ModifiedBy = p43.ModifiedBy,
                ModifiedDate = p43.ModifiedDate,
                IsDeleted = p43.IsDeleted,
                DeletedBy = p43.DeletedBy,
                DeletedDate = p43.DeletedDate
            };
        }
        
        private static ICollection<AppRoleReadModel> funcMain39(ICollection<AppRole> p45)
        {
            if (p45 == null)
            {
                return null;
            }
            ICollection<AppRoleReadModel> result = new List<AppRoleReadModel>(p45.Count);
            
            IEnumerator<AppRole> enumerator = p45.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRole item = enumerator.Current;
                result.Add(TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserReadModel> funcMain40(ICollection<AppUser> p46)
        {
            if (p46 == null)
            {
                return null;
            }
            ICollection<AppUserReadModel> result = new List<AppUserReadModel>(p46.Count);
            
            IEnumerator<AppUser> enumerator = p46.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUser item = enumerator.Current;
                result.Add(funcMain41(item));
            }
            return result;
            
        }
        
        private static AppUserReadModel funcMain47(AppUser p54)
        {
            return p54 == null ? null : new AppUserReadModel()
            {
                Hash = p54.Hash,
                FirstName = p54.FirstName,
                LastName = p54.LastName,
                Mobile = p54.Mobile,
                CountryCode = p54.CountryCode,
                TwoFactorMethod = p54.TwoFactorMethod,
                CreatedBy = p54.CreatedBy,
                CreatedDate = p54.CreatedDate,
                ModifiedBy = p54.ModifiedBy,
                ModifiedDate = p54.ModifiedDate,
                IsDeleted = p54.IsDeleted,
                DeletedBy = p54.DeletedBy,
                DeletedDate = p54.DeletedDate,
                MembershipType = p54.MembershipType,
                UserRoles = TypeAdapter<ICollection<AppUserRole>, ICollection<AppUserRoleReadModel>>.Map.Invoke(p54.UserRoles),
                UserTokens = funcMain48(p54.UserTokens),
                RefreshTokens = funcMain49(p54.RefreshTokens),
                AccessControlEntries = funcMain50(p54.AccessControlEntries),
                Id = p54.Id,
                UserName = p54.UserName,
                NormalizedUserName = p54.NormalizedUserName,
                Email = p54.Email,
                NormalizedEmail = p54.NormalizedEmail,
                EmailConfirmed = p54.EmailConfirmed,
                PasswordHash = p54.PasswordHash,
                SecurityStamp = p54.SecurityStamp,
                ConcurrencyStamp = p54.ConcurrencyStamp,
                PhoneNumber = p54.PhoneNumber,
                PhoneNumberConfirmed = p54.PhoneNumberConfirmed,
                TwoFactorEnabled = p54.TwoFactorEnabled,
                LockoutEnd = p54.LockoutEnd,
                LockoutEnabled = p54.LockoutEnabled,
                AccessFailedCount = p54.AccessFailedCount
            };
        }
        
        private static AppRoleReadModel funcMain58(AppRole p65)
        {
            return p65 == null ? null : new AppRoleReadModel()
            {
                CreatedBy = p65.CreatedBy,
                CreatedDate = p65.CreatedDate,
                ModifiedBy = p65.ModifiedBy,
                ModifiedDate = p65.ModifiedDate,
                IsDeleted = p65.IsDeleted,
                DeletedBy = p65.DeletedBy,
                DeletedDate = p65.DeletedDate,
                AppUserRoles = TypeAdapter<ICollection<AppUserRole>, ICollection<AppUserRoleReadModel>>.Map.Invoke(p65.AppUserRoles),
                AppRoleClaims = funcMain59(p65.AppRoleClaims),
                AccessControlEntries = funcMain60(p65.AccessControlEntries),
                Hash = p65.Hash,
                Id = p65.Id,
                Name = p65.Name,
                NormalizedName = p65.NormalizedName,
                ConcurrencyStamp = p65.ConcurrencyStamp
            };
        }
        
        private static AppRoleReadModel funcMain71(AppRole p78)
        {
            return p78 == null ? null : new AppRoleReadModel()
            {
                CreatedBy = p78.CreatedBy,
                CreatedDate = p78.CreatedDate,
                ModifiedBy = p78.ModifiedBy,
                ModifiedDate = p78.ModifiedDate,
                IsDeleted = p78.IsDeleted,
                DeletedBy = p78.DeletedBy,
                DeletedDate = p78.DeletedDate,
                AppUserRoles = funcMain72(p78.AppUserRoles),
                AppRoleClaims = TypeAdapter<ICollection<AppRoleClaim>, ICollection<AppRoleClaimReadModel>>.Map.Invoke(p78.AppRoleClaims),
                AccessControlEntries = funcMain83(p78.AccessControlEntries),
                Hash = p78.Hash,
                Id = p78.Id,
                Name = p78.Name,
                NormalizedName = p78.NormalizedName,
                ConcurrencyStamp = p78.ConcurrencyStamp
            };
        }
        
        private static AppFeatureReadModel funcMain95(AppFeature p102)
        {
            return p102 == null ? null : new AppFeatureReadModel()
            {
                Name = p102.Name,
                Description = p102.Description,
                IsEnabled = p102.IsEnabled,
                Scope = p102.Scope,
                FeatureFlags = funcMain96(p102.FeatureFlags),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p102.AccessControlEntries),
                Id = p102.Id,
                CreatedBy = p102.CreatedBy,
                CreatedDate = p102.CreatedDate,
                ModifiedBy = p102.ModifiedBy,
                ModifiedDate = p102.ModifiedDate,
                IsDeleted = p102.IsDeleted,
                DeletedBy = p102.DeletedBy,
                DeletedDate = p102.DeletedDate
            };
        }
        
        private static ICollection<AppRoleReadModel> funcMain97(ICollection<AppRole> p104)
        {
            if (p104 == null)
            {
                return null;
            }
            ICollection<AppRoleReadModel> result = new List<AppRoleReadModel>(p104.Count);
            
            IEnumerator<AppRole> enumerator = p104.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRole item = enumerator.Current;
                result.Add(funcMain98(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserReadModel> funcMain105(ICollection<AppUser> p112)
        {
            if (p112 == null)
            {
                return null;
            }
            ICollection<AppUserReadModel> result = new List<AppUserReadModel>(p112.Count);
            
            IEnumerator<AppUser> enumerator = p112.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUser item = enumerator.Current;
                result.Add(funcMain106(item));
            }
            return result;
            
        }
        
        private static AppUserReadModel funcMain115(AppUser p125)
        {
            return p125 == null ? null : new AppUserReadModel()
            {
                Hash = p125.Hash,
                FirstName = p125.FirstName,
                LastName = p125.LastName,
                Mobile = p125.Mobile,
                CountryCode = p125.CountryCode,
                TwoFactorMethod = p125.TwoFactorMethod,
                CreatedBy = p125.CreatedBy,
                CreatedDate = p125.CreatedDate,
                ModifiedBy = p125.ModifiedBy,
                ModifiedDate = p125.ModifiedDate,
                IsDeleted = p125.IsDeleted,
                DeletedBy = p125.DeletedBy,
                DeletedDate = p125.DeletedDate,
                MembershipType = p125.MembershipType,
                UserRoles = TypeAdapter<ICollection<AppUserRole>, ICollection<AppUserRoleReadModel>>.Map.Invoke(p125.UserRoles),
                UserTokens = funcMain116(p125.UserTokens),
                RefreshTokens = funcMain117(p125.RefreshTokens),
                AccessControlEntries = funcMain118(p125.AccessControlEntries),
                Id = p125.Id,
                UserName = p125.UserName,
                NormalizedUserName = p125.NormalizedUserName,
                Email = p125.Email,
                NormalizedEmail = p125.NormalizedEmail,
                EmailConfirmed = p125.EmailConfirmed,
                PasswordHash = p125.PasswordHash,
                SecurityStamp = p125.SecurityStamp,
                ConcurrencyStamp = p125.ConcurrencyStamp,
                PhoneNumber = p125.PhoneNumber,
                PhoneNumberConfirmed = p125.PhoneNumberConfirmed,
                TwoFactorEnabled = p125.TwoFactorEnabled,
                LockoutEnd = p125.LockoutEnd,
                LockoutEnabled = p125.LockoutEnabled,
                AccessFailedCount = p125.AccessFailedCount
            };
        }
        
        private static AppRoleReadModel funcMain126(AppRole p136)
        {
            return p136 == null ? null : new AppRoleReadModel()
            {
                CreatedBy = p136.CreatedBy,
                CreatedDate = p136.CreatedDate,
                ModifiedBy = p136.ModifiedBy,
                ModifiedDate = p136.ModifiedDate,
                IsDeleted = p136.IsDeleted,
                DeletedBy = p136.DeletedBy,
                DeletedDate = p136.DeletedDate,
                AppUserRoles = TypeAdapter<ICollection<AppUserRole>, ICollection<AppUserRoleReadModel>>.Map.Invoke(p136.AppUserRoles),
                AppRoleClaims = funcMain127(p136.AppRoleClaims),
                AccessControlEntries = funcMain128(p136.AccessControlEntries),
                Hash = p136.Hash,
                Id = p136.Id,
                Name = p136.Name,
                NormalizedName = p136.NormalizedName,
                ConcurrencyStamp = p136.ConcurrencyStamp
            };
        }
        
        private static AppRoleReadModel funcMain139(AppRole p150)
        {
            return p150 == null ? null : new AppRoleReadModel()
            {
                CreatedBy = p150.CreatedBy,
                CreatedDate = p150.CreatedDate,
                ModifiedBy = p150.ModifiedBy,
                ModifiedDate = p150.ModifiedDate,
                IsDeleted = p150.IsDeleted,
                DeletedBy = p150.DeletedBy,
                DeletedDate = p150.DeletedDate,
                AppUserRoles = funcMain140(p150.AppUserRoles),
                AppRoleClaims = TypeAdapter<ICollection<AppRoleClaim>, ICollection<AppRoleClaimReadModel>>.Map.Invoke(p150.AppRoleClaims),
                AccessControlEntries = funcMain151(p150.AccessControlEntries),
                Hash = p150.Hash,
                Id = p150.Id,
                Name = p150.Name,
                NormalizedName = p150.NormalizedName,
                ConcurrencyStamp = p150.ConcurrencyStamp
            };
        }
        
        private static AppFeatureReadModel funcMain163(AppFeature p175)
        {
            return p175 == null ? null : new AppFeatureReadModel()
            {
                Name = p175.Name,
                Description = p175.Description,
                IsEnabled = p175.IsEnabled,
                Scope = p175.Scope,
                FeatureFlags = funcMain164(p175.FeatureFlags),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p175.AccessControlEntries),
                Id = p175.Id,
                CreatedBy = p175.CreatedBy,
                CreatedDate = p175.CreatedDate,
                ModifiedBy = p175.ModifiedBy,
                ModifiedDate = p175.ModifiedDate,
                IsDeleted = p175.IsDeleted,
                DeletedBy = p175.DeletedBy,
                DeletedDate = p175.DeletedDate
            };
        }
        
        private static ICollection<AppRoleReadModel> funcMain165(ICollection<AppRole> p177)
        {
            if (p177 == null)
            {
                return null;
            }
            ICollection<AppRoleReadModel> result = new List<AppRoleReadModel>(p177.Count);
            
            IEnumerator<AppRole> enumerator = p177.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRole item = enumerator.Current;
                result.Add(funcMain166(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserReadModel> funcMain173(ICollection<AppUser> p185)
        {
            if (p185 == null)
            {
                return null;
            }
            ICollection<AppUserReadModel> result = new List<AppUserReadModel>(p185.Count);
            
            IEnumerator<AppUser> enumerator = p185.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUser item = enumerator.Current;
                result.Add(funcMain174(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserTokenReadModel> funcMain4(ICollection<AppUserToken> p5)
        {
            if (p5 == null)
            {
                return null;
            }
            ICollection<AppUserTokenReadModel> result = new List<AppUserTokenReadModel>(p5.Count);
            
            IEnumerator<AppUserToken> enumerator = p5.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserToken item = enumerator.Current;
                result.Add(item == null ? null : new AppUserTokenReadModel()
                {
                    Token = item.Token,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    LoginProvider = item.LoginProvider,
                    Name = item.Name,
                    Value = item.Value
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRefreshTokenReadModel> funcMain5(ICollection<AppRefreshToken> p6)
        {
            if (p6 == null)
            {
                return null;
            }
            ICollection<AppRefreshTokenReadModel> result = new List<AppRefreshTokenReadModel>(p6.Count);
            
            IEnumerator<AppRefreshToken> enumerator = p6.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRefreshToken item = enumerator.Current;
                result.Add(item == null ? null : new AppRefreshTokenReadModel()
                {
                    UserId = item.UserId,
                    Token = item.Token,
                    JwtId = item.JwtId,
                    IsUsed = item.IsUsed,
                    IsRevoked = item.IsRevoked,
                    ExpiryDate = item.ExpiryDate,
                    Hash = item.Hash,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static ICollection<AppAccessControlEntryReadModel> funcMain6(ICollection<AppAccessControlEntry> p7)
        {
            if (p7 == null)
            {
                return null;
            }
            ICollection<AppAccessControlEntryReadModel> result = new List<AppAccessControlEntryReadModel>(p7.Count);
            
            IEnumerator<AppAccessControlEntry> enumerator = p7.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppAccessControlEntry item = enumerator.Current;
                result.Add(funcMain7(item));
            }
            return result;
            
        }
        
        private static ICollection<AppFeatureFlagReadModel> funcMain16(ICollection<AppFeatureFlag> p17)
        {
            if (p17 == null)
            {
                return null;
            }
            ICollection<AppFeatureFlagReadModel> result = new List<AppFeatureFlagReadModel>(p17.Count);
            
            IEnumerator<AppFeatureFlag> enumerator = p17.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppFeatureFlag item = enumerator.Current;
                result.Add(item == null ? null : new AppFeatureFlagReadModel()
                {
                    FeatureId = item.FeatureId,
                    ScopeIdentifier = item.ScopeIdentifier,
                    IsEnabled = item.IsEnabled,
                    Feature = TypeAdapter<AppFeature, AppFeatureReadModel>.Map.Invoke(item.Feature),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static AppUserReadModel funcMain19(AppUser p20)
        {
            return p20 == null ? null : new AppUserReadModel()
            {
                Hash = p20.Hash,
                FirstName = p20.FirstName,
                LastName = p20.LastName,
                Mobile = p20.Mobile,
                CountryCode = p20.CountryCode,
                TwoFactorMethod = p20.TwoFactorMethod,
                CreatedBy = p20.CreatedBy,
                CreatedDate = p20.CreatedDate,
                ModifiedBy = p20.ModifiedBy,
                ModifiedDate = p20.ModifiedDate,
                IsDeleted = p20.IsDeleted,
                DeletedBy = p20.DeletedBy,
                DeletedDate = p20.DeletedDate,
                MembershipType = p20.MembershipType,
                UserRoles = funcMain20(p20.UserRoles),
                UserTokens = funcMain21(p20.UserTokens),
                RefreshTokens = funcMain22(p20.RefreshTokens),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p20.AccessControlEntries),
                Id = p20.Id,
                UserName = p20.UserName,
                NormalizedUserName = p20.NormalizedUserName,
                Email = p20.Email,
                NormalizedEmail = p20.NormalizedEmail,
                EmailConfirmed = p20.EmailConfirmed,
                PasswordHash = p20.PasswordHash,
                SecurityStamp = p20.SecurityStamp,
                ConcurrencyStamp = p20.ConcurrencyStamp,
                PhoneNumber = p20.PhoneNumber,
                PhoneNumberConfirmed = p20.PhoneNumberConfirmed,
                TwoFactorEnabled = p20.TwoFactorEnabled,
                LockoutEnd = p20.LockoutEnd,
                LockoutEnabled = p20.LockoutEnabled,
                AccessFailedCount = p20.AccessFailedCount
            };
        }
        
        private static ICollection<AppUserTokenReadModel> funcMain26(ICollection<AppUserToken> p30)
        {
            if (p30 == null)
            {
                return null;
            }
            ICollection<AppUserTokenReadModel> result = new List<AppUserTokenReadModel>(p30.Count);
            
            IEnumerator<AppUserToken> enumerator = p30.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserToken item = enumerator.Current;
                result.Add(item == null ? null : new AppUserTokenReadModel()
                {
                    Token = item.Token,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    LoginProvider = item.LoginProvider,
                    Name = item.Name,
                    Value = item.Value
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRefreshTokenReadModel> funcMain27(ICollection<AppRefreshToken> p31)
        {
            if (p31 == null)
            {
                return null;
            }
            ICollection<AppRefreshTokenReadModel> result = new List<AppRefreshTokenReadModel>(p31.Count);
            
            IEnumerator<AppRefreshToken> enumerator = p31.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRefreshToken item = enumerator.Current;
                result.Add(item == null ? null : new AppRefreshTokenReadModel()
                {
                    UserId = item.UserId,
                    Token = item.Token,
                    JwtId = item.JwtId,
                    IsUsed = item.IsUsed,
                    IsRevoked = item.IsRevoked,
                    ExpiryDate = item.ExpiryDate,
                    Hash = item.Hash,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static ICollection<AppAccessControlEntryReadModel> funcMain28(ICollection<AppAccessControlEntry> p32)
        {
            if (p32 == null)
            {
                return null;
            }
            ICollection<AppAccessControlEntryReadModel> result = new List<AppAccessControlEntryReadModel>(p32.Count);
            
            IEnumerator<AppAccessControlEntry> enumerator = p32.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppAccessControlEntry item = enumerator.Current;
                result.Add(funcMain29(item));
            }
            return result;
            
        }
        
        private static ICollection<AppFeatureFlagReadModel> funcMain38(ICollection<AppFeatureFlag> p44)
        {
            if (p44 == null)
            {
                return null;
            }
            ICollection<AppFeatureFlagReadModel> result = new List<AppFeatureFlagReadModel>(p44.Count);
            
            IEnumerator<AppFeatureFlag> enumerator = p44.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppFeatureFlag item = enumerator.Current;
                result.Add(item == null ? null : new AppFeatureFlagReadModel()
                {
                    FeatureId = item.FeatureId,
                    ScopeIdentifier = item.ScopeIdentifier,
                    IsEnabled = item.IsEnabled,
                    Feature = TypeAdapter<AppFeature, AppFeatureReadModel>.Map.Invoke(item.Feature),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static AppUserReadModel funcMain41(AppUser p47)
        {
            return p47 == null ? null : new AppUserReadModel()
            {
                Hash = p47.Hash,
                FirstName = p47.FirstName,
                LastName = p47.LastName,
                Mobile = p47.Mobile,
                CountryCode = p47.CountryCode,
                TwoFactorMethod = p47.TwoFactorMethod,
                CreatedBy = p47.CreatedBy,
                CreatedDate = p47.CreatedDate,
                ModifiedBy = p47.ModifiedBy,
                ModifiedDate = p47.ModifiedDate,
                IsDeleted = p47.IsDeleted,
                DeletedBy = p47.DeletedBy,
                DeletedDate = p47.DeletedDate,
                MembershipType = p47.MembershipType,
                UserRoles = funcMain42(p47.UserRoles),
                UserTokens = funcMain43(p47.UserTokens),
                RefreshTokens = funcMain44(p47.RefreshTokens),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p47.AccessControlEntries),
                Id = p47.Id,
                UserName = p47.UserName,
                NormalizedUserName = p47.NormalizedUserName,
                Email = p47.Email,
                NormalizedEmail = p47.NormalizedEmail,
                EmailConfirmed = p47.EmailConfirmed,
                PasswordHash = p47.PasswordHash,
                SecurityStamp = p47.SecurityStamp,
                ConcurrencyStamp = p47.ConcurrencyStamp,
                PhoneNumber = p47.PhoneNumber,
                PhoneNumberConfirmed = p47.PhoneNumberConfirmed,
                TwoFactorEnabled = p47.TwoFactorEnabled,
                LockoutEnd = p47.LockoutEnd,
                LockoutEnabled = p47.LockoutEnabled,
                AccessFailedCount = p47.AccessFailedCount
            };
        }
        
        private static ICollection<AppUserTokenReadModel> funcMain48(ICollection<AppUserToken> p55)
        {
            if (p55 == null)
            {
                return null;
            }
            ICollection<AppUserTokenReadModel> result = new List<AppUserTokenReadModel>(p55.Count);
            
            IEnumerator<AppUserToken> enumerator = p55.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserToken item = enumerator.Current;
                result.Add(item == null ? null : new AppUserTokenReadModel()
                {
                    Token = item.Token,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    LoginProvider = item.LoginProvider,
                    Name = item.Name,
                    Value = item.Value
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRefreshTokenReadModel> funcMain49(ICollection<AppRefreshToken> p56)
        {
            if (p56 == null)
            {
                return null;
            }
            ICollection<AppRefreshTokenReadModel> result = new List<AppRefreshTokenReadModel>(p56.Count);
            
            IEnumerator<AppRefreshToken> enumerator = p56.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRefreshToken item = enumerator.Current;
                result.Add(item == null ? null : new AppRefreshTokenReadModel()
                {
                    UserId = item.UserId,
                    Token = item.Token,
                    JwtId = item.JwtId,
                    IsUsed = item.IsUsed,
                    IsRevoked = item.IsRevoked,
                    ExpiryDate = item.ExpiryDate,
                    Hash = item.Hash,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static ICollection<AppAccessControlEntryReadModel> funcMain50(ICollection<AppAccessControlEntry> p57)
        {
            if (p57 == null)
            {
                return null;
            }
            ICollection<AppAccessControlEntryReadModel> result = new List<AppAccessControlEntryReadModel>(p57.Count);
            
            IEnumerator<AppAccessControlEntry> enumerator = p57.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppAccessControlEntry item = enumerator.Current;
                result.Add(funcMain51(item));
            }
            return result;
            
        }
        
        private static ICollection<AppRoleClaimReadModel> funcMain59(ICollection<AppRoleClaim> p66)
        {
            if (p66 == null)
            {
                return null;
            }
            ICollection<AppRoleClaimReadModel> result = new List<AppRoleClaimReadModel>(p66.Count);
            
            IEnumerator<AppRoleClaim> enumerator = p66.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRoleClaim item = enumerator.Current;
                result.Add(item == null ? null : new AppRoleClaimReadModel()
                {
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Id = item.Id,
                    RoleId = item.RoleId,
                    ClaimType = item.ClaimType,
                    ClaimValue = item.ClaimValue
                });
            }
            return result;
            
        }
        
        private static ICollection<AppAccessControlEntryReadModel> funcMain60(ICollection<AppAccessControlEntry> p67)
        {
            if (p67 == null)
            {
                return null;
            }
            ICollection<AppAccessControlEntryReadModel> result = new List<AppAccessControlEntryReadModel>(p67.Count);
            
            IEnumerator<AppAccessControlEntry> enumerator = p67.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppAccessControlEntry item = enumerator.Current;
                result.Add(funcMain61(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain72(ICollection<AppUserRole> p79)
        {
            if (p79 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p79.Count);
            
            IEnumerator<AppUserRole> enumerator = p79.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(funcMain73(item));
            }
            return result;
            
        }
        
        private static ICollection<AppAccessControlEntryReadModel> funcMain83(ICollection<AppAccessControlEntry> p90)
        {
            if (p90 == null)
            {
                return null;
            }
            ICollection<AppAccessControlEntryReadModel> result = new List<AppAccessControlEntryReadModel>(p90.Count);
            
            IEnumerator<AppAccessControlEntry> enumerator = p90.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppAccessControlEntry item = enumerator.Current;
                result.Add(funcMain84(item));
            }
            return result;
            
        }
        
        private static ICollection<AppFeatureFlagReadModel> funcMain96(ICollection<AppFeatureFlag> p103)
        {
            if (p103 == null)
            {
                return null;
            }
            ICollection<AppFeatureFlagReadModel> result = new List<AppFeatureFlagReadModel>(p103.Count);
            
            IEnumerator<AppFeatureFlag> enumerator = p103.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppFeatureFlag item = enumerator.Current;
                result.Add(item == null ? null : new AppFeatureFlagReadModel()
                {
                    FeatureId = item.FeatureId,
                    ScopeIdentifier = item.ScopeIdentifier,
                    IsEnabled = item.IsEnabled,
                    Feature = TypeAdapter<AppFeature, AppFeatureReadModel>.Map.Invoke(item.Feature),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static AppRoleReadModel funcMain98(AppRole p105)
        {
            return p105 == null ? null : new AppRoleReadModel()
            {
                CreatedBy = p105.CreatedBy,
                CreatedDate = p105.CreatedDate,
                ModifiedBy = p105.ModifiedBy,
                ModifiedDate = p105.ModifiedDate,
                IsDeleted = p105.IsDeleted,
                DeletedBy = p105.DeletedBy,
                DeletedDate = p105.DeletedDate,
                AppUserRoles = funcMain99(p105.AppUserRoles),
                AppRoleClaims = funcMain104(p105.AppRoleClaims),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p105.AccessControlEntries),
                Hash = p105.Hash,
                Id = p105.Id,
                Name = p105.Name,
                NormalizedName = p105.NormalizedName,
                ConcurrencyStamp = p105.ConcurrencyStamp
            };
        }
        
        private static AppUserReadModel funcMain106(AppUser p113)
        {
            return p113 == null ? null : new AppUserReadModel()
            {
                Hash = p113.Hash,
                FirstName = p113.FirstName,
                LastName = p113.LastName,
                Mobile = p113.Mobile,
                CountryCode = p113.CountryCode,
                TwoFactorMethod = p113.TwoFactorMethod,
                CreatedBy = p113.CreatedBy,
                CreatedDate = p113.CreatedDate,
                ModifiedBy = p113.ModifiedBy,
                ModifiedDate = p113.ModifiedDate,
                IsDeleted = p113.IsDeleted,
                DeletedBy = p113.DeletedBy,
                DeletedDate = p113.DeletedDate,
                MembershipType = p113.MembershipType,
                UserRoles = funcMain107(p113.UserRoles),
                UserTokens = funcMain111(p113.UserTokens),
                RefreshTokens = funcMain112(p113.RefreshTokens),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p113.AccessControlEntries),
                Id = p113.Id,
                UserName = p113.UserName,
                NormalizedUserName = p113.NormalizedUserName,
                Email = p113.Email,
                NormalizedEmail = p113.NormalizedEmail,
                EmailConfirmed = p113.EmailConfirmed,
                PasswordHash = p113.PasswordHash,
                SecurityStamp = p113.SecurityStamp,
                ConcurrencyStamp = p113.ConcurrencyStamp,
                PhoneNumber = p113.PhoneNumber,
                PhoneNumberConfirmed = p113.PhoneNumberConfirmed,
                TwoFactorEnabled = p113.TwoFactorEnabled,
                LockoutEnd = p113.LockoutEnd,
                LockoutEnabled = p113.LockoutEnabled,
                AccessFailedCount = p113.AccessFailedCount
            };
        }
        
        private static ICollection<AppUserTokenReadModel> funcMain116(ICollection<AppUserToken> p126)
        {
            if (p126 == null)
            {
                return null;
            }
            ICollection<AppUserTokenReadModel> result = new List<AppUserTokenReadModel>(p126.Count);
            
            IEnumerator<AppUserToken> enumerator = p126.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserToken item = enumerator.Current;
                result.Add(item == null ? null : new AppUserTokenReadModel()
                {
                    Token = item.Token,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    LoginProvider = item.LoginProvider,
                    Name = item.Name,
                    Value = item.Value
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRefreshTokenReadModel> funcMain117(ICollection<AppRefreshToken> p127)
        {
            if (p127 == null)
            {
                return null;
            }
            ICollection<AppRefreshTokenReadModel> result = new List<AppRefreshTokenReadModel>(p127.Count);
            
            IEnumerator<AppRefreshToken> enumerator = p127.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRefreshToken item = enumerator.Current;
                result.Add(item == null ? null : new AppRefreshTokenReadModel()
                {
                    UserId = item.UserId,
                    Token = item.Token,
                    JwtId = item.JwtId,
                    IsUsed = item.IsUsed,
                    IsRevoked = item.IsRevoked,
                    ExpiryDate = item.ExpiryDate,
                    Hash = item.Hash,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static ICollection<AppAccessControlEntryReadModel> funcMain118(ICollection<AppAccessControlEntry> p128)
        {
            if (p128 == null)
            {
                return null;
            }
            ICollection<AppAccessControlEntryReadModel> result = new List<AppAccessControlEntryReadModel>(p128.Count);
            
            IEnumerator<AppAccessControlEntry> enumerator = p128.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppAccessControlEntry item = enumerator.Current;
                result.Add(funcMain119(item));
            }
            return result;
            
        }
        
        private static ICollection<AppRoleClaimReadModel> funcMain127(ICollection<AppRoleClaim> p137)
        {
            if (p137 == null)
            {
                return null;
            }
            ICollection<AppRoleClaimReadModel> result = new List<AppRoleClaimReadModel>(p137.Count);
            
            IEnumerator<AppRoleClaim> enumerator = p137.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRoleClaim item = enumerator.Current;
                result.Add(item == null ? null : new AppRoleClaimReadModel()
                {
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Id = item.Id,
                    RoleId = item.RoleId,
                    ClaimType = item.ClaimType,
                    ClaimValue = item.ClaimValue
                });
            }
            return result;
            
        }
        
        private static ICollection<AppAccessControlEntryReadModel> funcMain128(ICollection<AppAccessControlEntry> p138)
        {
            if (p138 == null)
            {
                return null;
            }
            ICollection<AppAccessControlEntryReadModel> result = new List<AppAccessControlEntryReadModel>(p138.Count);
            
            IEnumerator<AppAccessControlEntry> enumerator = p138.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppAccessControlEntry item = enumerator.Current;
                result.Add(funcMain129(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain140(ICollection<AppUserRole> p151)
        {
            if (p151 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p151.Count);
            
            IEnumerator<AppUserRole> enumerator = p151.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(funcMain141(item));
            }
            return result;
            
        }
        
        private static ICollection<AppAccessControlEntryReadModel> funcMain151(ICollection<AppAccessControlEntry> p162)
        {
            if (p162 == null)
            {
                return null;
            }
            ICollection<AppAccessControlEntryReadModel> result = new List<AppAccessControlEntryReadModel>(p162.Count);
            
            IEnumerator<AppAccessControlEntry> enumerator = p162.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppAccessControlEntry item = enumerator.Current;
                result.Add(funcMain152(item));
            }
            return result;
            
        }
        
        private static ICollection<AppFeatureFlagReadModel> funcMain164(ICollection<AppFeatureFlag> p176)
        {
            if (p176 == null)
            {
                return null;
            }
            ICollection<AppFeatureFlagReadModel> result = new List<AppFeatureFlagReadModel>(p176.Count);
            
            IEnumerator<AppFeatureFlag> enumerator = p176.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppFeatureFlag item = enumerator.Current;
                result.Add(item == null ? null : new AppFeatureFlagReadModel()
                {
                    FeatureId = item.FeatureId,
                    ScopeIdentifier = item.ScopeIdentifier,
                    IsEnabled = item.IsEnabled,
                    Feature = TypeAdapter<AppFeature, AppFeatureReadModel>.Map.Invoke(item.Feature),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static AppRoleReadModel funcMain166(AppRole p178)
        {
            return p178 == null ? null : new AppRoleReadModel()
            {
                CreatedBy = p178.CreatedBy,
                CreatedDate = p178.CreatedDate,
                ModifiedBy = p178.ModifiedBy,
                ModifiedDate = p178.ModifiedDate,
                IsDeleted = p178.IsDeleted,
                DeletedBy = p178.DeletedBy,
                DeletedDate = p178.DeletedDate,
                AppUserRoles = funcMain167(p178.AppUserRoles),
                AppRoleClaims = funcMain172(p178.AppRoleClaims),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p178.AccessControlEntries),
                Hash = p178.Hash,
                Id = p178.Id,
                Name = p178.Name,
                NormalizedName = p178.NormalizedName,
                ConcurrencyStamp = p178.ConcurrencyStamp
            };
        }
        
        private static AppUserReadModel funcMain174(AppUser p186)
        {
            return p186 == null ? null : new AppUserReadModel()
            {
                Hash = p186.Hash,
                FirstName = p186.FirstName,
                LastName = p186.LastName,
                Mobile = p186.Mobile,
                CountryCode = p186.CountryCode,
                TwoFactorMethod = p186.TwoFactorMethod,
                CreatedBy = p186.CreatedBy,
                CreatedDate = p186.CreatedDate,
                ModifiedBy = p186.ModifiedBy,
                ModifiedDate = p186.ModifiedDate,
                IsDeleted = p186.IsDeleted,
                DeletedBy = p186.DeletedBy,
                DeletedDate = p186.DeletedDate,
                MembershipType = p186.MembershipType,
                UserRoles = funcMain175(p186.UserRoles),
                UserTokens = funcMain179(p186.UserTokens),
                RefreshTokens = funcMain180(p186.RefreshTokens),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p186.AccessControlEntries),
                Id = p186.Id,
                UserName = p186.UserName,
                NormalizedUserName = p186.NormalizedUserName,
                Email = p186.Email,
                NormalizedEmail = p186.NormalizedEmail,
                EmailConfirmed = p186.EmailConfirmed,
                PasswordHash = p186.PasswordHash,
                SecurityStamp = p186.SecurityStamp,
                ConcurrencyStamp = p186.ConcurrencyStamp,
                PhoneNumber = p186.PhoneNumber,
                PhoneNumberConfirmed = p186.PhoneNumberConfirmed,
                TwoFactorEnabled = p186.TwoFactorEnabled,
                LockoutEnd = p186.LockoutEnd,
                LockoutEnabled = p186.LockoutEnabled,
                AccessFailedCount = p186.AccessFailedCount
            };
        }
        
        private static AppAccessControlEntryReadModel funcMain7(AppAccessControlEntry p8)
        {
            return p8 == null ? null : new AppAccessControlEntryReadModel()
            {
                ResourcePattern = p8.ResourcePattern,
                PermissionPattern = p8.PermissionPattern,
                FeatureId = p8.FeatureId,
                Feature = funcMain8(p8.Feature),
                AppRoles = funcMain10(p8.AppRoles),
                AppUsers = funcMain11(p8.AppUsers),
                AppResource = p8.AppResource == null ? null : new AppResourceReadModel()
                {
                    Url = p8.AppResource.Url,
                    Description = p8.AppResource.Description,
                    ResourceType = p8.AppResource.ResourceType,
                    AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p8.AppResource.AccessControlEntries),
                    Id = p8.AppResource.Id,
                    CreatedBy = p8.AppResource.CreatedBy,
                    CreatedDate = p8.AppResource.CreatedDate,
                    ModifiedBy = p8.AppResource.ModifiedBy,
                    ModifiedDate = p8.AppResource.ModifiedDate,
                    IsDeleted = p8.AppResource.IsDeleted,
                    DeletedBy = p8.AppResource.DeletedBy,
                    DeletedDate = p8.AppResource.DeletedDate
                },
                ResourceId = p8.ResourceId,
                Id = p8.Id,
                CreatedBy = p8.CreatedBy,
                CreatedDate = p8.CreatedDate,
                ModifiedBy = p8.ModifiedBy,
                ModifiedDate = p8.ModifiedDate,
                IsDeleted = p8.IsDeleted,
                DeletedBy = p8.DeletedBy,
                DeletedDate = p8.DeletedDate
            };
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain20(ICollection<AppUserRole> p21)
        {
            if (p21 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p21.Count);
            
            IEnumerator<AppUserRole> enumerator = p21.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(item == null ? null : new AppUserRoleReadModel()
                {
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Hash = item.Hash,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    RoleId = item.RoleId
                });
            }
            return result;
            
        }
        
        private static ICollection<AppUserTokenReadModel> funcMain21(ICollection<AppUserToken> p22)
        {
            if (p22 == null)
            {
                return null;
            }
            ICollection<AppUserTokenReadModel> result = new List<AppUserTokenReadModel>(p22.Count);
            
            IEnumerator<AppUserToken> enumerator = p22.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserToken item = enumerator.Current;
                result.Add(item == null ? null : new AppUserTokenReadModel()
                {
                    Token = item.Token,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    LoginProvider = item.LoginProvider,
                    Name = item.Name,
                    Value = item.Value
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRefreshTokenReadModel> funcMain22(ICollection<AppRefreshToken> p23)
        {
            if (p23 == null)
            {
                return null;
            }
            ICollection<AppRefreshTokenReadModel> result = new List<AppRefreshTokenReadModel>(p23.Count);
            
            IEnumerator<AppRefreshToken> enumerator = p23.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRefreshToken item = enumerator.Current;
                result.Add(item == null ? null : new AppRefreshTokenReadModel()
                {
                    UserId = item.UserId,
                    Token = item.Token,
                    JwtId = item.JwtId,
                    IsUsed = item.IsUsed,
                    IsRevoked = item.IsRevoked,
                    ExpiryDate = item.ExpiryDate,
                    Hash = item.Hash,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static AppAccessControlEntryReadModel funcMain29(AppAccessControlEntry p33)
        {
            return p33 == null ? null : new AppAccessControlEntryReadModel()
            {
                ResourcePattern = p33.ResourcePattern,
                PermissionPattern = p33.PermissionPattern,
                FeatureId = p33.FeatureId,
                Feature = funcMain30(p33.Feature),
                AppRoles = funcMain32(p33.AppRoles),
                AppUsers = funcMain33(p33.AppUsers),
                AppResource = p33.AppResource == null ? null : new AppResourceReadModel()
                {
                    Url = p33.AppResource.Url,
                    Description = p33.AppResource.Description,
                    ResourceType = p33.AppResource.ResourceType,
                    AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p33.AppResource.AccessControlEntries),
                    Id = p33.AppResource.Id,
                    CreatedBy = p33.AppResource.CreatedBy,
                    CreatedDate = p33.AppResource.CreatedDate,
                    ModifiedBy = p33.AppResource.ModifiedBy,
                    ModifiedDate = p33.AppResource.ModifiedDate,
                    IsDeleted = p33.AppResource.IsDeleted,
                    DeletedBy = p33.AppResource.DeletedBy,
                    DeletedDate = p33.AppResource.DeletedDate
                },
                ResourceId = p33.ResourceId,
                Id = p33.Id,
                CreatedBy = p33.CreatedBy,
                CreatedDate = p33.CreatedDate,
                ModifiedBy = p33.ModifiedBy,
                ModifiedDate = p33.ModifiedDate,
                IsDeleted = p33.IsDeleted,
                DeletedBy = p33.DeletedBy,
                DeletedDate = p33.DeletedDate
            };
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain42(ICollection<AppUserRole> p48)
        {
            if (p48 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p48.Count);
            
            IEnumerator<AppUserRole> enumerator = p48.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(item == null ? null : new AppUserRoleReadModel()
                {
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Hash = item.Hash,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    RoleId = item.RoleId
                });
            }
            return result;
            
        }
        
        private static ICollection<AppUserTokenReadModel> funcMain43(ICollection<AppUserToken> p49)
        {
            if (p49 == null)
            {
                return null;
            }
            ICollection<AppUserTokenReadModel> result = new List<AppUserTokenReadModel>(p49.Count);
            
            IEnumerator<AppUserToken> enumerator = p49.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserToken item = enumerator.Current;
                result.Add(item == null ? null : new AppUserTokenReadModel()
                {
                    Token = item.Token,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    LoginProvider = item.LoginProvider,
                    Name = item.Name,
                    Value = item.Value
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRefreshTokenReadModel> funcMain44(ICollection<AppRefreshToken> p50)
        {
            if (p50 == null)
            {
                return null;
            }
            ICollection<AppRefreshTokenReadModel> result = new List<AppRefreshTokenReadModel>(p50.Count);
            
            IEnumerator<AppRefreshToken> enumerator = p50.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRefreshToken item = enumerator.Current;
                result.Add(item == null ? null : new AppRefreshTokenReadModel()
                {
                    UserId = item.UserId,
                    Token = item.Token,
                    JwtId = item.JwtId,
                    IsUsed = item.IsUsed,
                    IsRevoked = item.IsRevoked,
                    ExpiryDate = item.ExpiryDate,
                    Hash = item.Hash,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static AppAccessControlEntryReadModel funcMain51(AppAccessControlEntry p58)
        {
            return p58 == null ? null : new AppAccessControlEntryReadModel()
            {
                ResourcePattern = p58.ResourcePattern,
                PermissionPattern = p58.PermissionPattern,
                FeatureId = p58.FeatureId,
                Feature = funcMain52(p58.Feature),
                AppRoles = funcMain54(p58.AppRoles),
                AppUsers = funcMain57(p58.AppUsers),
                AppResource = p58.AppResource == null ? null : new AppResourceReadModel()
                {
                    Url = p58.AppResource.Url,
                    Description = p58.AppResource.Description,
                    ResourceType = p58.AppResource.ResourceType,
                    AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p58.AppResource.AccessControlEntries),
                    Id = p58.AppResource.Id,
                    CreatedBy = p58.AppResource.CreatedBy,
                    CreatedDate = p58.AppResource.CreatedDate,
                    ModifiedBy = p58.AppResource.ModifiedBy,
                    ModifiedDate = p58.AppResource.ModifiedDate,
                    IsDeleted = p58.AppResource.IsDeleted,
                    DeletedBy = p58.AppResource.DeletedBy,
                    DeletedDate = p58.AppResource.DeletedDate
                },
                ResourceId = p58.ResourceId,
                Id = p58.Id,
                CreatedBy = p58.CreatedBy,
                CreatedDate = p58.CreatedDate,
                ModifiedBy = p58.ModifiedBy,
                ModifiedDate = p58.ModifiedDate,
                IsDeleted = p58.IsDeleted,
                DeletedBy = p58.DeletedBy,
                DeletedDate = p58.DeletedDate
            };
        }
        
        private static AppAccessControlEntryReadModel funcMain61(AppAccessControlEntry p68)
        {
            return p68 == null ? null : new AppAccessControlEntryReadModel()
            {
                ResourcePattern = p68.ResourcePattern,
                PermissionPattern = p68.PermissionPattern,
                FeatureId = p68.FeatureId,
                Feature = funcMain62(p68.Feature),
                AppRoles = funcMain64(p68.AppRoles),
                AppUsers = funcMain65(p68.AppUsers),
                AppResource = p68.AppResource == null ? null : new AppResourceReadModel()
                {
                    Url = p68.AppResource.Url,
                    Description = p68.AppResource.Description,
                    ResourceType = p68.AppResource.ResourceType,
                    AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p68.AppResource.AccessControlEntries),
                    Id = p68.AppResource.Id,
                    CreatedBy = p68.AppResource.CreatedBy,
                    CreatedDate = p68.AppResource.CreatedDate,
                    ModifiedBy = p68.AppResource.ModifiedBy,
                    ModifiedDate = p68.AppResource.ModifiedDate,
                    IsDeleted = p68.AppResource.IsDeleted,
                    DeletedBy = p68.AppResource.DeletedBy,
                    DeletedDate = p68.AppResource.DeletedDate
                },
                ResourceId = p68.ResourceId,
                Id = p68.Id,
                CreatedBy = p68.CreatedBy,
                CreatedDate = p68.CreatedDate,
                ModifiedBy = p68.ModifiedBy,
                ModifiedDate = p68.ModifiedDate,
                IsDeleted = p68.IsDeleted,
                DeletedBy = p68.DeletedBy,
                DeletedDate = p68.DeletedDate
            };
        }
        
        private static AppUserRoleReadModel funcMain73(AppUserRole p80)
        {
            return p80 == null ? null : new AppUserRoleReadModel()
            {
                AppUser = funcMain74(p80.AppUser),
                AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(p80.AppRole),
                Hash = p80.Hash,
                CreatedBy = p80.CreatedBy,
                CreatedDate = p80.CreatedDate,
                ModifiedBy = p80.ModifiedBy,
                ModifiedDate = p80.ModifiedDate,
                IsDeleted = p80.IsDeleted,
                DeletedBy = p80.DeletedBy,
                DeletedDate = p80.DeletedDate,
                UserId = p80.UserId,
                RoleId = p80.RoleId
            };
        }
        
        private static AppAccessControlEntryReadModel funcMain84(AppAccessControlEntry p91)
        {
            return p91 == null ? null : new AppAccessControlEntryReadModel()
            {
                ResourcePattern = p91.ResourcePattern,
                PermissionPattern = p91.PermissionPattern,
                FeatureId = p91.FeatureId,
                Feature = funcMain85(p91.Feature),
                AppRoles = funcMain87(p91.AppRoles),
                AppUsers = funcMain88(p91.AppUsers),
                AppResource = p91.AppResource == null ? null : new AppResourceReadModel()
                {
                    Url = p91.AppResource.Url,
                    Description = p91.AppResource.Description,
                    ResourceType = p91.AppResource.ResourceType,
                    AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p91.AppResource.AccessControlEntries),
                    Id = p91.AppResource.Id,
                    CreatedBy = p91.AppResource.CreatedBy,
                    CreatedDate = p91.AppResource.CreatedDate,
                    ModifiedBy = p91.AppResource.ModifiedBy,
                    ModifiedDate = p91.AppResource.ModifiedDate,
                    IsDeleted = p91.AppResource.IsDeleted,
                    DeletedBy = p91.AppResource.DeletedBy,
                    DeletedDate = p91.AppResource.DeletedDate
                },
                ResourceId = p91.ResourceId,
                Id = p91.Id,
                CreatedBy = p91.CreatedBy,
                CreatedDate = p91.CreatedDate,
                ModifiedBy = p91.ModifiedBy,
                ModifiedDate = p91.ModifiedDate,
                IsDeleted = p91.IsDeleted,
                DeletedBy = p91.DeletedBy,
                DeletedDate = p91.DeletedDate
            };
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain99(ICollection<AppUserRole> p106)
        {
            if (p106 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p106.Count);
            
            IEnumerator<AppUserRole> enumerator = p106.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(funcMain100(item));
            }
            return result;
            
        }
        
        private static ICollection<AppRoleClaimReadModel> funcMain104(ICollection<AppRoleClaim> p111)
        {
            if (p111 == null)
            {
                return null;
            }
            ICollection<AppRoleClaimReadModel> result = new List<AppRoleClaimReadModel>(p111.Count);
            
            IEnumerator<AppRoleClaim> enumerator = p111.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRoleClaim item = enumerator.Current;
                result.Add(item == null ? null : new AppRoleClaimReadModel()
                {
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Id = item.Id,
                    RoleId = item.RoleId,
                    ClaimType = item.ClaimType,
                    ClaimValue = item.ClaimValue
                });
            }
            return result;
            
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain107(ICollection<AppUserRole> p114)
        {
            if (p114 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p114.Count);
            
            IEnumerator<AppUserRole> enumerator = p114.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(funcMain108(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserTokenReadModel> funcMain111(ICollection<AppUserToken> p118)
        {
            if (p118 == null)
            {
                return null;
            }
            ICollection<AppUserTokenReadModel> result = new List<AppUserTokenReadModel>(p118.Count);
            
            IEnumerator<AppUserToken> enumerator = p118.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserToken item = enumerator.Current;
                result.Add(item == null ? null : new AppUserTokenReadModel()
                {
                    Token = item.Token,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    LoginProvider = item.LoginProvider,
                    Name = item.Name,
                    Value = item.Value
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRefreshTokenReadModel> funcMain112(ICollection<AppRefreshToken> p119)
        {
            if (p119 == null)
            {
                return null;
            }
            ICollection<AppRefreshTokenReadModel> result = new List<AppRefreshTokenReadModel>(p119.Count);
            
            IEnumerator<AppRefreshToken> enumerator = p119.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRefreshToken item = enumerator.Current;
                result.Add(item == null ? null : new AppRefreshTokenReadModel()
                {
                    UserId = item.UserId,
                    Token = item.Token,
                    JwtId = item.JwtId,
                    IsUsed = item.IsUsed,
                    IsRevoked = item.IsRevoked,
                    ExpiryDate = item.ExpiryDate,
                    Hash = item.Hash,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static AppAccessControlEntryReadModel funcMain119(AppAccessControlEntry p129)
        {
            return p129 == null ? null : new AppAccessControlEntryReadModel()
            {
                ResourcePattern = p129.ResourcePattern,
                PermissionPattern = p129.PermissionPattern,
                FeatureId = p129.FeatureId,
                Feature = funcMain120(p129.Feature),
                AppRoles = funcMain122(p129.AppRoles),
                AppUsers = funcMain125(p129.AppUsers),
                AppResource = p129.AppResource == null ? null : new AppResourceReadModel()
                {
                    Url = p129.AppResource.Url,
                    Description = p129.AppResource.Description,
                    ResourceType = p129.AppResource.ResourceType,
                    AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p129.AppResource.AccessControlEntries),
                    Id = p129.AppResource.Id,
                    CreatedBy = p129.AppResource.CreatedBy,
                    CreatedDate = p129.AppResource.CreatedDate,
                    ModifiedBy = p129.AppResource.ModifiedBy,
                    ModifiedDate = p129.AppResource.ModifiedDate,
                    IsDeleted = p129.AppResource.IsDeleted,
                    DeletedBy = p129.AppResource.DeletedBy,
                    DeletedDate = p129.AppResource.DeletedDate
                },
                ResourceId = p129.ResourceId,
                Id = p129.Id,
                CreatedBy = p129.CreatedBy,
                CreatedDate = p129.CreatedDate,
                ModifiedBy = p129.ModifiedBy,
                ModifiedDate = p129.ModifiedDate,
                IsDeleted = p129.IsDeleted,
                DeletedBy = p129.DeletedBy,
                DeletedDate = p129.DeletedDate
            };
        }
        
        private static AppAccessControlEntryReadModel funcMain129(AppAccessControlEntry p139)
        {
            return p139 == null ? null : new AppAccessControlEntryReadModel()
            {
                ResourcePattern = p139.ResourcePattern,
                PermissionPattern = p139.PermissionPattern,
                FeatureId = p139.FeatureId,
                Feature = funcMain130(p139.Feature),
                AppRoles = funcMain132(p139.AppRoles),
                AppUsers = funcMain133(p139.AppUsers),
                AppResource = p139.AppResource == null ? null : new AppResourceReadModel()
                {
                    Url = p139.AppResource.Url,
                    Description = p139.AppResource.Description,
                    ResourceType = p139.AppResource.ResourceType,
                    AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p139.AppResource.AccessControlEntries),
                    Id = p139.AppResource.Id,
                    CreatedBy = p139.AppResource.CreatedBy,
                    CreatedDate = p139.AppResource.CreatedDate,
                    ModifiedBy = p139.AppResource.ModifiedBy,
                    ModifiedDate = p139.AppResource.ModifiedDate,
                    IsDeleted = p139.AppResource.IsDeleted,
                    DeletedBy = p139.AppResource.DeletedBy,
                    DeletedDate = p139.AppResource.DeletedDate
                },
                ResourceId = p139.ResourceId,
                Id = p139.Id,
                CreatedBy = p139.CreatedBy,
                CreatedDate = p139.CreatedDate,
                ModifiedBy = p139.ModifiedBy,
                ModifiedDate = p139.ModifiedDate,
                IsDeleted = p139.IsDeleted,
                DeletedBy = p139.DeletedBy,
                DeletedDate = p139.DeletedDate
            };
        }
        
        private static AppUserRoleReadModel funcMain141(AppUserRole p152)
        {
            return p152 == null ? null : new AppUserRoleReadModel()
            {
                AppUser = funcMain142(p152.AppUser),
                AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(p152.AppRole),
                Hash = p152.Hash,
                CreatedBy = p152.CreatedBy,
                CreatedDate = p152.CreatedDate,
                ModifiedBy = p152.ModifiedBy,
                ModifiedDate = p152.ModifiedDate,
                IsDeleted = p152.IsDeleted,
                DeletedBy = p152.DeletedBy,
                DeletedDate = p152.DeletedDate,
                UserId = p152.UserId,
                RoleId = p152.RoleId
            };
        }
        
        private static AppAccessControlEntryReadModel funcMain152(AppAccessControlEntry p163)
        {
            return p163 == null ? null : new AppAccessControlEntryReadModel()
            {
                ResourcePattern = p163.ResourcePattern,
                PermissionPattern = p163.PermissionPattern,
                FeatureId = p163.FeatureId,
                Feature = funcMain153(p163.Feature),
                AppRoles = funcMain155(p163.AppRoles),
                AppUsers = funcMain156(p163.AppUsers),
                AppResource = p163.AppResource == null ? null : new AppResourceReadModel()
                {
                    Url = p163.AppResource.Url,
                    Description = p163.AppResource.Description,
                    ResourceType = p163.AppResource.ResourceType,
                    AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p163.AppResource.AccessControlEntries),
                    Id = p163.AppResource.Id,
                    CreatedBy = p163.AppResource.CreatedBy,
                    CreatedDate = p163.AppResource.CreatedDate,
                    ModifiedBy = p163.AppResource.ModifiedBy,
                    ModifiedDate = p163.AppResource.ModifiedDate,
                    IsDeleted = p163.AppResource.IsDeleted,
                    DeletedBy = p163.AppResource.DeletedBy,
                    DeletedDate = p163.AppResource.DeletedDate
                },
                ResourceId = p163.ResourceId,
                Id = p163.Id,
                CreatedBy = p163.CreatedBy,
                CreatedDate = p163.CreatedDate,
                ModifiedBy = p163.ModifiedBy,
                ModifiedDate = p163.ModifiedDate,
                IsDeleted = p163.IsDeleted,
                DeletedBy = p163.DeletedBy,
                DeletedDate = p163.DeletedDate
            };
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain167(ICollection<AppUserRole> p179)
        {
            if (p179 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p179.Count);
            
            IEnumerator<AppUserRole> enumerator = p179.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(funcMain168(item));
            }
            return result;
            
        }
        
        private static ICollection<AppRoleClaimReadModel> funcMain172(ICollection<AppRoleClaim> p184)
        {
            if (p184 == null)
            {
                return null;
            }
            ICollection<AppRoleClaimReadModel> result = new List<AppRoleClaimReadModel>(p184.Count);
            
            IEnumerator<AppRoleClaim> enumerator = p184.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRoleClaim item = enumerator.Current;
                result.Add(item == null ? null : new AppRoleClaimReadModel()
                {
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Id = item.Id,
                    RoleId = item.RoleId,
                    ClaimType = item.ClaimType,
                    ClaimValue = item.ClaimValue
                });
            }
            return result;
            
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain175(ICollection<AppUserRole> p187)
        {
            if (p187 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p187.Count);
            
            IEnumerator<AppUserRole> enumerator = p187.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(funcMain176(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserTokenReadModel> funcMain179(ICollection<AppUserToken> p191)
        {
            if (p191 == null)
            {
                return null;
            }
            ICollection<AppUserTokenReadModel> result = new List<AppUserTokenReadModel>(p191.Count);
            
            IEnumerator<AppUserToken> enumerator = p191.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserToken item = enumerator.Current;
                result.Add(item == null ? null : new AppUserTokenReadModel()
                {
                    Token = item.Token,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    LoginProvider = item.LoginProvider,
                    Name = item.Name,
                    Value = item.Value
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRefreshTokenReadModel> funcMain180(ICollection<AppRefreshToken> p192)
        {
            if (p192 == null)
            {
                return null;
            }
            ICollection<AppRefreshTokenReadModel> result = new List<AppRefreshTokenReadModel>(p192.Count);
            
            IEnumerator<AppRefreshToken> enumerator = p192.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRefreshToken item = enumerator.Current;
                result.Add(item == null ? null : new AppRefreshTokenReadModel()
                {
                    UserId = item.UserId,
                    Token = item.Token,
                    JwtId = item.JwtId,
                    IsUsed = item.IsUsed,
                    IsRevoked = item.IsRevoked,
                    ExpiryDate = item.ExpiryDate,
                    Hash = item.Hash,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static AppFeatureReadModel funcMain8(AppFeature p9)
        {
            return p9 == null ? null : new AppFeatureReadModel()
            {
                Name = p9.Name,
                Description = p9.Description,
                IsEnabled = p9.IsEnabled,
                Scope = p9.Scope,
                FeatureFlags = funcMain9(p9.FeatureFlags),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p9.AccessControlEntries),
                Id = p9.Id,
                CreatedBy = p9.CreatedBy,
                CreatedDate = p9.CreatedDate,
                ModifiedBy = p9.ModifiedBy,
                ModifiedDate = p9.ModifiedDate,
                IsDeleted = p9.IsDeleted,
                DeletedBy = p9.DeletedBy,
                DeletedDate = p9.DeletedDate
            };
        }
        
        private static ICollection<AppRoleReadModel> funcMain10(ICollection<AppRole> p11)
        {
            if (p11 == null)
            {
                return null;
            }
            ICollection<AppRoleReadModel> result = new List<AppRoleReadModel>(p11.Count);
            
            IEnumerator<AppRole> enumerator = p11.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRole item = enumerator.Current;
                result.Add(TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserReadModel> funcMain11(ICollection<AppUser> p12)
        {
            if (p12 == null)
            {
                return null;
            }
            ICollection<AppUserReadModel> result = new List<AppUserReadModel>(p12.Count);
            
            IEnumerator<AppUser> enumerator = p12.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUser item = enumerator.Current;
                result.Add(TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static AppFeatureReadModel funcMain30(AppFeature p34)
        {
            return p34 == null ? null : new AppFeatureReadModel()
            {
                Name = p34.Name,
                Description = p34.Description,
                IsEnabled = p34.IsEnabled,
                Scope = p34.Scope,
                FeatureFlags = funcMain31(p34.FeatureFlags),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p34.AccessControlEntries),
                Id = p34.Id,
                CreatedBy = p34.CreatedBy,
                CreatedDate = p34.CreatedDate,
                ModifiedBy = p34.ModifiedBy,
                ModifiedDate = p34.ModifiedDate,
                IsDeleted = p34.IsDeleted,
                DeletedBy = p34.DeletedBy,
                DeletedDate = p34.DeletedDate
            };
        }
        
        private static ICollection<AppRoleReadModel> funcMain32(ICollection<AppRole> p36)
        {
            if (p36 == null)
            {
                return null;
            }
            ICollection<AppRoleReadModel> result = new List<AppRoleReadModel>(p36.Count);
            
            IEnumerator<AppRole> enumerator = p36.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRole item = enumerator.Current;
                result.Add(TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserReadModel> funcMain33(ICollection<AppUser> p37)
        {
            if (p37 == null)
            {
                return null;
            }
            ICollection<AppUserReadModel> result = new List<AppUserReadModel>(p37.Count);
            
            IEnumerator<AppUser> enumerator = p37.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUser item = enumerator.Current;
                result.Add(TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static AppFeatureReadModel funcMain52(AppFeature p59)
        {
            return p59 == null ? null : new AppFeatureReadModel()
            {
                Name = p59.Name,
                Description = p59.Description,
                IsEnabled = p59.IsEnabled,
                Scope = p59.Scope,
                FeatureFlags = funcMain53(p59.FeatureFlags),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p59.AccessControlEntries),
                Id = p59.Id,
                CreatedBy = p59.CreatedBy,
                CreatedDate = p59.CreatedDate,
                ModifiedBy = p59.ModifiedBy,
                ModifiedDate = p59.ModifiedDate,
                IsDeleted = p59.IsDeleted,
                DeletedBy = p59.DeletedBy,
                DeletedDate = p59.DeletedDate
            };
        }
        
        private static ICollection<AppRoleReadModel> funcMain54(ICollection<AppRole> p61)
        {
            if (p61 == null)
            {
                return null;
            }
            ICollection<AppRoleReadModel> result = new List<AppRoleReadModel>(p61.Count);
            
            IEnumerator<AppRole> enumerator = p61.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRole item = enumerator.Current;
                result.Add(funcMain55(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserReadModel> funcMain57(ICollection<AppUser> p64)
        {
            if (p64 == null)
            {
                return null;
            }
            ICollection<AppUserReadModel> result = new List<AppUserReadModel>(p64.Count);
            
            IEnumerator<AppUser> enumerator = p64.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUser item = enumerator.Current;
                result.Add(TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static AppFeatureReadModel funcMain62(AppFeature p69)
        {
            return p69 == null ? null : new AppFeatureReadModel()
            {
                Name = p69.Name,
                Description = p69.Description,
                IsEnabled = p69.IsEnabled,
                Scope = p69.Scope,
                FeatureFlags = funcMain63(p69.FeatureFlags),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p69.AccessControlEntries),
                Id = p69.Id,
                CreatedBy = p69.CreatedBy,
                CreatedDate = p69.CreatedDate,
                ModifiedBy = p69.ModifiedBy,
                ModifiedDate = p69.ModifiedDate,
                IsDeleted = p69.IsDeleted,
                DeletedBy = p69.DeletedBy,
                DeletedDate = p69.DeletedDate
            };
        }
        
        private static ICollection<AppRoleReadModel> funcMain64(ICollection<AppRole> p71)
        {
            if (p71 == null)
            {
                return null;
            }
            ICollection<AppRoleReadModel> result = new List<AppRoleReadModel>(p71.Count);
            
            IEnumerator<AppRole> enumerator = p71.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRole item = enumerator.Current;
                result.Add(TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserReadModel> funcMain65(ICollection<AppUser> p72)
        {
            if (p72 == null)
            {
                return null;
            }
            ICollection<AppUserReadModel> result = new List<AppUserReadModel>(p72.Count);
            
            IEnumerator<AppUser> enumerator = p72.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUser item = enumerator.Current;
                result.Add(funcMain66(item));
            }
            return result;
            
        }
        
        private static AppUserReadModel funcMain74(AppUser p81)
        {
            return p81 == null ? null : new AppUserReadModel()
            {
                Hash = p81.Hash,
                FirstName = p81.FirstName,
                LastName = p81.LastName,
                Mobile = p81.Mobile,
                CountryCode = p81.CountryCode,
                TwoFactorMethod = p81.TwoFactorMethod,
                CreatedBy = p81.CreatedBy,
                CreatedDate = p81.CreatedDate,
                ModifiedBy = p81.ModifiedBy,
                ModifiedDate = p81.ModifiedDate,
                IsDeleted = p81.IsDeleted,
                DeletedBy = p81.DeletedBy,
                DeletedDate = p81.DeletedDate,
                MembershipType = p81.MembershipType,
                UserRoles = TypeAdapter<ICollection<AppUserRole>, ICollection<AppUserRoleReadModel>>.Map.Invoke(p81.UserRoles),
                UserTokens = funcMain75(p81.UserTokens),
                RefreshTokens = funcMain76(p81.RefreshTokens),
                AccessControlEntries = funcMain77(p81.AccessControlEntries),
                Id = p81.Id,
                UserName = p81.UserName,
                NormalizedUserName = p81.NormalizedUserName,
                Email = p81.Email,
                NormalizedEmail = p81.NormalizedEmail,
                EmailConfirmed = p81.EmailConfirmed,
                PasswordHash = p81.PasswordHash,
                SecurityStamp = p81.SecurityStamp,
                ConcurrencyStamp = p81.ConcurrencyStamp,
                PhoneNumber = p81.PhoneNumber,
                PhoneNumberConfirmed = p81.PhoneNumberConfirmed,
                TwoFactorEnabled = p81.TwoFactorEnabled,
                LockoutEnd = p81.LockoutEnd,
                LockoutEnabled = p81.LockoutEnabled,
                AccessFailedCount = p81.AccessFailedCount
            };
        }
        
        private static AppFeatureReadModel funcMain85(AppFeature p92)
        {
            return p92 == null ? null : new AppFeatureReadModel()
            {
                Name = p92.Name,
                Description = p92.Description,
                IsEnabled = p92.IsEnabled,
                Scope = p92.Scope,
                FeatureFlags = funcMain86(p92.FeatureFlags),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p92.AccessControlEntries),
                Id = p92.Id,
                CreatedBy = p92.CreatedBy,
                CreatedDate = p92.CreatedDate,
                ModifiedBy = p92.ModifiedBy,
                ModifiedDate = p92.ModifiedDate,
                IsDeleted = p92.IsDeleted,
                DeletedBy = p92.DeletedBy,
                DeletedDate = p92.DeletedDate
            };
        }
        
        private static ICollection<AppRoleReadModel> funcMain87(ICollection<AppRole> p94)
        {
            if (p94 == null)
            {
                return null;
            }
            ICollection<AppRoleReadModel> result = new List<AppRoleReadModel>(p94.Count);
            
            IEnumerator<AppRole> enumerator = p94.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRole item = enumerator.Current;
                result.Add(TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserReadModel> funcMain88(ICollection<AppUser> p95)
        {
            if (p95 == null)
            {
                return null;
            }
            ICollection<AppUserReadModel> result = new List<AppUserReadModel>(p95.Count);
            
            IEnumerator<AppUser> enumerator = p95.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUser item = enumerator.Current;
                result.Add(funcMain89(item));
            }
            return result;
            
        }
        
        private static AppUserRoleReadModel funcMain100(AppUserRole p107)
        {
            return p107 == null ? null : new AppUserRoleReadModel()
            {
                AppUser = funcMain101(p107.AppUser),
                AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(p107.AppRole),
                Hash = p107.Hash,
                CreatedBy = p107.CreatedBy,
                CreatedDate = p107.CreatedDate,
                ModifiedBy = p107.ModifiedBy,
                ModifiedDate = p107.ModifiedDate,
                IsDeleted = p107.IsDeleted,
                DeletedBy = p107.DeletedBy,
                DeletedDate = p107.DeletedDate,
                UserId = p107.UserId,
                RoleId = p107.RoleId
            };
        }
        
        private static AppUserRoleReadModel funcMain108(AppUserRole p115)
        {
            return p115 == null ? null : new AppUserRoleReadModel()
            {
                AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(p115.AppUser),
                AppRole = funcMain109(p115.AppRole),
                Hash = p115.Hash,
                CreatedBy = p115.CreatedBy,
                CreatedDate = p115.CreatedDate,
                ModifiedBy = p115.ModifiedBy,
                ModifiedDate = p115.ModifiedDate,
                IsDeleted = p115.IsDeleted,
                DeletedBy = p115.DeletedBy,
                DeletedDate = p115.DeletedDate,
                UserId = p115.UserId,
                RoleId = p115.RoleId
            };
        }
        
        private static AppFeatureReadModel funcMain120(AppFeature p130)
        {
            return p130 == null ? null : new AppFeatureReadModel()
            {
                Name = p130.Name,
                Description = p130.Description,
                IsEnabled = p130.IsEnabled,
                Scope = p130.Scope,
                FeatureFlags = funcMain121(p130.FeatureFlags),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p130.AccessControlEntries),
                Id = p130.Id,
                CreatedBy = p130.CreatedBy,
                CreatedDate = p130.CreatedDate,
                ModifiedBy = p130.ModifiedBy,
                ModifiedDate = p130.ModifiedDate,
                IsDeleted = p130.IsDeleted,
                DeletedBy = p130.DeletedBy,
                DeletedDate = p130.DeletedDate
            };
        }
        
        private static ICollection<AppRoleReadModel> funcMain122(ICollection<AppRole> p132)
        {
            if (p132 == null)
            {
                return null;
            }
            ICollection<AppRoleReadModel> result = new List<AppRoleReadModel>(p132.Count);
            
            IEnumerator<AppRole> enumerator = p132.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRole item = enumerator.Current;
                result.Add(funcMain123(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserReadModel> funcMain125(ICollection<AppUser> p135)
        {
            if (p135 == null)
            {
                return null;
            }
            ICollection<AppUserReadModel> result = new List<AppUserReadModel>(p135.Count);
            
            IEnumerator<AppUser> enumerator = p135.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUser item = enumerator.Current;
                result.Add(TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static AppFeatureReadModel funcMain130(AppFeature p140)
        {
            return p140 == null ? null : new AppFeatureReadModel()
            {
                Name = p140.Name,
                Description = p140.Description,
                IsEnabled = p140.IsEnabled,
                Scope = p140.Scope,
                FeatureFlags = funcMain131(p140.FeatureFlags),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p140.AccessControlEntries),
                Id = p140.Id,
                CreatedBy = p140.CreatedBy,
                CreatedDate = p140.CreatedDate,
                ModifiedBy = p140.ModifiedBy,
                ModifiedDate = p140.ModifiedDate,
                IsDeleted = p140.IsDeleted,
                DeletedBy = p140.DeletedBy,
                DeletedDate = p140.DeletedDate
            };
        }
        
        private static ICollection<AppRoleReadModel> funcMain132(ICollection<AppRole> p142)
        {
            if (p142 == null)
            {
                return null;
            }
            ICollection<AppRoleReadModel> result = new List<AppRoleReadModel>(p142.Count);
            
            IEnumerator<AppRole> enumerator = p142.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRole item = enumerator.Current;
                result.Add(TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserReadModel> funcMain133(ICollection<AppUser> p143)
        {
            if (p143 == null)
            {
                return null;
            }
            ICollection<AppUserReadModel> result = new List<AppUserReadModel>(p143.Count);
            
            IEnumerator<AppUser> enumerator = p143.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUser item = enumerator.Current;
                result.Add(funcMain134(item));
            }
            return result;
            
        }
        
        private static AppUserReadModel funcMain142(AppUser p153)
        {
            return p153 == null ? null : new AppUserReadModel()
            {
                Hash = p153.Hash,
                FirstName = p153.FirstName,
                LastName = p153.LastName,
                Mobile = p153.Mobile,
                CountryCode = p153.CountryCode,
                TwoFactorMethod = p153.TwoFactorMethod,
                CreatedBy = p153.CreatedBy,
                CreatedDate = p153.CreatedDate,
                ModifiedBy = p153.ModifiedBy,
                ModifiedDate = p153.ModifiedDate,
                IsDeleted = p153.IsDeleted,
                DeletedBy = p153.DeletedBy,
                DeletedDate = p153.DeletedDate,
                MembershipType = p153.MembershipType,
                UserRoles = TypeAdapter<ICollection<AppUserRole>, ICollection<AppUserRoleReadModel>>.Map.Invoke(p153.UserRoles),
                UserTokens = funcMain143(p153.UserTokens),
                RefreshTokens = funcMain144(p153.RefreshTokens),
                AccessControlEntries = funcMain145(p153.AccessControlEntries),
                Id = p153.Id,
                UserName = p153.UserName,
                NormalizedUserName = p153.NormalizedUserName,
                Email = p153.Email,
                NormalizedEmail = p153.NormalizedEmail,
                EmailConfirmed = p153.EmailConfirmed,
                PasswordHash = p153.PasswordHash,
                SecurityStamp = p153.SecurityStamp,
                ConcurrencyStamp = p153.ConcurrencyStamp,
                PhoneNumber = p153.PhoneNumber,
                PhoneNumberConfirmed = p153.PhoneNumberConfirmed,
                TwoFactorEnabled = p153.TwoFactorEnabled,
                LockoutEnd = p153.LockoutEnd,
                LockoutEnabled = p153.LockoutEnabled,
                AccessFailedCount = p153.AccessFailedCount
            };
        }
        
        private static AppFeatureReadModel funcMain153(AppFeature p164)
        {
            return p164 == null ? null : new AppFeatureReadModel()
            {
                Name = p164.Name,
                Description = p164.Description,
                IsEnabled = p164.IsEnabled,
                Scope = p164.Scope,
                FeatureFlags = funcMain154(p164.FeatureFlags),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p164.AccessControlEntries),
                Id = p164.Id,
                CreatedBy = p164.CreatedBy,
                CreatedDate = p164.CreatedDate,
                ModifiedBy = p164.ModifiedBy,
                ModifiedDate = p164.ModifiedDate,
                IsDeleted = p164.IsDeleted,
                DeletedBy = p164.DeletedBy,
                DeletedDate = p164.DeletedDate
            };
        }
        
        private static ICollection<AppRoleReadModel> funcMain155(ICollection<AppRole> p166)
        {
            if (p166 == null)
            {
                return null;
            }
            ICollection<AppRoleReadModel> result = new List<AppRoleReadModel>(p166.Count);
            
            IEnumerator<AppRole> enumerator = p166.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRole item = enumerator.Current;
                result.Add(TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserReadModel> funcMain156(ICollection<AppUser> p167)
        {
            if (p167 == null)
            {
                return null;
            }
            ICollection<AppUserReadModel> result = new List<AppUserReadModel>(p167.Count);
            
            IEnumerator<AppUser> enumerator = p167.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUser item = enumerator.Current;
                result.Add(funcMain157(item));
            }
            return result;
            
        }
        
        private static AppUserRoleReadModel funcMain168(AppUserRole p180)
        {
            return p180 == null ? null : new AppUserRoleReadModel()
            {
                AppUser = funcMain169(p180.AppUser),
                AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(p180.AppRole),
                Hash = p180.Hash,
                CreatedBy = p180.CreatedBy,
                CreatedDate = p180.CreatedDate,
                ModifiedBy = p180.ModifiedBy,
                ModifiedDate = p180.ModifiedDate,
                IsDeleted = p180.IsDeleted,
                DeletedBy = p180.DeletedBy,
                DeletedDate = p180.DeletedDate,
                UserId = p180.UserId,
                RoleId = p180.RoleId
            };
        }
        
        private static AppUserRoleReadModel funcMain176(AppUserRole p188)
        {
            return p188 == null ? null : new AppUserRoleReadModel()
            {
                AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(p188.AppUser),
                AppRole = funcMain177(p188.AppRole),
                Hash = p188.Hash,
                CreatedBy = p188.CreatedBy,
                CreatedDate = p188.CreatedDate,
                ModifiedBy = p188.ModifiedBy,
                ModifiedDate = p188.ModifiedDate,
                IsDeleted = p188.IsDeleted,
                DeletedBy = p188.DeletedBy,
                DeletedDate = p188.DeletedDate,
                UserId = p188.UserId,
                RoleId = p188.RoleId
            };
        }
        
        private static ICollection<AppFeatureFlagReadModel> funcMain9(ICollection<AppFeatureFlag> p10)
        {
            if (p10 == null)
            {
                return null;
            }
            ICollection<AppFeatureFlagReadModel> result = new List<AppFeatureFlagReadModel>(p10.Count);
            
            IEnumerator<AppFeatureFlag> enumerator = p10.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppFeatureFlag item = enumerator.Current;
                result.Add(item == null ? null : new AppFeatureFlagReadModel()
                {
                    FeatureId = item.FeatureId,
                    ScopeIdentifier = item.ScopeIdentifier,
                    IsEnabled = item.IsEnabled,
                    Feature = TypeAdapter<AppFeature, AppFeatureReadModel>.Map.Invoke(item.Feature),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static ICollection<AppFeatureFlagReadModel> funcMain31(ICollection<AppFeatureFlag> p35)
        {
            if (p35 == null)
            {
                return null;
            }
            ICollection<AppFeatureFlagReadModel> result = new List<AppFeatureFlagReadModel>(p35.Count);
            
            IEnumerator<AppFeatureFlag> enumerator = p35.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppFeatureFlag item = enumerator.Current;
                result.Add(item == null ? null : new AppFeatureFlagReadModel()
                {
                    FeatureId = item.FeatureId,
                    ScopeIdentifier = item.ScopeIdentifier,
                    IsEnabled = item.IsEnabled,
                    Feature = TypeAdapter<AppFeature, AppFeatureReadModel>.Map.Invoke(item.Feature),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static ICollection<AppFeatureFlagReadModel> funcMain53(ICollection<AppFeatureFlag> p60)
        {
            if (p60 == null)
            {
                return null;
            }
            ICollection<AppFeatureFlagReadModel> result = new List<AppFeatureFlagReadModel>(p60.Count);
            
            IEnumerator<AppFeatureFlag> enumerator = p60.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppFeatureFlag item = enumerator.Current;
                result.Add(item == null ? null : new AppFeatureFlagReadModel()
                {
                    FeatureId = item.FeatureId,
                    ScopeIdentifier = item.ScopeIdentifier,
                    IsEnabled = item.IsEnabled,
                    Feature = TypeAdapter<AppFeature, AppFeatureReadModel>.Map.Invoke(item.Feature),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static AppRoleReadModel funcMain55(AppRole p62)
        {
            return p62 == null ? null : new AppRoleReadModel()
            {
                CreatedBy = p62.CreatedBy,
                CreatedDate = p62.CreatedDate,
                ModifiedBy = p62.ModifiedBy,
                ModifiedDate = p62.ModifiedDate,
                IsDeleted = p62.IsDeleted,
                DeletedBy = p62.DeletedBy,
                DeletedDate = p62.DeletedDate,
                AppUserRoles = TypeAdapter<ICollection<AppUserRole>, ICollection<AppUserRoleReadModel>>.Map.Invoke(p62.AppUserRoles),
                AppRoleClaims = funcMain56(p62.AppRoleClaims),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p62.AccessControlEntries),
                Hash = p62.Hash,
                Id = p62.Id,
                Name = p62.Name,
                NormalizedName = p62.NormalizedName,
                ConcurrencyStamp = p62.ConcurrencyStamp
            };
        }
        
        private static ICollection<AppFeatureFlagReadModel> funcMain63(ICollection<AppFeatureFlag> p70)
        {
            if (p70 == null)
            {
                return null;
            }
            ICollection<AppFeatureFlagReadModel> result = new List<AppFeatureFlagReadModel>(p70.Count);
            
            IEnumerator<AppFeatureFlag> enumerator = p70.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppFeatureFlag item = enumerator.Current;
                result.Add(item == null ? null : new AppFeatureFlagReadModel()
                {
                    FeatureId = item.FeatureId,
                    ScopeIdentifier = item.ScopeIdentifier,
                    IsEnabled = item.IsEnabled,
                    Feature = TypeAdapter<AppFeature, AppFeatureReadModel>.Map.Invoke(item.Feature),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static AppUserReadModel funcMain66(AppUser p73)
        {
            return p73 == null ? null : new AppUserReadModel()
            {
                Hash = p73.Hash,
                FirstName = p73.FirstName,
                LastName = p73.LastName,
                Mobile = p73.Mobile,
                CountryCode = p73.CountryCode,
                TwoFactorMethod = p73.TwoFactorMethod,
                CreatedBy = p73.CreatedBy,
                CreatedDate = p73.CreatedDate,
                ModifiedBy = p73.ModifiedBy,
                ModifiedDate = p73.ModifiedDate,
                IsDeleted = p73.IsDeleted,
                DeletedBy = p73.DeletedBy,
                DeletedDate = p73.DeletedDate,
                MembershipType = p73.MembershipType,
                UserRoles = TypeAdapter<ICollection<AppUserRole>, ICollection<AppUserRoleReadModel>>.Map.Invoke(p73.UserRoles),
                UserTokens = funcMain67(p73.UserTokens),
                RefreshTokens = funcMain68(p73.RefreshTokens),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p73.AccessControlEntries),
                Id = p73.Id,
                UserName = p73.UserName,
                NormalizedUserName = p73.NormalizedUserName,
                Email = p73.Email,
                NormalizedEmail = p73.NormalizedEmail,
                EmailConfirmed = p73.EmailConfirmed,
                PasswordHash = p73.PasswordHash,
                SecurityStamp = p73.SecurityStamp,
                ConcurrencyStamp = p73.ConcurrencyStamp,
                PhoneNumber = p73.PhoneNumber,
                PhoneNumberConfirmed = p73.PhoneNumberConfirmed,
                TwoFactorEnabled = p73.TwoFactorEnabled,
                LockoutEnd = p73.LockoutEnd,
                LockoutEnabled = p73.LockoutEnabled,
                AccessFailedCount = p73.AccessFailedCount
            };
        }
        
        private static ICollection<AppUserTokenReadModel> funcMain75(ICollection<AppUserToken> p82)
        {
            if (p82 == null)
            {
                return null;
            }
            ICollection<AppUserTokenReadModel> result = new List<AppUserTokenReadModel>(p82.Count);
            
            IEnumerator<AppUserToken> enumerator = p82.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserToken item = enumerator.Current;
                result.Add(item == null ? null : new AppUserTokenReadModel()
                {
                    Token = item.Token,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    LoginProvider = item.LoginProvider,
                    Name = item.Name,
                    Value = item.Value
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRefreshTokenReadModel> funcMain76(ICollection<AppRefreshToken> p83)
        {
            if (p83 == null)
            {
                return null;
            }
            ICollection<AppRefreshTokenReadModel> result = new List<AppRefreshTokenReadModel>(p83.Count);
            
            IEnumerator<AppRefreshToken> enumerator = p83.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRefreshToken item = enumerator.Current;
                result.Add(item == null ? null : new AppRefreshTokenReadModel()
                {
                    UserId = item.UserId,
                    Token = item.Token,
                    JwtId = item.JwtId,
                    IsUsed = item.IsUsed,
                    IsRevoked = item.IsRevoked,
                    ExpiryDate = item.ExpiryDate,
                    Hash = item.Hash,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static ICollection<AppAccessControlEntryReadModel> funcMain77(ICollection<AppAccessControlEntry> p84)
        {
            if (p84 == null)
            {
                return null;
            }
            ICollection<AppAccessControlEntryReadModel> result = new List<AppAccessControlEntryReadModel>(p84.Count);
            
            IEnumerator<AppAccessControlEntry> enumerator = p84.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppAccessControlEntry item = enumerator.Current;
                result.Add(funcMain78(item));
            }
            return result;
            
        }
        
        private static ICollection<AppFeatureFlagReadModel> funcMain86(ICollection<AppFeatureFlag> p93)
        {
            if (p93 == null)
            {
                return null;
            }
            ICollection<AppFeatureFlagReadModel> result = new List<AppFeatureFlagReadModel>(p93.Count);
            
            IEnumerator<AppFeatureFlag> enumerator = p93.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppFeatureFlag item = enumerator.Current;
                result.Add(item == null ? null : new AppFeatureFlagReadModel()
                {
                    FeatureId = item.FeatureId,
                    ScopeIdentifier = item.ScopeIdentifier,
                    IsEnabled = item.IsEnabled,
                    Feature = TypeAdapter<AppFeature, AppFeatureReadModel>.Map.Invoke(item.Feature),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static AppUserReadModel funcMain89(AppUser p96)
        {
            return p96 == null ? null : new AppUserReadModel()
            {
                Hash = p96.Hash,
                FirstName = p96.FirstName,
                LastName = p96.LastName,
                Mobile = p96.Mobile,
                CountryCode = p96.CountryCode,
                TwoFactorMethod = p96.TwoFactorMethod,
                CreatedBy = p96.CreatedBy,
                CreatedDate = p96.CreatedDate,
                ModifiedBy = p96.ModifiedBy,
                ModifiedDate = p96.ModifiedDate,
                IsDeleted = p96.IsDeleted,
                DeletedBy = p96.DeletedBy,
                DeletedDate = p96.DeletedDate,
                MembershipType = p96.MembershipType,
                UserRoles = funcMain90(p96.UserRoles),
                UserTokens = funcMain91(p96.UserTokens),
                RefreshTokens = funcMain92(p96.RefreshTokens),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p96.AccessControlEntries),
                Id = p96.Id,
                UserName = p96.UserName,
                NormalizedUserName = p96.NormalizedUserName,
                Email = p96.Email,
                NormalizedEmail = p96.NormalizedEmail,
                EmailConfirmed = p96.EmailConfirmed,
                PasswordHash = p96.PasswordHash,
                SecurityStamp = p96.SecurityStamp,
                ConcurrencyStamp = p96.ConcurrencyStamp,
                PhoneNumber = p96.PhoneNumber,
                PhoneNumberConfirmed = p96.PhoneNumberConfirmed,
                TwoFactorEnabled = p96.TwoFactorEnabled,
                LockoutEnd = p96.LockoutEnd,
                LockoutEnabled = p96.LockoutEnabled,
                AccessFailedCount = p96.AccessFailedCount
            };
        }
        
        private static AppUserReadModel funcMain101(AppUser p108)
        {
            return p108 == null ? null : new AppUserReadModel()
            {
                Hash = p108.Hash,
                FirstName = p108.FirstName,
                LastName = p108.LastName,
                Mobile = p108.Mobile,
                CountryCode = p108.CountryCode,
                TwoFactorMethod = p108.TwoFactorMethod,
                CreatedBy = p108.CreatedBy,
                CreatedDate = p108.CreatedDate,
                ModifiedBy = p108.ModifiedBy,
                ModifiedDate = p108.ModifiedDate,
                IsDeleted = p108.IsDeleted,
                DeletedBy = p108.DeletedBy,
                DeletedDate = p108.DeletedDate,
                MembershipType = p108.MembershipType,
                UserRoles = TypeAdapter<ICollection<AppUserRole>, ICollection<AppUserRoleReadModel>>.Map.Invoke(p108.UserRoles),
                UserTokens = funcMain102(p108.UserTokens),
                RefreshTokens = funcMain103(p108.RefreshTokens),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p108.AccessControlEntries),
                Id = p108.Id,
                UserName = p108.UserName,
                NormalizedUserName = p108.NormalizedUserName,
                Email = p108.Email,
                NormalizedEmail = p108.NormalizedEmail,
                EmailConfirmed = p108.EmailConfirmed,
                PasswordHash = p108.PasswordHash,
                SecurityStamp = p108.SecurityStamp,
                ConcurrencyStamp = p108.ConcurrencyStamp,
                PhoneNumber = p108.PhoneNumber,
                PhoneNumberConfirmed = p108.PhoneNumberConfirmed,
                TwoFactorEnabled = p108.TwoFactorEnabled,
                LockoutEnd = p108.LockoutEnd,
                LockoutEnabled = p108.LockoutEnabled,
                AccessFailedCount = p108.AccessFailedCount
            };
        }
        
        private static AppRoleReadModel funcMain109(AppRole p116)
        {
            return p116 == null ? null : new AppRoleReadModel()
            {
                CreatedBy = p116.CreatedBy,
                CreatedDate = p116.CreatedDate,
                ModifiedBy = p116.ModifiedBy,
                ModifiedDate = p116.ModifiedDate,
                IsDeleted = p116.IsDeleted,
                DeletedBy = p116.DeletedBy,
                DeletedDate = p116.DeletedDate,
                AppUserRoles = TypeAdapter<ICollection<AppUserRole>, ICollection<AppUserRoleReadModel>>.Map.Invoke(p116.AppUserRoles),
                AppRoleClaims = funcMain110(p116.AppRoleClaims),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p116.AccessControlEntries),
                Hash = p116.Hash,
                Id = p116.Id,
                Name = p116.Name,
                NormalizedName = p116.NormalizedName,
                ConcurrencyStamp = p116.ConcurrencyStamp
            };
        }
        
        private static ICollection<AppFeatureFlagReadModel> funcMain121(ICollection<AppFeatureFlag> p131)
        {
            if (p131 == null)
            {
                return null;
            }
            ICollection<AppFeatureFlagReadModel> result = new List<AppFeatureFlagReadModel>(p131.Count);
            
            IEnumerator<AppFeatureFlag> enumerator = p131.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppFeatureFlag item = enumerator.Current;
                result.Add(item == null ? null : new AppFeatureFlagReadModel()
                {
                    FeatureId = item.FeatureId,
                    ScopeIdentifier = item.ScopeIdentifier,
                    IsEnabled = item.IsEnabled,
                    Feature = TypeAdapter<AppFeature, AppFeatureReadModel>.Map.Invoke(item.Feature),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static AppRoleReadModel funcMain123(AppRole p133)
        {
            return p133 == null ? null : new AppRoleReadModel()
            {
                CreatedBy = p133.CreatedBy,
                CreatedDate = p133.CreatedDate,
                ModifiedBy = p133.ModifiedBy,
                ModifiedDate = p133.ModifiedDate,
                IsDeleted = p133.IsDeleted,
                DeletedBy = p133.DeletedBy,
                DeletedDate = p133.DeletedDate,
                AppUserRoles = TypeAdapter<ICollection<AppUserRole>, ICollection<AppUserRoleReadModel>>.Map.Invoke(p133.AppUserRoles),
                AppRoleClaims = funcMain124(p133.AppRoleClaims),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p133.AccessControlEntries),
                Hash = p133.Hash,
                Id = p133.Id,
                Name = p133.Name,
                NormalizedName = p133.NormalizedName,
                ConcurrencyStamp = p133.ConcurrencyStamp
            };
        }
        
        private static ICollection<AppFeatureFlagReadModel> funcMain131(ICollection<AppFeatureFlag> p141)
        {
            if (p141 == null)
            {
                return null;
            }
            ICollection<AppFeatureFlagReadModel> result = new List<AppFeatureFlagReadModel>(p141.Count);
            
            IEnumerator<AppFeatureFlag> enumerator = p141.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppFeatureFlag item = enumerator.Current;
                result.Add(item == null ? null : new AppFeatureFlagReadModel()
                {
                    FeatureId = item.FeatureId,
                    ScopeIdentifier = item.ScopeIdentifier,
                    IsEnabled = item.IsEnabled,
                    Feature = TypeAdapter<AppFeature, AppFeatureReadModel>.Map.Invoke(item.Feature),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static AppUserReadModel funcMain134(AppUser p144)
        {
            return p144 == null ? null : new AppUserReadModel()
            {
                Hash = p144.Hash,
                FirstName = p144.FirstName,
                LastName = p144.LastName,
                Mobile = p144.Mobile,
                CountryCode = p144.CountryCode,
                TwoFactorMethod = p144.TwoFactorMethod,
                CreatedBy = p144.CreatedBy,
                CreatedDate = p144.CreatedDate,
                ModifiedBy = p144.ModifiedBy,
                ModifiedDate = p144.ModifiedDate,
                IsDeleted = p144.IsDeleted,
                DeletedBy = p144.DeletedBy,
                DeletedDate = p144.DeletedDate,
                MembershipType = p144.MembershipType,
                UserRoles = TypeAdapter<ICollection<AppUserRole>, ICollection<AppUserRoleReadModel>>.Map.Invoke(p144.UserRoles),
                UserTokens = funcMain135(p144.UserTokens),
                RefreshTokens = funcMain136(p144.RefreshTokens),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p144.AccessControlEntries),
                Id = p144.Id,
                UserName = p144.UserName,
                NormalizedUserName = p144.NormalizedUserName,
                Email = p144.Email,
                NormalizedEmail = p144.NormalizedEmail,
                EmailConfirmed = p144.EmailConfirmed,
                PasswordHash = p144.PasswordHash,
                SecurityStamp = p144.SecurityStamp,
                ConcurrencyStamp = p144.ConcurrencyStamp,
                PhoneNumber = p144.PhoneNumber,
                PhoneNumberConfirmed = p144.PhoneNumberConfirmed,
                TwoFactorEnabled = p144.TwoFactorEnabled,
                LockoutEnd = p144.LockoutEnd,
                LockoutEnabled = p144.LockoutEnabled,
                AccessFailedCount = p144.AccessFailedCount
            };
        }
        
        private static ICollection<AppUserTokenReadModel> funcMain143(ICollection<AppUserToken> p154)
        {
            if (p154 == null)
            {
                return null;
            }
            ICollection<AppUserTokenReadModel> result = new List<AppUserTokenReadModel>(p154.Count);
            
            IEnumerator<AppUserToken> enumerator = p154.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserToken item = enumerator.Current;
                result.Add(item == null ? null : new AppUserTokenReadModel()
                {
                    Token = item.Token,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    LoginProvider = item.LoginProvider,
                    Name = item.Name,
                    Value = item.Value
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRefreshTokenReadModel> funcMain144(ICollection<AppRefreshToken> p155)
        {
            if (p155 == null)
            {
                return null;
            }
            ICollection<AppRefreshTokenReadModel> result = new List<AppRefreshTokenReadModel>(p155.Count);
            
            IEnumerator<AppRefreshToken> enumerator = p155.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRefreshToken item = enumerator.Current;
                result.Add(item == null ? null : new AppRefreshTokenReadModel()
                {
                    UserId = item.UserId,
                    Token = item.Token,
                    JwtId = item.JwtId,
                    IsUsed = item.IsUsed,
                    IsRevoked = item.IsRevoked,
                    ExpiryDate = item.ExpiryDate,
                    Hash = item.Hash,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static ICollection<AppAccessControlEntryReadModel> funcMain145(ICollection<AppAccessControlEntry> p156)
        {
            if (p156 == null)
            {
                return null;
            }
            ICollection<AppAccessControlEntryReadModel> result = new List<AppAccessControlEntryReadModel>(p156.Count);
            
            IEnumerator<AppAccessControlEntry> enumerator = p156.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppAccessControlEntry item = enumerator.Current;
                result.Add(funcMain146(item));
            }
            return result;
            
        }
        
        private static ICollection<AppFeatureFlagReadModel> funcMain154(ICollection<AppFeatureFlag> p165)
        {
            if (p165 == null)
            {
                return null;
            }
            ICollection<AppFeatureFlagReadModel> result = new List<AppFeatureFlagReadModel>(p165.Count);
            
            IEnumerator<AppFeatureFlag> enumerator = p165.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppFeatureFlag item = enumerator.Current;
                result.Add(item == null ? null : new AppFeatureFlagReadModel()
                {
                    FeatureId = item.FeatureId,
                    ScopeIdentifier = item.ScopeIdentifier,
                    IsEnabled = item.IsEnabled,
                    Feature = TypeAdapter<AppFeature, AppFeatureReadModel>.Map.Invoke(item.Feature),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static AppUserReadModel funcMain157(AppUser p168)
        {
            return p168 == null ? null : new AppUserReadModel()
            {
                Hash = p168.Hash,
                FirstName = p168.FirstName,
                LastName = p168.LastName,
                Mobile = p168.Mobile,
                CountryCode = p168.CountryCode,
                TwoFactorMethod = p168.TwoFactorMethod,
                CreatedBy = p168.CreatedBy,
                CreatedDate = p168.CreatedDate,
                ModifiedBy = p168.ModifiedBy,
                ModifiedDate = p168.ModifiedDate,
                IsDeleted = p168.IsDeleted,
                DeletedBy = p168.DeletedBy,
                DeletedDate = p168.DeletedDate,
                MembershipType = p168.MembershipType,
                UserRoles = funcMain158(p168.UserRoles),
                UserTokens = funcMain159(p168.UserTokens),
                RefreshTokens = funcMain160(p168.RefreshTokens),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p168.AccessControlEntries),
                Id = p168.Id,
                UserName = p168.UserName,
                NormalizedUserName = p168.NormalizedUserName,
                Email = p168.Email,
                NormalizedEmail = p168.NormalizedEmail,
                EmailConfirmed = p168.EmailConfirmed,
                PasswordHash = p168.PasswordHash,
                SecurityStamp = p168.SecurityStamp,
                ConcurrencyStamp = p168.ConcurrencyStamp,
                PhoneNumber = p168.PhoneNumber,
                PhoneNumberConfirmed = p168.PhoneNumberConfirmed,
                TwoFactorEnabled = p168.TwoFactorEnabled,
                LockoutEnd = p168.LockoutEnd,
                LockoutEnabled = p168.LockoutEnabled,
                AccessFailedCount = p168.AccessFailedCount
            };
        }
        
        private static AppUserReadModel funcMain169(AppUser p181)
        {
            return p181 == null ? null : new AppUserReadModel()
            {
                Hash = p181.Hash,
                FirstName = p181.FirstName,
                LastName = p181.LastName,
                Mobile = p181.Mobile,
                CountryCode = p181.CountryCode,
                TwoFactorMethod = p181.TwoFactorMethod,
                CreatedBy = p181.CreatedBy,
                CreatedDate = p181.CreatedDate,
                ModifiedBy = p181.ModifiedBy,
                ModifiedDate = p181.ModifiedDate,
                IsDeleted = p181.IsDeleted,
                DeletedBy = p181.DeletedBy,
                DeletedDate = p181.DeletedDate,
                MembershipType = p181.MembershipType,
                UserRoles = TypeAdapter<ICollection<AppUserRole>, ICollection<AppUserRoleReadModel>>.Map.Invoke(p181.UserRoles),
                UserTokens = funcMain170(p181.UserTokens),
                RefreshTokens = funcMain171(p181.RefreshTokens),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p181.AccessControlEntries),
                Id = p181.Id,
                UserName = p181.UserName,
                NormalizedUserName = p181.NormalizedUserName,
                Email = p181.Email,
                NormalizedEmail = p181.NormalizedEmail,
                EmailConfirmed = p181.EmailConfirmed,
                PasswordHash = p181.PasswordHash,
                SecurityStamp = p181.SecurityStamp,
                ConcurrencyStamp = p181.ConcurrencyStamp,
                PhoneNumber = p181.PhoneNumber,
                PhoneNumberConfirmed = p181.PhoneNumberConfirmed,
                TwoFactorEnabled = p181.TwoFactorEnabled,
                LockoutEnd = p181.LockoutEnd,
                LockoutEnabled = p181.LockoutEnabled,
                AccessFailedCount = p181.AccessFailedCount
            };
        }
        
        private static AppRoleReadModel funcMain177(AppRole p189)
        {
            return p189 == null ? null : new AppRoleReadModel()
            {
                CreatedBy = p189.CreatedBy,
                CreatedDate = p189.CreatedDate,
                ModifiedBy = p189.ModifiedBy,
                ModifiedDate = p189.ModifiedDate,
                IsDeleted = p189.IsDeleted,
                DeletedBy = p189.DeletedBy,
                DeletedDate = p189.DeletedDate,
                AppUserRoles = TypeAdapter<ICollection<AppUserRole>, ICollection<AppUserRoleReadModel>>.Map.Invoke(p189.AppUserRoles),
                AppRoleClaims = funcMain178(p189.AppRoleClaims),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p189.AccessControlEntries),
                Hash = p189.Hash,
                Id = p189.Id,
                Name = p189.Name,
                NormalizedName = p189.NormalizedName,
                ConcurrencyStamp = p189.ConcurrencyStamp
            };
        }
        
        private static ICollection<AppRoleClaimReadModel> funcMain56(ICollection<AppRoleClaim> p63)
        {
            if (p63 == null)
            {
                return null;
            }
            ICollection<AppRoleClaimReadModel> result = new List<AppRoleClaimReadModel>(p63.Count);
            
            IEnumerator<AppRoleClaim> enumerator = p63.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRoleClaim item = enumerator.Current;
                result.Add(item == null ? null : new AppRoleClaimReadModel()
                {
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Id = item.Id,
                    RoleId = item.RoleId,
                    ClaimType = item.ClaimType,
                    ClaimValue = item.ClaimValue
                });
            }
            return result;
            
        }
        
        private static ICollection<AppUserTokenReadModel> funcMain67(ICollection<AppUserToken> p74)
        {
            if (p74 == null)
            {
                return null;
            }
            ICollection<AppUserTokenReadModel> result = new List<AppUserTokenReadModel>(p74.Count);
            
            IEnumerator<AppUserToken> enumerator = p74.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserToken item = enumerator.Current;
                result.Add(item == null ? null : new AppUserTokenReadModel()
                {
                    Token = item.Token,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    LoginProvider = item.LoginProvider,
                    Name = item.Name,
                    Value = item.Value
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRefreshTokenReadModel> funcMain68(ICollection<AppRefreshToken> p75)
        {
            if (p75 == null)
            {
                return null;
            }
            ICollection<AppRefreshTokenReadModel> result = new List<AppRefreshTokenReadModel>(p75.Count);
            
            IEnumerator<AppRefreshToken> enumerator = p75.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRefreshToken item = enumerator.Current;
                result.Add(item == null ? null : new AppRefreshTokenReadModel()
                {
                    UserId = item.UserId,
                    Token = item.Token,
                    JwtId = item.JwtId,
                    IsUsed = item.IsUsed,
                    IsRevoked = item.IsRevoked,
                    ExpiryDate = item.ExpiryDate,
                    Hash = item.Hash,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static AppAccessControlEntryReadModel funcMain78(AppAccessControlEntry p85)
        {
            return p85 == null ? null : new AppAccessControlEntryReadModel()
            {
                ResourcePattern = p85.ResourcePattern,
                PermissionPattern = p85.PermissionPattern,
                FeatureId = p85.FeatureId,
                Feature = funcMain79(p85.Feature),
                AppRoles = funcMain81(p85.AppRoles),
                AppUsers = funcMain82(p85.AppUsers),
                AppResource = p85.AppResource == null ? null : new AppResourceReadModel()
                {
                    Url = p85.AppResource.Url,
                    Description = p85.AppResource.Description,
                    ResourceType = p85.AppResource.ResourceType,
                    AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p85.AppResource.AccessControlEntries),
                    Id = p85.AppResource.Id,
                    CreatedBy = p85.AppResource.CreatedBy,
                    CreatedDate = p85.AppResource.CreatedDate,
                    ModifiedBy = p85.AppResource.ModifiedBy,
                    ModifiedDate = p85.AppResource.ModifiedDate,
                    IsDeleted = p85.AppResource.IsDeleted,
                    DeletedBy = p85.AppResource.DeletedBy,
                    DeletedDate = p85.AppResource.DeletedDate
                },
                ResourceId = p85.ResourceId,
                Id = p85.Id,
                CreatedBy = p85.CreatedBy,
                CreatedDate = p85.CreatedDate,
                ModifiedBy = p85.ModifiedBy,
                ModifiedDate = p85.ModifiedDate,
                IsDeleted = p85.IsDeleted,
                DeletedBy = p85.DeletedBy,
                DeletedDate = p85.DeletedDate
            };
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain90(ICollection<AppUserRole> p97)
        {
            if (p97 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p97.Count);
            
            IEnumerator<AppUserRole> enumerator = p97.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(item == null ? null : new AppUserRoleReadModel()
                {
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Hash = item.Hash,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    RoleId = item.RoleId
                });
            }
            return result;
            
        }
        
        private static ICollection<AppUserTokenReadModel> funcMain91(ICollection<AppUserToken> p98)
        {
            if (p98 == null)
            {
                return null;
            }
            ICollection<AppUserTokenReadModel> result = new List<AppUserTokenReadModel>(p98.Count);
            
            IEnumerator<AppUserToken> enumerator = p98.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserToken item = enumerator.Current;
                result.Add(item == null ? null : new AppUserTokenReadModel()
                {
                    Token = item.Token,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    LoginProvider = item.LoginProvider,
                    Name = item.Name,
                    Value = item.Value
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRefreshTokenReadModel> funcMain92(ICollection<AppRefreshToken> p99)
        {
            if (p99 == null)
            {
                return null;
            }
            ICollection<AppRefreshTokenReadModel> result = new List<AppRefreshTokenReadModel>(p99.Count);
            
            IEnumerator<AppRefreshToken> enumerator = p99.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRefreshToken item = enumerator.Current;
                result.Add(item == null ? null : new AppRefreshTokenReadModel()
                {
                    UserId = item.UserId,
                    Token = item.Token,
                    JwtId = item.JwtId,
                    IsUsed = item.IsUsed,
                    IsRevoked = item.IsRevoked,
                    ExpiryDate = item.ExpiryDate,
                    Hash = item.Hash,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static ICollection<AppUserTokenReadModel> funcMain102(ICollection<AppUserToken> p109)
        {
            if (p109 == null)
            {
                return null;
            }
            ICollection<AppUserTokenReadModel> result = new List<AppUserTokenReadModel>(p109.Count);
            
            IEnumerator<AppUserToken> enumerator = p109.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserToken item = enumerator.Current;
                result.Add(item == null ? null : new AppUserTokenReadModel()
                {
                    Token = item.Token,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    LoginProvider = item.LoginProvider,
                    Name = item.Name,
                    Value = item.Value
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRefreshTokenReadModel> funcMain103(ICollection<AppRefreshToken> p110)
        {
            if (p110 == null)
            {
                return null;
            }
            ICollection<AppRefreshTokenReadModel> result = new List<AppRefreshTokenReadModel>(p110.Count);
            
            IEnumerator<AppRefreshToken> enumerator = p110.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRefreshToken item = enumerator.Current;
                result.Add(item == null ? null : new AppRefreshTokenReadModel()
                {
                    UserId = item.UserId,
                    Token = item.Token,
                    JwtId = item.JwtId,
                    IsUsed = item.IsUsed,
                    IsRevoked = item.IsRevoked,
                    ExpiryDate = item.ExpiryDate,
                    Hash = item.Hash,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRoleClaimReadModel> funcMain110(ICollection<AppRoleClaim> p117)
        {
            if (p117 == null)
            {
                return null;
            }
            ICollection<AppRoleClaimReadModel> result = new List<AppRoleClaimReadModel>(p117.Count);
            
            IEnumerator<AppRoleClaim> enumerator = p117.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRoleClaim item = enumerator.Current;
                result.Add(item == null ? null : new AppRoleClaimReadModel()
                {
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Id = item.Id,
                    RoleId = item.RoleId,
                    ClaimType = item.ClaimType,
                    ClaimValue = item.ClaimValue
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRoleClaimReadModel> funcMain124(ICollection<AppRoleClaim> p134)
        {
            if (p134 == null)
            {
                return null;
            }
            ICollection<AppRoleClaimReadModel> result = new List<AppRoleClaimReadModel>(p134.Count);
            
            IEnumerator<AppRoleClaim> enumerator = p134.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRoleClaim item = enumerator.Current;
                result.Add(item == null ? null : new AppRoleClaimReadModel()
                {
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Id = item.Id,
                    RoleId = item.RoleId,
                    ClaimType = item.ClaimType,
                    ClaimValue = item.ClaimValue
                });
            }
            return result;
            
        }
        
        private static ICollection<AppUserTokenReadModel> funcMain135(ICollection<AppUserToken> p145)
        {
            if (p145 == null)
            {
                return null;
            }
            ICollection<AppUserTokenReadModel> result = new List<AppUserTokenReadModel>(p145.Count);
            
            IEnumerator<AppUserToken> enumerator = p145.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserToken item = enumerator.Current;
                result.Add(item == null ? null : new AppUserTokenReadModel()
                {
                    Token = item.Token,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    LoginProvider = item.LoginProvider,
                    Name = item.Name,
                    Value = item.Value
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRefreshTokenReadModel> funcMain136(ICollection<AppRefreshToken> p146)
        {
            if (p146 == null)
            {
                return null;
            }
            ICollection<AppRefreshTokenReadModel> result = new List<AppRefreshTokenReadModel>(p146.Count);
            
            IEnumerator<AppRefreshToken> enumerator = p146.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRefreshToken item = enumerator.Current;
                result.Add(item == null ? null : new AppRefreshTokenReadModel()
                {
                    UserId = item.UserId,
                    Token = item.Token,
                    JwtId = item.JwtId,
                    IsUsed = item.IsUsed,
                    IsRevoked = item.IsRevoked,
                    ExpiryDate = item.ExpiryDate,
                    Hash = item.Hash,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static AppAccessControlEntryReadModel funcMain146(AppAccessControlEntry p157)
        {
            return p157 == null ? null : new AppAccessControlEntryReadModel()
            {
                ResourcePattern = p157.ResourcePattern,
                PermissionPattern = p157.PermissionPattern,
                FeatureId = p157.FeatureId,
                Feature = funcMain147(p157.Feature),
                AppRoles = funcMain149(p157.AppRoles),
                AppUsers = funcMain150(p157.AppUsers),
                AppResource = p157.AppResource == null ? null : new AppResourceReadModel()
                {
                    Url = p157.AppResource.Url,
                    Description = p157.AppResource.Description,
                    ResourceType = p157.AppResource.ResourceType,
                    AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p157.AppResource.AccessControlEntries),
                    Id = p157.AppResource.Id,
                    CreatedBy = p157.AppResource.CreatedBy,
                    CreatedDate = p157.AppResource.CreatedDate,
                    ModifiedBy = p157.AppResource.ModifiedBy,
                    ModifiedDate = p157.AppResource.ModifiedDate,
                    IsDeleted = p157.AppResource.IsDeleted,
                    DeletedBy = p157.AppResource.DeletedBy,
                    DeletedDate = p157.AppResource.DeletedDate
                },
                ResourceId = p157.ResourceId,
                Id = p157.Id,
                CreatedBy = p157.CreatedBy,
                CreatedDate = p157.CreatedDate,
                ModifiedBy = p157.ModifiedBy,
                ModifiedDate = p157.ModifiedDate,
                IsDeleted = p157.IsDeleted,
                DeletedBy = p157.DeletedBy,
                DeletedDate = p157.DeletedDate
            };
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain158(ICollection<AppUserRole> p169)
        {
            if (p169 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p169.Count);
            
            IEnumerator<AppUserRole> enumerator = p169.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(item == null ? null : new AppUserRoleReadModel()
                {
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Hash = item.Hash,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    RoleId = item.RoleId
                });
            }
            return result;
            
        }
        
        private static ICollection<AppUserTokenReadModel> funcMain159(ICollection<AppUserToken> p170)
        {
            if (p170 == null)
            {
                return null;
            }
            ICollection<AppUserTokenReadModel> result = new List<AppUserTokenReadModel>(p170.Count);
            
            IEnumerator<AppUserToken> enumerator = p170.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserToken item = enumerator.Current;
                result.Add(item == null ? null : new AppUserTokenReadModel()
                {
                    Token = item.Token,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    LoginProvider = item.LoginProvider,
                    Name = item.Name,
                    Value = item.Value
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRefreshTokenReadModel> funcMain160(ICollection<AppRefreshToken> p171)
        {
            if (p171 == null)
            {
                return null;
            }
            ICollection<AppRefreshTokenReadModel> result = new List<AppRefreshTokenReadModel>(p171.Count);
            
            IEnumerator<AppRefreshToken> enumerator = p171.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRefreshToken item = enumerator.Current;
                result.Add(item == null ? null : new AppRefreshTokenReadModel()
                {
                    UserId = item.UserId,
                    Token = item.Token,
                    JwtId = item.JwtId,
                    IsUsed = item.IsUsed,
                    IsRevoked = item.IsRevoked,
                    ExpiryDate = item.ExpiryDate,
                    Hash = item.Hash,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static ICollection<AppUserTokenReadModel> funcMain170(ICollection<AppUserToken> p182)
        {
            if (p182 == null)
            {
                return null;
            }
            ICollection<AppUserTokenReadModel> result = new List<AppUserTokenReadModel>(p182.Count);
            
            IEnumerator<AppUserToken> enumerator = p182.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserToken item = enumerator.Current;
                result.Add(item == null ? null : new AppUserTokenReadModel()
                {
                    Token = item.Token,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    LoginProvider = item.LoginProvider,
                    Name = item.Name,
                    Value = item.Value
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRefreshTokenReadModel> funcMain171(ICollection<AppRefreshToken> p183)
        {
            if (p183 == null)
            {
                return null;
            }
            ICollection<AppRefreshTokenReadModel> result = new List<AppRefreshTokenReadModel>(p183.Count);
            
            IEnumerator<AppRefreshToken> enumerator = p183.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRefreshToken item = enumerator.Current;
                result.Add(item == null ? null : new AppRefreshTokenReadModel()
                {
                    UserId = item.UserId,
                    Token = item.Token,
                    JwtId = item.JwtId,
                    IsUsed = item.IsUsed,
                    IsRevoked = item.IsRevoked,
                    ExpiryDate = item.ExpiryDate,
                    Hash = item.Hash,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRoleClaimReadModel> funcMain178(ICollection<AppRoleClaim> p190)
        {
            if (p190 == null)
            {
                return null;
            }
            ICollection<AppRoleClaimReadModel> result = new List<AppRoleClaimReadModel>(p190.Count);
            
            IEnumerator<AppRoleClaim> enumerator = p190.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRoleClaim item = enumerator.Current;
                result.Add(item == null ? null : new AppRoleClaimReadModel()
                {
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Id = item.Id,
                    RoleId = item.RoleId,
                    ClaimType = item.ClaimType,
                    ClaimValue = item.ClaimValue
                });
            }
            return result;
            
        }
        
        private static AppFeatureReadModel funcMain79(AppFeature p86)
        {
            return p86 == null ? null : new AppFeatureReadModel()
            {
                Name = p86.Name,
                Description = p86.Description,
                IsEnabled = p86.IsEnabled,
                Scope = p86.Scope,
                FeatureFlags = funcMain80(p86.FeatureFlags),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p86.AccessControlEntries),
                Id = p86.Id,
                CreatedBy = p86.CreatedBy,
                CreatedDate = p86.CreatedDate,
                ModifiedBy = p86.ModifiedBy,
                ModifiedDate = p86.ModifiedDate,
                IsDeleted = p86.IsDeleted,
                DeletedBy = p86.DeletedBy,
                DeletedDate = p86.DeletedDate
            };
        }
        
        private static ICollection<AppRoleReadModel> funcMain81(ICollection<AppRole> p88)
        {
            if (p88 == null)
            {
                return null;
            }
            ICollection<AppRoleReadModel> result = new List<AppRoleReadModel>(p88.Count);
            
            IEnumerator<AppRole> enumerator = p88.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRole item = enumerator.Current;
                result.Add(TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserReadModel> funcMain82(ICollection<AppUser> p89)
        {
            if (p89 == null)
            {
                return null;
            }
            ICollection<AppUserReadModel> result = new List<AppUserReadModel>(p89.Count);
            
            IEnumerator<AppUser> enumerator = p89.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUser item = enumerator.Current;
                result.Add(TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static AppFeatureReadModel funcMain147(AppFeature p158)
        {
            return p158 == null ? null : new AppFeatureReadModel()
            {
                Name = p158.Name,
                Description = p158.Description,
                IsEnabled = p158.IsEnabled,
                Scope = p158.Scope,
                FeatureFlags = funcMain148(p158.FeatureFlags),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p158.AccessControlEntries),
                Id = p158.Id,
                CreatedBy = p158.CreatedBy,
                CreatedDate = p158.CreatedDate,
                ModifiedBy = p158.ModifiedBy,
                ModifiedDate = p158.ModifiedDate,
                IsDeleted = p158.IsDeleted,
                DeletedBy = p158.DeletedBy,
                DeletedDate = p158.DeletedDate
            };
        }
        
        private static ICollection<AppRoleReadModel> funcMain149(ICollection<AppRole> p160)
        {
            if (p160 == null)
            {
                return null;
            }
            ICollection<AppRoleReadModel> result = new List<AppRoleReadModel>(p160.Count);
            
            IEnumerator<AppRole> enumerator = p160.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRole item = enumerator.Current;
                result.Add(TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserReadModel> funcMain150(ICollection<AppUser> p161)
        {
            if (p161 == null)
            {
                return null;
            }
            ICollection<AppUserReadModel> result = new List<AppUserReadModel>(p161.Count);
            
            IEnumerator<AppUser> enumerator = p161.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUser item = enumerator.Current;
                result.Add(TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static ICollection<AppFeatureFlagReadModel> funcMain80(ICollection<AppFeatureFlag> p87)
        {
            if (p87 == null)
            {
                return null;
            }
            ICollection<AppFeatureFlagReadModel> result = new List<AppFeatureFlagReadModel>(p87.Count);
            
            IEnumerator<AppFeatureFlag> enumerator = p87.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppFeatureFlag item = enumerator.Current;
                result.Add(item == null ? null : new AppFeatureFlagReadModel()
                {
                    FeatureId = item.FeatureId,
                    ScopeIdentifier = item.ScopeIdentifier,
                    IsEnabled = item.IsEnabled,
                    Feature = TypeAdapter<AppFeature, AppFeatureReadModel>.Map.Invoke(item.Feature),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static ICollection<AppFeatureFlagReadModel> funcMain148(ICollection<AppFeatureFlag> p159)
        {
            if (p159 == null)
            {
                return null;
            }
            ICollection<AppFeatureFlagReadModel> result = new List<AppFeatureFlagReadModel>(p159.Count);
            
            IEnumerator<AppFeatureFlag> enumerator = p159.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppFeatureFlag item = enumerator.Current;
                result.Add(item == null ? null : new AppFeatureFlagReadModel()
                {
                    FeatureId = item.FeatureId,
                    ScopeIdentifier = item.ScopeIdentifier,
                    IsEnabled = item.IsEnabled,
                    Feature = TypeAdapter<AppFeature, AppFeatureReadModel>.Map.Invoke(item.Feature),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
    }
}