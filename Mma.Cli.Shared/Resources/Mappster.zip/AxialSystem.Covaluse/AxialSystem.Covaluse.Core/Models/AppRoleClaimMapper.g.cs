using System.Collections.Generic;
using AxialSystem.Covaluse.Core.Database.Identity;
using Mapster;

namespace AxialSystem.Covaluse.Core.Database.Identity
{
    public static partial class AppRoleClaimMapper
    {
        public static AppRoleClaimReadModel AdaptToReadModel(this AppRoleClaim p1)
        {
            return p1 == null ? null : new AppRoleClaimReadModel()
            {
                CreatedBy = p1.CreatedBy,
                CreatedDate = p1.CreatedDate,
                ModifiedBy = p1.ModifiedBy,
                ModifiedDate = p1.ModifiedDate,
                IsDeleted = p1.IsDeleted,
                DeletedBy = p1.DeletedBy,
                DeletedDate = p1.DeletedDate,
                AppRole = funcMain1(p1.AppRole),
                Id = p1.Id,
                RoleId = p1.RoleId,
                ClaimType = p1.ClaimType,
                ClaimValue = p1.ClaimValue
            };
        }
        public static AppRoleClaimReadModel AdaptTo(this AppRoleClaim p25, AppRoleClaimReadModel p26)
        {
            if (p25 == null)
            {
                return null;
            }
            AppRoleClaimReadModel result = p26 ?? new AppRoleClaimReadModel();
            
            result.CreatedBy = p25.CreatedBy;
            result.CreatedDate = p25.CreatedDate;
            result.ModifiedBy = p25.ModifiedBy;
            result.ModifiedDate = p25.ModifiedDate;
            result.IsDeleted = p25.IsDeleted;
            result.DeletedBy = p25.DeletedBy;
            result.DeletedDate = p25.DeletedDate;
            result.AppRole = funcMain24(p25.AppRole, result.AppRole);
            result.Id = p25.Id;
            result.RoleId = p25.RoleId;
            result.ClaimType = p25.ClaimType;
            result.ClaimValue = p25.ClaimValue;
            return result;
            
        }
        public static AppRoleClaimModifyModel AdaptToModifyModel(this AppRoleClaim p54)
        {
            return p54 == null ? null : new AppRoleClaimModifyModel()
            {
                CreatedBy = p54.CreatedBy,
                CreatedDate = p54.CreatedDate,
                ModifiedBy = p54.ModifiedBy,
                ModifiedDate = p54.ModifiedDate,
                IsDeleted = p54.IsDeleted,
                DeletedBy = p54.DeletedBy,
                DeletedDate = p54.DeletedDate,
                AppRole = funcMain47(p54.AppRole),
                Id = p54.Id,
                RoleId = p54.RoleId,
                ClaimType = p54.ClaimType,
                ClaimValue = p54.ClaimValue
            };
        }
        public static AppRoleClaimModifyModel AdaptTo(this AppRoleClaim p78, AppRoleClaimModifyModel p79)
        {
            if (p78 == null)
            {
                return null;
            }
            AppRoleClaimModifyModel result = p79 ?? new AppRoleClaimModifyModel();
            
            result.CreatedBy = p78.CreatedBy;
            result.CreatedDate = p78.CreatedDate;
            result.ModifiedBy = p78.ModifiedBy;
            result.ModifiedDate = p78.ModifiedDate;
            result.IsDeleted = p78.IsDeleted;
            result.DeletedBy = p78.DeletedBy;
            result.DeletedDate = p78.DeletedDate;
            result.AppRole = funcMain70(p78.AppRole, result.AppRole);
            result.Id = p78.Id;
            result.RoleId = p78.RoleId;
            result.ClaimType = p78.ClaimType;
            result.ClaimValue = p78.ClaimValue;
            return result;
            
        }
        
        private static AppRoleReadModel funcMain1(AppRole p2)
        {
            return p2 == null ? null : new AppRoleReadModel()
            {
                CreatedBy = p2.CreatedBy,
                CreatedDate = p2.CreatedDate,
                ModifiedBy = p2.ModifiedBy,
                ModifiedDate = p2.ModifiedDate,
                IsDeleted = p2.IsDeleted,
                DeletedBy = p2.DeletedBy,
                DeletedDate = p2.DeletedDate,
                AppUserRoles = funcMain2(p2.AppUserRoles),
                AppRoleClaims = funcMain13(p2.AppRoleClaims),
                AccessControlEntries = funcMain14(p2.AccessControlEntries),
                Hash = p2.Hash,
                Id = p2.Id,
                Name = p2.Name,
                NormalizedName = p2.NormalizedName,
                ConcurrencyStamp = p2.ConcurrencyStamp
            };
        }
        
        private static AppRoleReadModel funcMain24(AppRole p27, AppRoleReadModel p28)
        {
            if (p27 == null)
            {
                return null;
            }
            AppRoleReadModel result = p28 ?? new AppRoleReadModel();
            
            result.CreatedBy = p27.CreatedBy;
            result.CreatedDate = p27.CreatedDate;
            result.ModifiedBy = p27.ModifiedBy;
            result.ModifiedDate = p27.ModifiedDate;
            result.IsDeleted = p27.IsDeleted;
            result.DeletedBy = p27.DeletedBy;
            result.DeletedDate = p27.DeletedDate;
            result.AppUserRoles = funcMain25(p27.AppUserRoles, result.AppUserRoles);
            result.AppRoleClaims = funcMain36(p27.AppRoleClaims, result.AppRoleClaims);
            result.AccessControlEntries = funcMain37(p27.AccessControlEntries, result.AccessControlEntries);
            result.Hash = p27.Hash;
            result.Id = p27.Id;
            result.Name = p27.Name;
            result.NormalizedName = p27.NormalizedName;
            result.ConcurrencyStamp = p27.ConcurrencyStamp;
            return result;
            
        }
        
        private static AppRoleReadModel funcMain47(AppRole p55)
        {
            return p55 == null ? null : new AppRoleReadModel()
            {
                CreatedBy = p55.CreatedBy,
                CreatedDate = p55.CreatedDate,
                ModifiedBy = p55.ModifiedBy,
                ModifiedDate = p55.ModifiedDate,
                IsDeleted = p55.IsDeleted,
                DeletedBy = p55.DeletedBy,
                DeletedDate = p55.DeletedDate,
                AppUserRoles = funcMain48(p55.AppUserRoles),
                AppRoleClaims = funcMain59(p55.AppRoleClaims),
                AccessControlEntries = funcMain60(p55.AccessControlEntries),
                Hash = p55.Hash,
                Id = p55.Id,
                Name = p55.Name,
                NormalizedName = p55.NormalizedName,
                ConcurrencyStamp = p55.ConcurrencyStamp
            };
        }
        
        private static AppRoleReadModel funcMain70(AppRole p80, AppRoleReadModel p81)
        {
            if (p80 == null)
            {
                return null;
            }
            AppRoleReadModel result = p81 ?? new AppRoleReadModel();
            
            result.CreatedBy = p80.CreatedBy;
            result.CreatedDate = p80.CreatedDate;
            result.ModifiedBy = p80.ModifiedBy;
            result.ModifiedDate = p80.ModifiedDate;
            result.IsDeleted = p80.IsDeleted;
            result.DeletedBy = p80.DeletedBy;
            result.DeletedDate = p80.DeletedDate;
            result.AppUserRoles = funcMain71(p80.AppUserRoles, result.AppUserRoles);
            result.AppRoleClaims = funcMain82(p80.AppRoleClaims, result.AppRoleClaims);
            result.AccessControlEntries = funcMain83(p80.AccessControlEntries, result.AccessControlEntries);
            result.Hash = p80.Hash;
            result.Id = p80.Id;
            result.Name = p80.Name;
            result.NormalizedName = p80.NormalizedName;
            result.ConcurrencyStamp = p80.ConcurrencyStamp;
            return result;
            
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain2(ICollection<AppUserRole> p3)
        {
            if (p3 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p3.Count);
            
            IEnumerator<AppUserRole> enumerator = p3.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(funcMain3(item));
            }
            return result;
            
        }
        
        private static ICollection<AppRoleClaimReadModel> funcMain13(ICollection<AppRoleClaim> p14)
        {
            if (p14 == null)
            {
                return null;
            }
            ICollection<AppRoleClaimReadModel> result = new List<AppRoleClaimReadModel>(p14.Count);
            
            IEnumerator<AppRoleClaim> enumerator = p14.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRoleClaim item = enumerator.Current;
                result.Add(TypeAdapter<AppRoleClaim, AppRoleClaimReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static ICollection<AppAccessControlEntryReadModel> funcMain14(ICollection<AppAccessControlEntry> p15)
        {
            if (p15 == null)
            {
                return null;
            }
            ICollection<AppAccessControlEntryReadModel> result = new List<AppAccessControlEntryReadModel>(p15.Count);
            
            IEnumerator<AppAccessControlEntry> enumerator = p15.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppAccessControlEntry item = enumerator.Current;
                result.Add(funcMain15(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain25(ICollection<AppUserRole> p29, ICollection<AppUserRoleReadModel> p30)
        {
            if (p29 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p29.Count);
            
            IEnumerator<AppUserRole> enumerator = p29.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(funcMain26(item));
            }
            return result;
            
        }
        
        private static ICollection<AppRoleClaimReadModel> funcMain36(ICollection<AppRoleClaim> p41, ICollection<AppRoleClaimReadModel> p42)
        {
            if (p41 == null)
            {
                return null;
            }
            ICollection<AppRoleClaimReadModel> result = new List<AppRoleClaimReadModel>(p41.Count);
            
            IEnumerator<AppRoleClaim> enumerator = p41.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRoleClaim item = enumerator.Current;
                result.Add(TypeAdapter<AppRoleClaim, AppRoleClaimReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static ICollection<AppAccessControlEntryReadModel> funcMain37(ICollection<AppAccessControlEntry> p43, ICollection<AppAccessControlEntryReadModel> p44)
        {
            if (p43 == null)
            {
                return null;
            }
            ICollection<AppAccessControlEntryReadModel> result = new List<AppAccessControlEntryReadModel>(p43.Count);
            
            IEnumerator<AppAccessControlEntry> enumerator = p43.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppAccessControlEntry item = enumerator.Current;
                result.Add(funcMain38(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain48(ICollection<AppUserRole> p56)
        {
            if (p56 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p56.Count);
            
            IEnumerator<AppUserRole> enumerator = p56.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(funcMain49(item));
            }
            return result;
            
        }
        
        private static ICollection<AppRoleClaimReadModel> funcMain59(ICollection<AppRoleClaim> p67)
        {
            if (p67 == null)
            {
                return null;
            }
            ICollection<AppRoleClaimReadModel> result = new List<AppRoleClaimReadModel>(p67.Count);
            
            IEnumerator<AppRoleClaim> enumerator = p67.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRoleClaim item = enumerator.Current;
                result.Add(item == null ? null : new AppRoleClaimReadModel()
                {
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Id = item.Id,
                    RoleId = item.RoleId,
                    ClaimType = item.ClaimType,
                    ClaimValue = item.ClaimValue
                });
            }
            return result;
            
        }
        
        private static ICollection<AppAccessControlEntryReadModel> funcMain60(ICollection<AppAccessControlEntry> p68)
        {
            if (p68 == null)
            {
                return null;
            }
            ICollection<AppAccessControlEntryReadModel> result = new List<AppAccessControlEntryReadModel>(p68.Count);
            
            IEnumerator<AppAccessControlEntry> enumerator = p68.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppAccessControlEntry item = enumerator.Current;
                result.Add(funcMain61(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain71(ICollection<AppUserRole> p82, ICollection<AppUserRoleReadModel> p83)
        {
            if (p82 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p82.Count);
            
            IEnumerator<AppUserRole> enumerator = p82.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(funcMain72(item));
            }
            return result;
            
        }
        
        private static ICollection<AppRoleClaimReadModel> funcMain82(ICollection<AppRoleClaim> p94, ICollection<AppRoleClaimReadModel> p95)
        {
            if (p94 == null)
            {
                return null;
            }
            ICollection<AppRoleClaimReadModel> result = new List<AppRoleClaimReadModel>(p94.Count);
            
            IEnumerator<AppRoleClaim> enumerator = p94.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRoleClaim item = enumerator.Current;
                result.Add(item == null ? null : new AppRoleClaimReadModel()
                {
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Id = item.Id,
                    RoleId = item.RoleId,
                    ClaimType = item.ClaimType,
                    ClaimValue = item.ClaimValue
                });
            }
            return result;
            
        }
        
        private static ICollection<AppAccessControlEntryReadModel> funcMain83(ICollection<AppAccessControlEntry> p96, ICollection<AppAccessControlEntryReadModel> p97)
        {
            if (p96 == null)
            {
                return null;
            }
            ICollection<AppAccessControlEntryReadModel> result = new List<AppAccessControlEntryReadModel>(p96.Count);
            
            IEnumerator<AppAccessControlEntry> enumerator = p96.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppAccessControlEntry item = enumerator.Current;
                result.Add(funcMain84(item));
            }
            return result;
            
        }
        
        private static AppUserRoleReadModel funcMain3(AppUserRole p4)
        {
            return p4 == null ? null : new AppUserRoleReadModel()
            {
                AppUser = funcMain4(p4.AppUser),
                AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(p4.AppRole),
                Hash = p4.Hash,
                CreatedBy = p4.CreatedBy,
                CreatedDate = p4.CreatedDate,
                ModifiedBy = p4.ModifiedBy,
                ModifiedDate = p4.ModifiedDate,
                IsDeleted = p4.IsDeleted,
                DeletedBy = p4.DeletedBy,
                DeletedDate = p4.DeletedDate,
                UserId = p4.UserId,
                RoleId = p4.RoleId
            };
        }
        
        private static AppAccessControlEntryReadModel funcMain15(AppAccessControlEntry p16)
        {
            return p16 == null ? null : new AppAccessControlEntryReadModel()
            {
                ResourcePattern = p16.ResourcePattern,
                PermissionPattern = p16.PermissionPattern,
                FeatureId = p16.FeatureId,
                Feature = funcMain16(p16.Feature),
                AppRoles = funcMain18(p16.AppRoles),
                AppUsers = funcMain19(p16.AppUsers),
                AppResource = p16.AppResource == null ? null : new AppResourceReadModel()
                {
                    Url = p16.AppResource.Url,
                    Description = p16.AppResource.Description,
                    ResourceType = p16.AppResource.ResourceType,
                    AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p16.AppResource.AccessControlEntries),
                    Id = p16.AppResource.Id,
                    CreatedBy = p16.AppResource.CreatedBy,
                    CreatedDate = p16.AppResource.CreatedDate,
                    ModifiedBy = p16.AppResource.ModifiedBy,
                    ModifiedDate = p16.AppResource.ModifiedDate,
                    IsDeleted = p16.AppResource.IsDeleted,
                    DeletedBy = p16.AppResource.DeletedBy,
                    DeletedDate = p16.AppResource.DeletedDate
                },
                ResourceId = p16.ResourceId,
                Id = p16.Id,
                CreatedBy = p16.CreatedBy,
                CreatedDate = p16.CreatedDate,
                ModifiedBy = p16.ModifiedBy,
                ModifiedDate = p16.ModifiedDate,
                IsDeleted = p16.IsDeleted,
                DeletedBy = p16.DeletedBy,
                DeletedDate = p16.DeletedDate
            };
        }
        
        private static AppUserRoleReadModel funcMain26(AppUserRole p31)
        {
            return p31 == null ? null : new AppUserRoleReadModel()
            {
                AppUser = funcMain27(p31.AppUser),
                AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(p31.AppRole),
                Hash = p31.Hash,
                CreatedBy = p31.CreatedBy,
                CreatedDate = p31.CreatedDate,
                ModifiedBy = p31.ModifiedBy,
                ModifiedDate = p31.ModifiedDate,
                IsDeleted = p31.IsDeleted,
                DeletedBy = p31.DeletedBy,
                DeletedDate = p31.DeletedDate,
                UserId = p31.UserId,
                RoleId = p31.RoleId
            };
        }
        
        private static AppAccessControlEntryReadModel funcMain38(AppAccessControlEntry p45)
        {
            return p45 == null ? null : new AppAccessControlEntryReadModel()
            {
                ResourcePattern = p45.ResourcePattern,
                PermissionPattern = p45.PermissionPattern,
                FeatureId = p45.FeatureId,
                Feature = funcMain39(p45.Feature),
                AppRoles = funcMain41(p45.AppRoles),
                AppUsers = funcMain42(p45.AppUsers),
                AppResource = p45.AppResource == null ? null : new AppResourceReadModel()
                {
                    Url = p45.AppResource.Url,
                    Description = p45.AppResource.Description,
                    ResourceType = p45.AppResource.ResourceType,
                    AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p45.AppResource.AccessControlEntries),
                    Id = p45.AppResource.Id,
                    CreatedBy = p45.AppResource.CreatedBy,
                    CreatedDate = p45.AppResource.CreatedDate,
                    ModifiedBy = p45.AppResource.ModifiedBy,
                    ModifiedDate = p45.AppResource.ModifiedDate,
                    IsDeleted = p45.AppResource.IsDeleted,
                    DeletedBy = p45.AppResource.DeletedBy,
                    DeletedDate = p45.AppResource.DeletedDate
                },
                ResourceId = p45.ResourceId,
                Id = p45.Id,
                CreatedBy = p45.CreatedBy,
                CreatedDate = p45.CreatedDate,
                ModifiedBy = p45.ModifiedBy,
                ModifiedDate = p45.ModifiedDate,
                IsDeleted = p45.IsDeleted,
                DeletedBy = p45.DeletedBy,
                DeletedDate = p45.DeletedDate
            };
        }
        
        private static AppUserRoleReadModel funcMain49(AppUserRole p57)
        {
            return p57 == null ? null : new AppUserRoleReadModel()
            {
                AppUser = funcMain50(p57.AppUser),
                AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(p57.AppRole),
                Hash = p57.Hash,
                CreatedBy = p57.CreatedBy,
                CreatedDate = p57.CreatedDate,
                ModifiedBy = p57.ModifiedBy,
                ModifiedDate = p57.ModifiedDate,
                IsDeleted = p57.IsDeleted,
                DeletedBy = p57.DeletedBy,
                DeletedDate = p57.DeletedDate,
                UserId = p57.UserId,
                RoleId = p57.RoleId
            };
        }
        
        private static AppAccessControlEntryReadModel funcMain61(AppAccessControlEntry p69)
        {
            return p69 == null ? null : new AppAccessControlEntryReadModel()
            {
                ResourcePattern = p69.ResourcePattern,
                PermissionPattern = p69.PermissionPattern,
                FeatureId = p69.FeatureId,
                Feature = funcMain62(p69.Feature),
                AppRoles = funcMain64(p69.AppRoles),
                AppUsers = funcMain65(p69.AppUsers),
                AppResource = p69.AppResource == null ? null : new AppResourceReadModel()
                {
                    Url = p69.AppResource.Url,
                    Description = p69.AppResource.Description,
                    ResourceType = p69.AppResource.ResourceType,
                    AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p69.AppResource.AccessControlEntries),
                    Id = p69.AppResource.Id,
                    CreatedBy = p69.AppResource.CreatedBy,
                    CreatedDate = p69.AppResource.CreatedDate,
                    ModifiedBy = p69.AppResource.ModifiedBy,
                    ModifiedDate = p69.AppResource.ModifiedDate,
                    IsDeleted = p69.AppResource.IsDeleted,
                    DeletedBy = p69.AppResource.DeletedBy,
                    DeletedDate = p69.AppResource.DeletedDate
                },
                ResourceId = p69.ResourceId,
                Id = p69.Id,
                CreatedBy = p69.CreatedBy,
                CreatedDate = p69.CreatedDate,
                ModifiedBy = p69.ModifiedBy,
                ModifiedDate = p69.ModifiedDate,
                IsDeleted = p69.IsDeleted,
                DeletedBy = p69.DeletedBy,
                DeletedDate = p69.DeletedDate
            };
        }
        
        private static AppUserRoleReadModel funcMain72(AppUserRole p84)
        {
            return p84 == null ? null : new AppUserRoleReadModel()
            {
                AppUser = funcMain73(p84.AppUser),
                AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(p84.AppRole),
                Hash = p84.Hash,
                CreatedBy = p84.CreatedBy,
                CreatedDate = p84.CreatedDate,
                ModifiedBy = p84.ModifiedBy,
                ModifiedDate = p84.ModifiedDate,
                IsDeleted = p84.IsDeleted,
                DeletedBy = p84.DeletedBy,
                DeletedDate = p84.DeletedDate,
                UserId = p84.UserId,
                RoleId = p84.RoleId
            };
        }
        
        private static AppAccessControlEntryReadModel funcMain84(AppAccessControlEntry p98)
        {
            return p98 == null ? null : new AppAccessControlEntryReadModel()
            {
                ResourcePattern = p98.ResourcePattern,
                PermissionPattern = p98.PermissionPattern,
                FeatureId = p98.FeatureId,
                Feature = funcMain85(p98.Feature),
                AppRoles = funcMain87(p98.AppRoles),
                AppUsers = funcMain88(p98.AppUsers),
                AppResource = p98.AppResource == null ? null : new AppResourceReadModel()
                {
                    Url = p98.AppResource.Url,
                    Description = p98.AppResource.Description,
                    ResourceType = p98.AppResource.ResourceType,
                    AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p98.AppResource.AccessControlEntries),
                    Id = p98.AppResource.Id,
                    CreatedBy = p98.AppResource.CreatedBy,
                    CreatedDate = p98.AppResource.CreatedDate,
                    ModifiedBy = p98.AppResource.ModifiedBy,
                    ModifiedDate = p98.AppResource.ModifiedDate,
                    IsDeleted = p98.AppResource.IsDeleted,
                    DeletedBy = p98.AppResource.DeletedBy,
                    DeletedDate = p98.AppResource.DeletedDate
                },
                ResourceId = p98.ResourceId,
                Id = p98.Id,
                CreatedBy = p98.CreatedBy,
                CreatedDate = p98.CreatedDate,
                ModifiedBy = p98.ModifiedBy,
                ModifiedDate = p98.ModifiedDate,
                IsDeleted = p98.IsDeleted,
                DeletedBy = p98.DeletedBy,
                DeletedDate = p98.DeletedDate
            };
        }
        
        private static AppUserReadModel funcMain4(AppUser p5)
        {
            return p5 == null ? null : new AppUserReadModel()
            {
                Hash = p5.Hash,
                FirstName = p5.FirstName,
                LastName = p5.LastName,
                Mobile = p5.Mobile,
                CountryCode = p5.CountryCode,
                TwoFactorMethod = p5.TwoFactorMethod,
                CreatedBy = p5.CreatedBy,
                CreatedDate = p5.CreatedDate,
                ModifiedBy = p5.ModifiedBy,
                ModifiedDate = p5.ModifiedDate,
                IsDeleted = p5.IsDeleted,
                DeletedBy = p5.DeletedBy,
                DeletedDate = p5.DeletedDate,
                MembershipType = p5.MembershipType,
                UserRoles = TypeAdapter<ICollection<AppUserRole>, ICollection<AppUserRoleReadModel>>.Map.Invoke(p5.UserRoles),
                UserTokens = funcMain5(p5.UserTokens),
                RefreshTokens = funcMain6(p5.RefreshTokens),
                AccessControlEntries = funcMain7(p5.AccessControlEntries),
                Id = p5.Id,
                UserName = p5.UserName,
                NormalizedUserName = p5.NormalizedUserName,
                Email = p5.Email,
                NormalizedEmail = p5.NormalizedEmail,
                EmailConfirmed = p5.EmailConfirmed,
                PasswordHash = p5.PasswordHash,
                SecurityStamp = p5.SecurityStamp,
                ConcurrencyStamp = p5.ConcurrencyStamp,
                PhoneNumber = p5.PhoneNumber,
                PhoneNumberConfirmed = p5.PhoneNumberConfirmed,
                TwoFactorEnabled = p5.TwoFactorEnabled,
                LockoutEnd = p5.LockoutEnd,
                LockoutEnabled = p5.LockoutEnabled,
                AccessFailedCount = p5.AccessFailedCount
            };
        }
        
        private static AppFeatureReadModel funcMain16(AppFeature p17)
        {
            return p17 == null ? null : new AppFeatureReadModel()
            {
                Name = p17.Name,
                Description = p17.Description,
                IsEnabled = p17.IsEnabled,
                Scope = p17.Scope,
                FeatureFlags = funcMain17(p17.FeatureFlags),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p17.AccessControlEntries),
                Id = p17.Id,
                CreatedBy = p17.CreatedBy,
                CreatedDate = p17.CreatedDate,
                ModifiedBy = p17.ModifiedBy,
                ModifiedDate = p17.ModifiedDate,
                IsDeleted = p17.IsDeleted,
                DeletedBy = p17.DeletedBy,
                DeletedDate = p17.DeletedDate
            };
        }
        
        private static ICollection<AppRoleReadModel> funcMain18(ICollection<AppRole> p19)
        {
            if (p19 == null)
            {
                return null;
            }
            ICollection<AppRoleReadModel> result = new List<AppRoleReadModel>(p19.Count);
            
            IEnumerator<AppRole> enumerator = p19.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRole item = enumerator.Current;
                result.Add(TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserReadModel> funcMain19(ICollection<AppUser> p20)
        {
            if (p20 == null)
            {
                return null;
            }
            ICollection<AppUserReadModel> result = new List<AppUserReadModel>(p20.Count);
            
            IEnumerator<AppUser> enumerator = p20.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUser item = enumerator.Current;
                result.Add(funcMain20(item));
            }
            return result;
            
        }
        
        private static AppUserReadModel funcMain27(AppUser p32)
        {
            return p32 == null ? null : new AppUserReadModel()
            {
                Hash = p32.Hash,
                FirstName = p32.FirstName,
                LastName = p32.LastName,
                Mobile = p32.Mobile,
                CountryCode = p32.CountryCode,
                TwoFactorMethod = p32.TwoFactorMethod,
                CreatedBy = p32.CreatedBy,
                CreatedDate = p32.CreatedDate,
                ModifiedBy = p32.ModifiedBy,
                ModifiedDate = p32.ModifiedDate,
                IsDeleted = p32.IsDeleted,
                DeletedBy = p32.DeletedBy,
                DeletedDate = p32.DeletedDate,
                MembershipType = p32.MembershipType,
                UserRoles = TypeAdapter<ICollection<AppUserRole>, ICollection<AppUserRoleReadModel>>.Map.Invoke(p32.UserRoles),
                UserTokens = funcMain28(p32.UserTokens),
                RefreshTokens = funcMain29(p32.RefreshTokens),
                AccessControlEntries = funcMain30(p32.AccessControlEntries),
                Id = p32.Id,
                UserName = p32.UserName,
                NormalizedUserName = p32.NormalizedUserName,
                Email = p32.Email,
                NormalizedEmail = p32.NormalizedEmail,
                EmailConfirmed = p32.EmailConfirmed,
                PasswordHash = p32.PasswordHash,
                SecurityStamp = p32.SecurityStamp,
                ConcurrencyStamp = p32.ConcurrencyStamp,
                PhoneNumber = p32.PhoneNumber,
                PhoneNumberConfirmed = p32.PhoneNumberConfirmed,
                TwoFactorEnabled = p32.TwoFactorEnabled,
                LockoutEnd = p32.LockoutEnd,
                LockoutEnabled = p32.LockoutEnabled,
                AccessFailedCount = p32.AccessFailedCount
            };
        }
        
        private static AppFeatureReadModel funcMain39(AppFeature p46)
        {
            return p46 == null ? null : new AppFeatureReadModel()
            {
                Name = p46.Name,
                Description = p46.Description,
                IsEnabled = p46.IsEnabled,
                Scope = p46.Scope,
                FeatureFlags = funcMain40(p46.FeatureFlags),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p46.AccessControlEntries),
                Id = p46.Id,
                CreatedBy = p46.CreatedBy,
                CreatedDate = p46.CreatedDate,
                ModifiedBy = p46.ModifiedBy,
                ModifiedDate = p46.ModifiedDate,
                IsDeleted = p46.IsDeleted,
                DeletedBy = p46.DeletedBy,
                DeletedDate = p46.DeletedDate
            };
        }
        
        private static ICollection<AppRoleReadModel> funcMain41(ICollection<AppRole> p48)
        {
            if (p48 == null)
            {
                return null;
            }
            ICollection<AppRoleReadModel> result = new List<AppRoleReadModel>(p48.Count);
            
            IEnumerator<AppRole> enumerator = p48.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRole item = enumerator.Current;
                result.Add(TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserReadModel> funcMain42(ICollection<AppUser> p49)
        {
            if (p49 == null)
            {
                return null;
            }
            ICollection<AppUserReadModel> result = new List<AppUserReadModel>(p49.Count);
            
            IEnumerator<AppUser> enumerator = p49.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUser item = enumerator.Current;
                result.Add(funcMain43(item));
            }
            return result;
            
        }
        
        private static AppUserReadModel funcMain50(AppUser p58)
        {
            return p58 == null ? null : new AppUserReadModel()
            {
                Hash = p58.Hash,
                FirstName = p58.FirstName,
                LastName = p58.LastName,
                Mobile = p58.Mobile,
                CountryCode = p58.CountryCode,
                TwoFactorMethod = p58.TwoFactorMethod,
                CreatedBy = p58.CreatedBy,
                CreatedDate = p58.CreatedDate,
                ModifiedBy = p58.ModifiedBy,
                ModifiedDate = p58.ModifiedDate,
                IsDeleted = p58.IsDeleted,
                DeletedBy = p58.DeletedBy,
                DeletedDate = p58.DeletedDate,
                MembershipType = p58.MembershipType,
                UserRoles = TypeAdapter<ICollection<AppUserRole>, ICollection<AppUserRoleReadModel>>.Map.Invoke(p58.UserRoles),
                UserTokens = funcMain51(p58.UserTokens),
                RefreshTokens = funcMain52(p58.RefreshTokens),
                AccessControlEntries = funcMain53(p58.AccessControlEntries),
                Id = p58.Id,
                UserName = p58.UserName,
                NormalizedUserName = p58.NormalizedUserName,
                Email = p58.Email,
                NormalizedEmail = p58.NormalizedEmail,
                EmailConfirmed = p58.EmailConfirmed,
                PasswordHash = p58.PasswordHash,
                SecurityStamp = p58.SecurityStamp,
                ConcurrencyStamp = p58.ConcurrencyStamp,
                PhoneNumber = p58.PhoneNumber,
                PhoneNumberConfirmed = p58.PhoneNumberConfirmed,
                TwoFactorEnabled = p58.TwoFactorEnabled,
                LockoutEnd = p58.LockoutEnd,
                LockoutEnabled = p58.LockoutEnabled,
                AccessFailedCount = p58.AccessFailedCount
            };
        }
        
        private static AppFeatureReadModel funcMain62(AppFeature p70)
        {
            return p70 == null ? null : new AppFeatureReadModel()
            {
                Name = p70.Name,
                Description = p70.Description,
                IsEnabled = p70.IsEnabled,
                Scope = p70.Scope,
                FeatureFlags = funcMain63(p70.FeatureFlags),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p70.AccessControlEntries),
                Id = p70.Id,
                CreatedBy = p70.CreatedBy,
                CreatedDate = p70.CreatedDate,
                ModifiedBy = p70.ModifiedBy,
                ModifiedDate = p70.ModifiedDate,
                IsDeleted = p70.IsDeleted,
                DeletedBy = p70.DeletedBy,
                DeletedDate = p70.DeletedDate
            };
        }
        
        private static ICollection<AppRoleReadModel> funcMain64(ICollection<AppRole> p72)
        {
            if (p72 == null)
            {
                return null;
            }
            ICollection<AppRoleReadModel> result = new List<AppRoleReadModel>(p72.Count);
            
            IEnumerator<AppRole> enumerator = p72.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRole item = enumerator.Current;
                result.Add(TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserReadModel> funcMain65(ICollection<AppUser> p73)
        {
            if (p73 == null)
            {
                return null;
            }
            ICollection<AppUserReadModel> result = new List<AppUserReadModel>(p73.Count);
            
            IEnumerator<AppUser> enumerator = p73.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUser item = enumerator.Current;
                result.Add(funcMain66(item));
            }
            return result;
            
        }
        
        private static AppUserReadModel funcMain73(AppUser p85)
        {
            return p85 == null ? null : new AppUserReadModel()
            {
                Hash = p85.Hash,
                FirstName = p85.FirstName,
                LastName = p85.LastName,
                Mobile = p85.Mobile,
                CountryCode = p85.CountryCode,
                TwoFactorMethod = p85.TwoFactorMethod,
                CreatedBy = p85.CreatedBy,
                CreatedDate = p85.CreatedDate,
                ModifiedBy = p85.ModifiedBy,
                ModifiedDate = p85.ModifiedDate,
                IsDeleted = p85.IsDeleted,
                DeletedBy = p85.DeletedBy,
                DeletedDate = p85.DeletedDate,
                MembershipType = p85.MembershipType,
                UserRoles = TypeAdapter<ICollection<AppUserRole>, ICollection<AppUserRoleReadModel>>.Map.Invoke(p85.UserRoles),
                UserTokens = funcMain74(p85.UserTokens),
                RefreshTokens = funcMain75(p85.RefreshTokens),
                AccessControlEntries = funcMain76(p85.AccessControlEntries),
                Id = p85.Id,
                UserName = p85.UserName,
                NormalizedUserName = p85.NormalizedUserName,
                Email = p85.Email,
                NormalizedEmail = p85.NormalizedEmail,
                EmailConfirmed = p85.EmailConfirmed,
                PasswordHash = p85.PasswordHash,
                SecurityStamp = p85.SecurityStamp,
                ConcurrencyStamp = p85.ConcurrencyStamp,
                PhoneNumber = p85.PhoneNumber,
                PhoneNumberConfirmed = p85.PhoneNumberConfirmed,
                TwoFactorEnabled = p85.TwoFactorEnabled,
                LockoutEnd = p85.LockoutEnd,
                LockoutEnabled = p85.LockoutEnabled,
                AccessFailedCount = p85.AccessFailedCount
            };
        }
        
        private static AppFeatureReadModel funcMain85(AppFeature p99)
        {
            return p99 == null ? null : new AppFeatureReadModel()
            {
                Name = p99.Name,
                Description = p99.Description,
                IsEnabled = p99.IsEnabled,
                Scope = p99.Scope,
                FeatureFlags = funcMain86(p99.FeatureFlags),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p99.AccessControlEntries),
                Id = p99.Id,
                CreatedBy = p99.CreatedBy,
                CreatedDate = p99.CreatedDate,
                ModifiedBy = p99.ModifiedBy,
                ModifiedDate = p99.ModifiedDate,
                IsDeleted = p99.IsDeleted,
                DeletedBy = p99.DeletedBy,
                DeletedDate = p99.DeletedDate
            };
        }
        
        private static ICollection<AppRoleReadModel> funcMain87(ICollection<AppRole> p101)
        {
            if (p101 == null)
            {
                return null;
            }
            ICollection<AppRoleReadModel> result = new List<AppRoleReadModel>(p101.Count);
            
            IEnumerator<AppRole> enumerator = p101.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRole item = enumerator.Current;
                result.Add(TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserReadModel> funcMain88(ICollection<AppUser> p102)
        {
            if (p102 == null)
            {
                return null;
            }
            ICollection<AppUserReadModel> result = new List<AppUserReadModel>(p102.Count);
            
            IEnumerator<AppUser> enumerator = p102.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUser item = enumerator.Current;
                result.Add(funcMain89(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserTokenReadModel> funcMain5(ICollection<AppUserToken> p6)
        {
            if (p6 == null)
            {
                return null;
            }
            ICollection<AppUserTokenReadModel> result = new List<AppUserTokenReadModel>(p6.Count);
            
            IEnumerator<AppUserToken> enumerator = p6.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserToken item = enumerator.Current;
                result.Add(item == null ? null : new AppUserTokenReadModel()
                {
                    Token = item.Token,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    LoginProvider = item.LoginProvider,
                    Name = item.Name,
                    Value = item.Value
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRefreshTokenReadModel> funcMain6(ICollection<AppRefreshToken> p7)
        {
            if (p7 == null)
            {
                return null;
            }
            ICollection<AppRefreshTokenReadModel> result = new List<AppRefreshTokenReadModel>(p7.Count);
            
            IEnumerator<AppRefreshToken> enumerator = p7.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRefreshToken item = enumerator.Current;
                result.Add(item == null ? null : new AppRefreshTokenReadModel()
                {
                    UserId = item.UserId,
                    Token = item.Token,
                    JwtId = item.JwtId,
                    IsUsed = item.IsUsed,
                    IsRevoked = item.IsRevoked,
                    ExpiryDate = item.ExpiryDate,
                    Hash = item.Hash,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static ICollection<AppAccessControlEntryReadModel> funcMain7(ICollection<AppAccessControlEntry> p8)
        {
            if (p8 == null)
            {
                return null;
            }
            ICollection<AppAccessControlEntryReadModel> result = new List<AppAccessControlEntryReadModel>(p8.Count);
            
            IEnumerator<AppAccessControlEntry> enumerator = p8.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppAccessControlEntry item = enumerator.Current;
                result.Add(funcMain8(item));
            }
            return result;
            
        }
        
        private static ICollection<AppFeatureFlagReadModel> funcMain17(ICollection<AppFeatureFlag> p18)
        {
            if (p18 == null)
            {
                return null;
            }
            ICollection<AppFeatureFlagReadModel> result = new List<AppFeatureFlagReadModel>(p18.Count);
            
            IEnumerator<AppFeatureFlag> enumerator = p18.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppFeatureFlag item = enumerator.Current;
                result.Add(item == null ? null : new AppFeatureFlagReadModel()
                {
                    FeatureId = item.FeatureId,
                    ScopeIdentifier = item.ScopeIdentifier,
                    IsEnabled = item.IsEnabled,
                    Feature = TypeAdapter<AppFeature, AppFeatureReadModel>.Map.Invoke(item.Feature),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static AppUserReadModel funcMain20(AppUser p21)
        {
            return p21 == null ? null : new AppUserReadModel()
            {
                Hash = p21.Hash,
                FirstName = p21.FirstName,
                LastName = p21.LastName,
                Mobile = p21.Mobile,
                CountryCode = p21.CountryCode,
                TwoFactorMethod = p21.TwoFactorMethod,
                CreatedBy = p21.CreatedBy,
                CreatedDate = p21.CreatedDate,
                ModifiedBy = p21.ModifiedBy,
                ModifiedDate = p21.ModifiedDate,
                IsDeleted = p21.IsDeleted,
                DeletedBy = p21.DeletedBy,
                DeletedDate = p21.DeletedDate,
                MembershipType = p21.MembershipType,
                UserRoles = funcMain21(p21.UserRoles),
                UserTokens = funcMain22(p21.UserTokens),
                RefreshTokens = funcMain23(p21.RefreshTokens),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p21.AccessControlEntries),
                Id = p21.Id,
                UserName = p21.UserName,
                NormalizedUserName = p21.NormalizedUserName,
                Email = p21.Email,
                NormalizedEmail = p21.NormalizedEmail,
                EmailConfirmed = p21.EmailConfirmed,
                PasswordHash = p21.PasswordHash,
                SecurityStamp = p21.SecurityStamp,
                ConcurrencyStamp = p21.ConcurrencyStamp,
                PhoneNumber = p21.PhoneNumber,
                PhoneNumberConfirmed = p21.PhoneNumberConfirmed,
                TwoFactorEnabled = p21.TwoFactorEnabled,
                LockoutEnd = p21.LockoutEnd,
                LockoutEnabled = p21.LockoutEnabled,
                AccessFailedCount = p21.AccessFailedCount
            };
        }
        
        private static ICollection<AppUserTokenReadModel> funcMain28(ICollection<AppUserToken> p33)
        {
            if (p33 == null)
            {
                return null;
            }
            ICollection<AppUserTokenReadModel> result = new List<AppUserTokenReadModel>(p33.Count);
            
            IEnumerator<AppUserToken> enumerator = p33.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserToken item = enumerator.Current;
                result.Add(item == null ? null : new AppUserTokenReadModel()
                {
                    Token = item.Token,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    LoginProvider = item.LoginProvider,
                    Name = item.Name,
                    Value = item.Value
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRefreshTokenReadModel> funcMain29(ICollection<AppRefreshToken> p34)
        {
            if (p34 == null)
            {
                return null;
            }
            ICollection<AppRefreshTokenReadModel> result = new List<AppRefreshTokenReadModel>(p34.Count);
            
            IEnumerator<AppRefreshToken> enumerator = p34.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRefreshToken item = enumerator.Current;
                result.Add(item == null ? null : new AppRefreshTokenReadModel()
                {
                    UserId = item.UserId,
                    Token = item.Token,
                    JwtId = item.JwtId,
                    IsUsed = item.IsUsed,
                    IsRevoked = item.IsRevoked,
                    ExpiryDate = item.ExpiryDate,
                    Hash = item.Hash,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static ICollection<AppAccessControlEntryReadModel> funcMain30(ICollection<AppAccessControlEntry> p35)
        {
            if (p35 == null)
            {
                return null;
            }
            ICollection<AppAccessControlEntryReadModel> result = new List<AppAccessControlEntryReadModel>(p35.Count);
            
            IEnumerator<AppAccessControlEntry> enumerator = p35.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppAccessControlEntry item = enumerator.Current;
                result.Add(funcMain31(item));
            }
            return result;
            
        }
        
        private static ICollection<AppFeatureFlagReadModel> funcMain40(ICollection<AppFeatureFlag> p47)
        {
            if (p47 == null)
            {
                return null;
            }
            ICollection<AppFeatureFlagReadModel> result = new List<AppFeatureFlagReadModel>(p47.Count);
            
            IEnumerator<AppFeatureFlag> enumerator = p47.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppFeatureFlag item = enumerator.Current;
                result.Add(item == null ? null : new AppFeatureFlagReadModel()
                {
                    FeatureId = item.FeatureId,
                    ScopeIdentifier = item.ScopeIdentifier,
                    IsEnabled = item.IsEnabled,
                    Feature = TypeAdapter<AppFeature, AppFeatureReadModel>.Map.Invoke(item.Feature),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static AppUserReadModel funcMain43(AppUser p50)
        {
            return p50 == null ? null : new AppUserReadModel()
            {
                Hash = p50.Hash,
                FirstName = p50.FirstName,
                LastName = p50.LastName,
                Mobile = p50.Mobile,
                CountryCode = p50.CountryCode,
                TwoFactorMethod = p50.TwoFactorMethod,
                CreatedBy = p50.CreatedBy,
                CreatedDate = p50.CreatedDate,
                ModifiedBy = p50.ModifiedBy,
                ModifiedDate = p50.ModifiedDate,
                IsDeleted = p50.IsDeleted,
                DeletedBy = p50.DeletedBy,
                DeletedDate = p50.DeletedDate,
                MembershipType = p50.MembershipType,
                UserRoles = funcMain44(p50.UserRoles),
                UserTokens = funcMain45(p50.UserTokens),
                RefreshTokens = funcMain46(p50.RefreshTokens),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p50.AccessControlEntries),
                Id = p50.Id,
                UserName = p50.UserName,
                NormalizedUserName = p50.NormalizedUserName,
                Email = p50.Email,
                NormalizedEmail = p50.NormalizedEmail,
                EmailConfirmed = p50.EmailConfirmed,
                PasswordHash = p50.PasswordHash,
                SecurityStamp = p50.SecurityStamp,
                ConcurrencyStamp = p50.ConcurrencyStamp,
                PhoneNumber = p50.PhoneNumber,
                PhoneNumberConfirmed = p50.PhoneNumberConfirmed,
                TwoFactorEnabled = p50.TwoFactorEnabled,
                LockoutEnd = p50.LockoutEnd,
                LockoutEnabled = p50.LockoutEnabled,
                AccessFailedCount = p50.AccessFailedCount
            };
        }
        
        private static ICollection<AppUserTokenReadModel> funcMain51(ICollection<AppUserToken> p59)
        {
            if (p59 == null)
            {
                return null;
            }
            ICollection<AppUserTokenReadModel> result = new List<AppUserTokenReadModel>(p59.Count);
            
            IEnumerator<AppUserToken> enumerator = p59.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserToken item = enumerator.Current;
                result.Add(item == null ? null : new AppUserTokenReadModel()
                {
                    Token = item.Token,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    LoginProvider = item.LoginProvider,
                    Name = item.Name,
                    Value = item.Value
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRefreshTokenReadModel> funcMain52(ICollection<AppRefreshToken> p60)
        {
            if (p60 == null)
            {
                return null;
            }
            ICollection<AppRefreshTokenReadModel> result = new List<AppRefreshTokenReadModel>(p60.Count);
            
            IEnumerator<AppRefreshToken> enumerator = p60.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRefreshToken item = enumerator.Current;
                result.Add(item == null ? null : new AppRefreshTokenReadModel()
                {
                    UserId = item.UserId,
                    Token = item.Token,
                    JwtId = item.JwtId,
                    IsUsed = item.IsUsed,
                    IsRevoked = item.IsRevoked,
                    ExpiryDate = item.ExpiryDate,
                    Hash = item.Hash,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static ICollection<AppAccessControlEntryReadModel> funcMain53(ICollection<AppAccessControlEntry> p61)
        {
            if (p61 == null)
            {
                return null;
            }
            ICollection<AppAccessControlEntryReadModel> result = new List<AppAccessControlEntryReadModel>(p61.Count);
            
            IEnumerator<AppAccessControlEntry> enumerator = p61.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppAccessControlEntry item = enumerator.Current;
                result.Add(funcMain54(item));
            }
            return result;
            
        }
        
        private static ICollection<AppFeatureFlagReadModel> funcMain63(ICollection<AppFeatureFlag> p71)
        {
            if (p71 == null)
            {
                return null;
            }
            ICollection<AppFeatureFlagReadModel> result = new List<AppFeatureFlagReadModel>(p71.Count);
            
            IEnumerator<AppFeatureFlag> enumerator = p71.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppFeatureFlag item = enumerator.Current;
                result.Add(item == null ? null : new AppFeatureFlagReadModel()
                {
                    FeatureId = item.FeatureId,
                    ScopeIdentifier = item.ScopeIdentifier,
                    IsEnabled = item.IsEnabled,
                    Feature = TypeAdapter<AppFeature, AppFeatureReadModel>.Map.Invoke(item.Feature),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static AppUserReadModel funcMain66(AppUser p74)
        {
            return p74 == null ? null : new AppUserReadModel()
            {
                Hash = p74.Hash,
                FirstName = p74.FirstName,
                LastName = p74.LastName,
                Mobile = p74.Mobile,
                CountryCode = p74.CountryCode,
                TwoFactorMethod = p74.TwoFactorMethod,
                CreatedBy = p74.CreatedBy,
                CreatedDate = p74.CreatedDate,
                ModifiedBy = p74.ModifiedBy,
                ModifiedDate = p74.ModifiedDate,
                IsDeleted = p74.IsDeleted,
                DeletedBy = p74.DeletedBy,
                DeletedDate = p74.DeletedDate,
                MembershipType = p74.MembershipType,
                UserRoles = funcMain67(p74.UserRoles),
                UserTokens = funcMain68(p74.UserTokens),
                RefreshTokens = funcMain69(p74.RefreshTokens),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p74.AccessControlEntries),
                Id = p74.Id,
                UserName = p74.UserName,
                NormalizedUserName = p74.NormalizedUserName,
                Email = p74.Email,
                NormalizedEmail = p74.NormalizedEmail,
                EmailConfirmed = p74.EmailConfirmed,
                PasswordHash = p74.PasswordHash,
                SecurityStamp = p74.SecurityStamp,
                ConcurrencyStamp = p74.ConcurrencyStamp,
                PhoneNumber = p74.PhoneNumber,
                PhoneNumberConfirmed = p74.PhoneNumberConfirmed,
                TwoFactorEnabled = p74.TwoFactorEnabled,
                LockoutEnd = p74.LockoutEnd,
                LockoutEnabled = p74.LockoutEnabled,
                AccessFailedCount = p74.AccessFailedCount
            };
        }
        
        private static ICollection<AppUserTokenReadModel> funcMain74(ICollection<AppUserToken> p86)
        {
            if (p86 == null)
            {
                return null;
            }
            ICollection<AppUserTokenReadModel> result = new List<AppUserTokenReadModel>(p86.Count);
            
            IEnumerator<AppUserToken> enumerator = p86.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserToken item = enumerator.Current;
                result.Add(item == null ? null : new AppUserTokenReadModel()
                {
                    Token = item.Token,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    LoginProvider = item.LoginProvider,
                    Name = item.Name,
                    Value = item.Value
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRefreshTokenReadModel> funcMain75(ICollection<AppRefreshToken> p87)
        {
            if (p87 == null)
            {
                return null;
            }
            ICollection<AppRefreshTokenReadModel> result = new List<AppRefreshTokenReadModel>(p87.Count);
            
            IEnumerator<AppRefreshToken> enumerator = p87.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRefreshToken item = enumerator.Current;
                result.Add(item == null ? null : new AppRefreshTokenReadModel()
                {
                    UserId = item.UserId,
                    Token = item.Token,
                    JwtId = item.JwtId,
                    IsUsed = item.IsUsed,
                    IsRevoked = item.IsRevoked,
                    ExpiryDate = item.ExpiryDate,
                    Hash = item.Hash,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static ICollection<AppAccessControlEntryReadModel> funcMain76(ICollection<AppAccessControlEntry> p88)
        {
            if (p88 == null)
            {
                return null;
            }
            ICollection<AppAccessControlEntryReadModel> result = new List<AppAccessControlEntryReadModel>(p88.Count);
            
            IEnumerator<AppAccessControlEntry> enumerator = p88.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppAccessControlEntry item = enumerator.Current;
                result.Add(funcMain77(item));
            }
            return result;
            
        }
        
        private static ICollection<AppFeatureFlagReadModel> funcMain86(ICollection<AppFeatureFlag> p100)
        {
            if (p100 == null)
            {
                return null;
            }
            ICollection<AppFeatureFlagReadModel> result = new List<AppFeatureFlagReadModel>(p100.Count);
            
            IEnumerator<AppFeatureFlag> enumerator = p100.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppFeatureFlag item = enumerator.Current;
                result.Add(item == null ? null : new AppFeatureFlagReadModel()
                {
                    FeatureId = item.FeatureId,
                    ScopeIdentifier = item.ScopeIdentifier,
                    IsEnabled = item.IsEnabled,
                    Feature = TypeAdapter<AppFeature, AppFeatureReadModel>.Map.Invoke(item.Feature),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static AppUserReadModel funcMain89(AppUser p103)
        {
            return p103 == null ? null : new AppUserReadModel()
            {
                Hash = p103.Hash,
                FirstName = p103.FirstName,
                LastName = p103.LastName,
                Mobile = p103.Mobile,
                CountryCode = p103.CountryCode,
                TwoFactorMethod = p103.TwoFactorMethod,
                CreatedBy = p103.CreatedBy,
                CreatedDate = p103.CreatedDate,
                ModifiedBy = p103.ModifiedBy,
                ModifiedDate = p103.ModifiedDate,
                IsDeleted = p103.IsDeleted,
                DeletedBy = p103.DeletedBy,
                DeletedDate = p103.DeletedDate,
                MembershipType = p103.MembershipType,
                UserRoles = funcMain90(p103.UserRoles),
                UserTokens = funcMain91(p103.UserTokens),
                RefreshTokens = funcMain92(p103.RefreshTokens),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p103.AccessControlEntries),
                Id = p103.Id,
                UserName = p103.UserName,
                NormalizedUserName = p103.NormalizedUserName,
                Email = p103.Email,
                NormalizedEmail = p103.NormalizedEmail,
                EmailConfirmed = p103.EmailConfirmed,
                PasswordHash = p103.PasswordHash,
                SecurityStamp = p103.SecurityStamp,
                ConcurrencyStamp = p103.ConcurrencyStamp,
                PhoneNumber = p103.PhoneNumber,
                PhoneNumberConfirmed = p103.PhoneNumberConfirmed,
                TwoFactorEnabled = p103.TwoFactorEnabled,
                LockoutEnd = p103.LockoutEnd,
                LockoutEnabled = p103.LockoutEnabled,
                AccessFailedCount = p103.AccessFailedCount
            };
        }
        
        private static AppAccessControlEntryReadModel funcMain8(AppAccessControlEntry p9)
        {
            return p9 == null ? null : new AppAccessControlEntryReadModel()
            {
                ResourcePattern = p9.ResourcePattern,
                PermissionPattern = p9.PermissionPattern,
                FeatureId = p9.FeatureId,
                Feature = funcMain9(p9.Feature),
                AppRoles = funcMain11(p9.AppRoles),
                AppUsers = funcMain12(p9.AppUsers),
                AppResource = p9.AppResource == null ? null : new AppResourceReadModel()
                {
                    Url = p9.AppResource.Url,
                    Description = p9.AppResource.Description,
                    ResourceType = p9.AppResource.ResourceType,
                    AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p9.AppResource.AccessControlEntries),
                    Id = p9.AppResource.Id,
                    CreatedBy = p9.AppResource.CreatedBy,
                    CreatedDate = p9.AppResource.CreatedDate,
                    ModifiedBy = p9.AppResource.ModifiedBy,
                    ModifiedDate = p9.AppResource.ModifiedDate,
                    IsDeleted = p9.AppResource.IsDeleted,
                    DeletedBy = p9.AppResource.DeletedBy,
                    DeletedDate = p9.AppResource.DeletedDate
                },
                ResourceId = p9.ResourceId,
                Id = p9.Id,
                CreatedBy = p9.CreatedBy,
                CreatedDate = p9.CreatedDate,
                ModifiedBy = p9.ModifiedBy,
                ModifiedDate = p9.ModifiedDate,
                IsDeleted = p9.IsDeleted,
                DeletedBy = p9.DeletedBy,
                DeletedDate = p9.DeletedDate
            };
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain21(ICollection<AppUserRole> p22)
        {
            if (p22 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p22.Count);
            
            IEnumerator<AppUserRole> enumerator = p22.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(item == null ? null : new AppUserRoleReadModel()
                {
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Hash = item.Hash,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    RoleId = item.RoleId
                });
            }
            return result;
            
        }
        
        private static ICollection<AppUserTokenReadModel> funcMain22(ICollection<AppUserToken> p23)
        {
            if (p23 == null)
            {
                return null;
            }
            ICollection<AppUserTokenReadModel> result = new List<AppUserTokenReadModel>(p23.Count);
            
            IEnumerator<AppUserToken> enumerator = p23.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserToken item = enumerator.Current;
                result.Add(item == null ? null : new AppUserTokenReadModel()
                {
                    Token = item.Token,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    LoginProvider = item.LoginProvider,
                    Name = item.Name,
                    Value = item.Value
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRefreshTokenReadModel> funcMain23(ICollection<AppRefreshToken> p24)
        {
            if (p24 == null)
            {
                return null;
            }
            ICollection<AppRefreshTokenReadModel> result = new List<AppRefreshTokenReadModel>(p24.Count);
            
            IEnumerator<AppRefreshToken> enumerator = p24.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRefreshToken item = enumerator.Current;
                result.Add(item == null ? null : new AppRefreshTokenReadModel()
                {
                    UserId = item.UserId,
                    Token = item.Token,
                    JwtId = item.JwtId,
                    IsUsed = item.IsUsed,
                    IsRevoked = item.IsRevoked,
                    ExpiryDate = item.ExpiryDate,
                    Hash = item.Hash,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static AppAccessControlEntryReadModel funcMain31(AppAccessControlEntry p36)
        {
            return p36 == null ? null : new AppAccessControlEntryReadModel()
            {
                ResourcePattern = p36.ResourcePattern,
                PermissionPattern = p36.PermissionPattern,
                FeatureId = p36.FeatureId,
                Feature = funcMain32(p36.Feature),
                AppRoles = funcMain34(p36.AppRoles),
                AppUsers = funcMain35(p36.AppUsers),
                AppResource = p36.AppResource == null ? null : new AppResourceReadModel()
                {
                    Url = p36.AppResource.Url,
                    Description = p36.AppResource.Description,
                    ResourceType = p36.AppResource.ResourceType,
                    AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p36.AppResource.AccessControlEntries),
                    Id = p36.AppResource.Id,
                    CreatedBy = p36.AppResource.CreatedBy,
                    CreatedDate = p36.AppResource.CreatedDate,
                    ModifiedBy = p36.AppResource.ModifiedBy,
                    ModifiedDate = p36.AppResource.ModifiedDate,
                    IsDeleted = p36.AppResource.IsDeleted,
                    DeletedBy = p36.AppResource.DeletedBy,
                    DeletedDate = p36.AppResource.DeletedDate
                },
                ResourceId = p36.ResourceId,
                Id = p36.Id,
                CreatedBy = p36.CreatedBy,
                CreatedDate = p36.CreatedDate,
                ModifiedBy = p36.ModifiedBy,
                ModifiedDate = p36.ModifiedDate,
                IsDeleted = p36.IsDeleted,
                DeletedBy = p36.DeletedBy,
                DeletedDate = p36.DeletedDate
            };
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain44(ICollection<AppUserRole> p51)
        {
            if (p51 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p51.Count);
            
            IEnumerator<AppUserRole> enumerator = p51.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(item == null ? null : new AppUserRoleReadModel()
                {
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Hash = item.Hash,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    RoleId = item.RoleId
                });
            }
            return result;
            
        }
        
        private static ICollection<AppUserTokenReadModel> funcMain45(ICollection<AppUserToken> p52)
        {
            if (p52 == null)
            {
                return null;
            }
            ICollection<AppUserTokenReadModel> result = new List<AppUserTokenReadModel>(p52.Count);
            
            IEnumerator<AppUserToken> enumerator = p52.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserToken item = enumerator.Current;
                result.Add(item == null ? null : new AppUserTokenReadModel()
                {
                    Token = item.Token,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    LoginProvider = item.LoginProvider,
                    Name = item.Name,
                    Value = item.Value
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRefreshTokenReadModel> funcMain46(ICollection<AppRefreshToken> p53)
        {
            if (p53 == null)
            {
                return null;
            }
            ICollection<AppRefreshTokenReadModel> result = new List<AppRefreshTokenReadModel>(p53.Count);
            
            IEnumerator<AppRefreshToken> enumerator = p53.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRefreshToken item = enumerator.Current;
                result.Add(item == null ? null : new AppRefreshTokenReadModel()
                {
                    UserId = item.UserId,
                    Token = item.Token,
                    JwtId = item.JwtId,
                    IsUsed = item.IsUsed,
                    IsRevoked = item.IsRevoked,
                    ExpiryDate = item.ExpiryDate,
                    Hash = item.Hash,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static AppAccessControlEntryReadModel funcMain54(AppAccessControlEntry p62)
        {
            return p62 == null ? null : new AppAccessControlEntryReadModel()
            {
                ResourcePattern = p62.ResourcePattern,
                PermissionPattern = p62.PermissionPattern,
                FeatureId = p62.FeatureId,
                Feature = funcMain55(p62.Feature),
                AppRoles = funcMain57(p62.AppRoles),
                AppUsers = funcMain58(p62.AppUsers),
                AppResource = p62.AppResource == null ? null : new AppResourceReadModel()
                {
                    Url = p62.AppResource.Url,
                    Description = p62.AppResource.Description,
                    ResourceType = p62.AppResource.ResourceType,
                    AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p62.AppResource.AccessControlEntries),
                    Id = p62.AppResource.Id,
                    CreatedBy = p62.AppResource.CreatedBy,
                    CreatedDate = p62.AppResource.CreatedDate,
                    ModifiedBy = p62.AppResource.ModifiedBy,
                    ModifiedDate = p62.AppResource.ModifiedDate,
                    IsDeleted = p62.AppResource.IsDeleted,
                    DeletedBy = p62.AppResource.DeletedBy,
                    DeletedDate = p62.AppResource.DeletedDate
                },
                ResourceId = p62.ResourceId,
                Id = p62.Id,
                CreatedBy = p62.CreatedBy,
                CreatedDate = p62.CreatedDate,
                ModifiedBy = p62.ModifiedBy,
                ModifiedDate = p62.ModifiedDate,
                IsDeleted = p62.IsDeleted,
                DeletedBy = p62.DeletedBy,
                DeletedDate = p62.DeletedDate
            };
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain67(ICollection<AppUserRole> p75)
        {
            if (p75 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p75.Count);
            
            IEnumerator<AppUserRole> enumerator = p75.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(item == null ? null : new AppUserRoleReadModel()
                {
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Hash = item.Hash,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    RoleId = item.RoleId
                });
            }
            return result;
            
        }
        
        private static ICollection<AppUserTokenReadModel> funcMain68(ICollection<AppUserToken> p76)
        {
            if (p76 == null)
            {
                return null;
            }
            ICollection<AppUserTokenReadModel> result = new List<AppUserTokenReadModel>(p76.Count);
            
            IEnumerator<AppUserToken> enumerator = p76.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserToken item = enumerator.Current;
                result.Add(item == null ? null : new AppUserTokenReadModel()
                {
                    Token = item.Token,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    LoginProvider = item.LoginProvider,
                    Name = item.Name,
                    Value = item.Value
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRefreshTokenReadModel> funcMain69(ICollection<AppRefreshToken> p77)
        {
            if (p77 == null)
            {
                return null;
            }
            ICollection<AppRefreshTokenReadModel> result = new List<AppRefreshTokenReadModel>(p77.Count);
            
            IEnumerator<AppRefreshToken> enumerator = p77.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRefreshToken item = enumerator.Current;
                result.Add(item == null ? null : new AppRefreshTokenReadModel()
                {
                    UserId = item.UserId,
                    Token = item.Token,
                    JwtId = item.JwtId,
                    IsUsed = item.IsUsed,
                    IsRevoked = item.IsRevoked,
                    ExpiryDate = item.ExpiryDate,
                    Hash = item.Hash,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static AppAccessControlEntryReadModel funcMain77(AppAccessControlEntry p89)
        {
            return p89 == null ? null : new AppAccessControlEntryReadModel()
            {
                ResourcePattern = p89.ResourcePattern,
                PermissionPattern = p89.PermissionPattern,
                FeatureId = p89.FeatureId,
                Feature = funcMain78(p89.Feature),
                AppRoles = funcMain80(p89.AppRoles),
                AppUsers = funcMain81(p89.AppUsers),
                AppResource = p89.AppResource == null ? null : new AppResourceReadModel()
                {
                    Url = p89.AppResource.Url,
                    Description = p89.AppResource.Description,
                    ResourceType = p89.AppResource.ResourceType,
                    AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p89.AppResource.AccessControlEntries),
                    Id = p89.AppResource.Id,
                    CreatedBy = p89.AppResource.CreatedBy,
                    CreatedDate = p89.AppResource.CreatedDate,
                    ModifiedBy = p89.AppResource.ModifiedBy,
                    ModifiedDate = p89.AppResource.ModifiedDate,
                    IsDeleted = p89.AppResource.IsDeleted,
                    DeletedBy = p89.AppResource.DeletedBy,
                    DeletedDate = p89.AppResource.DeletedDate
                },
                ResourceId = p89.ResourceId,
                Id = p89.Id,
                CreatedBy = p89.CreatedBy,
                CreatedDate = p89.CreatedDate,
                ModifiedBy = p89.ModifiedBy,
                ModifiedDate = p89.ModifiedDate,
                IsDeleted = p89.IsDeleted,
                DeletedBy = p89.DeletedBy,
                DeletedDate = p89.DeletedDate
            };
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain90(ICollection<AppUserRole> p104)
        {
            if (p104 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p104.Count);
            
            IEnumerator<AppUserRole> enumerator = p104.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(item == null ? null : new AppUserRoleReadModel()
                {
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Hash = item.Hash,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    RoleId = item.RoleId
                });
            }
            return result;
            
        }
        
        private static ICollection<AppUserTokenReadModel> funcMain91(ICollection<AppUserToken> p105)
        {
            if (p105 == null)
            {
                return null;
            }
            ICollection<AppUserTokenReadModel> result = new List<AppUserTokenReadModel>(p105.Count);
            
            IEnumerator<AppUserToken> enumerator = p105.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserToken item = enumerator.Current;
                result.Add(item == null ? null : new AppUserTokenReadModel()
                {
                    Token = item.Token,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    LoginProvider = item.LoginProvider,
                    Name = item.Name,
                    Value = item.Value
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRefreshTokenReadModel> funcMain92(ICollection<AppRefreshToken> p106)
        {
            if (p106 == null)
            {
                return null;
            }
            ICollection<AppRefreshTokenReadModel> result = new List<AppRefreshTokenReadModel>(p106.Count);
            
            IEnumerator<AppRefreshToken> enumerator = p106.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRefreshToken item = enumerator.Current;
                result.Add(item == null ? null : new AppRefreshTokenReadModel()
                {
                    UserId = item.UserId,
                    Token = item.Token,
                    JwtId = item.JwtId,
                    IsUsed = item.IsUsed,
                    IsRevoked = item.IsRevoked,
                    ExpiryDate = item.ExpiryDate,
                    Hash = item.Hash,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static AppFeatureReadModel funcMain9(AppFeature p10)
        {
            return p10 == null ? null : new AppFeatureReadModel()
            {
                Name = p10.Name,
                Description = p10.Description,
                IsEnabled = p10.IsEnabled,
                Scope = p10.Scope,
                FeatureFlags = funcMain10(p10.FeatureFlags),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p10.AccessControlEntries),
                Id = p10.Id,
                CreatedBy = p10.CreatedBy,
                CreatedDate = p10.CreatedDate,
                ModifiedBy = p10.ModifiedBy,
                ModifiedDate = p10.ModifiedDate,
                IsDeleted = p10.IsDeleted,
                DeletedBy = p10.DeletedBy,
                DeletedDate = p10.DeletedDate
            };
        }
        
        private static ICollection<AppRoleReadModel> funcMain11(ICollection<AppRole> p12)
        {
            if (p12 == null)
            {
                return null;
            }
            ICollection<AppRoleReadModel> result = new List<AppRoleReadModel>(p12.Count);
            
            IEnumerator<AppRole> enumerator = p12.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRole item = enumerator.Current;
                result.Add(TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserReadModel> funcMain12(ICollection<AppUser> p13)
        {
            if (p13 == null)
            {
                return null;
            }
            ICollection<AppUserReadModel> result = new List<AppUserReadModel>(p13.Count);
            
            IEnumerator<AppUser> enumerator = p13.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUser item = enumerator.Current;
                result.Add(TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static AppFeatureReadModel funcMain32(AppFeature p37)
        {
            return p37 == null ? null : new AppFeatureReadModel()
            {
                Name = p37.Name,
                Description = p37.Description,
                IsEnabled = p37.IsEnabled,
                Scope = p37.Scope,
                FeatureFlags = funcMain33(p37.FeatureFlags),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p37.AccessControlEntries),
                Id = p37.Id,
                CreatedBy = p37.CreatedBy,
                CreatedDate = p37.CreatedDate,
                ModifiedBy = p37.ModifiedBy,
                ModifiedDate = p37.ModifiedDate,
                IsDeleted = p37.IsDeleted,
                DeletedBy = p37.DeletedBy,
                DeletedDate = p37.DeletedDate
            };
        }
        
        private static ICollection<AppRoleReadModel> funcMain34(ICollection<AppRole> p39)
        {
            if (p39 == null)
            {
                return null;
            }
            ICollection<AppRoleReadModel> result = new List<AppRoleReadModel>(p39.Count);
            
            IEnumerator<AppRole> enumerator = p39.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRole item = enumerator.Current;
                result.Add(TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserReadModel> funcMain35(ICollection<AppUser> p40)
        {
            if (p40 == null)
            {
                return null;
            }
            ICollection<AppUserReadModel> result = new List<AppUserReadModel>(p40.Count);
            
            IEnumerator<AppUser> enumerator = p40.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUser item = enumerator.Current;
                result.Add(TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static AppFeatureReadModel funcMain55(AppFeature p63)
        {
            return p63 == null ? null : new AppFeatureReadModel()
            {
                Name = p63.Name,
                Description = p63.Description,
                IsEnabled = p63.IsEnabled,
                Scope = p63.Scope,
                FeatureFlags = funcMain56(p63.FeatureFlags),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p63.AccessControlEntries),
                Id = p63.Id,
                CreatedBy = p63.CreatedBy,
                CreatedDate = p63.CreatedDate,
                ModifiedBy = p63.ModifiedBy,
                ModifiedDate = p63.ModifiedDate,
                IsDeleted = p63.IsDeleted,
                DeletedBy = p63.DeletedBy,
                DeletedDate = p63.DeletedDate
            };
        }
        
        private static ICollection<AppRoleReadModel> funcMain57(ICollection<AppRole> p65)
        {
            if (p65 == null)
            {
                return null;
            }
            ICollection<AppRoleReadModel> result = new List<AppRoleReadModel>(p65.Count);
            
            IEnumerator<AppRole> enumerator = p65.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRole item = enumerator.Current;
                result.Add(TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserReadModel> funcMain58(ICollection<AppUser> p66)
        {
            if (p66 == null)
            {
                return null;
            }
            ICollection<AppUserReadModel> result = new List<AppUserReadModel>(p66.Count);
            
            IEnumerator<AppUser> enumerator = p66.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUser item = enumerator.Current;
                result.Add(TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static AppFeatureReadModel funcMain78(AppFeature p90)
        {
            return p90 == null ? null : new AppFeatureReadModel()
            {
                Name = p90.Name,
                Description = p90.Description,
                IsEnabled = p90.IsEnabled,
                Scope = p90.Scope,
                FeatureFlags = funcMain79(p90.FeatureFlags),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p90.AccessControlEntries),
                Id = p90.Id,
                CreatedBy = p90.CreatedBy,
                CreatedDate = p90.CreatedDate,
                ModifiedBy = p90.ModifiedBy,
                ModifiedDate = p90.ModifiedDate,
                IsDeleted = p90.IsDeleted,
                DeletedBy = p90.DeletedBy,
                DeletedDate = p90.DeletedDate
            };
        }
        
        private static ICollection<AppRoleReadModel> funcMain80(ICollection<AppRole> p92)
        {
            if (p92 == null)
            {
                return null;
            }
            ICollection<AppRoleReadModel> result = new List<AppRoleReadModel>(p92.Count);
            
            IEnumerator<AppRole> enumerator = p92.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRole item = enumerator.Current;
                result.Add(TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserReadModel> funcMain81(ICollection<AppUser> p93)
        {
            if (p93 == null)
            {
                return null;
            }
            ICollection<AppUserReadModel> result = new List<AppUserReadModel>(p93.Count);
            
            IEnumerator<AppUser> enumerator = p93.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUser item = enumerator.Current;
                result.Add(TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static ICollection<AppFeatureFlagReadModel> funcMain10(ICollection<AppFeatureFlag> p11)
        {
            if (p11 == null)
            {
                return null;
            }
            ICollection<AppFeatureFlagReadModel> result = new List<AppFeatureFlagReadModel>(p11.Count);
            
            IEnumerator<AppFeatureFlag> enumerator = p11.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppFeatureFlag item = enumerator.Current;
                result.Add(item == null ? null : new AppFeatureFlagReadModel()
                {
                    FeatureId = item.FeatureId,
                    ScopeIdentifier = item.ScopeIdentifier,
                    IsEnabled = item.IsEnabled,
                    Feature = TypeAdapter<AppFeature, AppFeatureReadModel>.Map.Invoke(item.Feature),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static ICollection<AppFeatureFlagReadModel> funcMain33(ICollection<AppFeatureFlag> p38)
        {
            if (p38 == null)
            {
                return null;
            }
            ICollection<AppFeatureFlagReadModel> result = new List<AppFeatureFlagReadModel>(p38.Count);
            
            IEnumerator<AppFeatureFlag> enumerator = p38.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppFeatureFlag item = enumerator.Current;
                result.Add(item == null ? null : new AppFeatureFlagReadModel()
                {
                    FeatureId = item.FeatureId,
                    ScopeIdentifier = item.ScopeIdentifier,
                    IsEnabled = item.IsEnabled,
                    Feature = TypeAdapter<AppFeature, AppFeatureReadModel>.Map.Invoke(item.Feature),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static ICollection<AppFeatureFlagReadModel> funcMain56(ICollection<AppFeatureFlag> p64)
        {
            if (p64 == null)
            {
                return null;
            }
            ICollection<AppFeatureFlagReadModel> result = new List<AppFeatureFlagReadModel>(p64.Count);
            
            IEnumerator<AppFeatureFlag> enumerator = p64.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppFeatureFlag item = enumerator.Current;
                result.Add(item == null ? null : new AppFeatureFlagReadModel()
                {
                    FeatureId = item.FeatureId,
                    ScopeIdentifier = item.ScopeIdentifier,
                    IsEnabled = item.IsEnabled,
                    Feature = TypeAdapter<AppFeature, AppFeatureReadModel>.Map.Invoke(item.Feature),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static ICollection<AppFeatureFlagReadModel> funcMain79(ICollection<AppFeatureFlag> p91)
        {
            if (p91 == null)
            {
                return null;
            }
            ICollection<AppFeatureFlagReadModel> result = new List<AppFeatureFlagReadModel>(p91.Count);
            
            IEnumerator<AppFeatureFlag> enumerator = p91.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppFeatureFlag item = enumerator.Current;
                result.Add(item == null ? null : new AppFeatureFlagReadModel()
                {
                    FeatureId = item.FeatureId,
                    ScopeIdentifier = item.ScopeIdentifier,
                    IsEnabled = item.IsEnabled,
                    Feature = TypeAdapter<AppFeature, AppFeatureReadModel>.Map.Invoke(item.Feature),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
    }
}