using AxialSystem.Covaluse.Core.Database.LogTables;

namespace AxialSystem.Covaluse.Core.Database.LogTables
{
    public static partial class ElmahErrorMapper
    {
        public static ElmahErrorReadModel AdaptToReadModel(this ElmahError p1)
        {
            return p1 == null ? null : new ElmahErrorReadModel()
            {
                ErrorId = p1.ErrorId,
                Application = p1.Application,
                Host = p1.Host,
                Type = p1.Type,
                Source = p1.Source,
                Message = p1.Message,
                User = p1.User,
                StatusCode = p1.StatusCode,
                TimeUtc = p1.TimeUtc,
                Sequence = p1.Sequence,
                AllXml = p1.AllXml
            };
        }
        public static ElmahErrorReadModel AdaptTo(this ElmahError p2, ElmahErrorReadModel p3)
        {
            if (p2 == null)
            {
                return null;
            }
            ElmahErrorReadModel result = p3 ?? new ElmahErrorReadModel();
            
            result.ErrorId = p2.ErrorId;
            result.Application = p2.Application;
            result.Host = p2.Host;
            result.Type = p2.Type;
            result.Source = p2.Source;
            result.Message = p2.Message;
            result.User = p2.User;
            result.StatusCode = p2.StatusCode;
            result.TimeUtc = p2.TimeUtc;
            result.Sequence = p2.Sequence;
            result.AllXml = p2.AllXml;
            return result;
            
        }
        public static ElmahErrorModifyModel AdaptToModifyModel(this ElmahError p4)
        {
            return p4 == null ? null : new ElmahErrorModifyModel()
            {
                ErrorId = p4.ErrorId,
                Application = p4.Application,
                Host = p4.Host,
                Type = p4.Type,
                Source = p4.Source,
                Message = p4.Message,
                User = p4.User,
                StatusCode = p4.StatusCode,
                TimeUtc = p4.TimeUtc,
                Sequence = p4.Sequence,
                AllXml = p4.AllXml
            };
        }
        public static ElmahErrorModifyModel AdaptTo(this ElmahError p5, ElmahErrorModifyModel p6)
        {
            if (p5 == null)
            {
                return null;
            }
            ElmahErrorModifyModel result = p6 ?? new ElmahErrorModifyModel();
            
            result.ErrorId = p5.ErrorId;
            result.Application = p5.Application;
            result.Host = p5.Host;
            result.Type = p5.Type;
            result.Source = p5.Source;
            result.Message = p5.Message;
            result.User = p5.User;
            result.StatusCode = p5.StatusCode;
            result.TimeUtc = p5.TimeUtc;
            result.Sequence = p5.Sequence;
            result.AllXml = p5.AllXml;
            return result;
            
        }
    }
}