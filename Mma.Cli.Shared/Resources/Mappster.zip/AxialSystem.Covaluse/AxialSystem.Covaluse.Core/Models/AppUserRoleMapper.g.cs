using System.Collections.Generic;
using AxialSystem.Covaluse.Core.Database.Identity;
using Mapster;

namespace AxialSystem.Covaluse.Core.Database.Identity
{
    public static partial class AppUserRoleMapper
    {
        public static AppUserRoleReadModel AdaptToReadModel(this AppUserRole p1)
        {
            return p1 == null ? null : new AppUserRoleReadModel()
            {
                AppUser = funcMain1(p1.AppUser),
                AppRole = funcMain14(p1.AppRole),
                Hash = p1.Hash,
                CreatedBy = p1.CreatedBy,
                CreatedDate = p1.CreatedDate,
                ModifiedBy = p1.ModifiedBy,
                ModifiedDate = p1.ModifiedDate,
                IsDeleted = p1.IsDeleted,
                DeletedBy = p1.DeletedBy,
                DeletedDate = p1.DeletedDate,
                UserId = p1.UserId,
                RoleId = p1.RoleId
            };
        }
        public static AppUserRoleReadModel AdaptTo(this AppUserRole p28, AppUserRoleReadModel p29)
        {
            if (p28 == null)
            {
                return null;
            }
            AppUserRoleReadModel result = p29 ?? new AppUserRoleReadModel();
            
            result.AppUser = funcMain27(p28.AppUser, result.AppUser);
            result.AppRole = funcMain40(p28.AppRole, result.AppRole);
            result.Hash = p28.Hash;
            result.CreatedBy = p28.CreatedBy;
            result.CreatedDate = p28.CreatedDate;
            result.ModifiedBy = p28.ModifiedBy;
            result.ModifiedDate = p28.ModifiedDate;
            result.IsDeleted = p28.IsDeleted;
            result.DeletedBy = p28.DeletedBy;
            result.DeletedDate = p28.DeletedDate;
            result.UserId = p28.UserId;
            result.RoleId = p28.RoleId;
            return result;
            
        }
        public static AppUserRoleModifyModel AdaptToModifyModel(this AppUserRole p65)
        {
            return p65 == null ? null : new AppUserRoleModifyModel()
            {
                AppUser = funcMain53(p65.AppUser),
                AppRole = funcMain75(p65.AppRole),
                Hash = p65.Hash,
                CreatedBy = p65.CreatedBy,
                CreatedDate = p65.CreatedDate,
                ModifiedBy = p65.ModifiedBy,
                ModifiedDate = p65.ModifiedDate,
                IsDeleted = p65.IsDeleted,
                DeletedBy = p65.DeletedBy,
                DeletedDate = p65.DeletedDate,
                UserId = p65.UserId,
                RoleId = p65.RoleId
            };
        }
        public static AppUserRoleModifyModel AdaptTo(this AppUserRole p111, AppUserRoleModifyModel p112)
        {
            if (p111 == null)
            {
                return null;
            }
            AppUserRoleModifyModel result = p112 ?? new AppUserRoleModifyModel();
            
            result.AppUser = funcMain98(p111.AppUser, result.AppUser);
            result.AppRole = funcMain120(p111.AppRole, result.AppRole);
            result.Hash = p111.Hash;
            result.CreatedBy = p111.CreatedBy;
            result.CreatedDate = p111.CreatedDate;
            result.ModifiedBy = p111.ModifiedBy;
            result.ModifiedDate = p111.ModifiedDate;
            result.IsDeleted = p111.IsDeleted;
            result.DeletedBy = p111.DeletedBy;
            result.DeletedDate = p111.DeletedDate;
            result.UserId = p111.UserId;
            result.RoleId = p111.RoleId;
            return result;
            
        }
        
        private static AppUserReadModel funcMain1(AppUser p2)
        {
            return p2 == null ? null : new AppUserReadModel()
            {
                Hash = p2.Hash,
                FirstName = p2.FirstName,
                LastName = p2.LastName,
                Mobile = p2.Mobile,
                CountryCode = p2.CountryCode,
                TwoFactorMethod = p2.TwoFactorMethod,
                CreatedBy = p2.CreatedBy,
                CreatedDate = p2.CreatedDate,
                ModifiedBy = p2.ModifiedBy,
                ModifiedDate = p2.ModifiedDate,
                IsDeleted = p2.IsDeleted,
                DeletedBy = p2.DeletedBy,
                DeletedDate = p2.DeletedDate,
                MembershipType = p2.MembershipType,
                UserRoles = funcMain2(p2.UserRoles),
                UserTokens = funcMain3(p2.UserTokens),
                RefreshTokens = funcMain4(p2.RefreshTokens),
                AccessControlEntries = funcMain5(p2.AccessControlEntries),
                Id = p2.Id,
                UserName = p2.UserName,
                NormalizedUserName = p2.NormalizedUserName,
                Email = p2.Email,
                NormalizedEmail = p2.NormalizedEmail,
                EmailConfirmed = p2.EmailConfirmed,
                PasswordHash = p2.PasswordHash,
                SecurityStamp = p2.SecurityStamp,
                ConcurrencyStamp = p2.ConcurrencyStamp,
                PhoneNumber = p2.PhoneNumber,
                PhoneNumberConfirmed = p2.PhoneNumberConfirmed,
                TwoFactorEnabled = p2.TwoFactorEnabled,
                LockoutEnd = p2.LockoutEnd,
                LockoutEnabled = p2.LockoutEnabled,
                AccessFailedCount = p2.AccessFailedCount
            };
        }
        
        private static AppRoleReadModel funcMain14(AppRole p15)
        {
            return p15 == null ? null : new AppRoleReadModel()
            {
                CreatedBy = p15.CreatedBy,
                CreatedDate = p15.CreatedDate,
                ModifiedBy = p15.ModifiedBy,
                ModifiedDate = p15.ModifiedDate,
                IsDeleted = p15.IsDeleted,
                DeletedBy = p15.DeletedBy,
                DeletedDate = p15.DeletedDate,
                AppUserRoles = funcMain15(p15.AppUserRoles),
                AppRoleClaims = funcMain16(p15.AppRoleClaims),
                AccessControlEntries = funcMain17(p15.AccessControlEntries),
                Hash = p15.Hash,
                Id = p15.Id,
                Name = p15.Name,
                NormalizedName = p15.NormalizedName,
                ConcurrencyStamp = p15.ConcurrencyStamp
            };
        }
        
        private static AppUserReadModel funcMain27(AppUser p30, AppUserReadModel p31)
        {
            if (p30 == null)
            {
                return null;
            }
            AppUserReadModel result = p31 ?? new AppUserReadModel();
            
            result.Hash = p30.Hash;
            result.FirstName = p30.FirstName;
            result.LastName = p30.LastName;
            result.Mobile = p30.Mobile;
            result.CountryCode = p30.CountryCode;
            result.TwoFactorMethod = p30.TwoFactorMethod;
            result.CreatedBy = p30.CreatedBy;
            result.CreatedDate = p30.CreatedDate;
            result.ModifiedBy = p30.ModifiedBy;
            result.ModifiedDate = p30.ModifiedDate;
            result.IsDeleted = p30.IsDeleted;
            result.DeletedBy = p30.DeletedBy;
            result.DeletedDate = p30.DeletedDate;
            result.MembershipType = p30.MembershipType;
            result.UserRoles = funcMain28(p30.UserRoles, result.UserRoles);
            result.UserTokens = funcMain29(p30.UserTokens, result.UserTokens);
            result.RefreshTokens = funcMain30(p30.RefreshTokens, result.RefreshTokens);
            result.AccessControlEntries = funcMain31(p30.AccessControlEntries, result.AccessControlEntries);
            result.Id = p30.Id;
            result.UserName = p30.UserName;
            result.NormalizedUserName = p30.NormalizedUserName;
            result.Email = p30.Email;
            result.NormalizedEmail = p30.NormalizedEmail;
            result.EmailConfirmed = p30.EmailConfirmed;
            result.PasswordHash = p30.PasswordHash;
            result.SecurityStamp = p30.SecurityStamp;
            result.ConcurrencyStamp = p30.ConcurrencyStamp;
            result.PhoneNumber = p30.PhoneNumber;
            result.PhoneNumberConfirmed = p30.PhoneNumberConfirmed;
            result.TwoFactorEnabled = p30.TwoFactorEnabled;
            result.LockoutEnd = p30.LockoutEnd;
            result.LockoutEnabled = p30.LockoutEnabled;
            result.AccessFailedCount = p30.AccessFailedCount;
            return result;
            
        }
        
        private static AppRoleReadModel funcMain40(AppRole p48, AppRoleReadModel p49)
        {
            if (p48 == null)
            {
                return null;
            }
            AppRoleReadModel result = p49 ?? new AppRoleReadModel();
            
            result.CreatedBy = p48.CreatedBy;
            result.CreatedDate = p48.CreatedDate;
            result.ModifiedBy = p48.ModifiedBy;
            result.ModifiedDate = p48.ModifiedDate;
            result.IsDeleted = p48.IsDeleted;
            result.DeletedBy = p48.DeletedBy;
            result.DeletedDate = p48.DeletedDate;
            result.AppUserRoles = funcMain41(p48.AppUserRoles, result.AppUserRoles);
            result.AppRoleClaims = funcMain42(p48.AppRoleClaims, result.AppRoleClaims);
            result.AccessControlEntries = funcMain43(p48.AccessControlEntries, result.AccessControlEntries);
            result.Hash = p48.Hash;
            result.Id = p48.Id;
            result.Name = p48.Name;
            result.NormalizedName = p48.NormalizedName;
            result.ConcurrencyStamp = p48.ConcurrencyStamp;
            return result;
            
        }
        
        private static AppUserReadModel funcMain53(AppUser p66)
        {
            return p66 == null ? null : new AppUserReadModel()
            {
                Hash = p66.Hash,
                FirstName = p66.FirstName,
                LastName = p66.LastName,
                Mobile = p66.Mobile,
                CountryCode = p66.CountryCode,
                TwoFactorMethod = p66.TwoFactorMethod,
                CreatedBy = p66.CreatedBy,
                CreatedDate = p66.CreatedDate,
                ModifiedBy = p66.ModifiedBy,
                ModifiedDate = p66.ModifiedDate,
                IsDeleted = p66.IsDeleted,
                DeletedBy = p66.DeletedBy,
                DeletedDate = p66.DeletedDate,
                MembershipType = p66.MembershipType,
                UserRoles = funcMain54(p66.UserRoles),
                UserTokens = funcMain64(p66.UserTokens),
                RefreshTokens = funcMain65(p66.RefreshTokens),
                AccessControlEntries = funcMain66(p66.AccessControlEntries),
                Id = p66.Id,
                UserName = p66.UserName,
                NormalizedUserName = p66.NormalizedUserName,
                Email = p66.Email,
                NormalizedEmail = p66.NormalizedEmail,
                EmailConfirmed = p66.EmailConfirmed,
                PasswordHash = p66.PasswordHash,
                SecurityStamp = p66.SecurityStamp,
                ConcurrencyStamp = p66.ConcurrencyStamp,
                PhoneNumber = p66.PhoneNumber,
                PhoneNumberConfirmed = p66.PhoneNumberConfirmed,
                TwoFactorEnabled = p66.TwoFactorEnabled,
                LockoutEnd = p66.LockoutEnd,
                LockoutEnabled = p66.LockoutEnabled,
                AccessFailedCount = p66.AccessFailedCount
            };
        }
        
        private static AppRoleReadModel funcMain75(AppRole p88)
        {
            return p88 == null ? null : new AppRoleReadModel()
            {
                CreatedBy = p88.CreatedBy,
                CreatedDate = p88.CreatedDate,
                ModifiedBy = p88.ModifiedBy,
                ModifiedDate = p88.ModifiedDate,
                IsDeleted = p88.IsDeleted,
                DeletedBy = p88.DeletedBy,
                DeletedDate = p88.DeletedDate,
                AppUserRoles = funcMain76(p88.AppUserRoles),
                AppRoleClaims = funcMain87(p88.AppRoleClaims),
                AccessControlEntries = funcMain88(p88.AccessControlEntries),
                Hash = p88.Hash,
                Id = p88.Id,
                Name = p88.Name,
                NormalizedName = p88.NormalizedName,
                ConcurrencyStamp = p88.ConcurrencyStamp
            };
        }
        
        private static AppUserReadModel funcMain98(AppUser p113, AppUserReadModel p114)
        {
            if (p113 == null)
            {
                return null;
            }
            AppUserReadModel result = p114 ?? new AppUserReadModel();
            
            result.Hash = p113.Hash;
            result.FirstName = p113.FirstName;
            result.LastName = p113.LastName;
            result.Mobile = p113.Mobile;
            result.CountryCode = p113.CountryCode;
            result.TwoFactorMethod = p113.TwoFactorMethod;
            result.CreatedBy = p113.CreatedBy;
            result.CreatedDate = p113.CreatedDate;
            result.ModifiedBy = p113.ModifiedBy;
            result.ModifiedDate = p113.ModifiedDate;
            result.IsDeleted = p113.IsDeleted;
            result.DeletedBy = p113.DeletedBy;
            result.DeletedDate = p113.DeletedDate;
            result.MembershipType = p113.MembershipType;
            result.UserRoles = funcMain99(p113.UserRoles, result.UserRoles);
            result.UserTokens = funcMain109(p113.UserTokens, result.UserTokens);
            result.RefreshTokens = funcMain110(p113.RefreshTokens, result.RefreshTokens);
            result.AccessControlEntries = funcMain111(p113.AccessControlEntries, result.AccessControlEntries);
            result.Id = p113.Id;
            result.UserName = p113.UserName;
            result.NormalizedUserName = p113.NormalizedUserName;
            result.Email = p113.Email;
            result.NormalizedEmail = p113.NormalizedEmail;
            result.EmailConfirmed = p113.EmailConfirmed;
            result.PasswordHash = p113.PasswordHash;
            result.SecurityStamp = p113.SecurityStamp;
            result.ConcurrencyStamp = p113.ConcurrencyStamp;
            result.PhoneNumber = p113.PhoneNumber;
            result.PhoneNumberConfirmed = p113.PhoneNumberConfirmed;
            result.TwoFactorEnabled = p113.TwoFactorEnabled;
            result.LockoutEnd = p113.LockoutEnd;
            result.LockoutEnabled = p113.LockoutEnabled;
            result.AccessFailedCount = p113.AccessFailedCount;
            return result;
            
        }
        
        private static AppRoleReadModel funcMain120(AppRole p140, AppRoleReadModel p141)
        {
            if (p140 == null)
            {
                return null;
            }
            AppRoleReadModel result = p141 ?? new AppRoleReadModel();
            
            result.CreatedBy = p140.CreatedBy;
            result.CreatedDate = p140.CreatedDate;
            result.ModifiedBy = p140.ModifiedBy;
            result.ModifiedDate = p140.ModifiedDate;
            result.IsDeleted = p140.IsDeleted;
            result.DeletedBy = p140.DeletedBy;
            result.DeletedDate = p140.DeletedDate;
            result.AppUserRoles = funcMain121(p140.AppUserRoles, result.AppUserRoles);
            result.AppRoleClaims = funcMain132(p140.AppRoleClaims, result.AppRoleClaims);
            result.AccessControlEntries = funcMain133(p140.AccessControlEntries, result.AccessControlEntries);
            result.Hash = p140.Hash;
            result.Id = p140.Id;
            result.Name = p140.Name;
            result.NormalizedName = p140.NormalizedName;
            result.ConcurrencyStamp = p140.ConcurrencyStamp;
            return result;
            
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain2(ICollection<AppUserRole> p3)
        {
            if (p3 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p3.Count);
            
            IEnumerator<AppUserRole> enumerator = p3.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(TypeAdapter<AppUserRole, AppUserRoleReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserTokenReadModel> funcMain3(ICollection<AppUserToken> p4)
        {
            if (p4 == null)
            {
                return null;
            }
            ICollection<AppUserTokenReadModel> result = new List<AppUserTokenReadModel>(p4.Count);
            
            IEnumerator<AppUserToken> enumerator = p4.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserToken item = enumerator.Current;
                result.Add(item == null ? null : new AppUserTokenReadModel()
                {
                    Token = item.Token,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    LoginProvider = item.LoginProvider,
                    Name = item.Name,
                    Value = item.Value
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRefreshTokenReadModel> funcMain4(ICollection<AppRefreshToken> p5)
        {
            if (p5 == null)
            {
                return null;
            }
            ICollection<AppRefreshTokenReadModel> result = new List<AppRefreshTokenReadModel>(p5.Count);
            
            IEnumerator<AppRefreshToken> enumerator = p5.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRefreshToken item = enumerator.Current;
                result.Add(item == null ? null : new AppRefreshTokenReadModel()
                {
                    UserId = item.UserId,
                    Token = item.Token,
                    JwtId = item.JwtId,
                    IsUsed = item.IsUsed,
                    IsRevoked = item.IsRevoked,
                    ExpiryDate = item.ExpiryDate,
                    Hash = item.Hash,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static ICollection<AppAccessControlEntryReadModel> funcMain5(ICollection<AppAccessControlEntry> p6)
        {
            if (p6 == null)
            {
                return null;
            }
            ICollection<AppAccessControlEntryReadModel> result = new List<AppAccessControlEntryReadModel>(p6.Count);
            
            IEnumerator<AppAccessControlEntry> enumerator = p6.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppAccessControlEntry item = enumerator.Current;
                result.Add(funcMain6(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain15(ICollection<AppUserRole> p16)
        {
            if (p16 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p16.Count);
            
            IEnumerator<AppUserRole> enumerator = p16.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(TypeAdapter<AppUserRole, AppUserRoleReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static ICollection<AppRoleClaimReadModel> funcMain16(ICollection<AppRoleClaim> p17)
        {
            if (p17 == null)
            {
                return null;
            }
            ICollection<AppRoleClaimReadModel> result = new List<AppRoleClaimReadModel>(p17.Count);
            
            IEnumerator<AppRoleClaim> enumerator = p17.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRoleClaim item = enumerator.Current;
                result.Add(item == null ? null : new AppRoleClaimReadModel()
                {
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Id = item.Id,
                    RoleId = item.RoleId,
                    ClaimType = item.ClaimType,
                    ClaimValue = item.ClaimValue
                });
            }
            return result;
            
        }
        
        private static ICollection<AppAccessControlEntryReadModel> funcMain17(ICollection<AppAccessControlEntry> p18)
        {
            if (p18 == null)
            {
                return null;
            }
            ICollection<AppAccessControlEntryReadModel> result = new List<AppAccessControlEntryReadModel>(p18.Count);
            
            IEnumerator<AppAccessControlEntry> enumerator = p18.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppAccessControlEntry item = enumerator.Current;
                result.Add(funcMain18(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain28(ICollection<AppUserRole> p32, ICollection<AppUserRoleReadModel> p33)
        {
            if (p32 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p32.Count);
            
            IEnumerator<AppUserRole> enumerator = p32.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(TypeAdapter<AppUserRole, AppUserRoleReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserTokenReadModel> funcMain29(ICollection<AppUserToken> p34, ICollection<AppUserTokenReadModel> p35)
        {
            if (p34 == null)
            {
                return null;
            }
            ICollection<AppUserTokenReadModel> result = new List<AppUserTokenReadModel>(p34.Count);
            
            IEnumerator<AppUserToken> enumerator = p34.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserToken item = enumerator.Current;
                result.Add(item == null ? null : new AppUserTokenReadModel()
                {
                    Token = item.Token,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    LoginProvider = item.LoginProvider,
                    Name = item.Name,
                    Value = item.Value
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRefreshTokenReadModel> funcMain30(ICollection<AppRefreshToken> p36, ICollection<AppRefreshTokenReadModel> p37)
        {
            if (p36 == null)
            {
                return null;
            }
            ICollection<AppRefreshTokenReadModel> result = new List<AppRefreshTokenReadModel>(p36.Count);
            
            IEnumerator<AppRefreshToken> enumerator = p36.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRefreshToken item = enumerator.Current;
                result.Add(item == null ? null : new AppRefreshTokenReadModel()
                {
                    UserId = item.UserId,
                    Token = item.Token,
                    JwtId = item.JwtId,
                    IsUsed = item.IsUsed,
                    IsRevoked = item.IsRevoked,
                    ExpiryDate = item.ExpiryDate,
                    Hash = item.Hash,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static ICollection<AppAccessControlEntryReadModel> funcMain31(ICollection<AppAccessControlEntry> p38, ICollection<AppAccessControlEntryReadModel> p39)
        {
            if (p38 == null)
            {
                return null;
            }
            ICollection<AppAccessControlEntryReadModel> result = new List<AppAccessControlEntryReadModel>(p38.Count);
            
            IEnumerator<AppAccessControlEntry> enumerator = p38.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppAccessControlEntry item = enumerator.Current;
                result.Add(funcMain32(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain41(ICollection<AppUserRole> p50, ICollection<AppUserRoleReadModel> p51)
        {
            if (p50 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p50.Count);
            
            IEnumerator<AppUserRole> enumerator = p50.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(TypeAdapter<AppUserRole, AppUserRoleReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static ICollection<AppRoleClaimReadModel> funcMain42(ICollection<AppRoleClaim> p52, ICollection<AppRoleClaimReadModel> p53)
        {
            if (p52 == null)
            {
                return null;
            }
            ICollection<AppRoleClaimReadModel> result = new List<AppRoleClaimReadModel>(p52.Count);
            
            IEnumerator<AppRoleClaim> enumerator = p52.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRoleClaim item = enumerator.Current;
                result.Add(item == null ? null : new AppRoleClaimReadModel()
                {
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Id = item.Id,
                    RoleId = item.RoleId,
                    ClaimType = item.ClaimType,
                    ClaimValue = item.ClaimValue
                });
            }
            return result;
            
        }
        
        private static ICollection<AppAccessControlEntryReadModel> funcMain43(ICollection<AppAccessControlEntry> p54, ICollection<AppAccessControlEntryReadModel> p55)
        {
            if (p54 == null)
            {
                return null;
            }
            ICollection<AppAccessControlEntryReadModel> result = new List<AppAccessControlEntryReadModel>(p54.Count);
            
            IEnumerator<AppAccessControlEntry> enumerator = p54.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppAccessControlEntry item = enumerator.Current;
                result.Add(funcMain44(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain54(ICollection<AppUserRole> p67)
        {
            if (p67 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p67.Count);
            
            IEnumerator<AppUserRole> enumerator = p67.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(funcMain55(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserTokenReadModel> funcMain64(ICollection<AppUserToken> p77)
        {
            if (p77 == null)
            {
                return null;
            }
            ICollection<AppUserTokenReadModel> result = new List<AppUserTokenReadModel>(p77.Count);
            
            IEnumerator<AppUserToken> enumerator = p77.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserToken item = enumerator.Current;
                result.Add(item == null ? null : new AppUserTokenReadModel()
                {
                    Token = item.Token,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    LoginProvider = item.LoginProvider,
                    Name = item.Name,
                    Value = item.Value
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRefreshTokenReadModel> funcMain65(ICollection<AppRefreshToken> p78)
        {
            if (p78 == null)
            {
                return null;
            }
            ICollection<AppRefreshTokenReadModel> result = new List<AppRefreshTokenReadModel>(p78.Count);
            
            IEnumerator<AppRefreshToken> enumerator = p78.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRefreshToken item = enumerator.Current;
                result.Add(item == null ? null : new AppRefreshTokenReadModel()
                {
                    UserId = item.UserId,
                    Token = item.Token,
                    JwtId = item.JwtId,
                    IsUsed = item.IsUsed,
                    IsRevoked = item.IsRevoked,
                    ExpiryDate = item.ExpiryDate,
                    Hash = item.Hash,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static ICollection<AppAccessControlEntryReadModel> funcMain66(ICollection<AppAccessControlEntry> p79)
        {
            if (p79 == null)
            {
                return null;
            }
            ICollection<AppAccessControlEntryReadModel> result = new List<AppAccessControlEntryReadModel>(p79.Count);
            
            IEnumerator<AppAccessControlEntry> enumerator = p79.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppAccessControlEntry item = enumerator.Current;
                result.Add(funcMain67(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain76(ICollection<AppUserRole> p89)
        {
            if (p89 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p89.Count);
            
            IEnumerator<AppUserRole> enumerator = p89.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(funcMain77(item));
            }
            return result;
            
        }
        
        private static ICollection<AppRoleClaimReadModel> funcMain87(ICollection<AppRoleClaim> p100)
        {
            if (p100 == null)
            {
                return null;
            }
            ICollection<AppRoleClaimReadModel> result = new List<AppRoleClaimReadModel>(p100.Count);
            
            IEnumerator<AppRoleClaim> enumerator = p100.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRoleClaim item = enumerator.Current;
                result.Add(item == null ? null : new AppRoleClaimReadModel()
                {
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Id = item.Id,
                    RoleId = item.RoleId,
                    ClaimType = item.ClaimType,
                    ClaimValue = item.ClaimValue
                });
            }
            return result;
            
        }
        
        private static ICollection<AppAccessControlEntryReadModel> funcMain88(ICollection<AppAccessControlEntry> p101)
        {
            if (p101 == null)
            {
                return null;
            }
            ICollection<AppAccessControlEntryReadModel> result = new List<AppAccessControlEntryReadModel>(p101.Count);
            
            IEnumerator<AppAccessControlEntry> enumerator = p101.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppAccessControlEntry item = enumerator.Current;
                result.Add(funcMain89(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain99(ICollection<AppUserRole> p115, ICollection<AppUserRoleReadModel> p116)
        {
            if (p115 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p115.Count);
            
            IEnumerator<AppUserRole> enumerator = p115.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(funcMain100(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserTokenReadModel> funcMain109(ICollection<AppUserToken> p126, ICollection<AppUserTokenReadModel> p127)
        {
            if (p126 == null)
            {
                return null;
            }
            ICollection<AppUserTokenReadModel> result = new List<AppUserTokenReadModel>(p126.Count);
            
            IEnumerator<AppUserToken> enumerator = p126.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserToken item = enumerator.Current;
                result.Add(item == null ? null : new AppUserTokenReadModel()
                {
                    Token = item.Token,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    LoginProvider = item.LoginProvider,
                    Name = item.Name,
                    Value = item.Value
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRefreshTokenReadModel> funcMain110(ICollection<AppRefreshToken> p128, ICollection<AppRefreshTokenReadModel> p129)
        {
            if (p128 == null)
            {
                return null;
            }
            ICollection<AppRefreshTokenReadModel> result = new List<AppRefreshTokenReadModel>(p128.Count);
            
            IEnumerator<AppRefreshToken> enumerator = p128.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRefreshToken item = enumerator.Current;
                result.Add(item == null ? null : new AppRefreshTokenReadModel()
                {
                    UserId = item.UserId,
                    Token = item.Token,
                    JwtId = item.JwtId,
                    IsUsed = item.IsUsed,
                    IsRevoked = item.IsRevoked,
                    ExpiryDate = item.ExpiryDate,
                    Hash = item.Hash,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static ICollection<AppAccessControlEntryReadModel> funcMain111(ICollection<AppAccessControlEntry> p130, ICollection<AppAccessControlEntryReadModel> p131)
        {
            if (p130 == null)
            {
                return null;
            }
            ICollection<AppAccessControlEntryReadModel> result = new List<AppAccessControlEntryReadModel>(p130.Count);
            
            IEnumerator<AppAccessControlEntry> enumerator = p130.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppAccessControlEntry item = enumerator.Current;
                result.Add(funcMain112(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain121(ICollection<AppUserRole> p142, ICollection<AppUserRoleReadModel> p143)
        {
            if (p142 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p142.Count);
            
            IEnumerator<AppUserRole> enumerator = p142.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(funcMain122(item));
            }
            return result;
            
        }
        
        private static ICollection<AppRoleClaimReadModel> funcMain132(ICollection<AppRoleClaim> p154, ICollection<AppRoleClaimReadModel> p155)
        {
            if (p154 == null)
            {
                return null;
            }
            ICollection<AppRoleClaimReadModel> result = new List<AppRoleClaimReadModel>(p154.Count);
            
            IEnumerator<AppRoleClaim> enumerator = p154.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRoleClaim item = enumerator.Current;
                result.Add(item == null ? null : new AppRoleClaimReadModel()
                {
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Id = item.Id,
                    RoleId = item.RoleId,
                    ClaimType = item.ClaimType,
                    ClaimValue = item.ClaimValue
                });
            }
            return result;
            
        }
        
        private static ICollection<AppAccessControlEntryReadModel> funcMain133(ICollection<AppAccessControlEntry> p156, ICollection<AppAccessControlEntryReadModel> p157)
        {
            if (p156 == null)
            {
                return null;
            }
            ICollection<AppAccessControlEntryReadModel> result = new List<AppAccessControlEntryReadModel>(p156.Count);
            
            IEnumerator<AppAccessControlEntry> enumerator = p156.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppAccessControlEntry item = enumerator.Current;
                result.Add(funcMain134(item));
            }
            return result;
            
        }
        
        private static AppAccessControlEntryReadModel funcMain6(AppAccessControlEntry p7)
        {
            return p7 == null ? null : new AppAccessControlEntryReadModel()
            {
                ResourcePattern = p7.ResourcePattern,
                PermissionPattern = p7.PermissionPattern,
                FeatureId = p7.FeatureId,
                Feature = funcMain7(p7.Feature),
                AppRoles = funcMain9(p7.AppRoles),
                AppUsers = funcMain13(p7.AppUsers),
                AppResource = p7.AppResource == null ? null : new AppResourceReadModel()
                {
                    Url = p7.AppResource.Url,
                    Description = p7.AppResource.Description,
                    ResourceType = p7.AppResource.ResourceType,
                    AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p7.AppResource.AccessControlEntries),
                    Id = p7.AppResource.Id,
                    CreatedBy = p7.AppResource.CreatedBy,
                    CreatedDate = p7.AppResource.CreatedDate,
                    ModifiedBy = p7.AppResource.ModifiedBy,
                    ModifiedDate = p7.AppResource.ModifiedDate,
                    IsDeleted = p7.AppResource.IsDeleted,
                    DeletedBy = p7.AppResource.DeletedBy,
                    DeletedDate = p7.AppResource.DeletedDate
                },
                ResourceId = p7.ResourceId,
                Id = p7.Id,
                CreatedBy = p7.CreatedBy,
                CreatedDate = p7.CreatedDate,
                ModifiedBy = p7.ModifiedBy,
                ModifiedDate = p7.ModifiedDate,
                IsDeleted = p7.IsDeleted,
                DeletedBy = p7.DeletedBy,
                DeletedDate = p7.DeletedDate
            };
        }
        
        private static AppAccessControlEntryReadModel funcMain18(AppAccessControlEntry p19)
        {
            return p19 == null ? null : new AppAccessControlEntryReadModel()
            {
                ResourcePattern = p19.ResourcePattern,
                PermissionPattern = p19.PermissionPattern,
                FeatureId = p19.FeatureId,
                Feature = funcMain19(p19.Feature),
                AppRoles = funcMain21(p19.AppRoles),
                AppUsers = funcMain22(p19.AppUsers),
                AppResource = p19.AppResource == null ? null : new AppResourceReadModel()
                {
                    Url = p19.AppResource.Url,
                    Description = p19.AppResource.Description,
                    ResourceType = p19.AppResource.ResourceType,
                    AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p19.AppResource.AccessControlEntries),
                    Id = p19.AppResource.Id,
                    CreatedBy = p19.AppResource.CreatedBy,
                    CreatedDate = p19.AppResource.CreatedDate,
                    ModifiedBy = p19.AppResource.ModifiedBy,
                    ModifiedDate = p19.AppResource.ModifiedDate,
                    IsDeleted = p19.AppResource.IsDeleted,
                    DeletedBy = p19.AppResource.DeletedBy,
                    DeletedDate = p19.AppResource.DeletedDate
                },
                ResourceId = p19.ResourceId,
                Id = p19.Id,
                CreatedBy = p19.CreatedBy,
                CreatedDate = p19.CreatedDate,
                ModifiedBy = p19.ModifiedBy,
                ModifiedDate = p19.ModifiedDate,
                IsDeleted = p19.IsDeleted,
                DeletedBy = p19.DeletedBy,
                DeletedDate = p19.DeletedDate
            };
        }
        
        private static AppAccessControlEntryReadModel funcMain32(AppAccessControlEntry p40)
        {
            return p40 == null ? null : new AppAccessControlEntryReadModel()
            {
                ResourcePattern = p40.ResourcePattern,
                PermissionPattern = p40.PermissionPattern,
                FeatureId = p40.FeatureId,
                Feature = funcMain33(p40.Feature),
                AppRoles = funcMain35(p40.AppRoles),
                AppUsers = funcMain39(p40.AppUsers),
                AppResource = p40.AppResource == null ? null : new AppResourceReadModel()
                {
                    Url = p40.AppResource.Url,
                    Description = p40.AppResource.Description,
                    ResourceType = p40.AppResource.ResourceType,
                    AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p40.AppResource.AccessControlEntries),
                    Id = p40.AppResource.Id,
                    CreatedBy = p40.AppResource.CreatedBy,
                    CreatedDate = p40.AppResource.CreatedDate,
                    ModifiedBy = p40.AppResource.ModifiedBy,
                    ModifiedDate = p40.AppResource.ModifiedDate,
                    IsDeleted = p40.AppResource.IsDeleted,
                    DeletedBy = p40.AppResource.DeletedBy,
                    DeletedDate = p40.AppResource.DeletedDate
                },
                ResourceId = p40.ResourceId,
                Id = p40.Id,
                CreatedBy = p40.CreatedBy,
                CreatedDate = p40.CreatedDate,
                ModifiedBy = p40.ModifiedBy,
                ModifiedDate = p40.ModifiedDate,
                IsDeleted = p40.IsDeleted,
                DeletedBy = p40.DeletedBy,
                DeletedDate = p40.DeletedDate
            };
        }
        
        private static AppAccessControlEntryReadModel funcMain44(AppAccessControlEntry p56)
        {
            return p56 == null ? null : new AppAccessControlEntryReadModel()
            {
                ResourcePattern = p56.ResourcePattern,
                PermissionPattern = p56.PermissionPattern,
                FeatureId = p56.FeatureId,
                Feature = funcMain45(p56.Feature),
                AppRoles = funcMain47(p56.AppRoles),
                AppUsers = funcMain48(p56.AppUsers),
                AppResource = p56.AppResource == null ? null : new AppResourceReadModel()
                {
                    Url = p56.AppResource.Url,
                    Description = p56.AppResource.Description,
                    ResourceType = p56.AppResource.ResourceType,
                    AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p56.AppResource.AccessControlEntries),
                    Id = p56.AppResource.Id,
                    CreatedBy = p56.AppResource.CreatedBy,
                    CreatedDate = p56.AppResource.CreatedDate,
                    ModifiedBy = p56.AppResource.ModifiedBy,
                    ModifiedDate = p56.AppResource.ModifiedDate,
                    IsDeleted = p56.AppResource.IsDeleted,
                    DeletedBy = p56.AppResource.DeletedBy,
                    DeletedDate = p56.AppResource.DeletedDate
                },
                ResourceId = p56.ResourceId,
                Id = p56.Id,
                CreatedBy = p56.CreatedBy,
                CreatedDate = p56.CreatedDate,
                ModifiedBy = p56.ModifiedBy,
                ModifiedDate = p56.ModifiedDate,
                IsDeleted = p56.IsDeleted,
                DeletedBy = p56.DeletedBy,
                DeletedDate = p56.DeletedDate
            };
        }
        
        private static AppUserRoleReadModel funcMain55(AppUserRole p68)
        {
            return p68 == null ? null : new AppUserRoleReadModel()
            {
                AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(p68.AppUser),
                AppRole = funcMain56(p68.AppRole),
                Hash = p68.Hash,
                CreatedBy = p68.CreatedBy,
                CreatedDate = p68.CreatedDate,
                ModifiedBy = p68.ModifiedBy,
                ModifiedDate = p68.ModifiedDate,
                IsDeleted = p68.IsDeleted,
                DeletedBy = p68.DeletedBy,
                DeletedDate = p68.DeletedDate,
                UserId = p68.UserId,
                RoleId = p68.RoleId
            };
        }
        
        private static AppAccessControlEntryReadModel funcMain67(AppAccessControlEntry p80)
        {
            return p80 == null ? null : new AppAccessControlEntryReadModel()
            {
                ResourcePattern = p80.ResourcePattern,
                PermissionPattern = p80.PermissionPattern,
                FeatureId = p80.FeatureId,
                Feature = funcMain68(p80.Feature),
                AppRoles = funcMain70(p80.AppRoles),
                AppUsers = funcMain74(p80.AppUsers),
                AppResource = p80.AppResource == null ? null : new AppResourceReadModel()
                {
                    Url = p80.AppResource.Url,
                    Description = p80.AppResource.Description,
                    ResourceType = p80.AppResource.ResourceType,
                    AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p80.AppResource.AccessControlEntries),
                    Id = p80.AppResource.Id,
                    CreatedBy = p80.AppResource.CreatedBy,
                    CreatedDate = p80.AppResource.CreatedDate,
                    ModifiedBy = p80.AppResource.ModifiedBy,
                    ModifiedDate = p80.AppResource.ModifiedDate,
                    IsDeleted = p80.AppResource.IsDeleted,
                    DeletedBy = p80.AppResource.DeletedBy,
                    DeletedDate = p80.AppResource.DeletedDate
                },
                ResourceId = p80.ResourceId,
                Id = p80.Id,
                CreatedBy = p80.CreatedBy,
                CreatedDate = p80.CreatedDate,
                ModifiedBy = p80.ModifiedBy,
                ModifiedDate = p80.ModifiedDate,
                IsDeleted = p80.IsDeleted,
                DeletedBy = p80.DeletedBy,
                DeletedDate = p80.DeletedDate
            };
        }
        
        private static AppUserRoleReadModel funcMain77(AppUserRole p90)
        {
            return p90 == null ? null : new AppUserRoleReadModel()
            {
                AppUser = funcMain78(p90.AppUser),
                AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(p90.AppRole),
                Hash = p90.Hash,
                CreatedBy = p90.CreatedBy,
                CreatedDate = p90.CreatedDate,
                ModifiedBy = p90.ModifiedBy,
                ModifiedDate = p90.ModifiedDate,
                IsDeleted = p90.IsDeleted,
                DeletedBy = p90.DeletedBy,
                DeletedDate = p90.DeletedDate,
                UserId = p90.UserId,
                RoleId = p90.RoleId
            };
        }
        
        private static AppAccessControlEntryReadModel funcMain89(AppAccessControlEntry p102)
        {
            return p102 == null ? null : new AppAccessControlEntryReadModel()
            {
                ResourcePattern = p102.ResourcePattern,
                PermissionPattern = p102.PermissionPattern,
                FeatureId = p102.FeatureId,
                Feature = funcMain90(p102.Feature),
                AppRoles = funcMain92(p102.AppRoles),
                AppUsers = funcMain93(p102.AppUsers),
                AppResource = p102.AppResource == null ? null : new AppResourceReadModel()
                {
                    Url = p102.AppResource.Url,
                    Description = p102.AppResource.Description,
                    ResourceType = p102.AppResource.ResourceType,
                    AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p102.AppResource.AccessControlEntries),
                    Id = p102.AppResource.Id,
                    CreatedBy = p102.AppResource.CreatedBy,
                    CreatedDate = p102.AppResource.CreatedDate,
                    ModifiedBy = p102.AppResource.ModifiedBy,
                    ModifiedDate = p102.AppResource.ModifiedDate,
                    IsDeleted = p102.AppResource.IsDeleted,
                    DeletedBy = p102.AppResource.DeletedBy,
                    DeletedDate = p102.AppResource.DeletedDate
                },
                ResourceId = p102.ResourceId,
                Id = p102.Id,
                CreatedBy = p102.CreatedBy,
                CreatedDate = p102.CreatedDate,
                ModifiedBy = p102.ModifiedBy,
                ModifiedDate = p102.ModifiedDate,
                IsDeleted = p102.IsDeleted,
                DeletedBy = p102.DeletedBy,
                DeletedDate = p102.DeletedDate
            };
        }
        
        private static AppUserRoleReadModel funcMain100(AppUserRole p117)
        {
            return p117 == null ? null : new AppUserRoleReadModel()
            {
                AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(p117.AppUser),
                AppRole = funcMain101(p117.AppRole),
                Hash = p117.Hash,
                CreatedBy = p117.CreatedBy,
                CreatedDate = p117.CreatedDate,
                ModifiedBy = p117.ModifiedBy,
                ModifiedDate = p117.ModifiedDate,
                IsDeleted = p117.IsDeleted,
                DeletedBy = p117.DeletedBy,
                DeletedDate = p117.DeletedDate,
                UserId = p117.UserId,
                RoleId = p117.RoleId
            };
        }
        
        private static AppAccessControlEntryReadModel funcMain112(AppAccessControlEntry p132)
        {
            return p132 == null ? null : new AppAccessControlEntryReadModel()
            {
                ResourcePattern = p132.ResourcePattern,
                PermissionPattern = p132.PermissionPattern,
                FeatureId = p132.FeatureId,
                Feature = funcMain113(p132.Feature),
                AppRoles = funcMain115(p132.AppRoles),
                AppUsers = funcMain119(p132.AppUsers),
                AppResource = p132.AppResource == null ? null : new AppResourceReadModel()
                {
                    Url = p132.AppResource.Url,
                    Description = p132.AppResource.Description,
                    ResourceType = p132.AppResource.ResourceType,
                    AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p132.AppResource.AccessControlEntries),
                    Id = p132.AppResource.Id,
                    CreatedBy = p132.AppResource.CreatedBy,
                    CreatedDate = p132.AppResource.CreatedDate,
                    ModifiedBy = p132.AppResource.ModifiedBy,
                    ModifiedDate = p132.AppResource.ModifiedDate,
                    IsDeleted = p132.AppResource.IsDeleted,
                    DeletedBy = p132.AppResource.DeletedBy,
                    DeletedDate = p132.AppResource.DeletedDate
                },
                ResourceId = p132.ResourceId,
                Id = p132.Id,
                CreatedBy = p132.CreatedBy,
                CreatedDate = p132.CreatedDate,
                ModifiedBy = p132.ModifiedBy,
                ModifiedDate = p132.ModifiedDate,
                IsDeleted = p132.IsDeleted,
                DeletedBy = p132.DeletedBy,
                DeletedDate = p132.DeletedDate
            };
        }
        
        private static AppUserRoleReadModel funcMain122(AppUserRole p144)
        {
            return p144 == null ? null : new AppUserRoleReadModel()
            {
                AppUser = funcMain123(p144.AppUser),
                AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(p144.AppRole),
                Hash = p144.Hash,
                CreatedBy = p144.CreatedBy,
                CreatedDate = p144.CreatedDate,
                ModifiedBy = p144.ModifiedBy,
                ModifiedDate = p144.ModifiedDate,
                IsDeleted = p144.IsDeleted,
                DeletedBy = p144.DeletedBy,
                DeletedDate = p144.DeletedDate,
                UserId = p144.UserId,
                RoleId = p144.RoleId
            };
        }
        
        private static AppAccessControlEntryReadModel funcMain134(AppAccessControlEntry p158)
        {
            return p158 == null ? null : new AppAccessControlEntryReadModel()
            {
                ResourcePattern = p158.ResourcePattern,
                PermissionPattern = p158.PermissionPattern,
                FeatureId = p158.FeatureId,
                Feature = funcMain135(p158.Feature),
                AppRoles = funcMain137(p158.AppRoles),
                AppUsers = funcMain138(p158.AppUsers),
                AppResource = p158.AppResource == null ? null : new AppResourceReadModel()
                {
                    Url = p158.AppResource.Url,
                    Description = p158.AppResource.Description,
                    ResourceType = p158.AppResource.ResourceType,
                    AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p158.AppResource.AccessControlEntries),
                    Id = p158.AppResource.Id,
                    CreatedBy = p158.AppResource.CreatedBy,
                    CreatedDate = p158.AppResource.CreatedDate,
                    ModifiedBy = p158.AppResource.ModifiedBy,
                    ModifiedDate = p158.AppResource.ModifiedDate,
                    IsDeleted = p158.AppResource.IsDeleted,
                    DeletedBy = p158.AppResource.DeletedBy,
                    DeletedDate = p158.AppResource.DeletedDate
                },
                ResourceId = p158.ResourceId,
                Id = p158.Id,
                CreatedBy = p158.CreatedBy,
                CreatedDate = p158.CreatedDate,
                ModifiedBy = p158.ModifiedBy,
                ModifiedDate = p158.ModifiedDate,
                IsDeleted = p158.IsDeleted,
                DeletedBy = p158.DeletedBy,
                DeletedDate = p158.DeletedDate
            };
        }
        
        private static AppFeatureReadModel funcMain7(AppFeature p8)
        {
            return p8 == null ? null : new AppFeatureReadModel()
            {
                Name = p8.Name,
                Description = p8.Description,
                IsEnabled = p8.IsEnabled,
                Scope = p8.Scope,
                FeatureFlags = funcMain8(p8.FeatureFlags),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p8.AccessControlEntries),
                Id = p8.Id,
                CreatedBy = p8.CreatedBy,
                CreatedDate = p8.CreatedDate,
                ModifiedBy = p8.ModifiedBy,
                ModifiedDate = p8.ModifiedDate,
                IsDeleted = p8.IsDeleted,
                DeletedBy = p8.DeletedBy,
                DeletedDate = p8.DeletedDate
            };
        }
        
        private static ICollection<AppRoleReadModel> funcMain9(ICollection<AppRole> p10)
        {
            if (p10 == null)
            {
                return null;
            }
            ICollection<AppRoleReadModel> result = new List<AppRoleReadModel>(p10.Count);
            
            IEnumerator<AppRole> enumerator = p10.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRole item = enumerator.Current;
                result.Add(funcMain10(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserReadModel> funcMain13(ICollection<AppUser> p14)
        {
            if (p14 == null)
            {
                return null;
            }
            ICollection<AppUserReadModel> result = new List<AppUserReadModel>(p14.Count);
            
            IEnumerator<AppUser> enumerator = p14.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUser item = enumerator.Current;
                result.Add(TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static AppFeatureReadModel funcMain19(AppFeature p20)
        {
            return p20 == null ? null : new AppFeatureReadModel()
            {
                Name = p20.Name,
                Description = p20.Description,
                IsEnabled = p20.IsEnabled,
                Scope = p20.Scope,
                FeatureFlags = funcMain20(p20.FeatureFlags),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p20.AccessControlEntries),
                Id = p20.Id,
                CreatedBy = p20.CreatedBy,
                CreatedDate = p20.CreatedDate,
                ModifiedBy = p20.ModifiedBy,
                ModifiedDate = p20.ModifiedDate,
                IsDeleted = p20.IsDeleted,
                DeletedBy = p20.DeletedBy,
                DeletedDate = p20.DeletedDate
            };
        }
        
        private static ICollection<AppRoleReadModel> funcMain21(ICollection<AppRole> p22)
        {
            if (p22 == null)
            {
                return null;
            }
            ICollection<AppRoleReadModel> result = new List<AppRoleReadModel>(p22.Count);
            
            IEnumerator<AppRole> enumerator = p22.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRole item = enumerator.Current;
                result.Add(TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserReadModel> funcMain22(ICollection<AppUser> p23)
        {
            if (p23 == null)
            {
                return null;
            }
            ICollection<AppUserReadModel> result = new List<AppUserReadModel>(p23.Count);
            
            IEnumerator<AppUser> enumerator = p23.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUser item = enumerator.Current;
                result.Add(funcMain23(item));
            }
            return result;
            
        }
        
        private static AppFeatureReadModel funcMain33(AppFeature p41)
        {
            return p41 == null ? null : new AppFeatureReadModel()
            {
                Name = p41.Name,
                Description = p41.Description,
                IsEnabled = p41.IsEnabled,
                Scope = p41.Scope,
                FeatureFlags = funcMain34(p41.FeatureFlags),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p41.AccessControlEntries),
                Id = p41.Id,
                CreatedBy = p41.CreatedBy,
                CreatedDate = p41.CreatedDate,
                ModifiedBy = p41.ModifiedBy,
                ModifiedDate = p41.ModifiedDate,
                IsDeleted = p41.IsDeleted,
                DeletedBy = p41.DeletedBy,
                DeletedDate = p41.DeletedDate
            };
        }
        
        private static ICollection<AppRoleReadModel> funcMain35(ICollection<AppRole> p43)
        {
            if (p43 == null)
            {
                return null;
            }
            ICollection<AppRoleReadModel> result = new List<AppRoleReadModel>(p43.Count);
            
            IEnumerator<AppRole> enumerator = p43.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRole item = enumerator.Current;
                result.Add(funcMain36(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserReadModel> funcMain39(ICollection<AppUser> p47)
        {
            if (p47 == null)
            {
                return null;
            }
            ICollection<AppUserReadModel> result = new List<AppUserReadModel>(p47.Count);
            
            IEnumerator<AppUser> enumerator = p47.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUser item = enumerator.Current;
                result.Add(TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static AppFeatureReadModel funcMain45(AppFeature p57)
        {
            return p57 == null ? null : new AppFeatureReadModel()
            {
                Name = p57.Name,
                Description = p57.Description,
                IsEnabled = p57.IsEnabled,
                Scope = p57.Scope,
                FeatureFlags = funcMain46(p57.FeatureFlags),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p57.AccessControlEntries),
                Id = p57.Id,
                CreatedBy = p57.CreatedBy,
                CreatedDate = p57.CreatedDate,
                ModifiedBy = p57.ModifiedBy,
                ModifiedDate = p57.ModifiedDate,
                IsDeleted = p57.IsDeleted,
                DeletedBy = p57.DeletedBy,
                DeletedDate = p57.DeletedDate
            };
        }
        
        private static ICollection<AppRoleReadModel> funcMain47(ICollection<AppRole> p59)
        {
            if (p59 == null)
            {
                return null;
            }
            ICollection<AppRoleReadModel> result = new List<AppRoleReadModel>(p59.Count);
            
            IEnumerator<AppRole> enumerator = p59.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRole item = enumerator.Current;
                result.Add(TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserReadModel> funcMain48(ICollection<AppUser> p60)
        {
            if (p60 == null)
            {
                return null;
            }
            ICollection<AppUserReadModel> result = new List<AppUserReadModel>(p60.Count);
            
            IEnumerator<AppUser> enumerator = p60.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUser item = enumerator.Current;
                result.Add(funcMain49(item));
            }
            return result;
            
        }
        
        private static AppRoleReadModel funcMain56(AppRole p69)
        {
            return p69 == null ? null : new AppRoleReadModel()
            {
                CreatedBy = p69.CreatedBy,
                CreatedDate = p69.CreatedDate,
                ModifiedBy = p69.ModifiedBy,
                ModifiedDate = p69.ModifiedDate,
                IsDeleted = p69.IsDeleted,
                DeletedBy = p69.DeletedBy,
                DeletedDate = p69.DeletedDate,
                AppUserRoles = TypeAdapter<ICollection<AppUserRole>, ICollection<AppUserRoleReadModel>>.Map.Invoke(p69.AppUserRoles),
                AppRoleClaims = funcMain57(p69.AppRoleClaims),
                AccessControlEntries = funcMain58(p69.AccessControlEntries),
                Hash = p69.Hash,
                Id = p69.Id,
                Name = p69.Name,
                NormalizedName = p69.NormalizedName,
                ConcurrencyStamp = p69.ConcurrencyStamp
            };
        }
        
        private static AppFeatureReadModel funcMain68(AppFeature p81)
        {
            return p81 == null ? null : new AppFeatureReadModel()
            {
                Name = p81.Name,
                Description = p81.Description,
                IsEnabled = p81.IsEnabled,
                Scope = p81.Scope,
                FeatureFlags = funcMain69(p81.FeatureFlags),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p81.AccessControlEntries),
                Id = p81.Id,
                CreatedBy = p81.CreatedBy,
                CreatedDate = p81.CreatedDate,
                ModifiedBy = p81.ModifiedBy,
                ModifiedDate = p81.ModifiedDate,
                IsDeleted = p81.IsDeleted,
                DeletedBy = p81.DeletedBy,
                DeletedDate = p81.DeletedDate
            };
        }
        
        private static ICollection<AppRoleReadModel> funcMain70(ICollection<AppRole> p83)
        {
            if (p83 == null)
            {
                return null;
            }
            ICollection<AppRoleReadModel> result = new List<AppRoleReadModel>(p83.Count);
            
            IEnumerator<AppRole> enumerator = p83.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRole item = enumerator.Current;
                result.Add(funcMain71(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserReadModel> funcMain74(ICollection<AppUser> p87)
        {
            if (p87 == null)
            {
                return null;
            }
            ICollection<AppUserReadModel> result = new List<AppUserReadModel>(p87.Count);
            
            IEnumerator<AppUser> enumerator = p87.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUser item = enumerator.Current;
                result.Add(TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static AppUserReadModel funcMain78(AppUser p91)
        {
            return p91 == null ? null : new AppUserReadModel()
            {
                Hash = p91.Hash,
                FirstName = p91.FirstName,
                LastName = p91.LastName,
                Mobile = p91.Mobile,
                CountryCode = p91.CountryCode,
                TwoFactorMethod = p91.TwoFactorMethod,
                CreatedBy = p91.CreatedBy,
                CreatedDate = p91.CreatedDate,
                ModifiedBy = p91.ModifiedBy,
                ModifiedDate = p91.ModifiedDate,
                IsDeleted = p91.IsDeleted,
                DeletedBy = p91.DeletedBy,
                DeletedDate = p91.DeletedDate,
                MembershipType = p91.MembershipType,
                UserRoles = TypeAdapter<ICollection<AppUserRole>, ICollection<AppUserRoleReadModel>>.Map.Invoke(p91.UserRoles),
                UserTokens = funcMain79(p91.UserTokens),
                RefreshTokens = funcMain80(p91.RefreshTokens),
                AccessControlEntries = funcMain81(p91.AccessControlEntries),
                Id = p91.Id,
                UserName = p91.UserName,
                NormalizedUserName = p91.NormalizedUserName,
                Email = p91.Email,
                NormalizedEmail = p91.NormalizedEmail,
                EmailConfirmed = p91.EmailConfirmed,
                PasswordHash = p91.PasswordHash,
                SecurityStamp = p91.SecurityStamp,
                ConcurrencyStamp = p91.ConcurrencyStamp,
                PhoneNumber = p91.PhoneNumber,
                PhoneNumberConfirmed = p91.PhoneNumberConfirmed,
                TwoFactorEnabled = p91.TwoFactorEnabled,
                LockoutEnd = p91.LockoutEnd,
                LockoutEnabled = p91.LockoutEnabled,
                AccessFailedCount = p91.AccessFailedCount
            };
        }
        
        private static AppFeatureReadModel funcMain90(AppFeature p103)
        {
            return p103 == null ? null : new AppFeatureReadModel()
            {
                Name = p103.Name,
                Description = p103.Description,
                IsEnabled = p103.IsEnabled,
                Scope = p103.Scope,
                FeatureFlags = funcMain91(p103.FeatureFlags),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p103.AccessControlEntries),
                Id = p103.Id,
                CreatedBy = p103.CreatedBy,
                CreatedDate = p103.CreatedDate,
                ModifiedBy = p103.ModifiedBy,
                ModifiedDate = p103.ModifiedDate,
                IsDeleted = p103.IsDeleted,
                DeletedBy = p103.DeletedBy,
                DeletedDate = p103.DeletedDate
            };
        }
        
        private static ICollection<AppRoleReadModel> funcMain92(ICollection<AppRole> p105)
        {
            if (p105 == null)
            {
                return null;
            }
            ICollection<AppRoleReadModel> result = new List<AppRoleReadModel>(p105.Count);
            
            IEnumerator<AppRole> enumerator = p105.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRole item = enumerator.Current;
                result.Add(TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserReadModel> funcMain93(ICollection<AppUser> p106)
        {
            if (p106 == null)
            {
                return null;
            }
            ICollection<AppUserReadModel> result = new List<AppUserReadModel>(p106.Count);
            
            IEnumerator<AppUser> enumerator = p106.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUser item = enumerator.Current;
                result.Add(funcMain94(item));
            }
            return result;
            
        }
        
        private static AppRoleReadModel funcMain101(AppRole p118)
        {
            return p118 == null ? null : new AppRoleReadModel()
            {
                CreatedBy = p118.CreatedBy,
                CreatedDate = p118.CreatedDate,
                ModifiedBy = p118.ModifiedBy,
                ModifiedDate = p118.ModifiedDate,
                IsDeleted = p118.IsDeleted,
                DeletedBy = p118.DeletedBy,
                DeletedDate = p118.DeletedDate,
                AppUserRoles = TypeAdapter<ICollection<AppUserRole>, ICollection<AppUserRoleReadModel>>.Map.Invoke(p118.AppUserRoles),
                AppRoleClaims = funcMain102(p118.AppRoleClaims),
                AccessControlEntries = funcMain103(p118.AccessControlEntries),
                Hash = p118.Hash,
                Id = p118.Id,
                Name = p118.Name,
                NormalizedName = p118.NormalizedName,
                ConcurrencyStamp = p118.ConcurrencyStamp
            };
        }
        
        private static AppFeatureReadModel funcMain113(AppFeature p133)
        {
            return p133 == null ? null : new AppFeatureReadModel()
            {
                Name = p133.Name,
                Description = p133.Description,
                IsEnabled = p133.IsEnabled,
                Scope = p133.Scope,
                FeatureFlags = funcMain114(p133.FeatureFlags),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p133.AccessControlEntries),
                Id = p133.Id,
                CreatedBy = p133.CreatedBy,
                CreatedDate = p133.CreatedDate,
                ModifiedBy = p133.ModifiedBy,
                ModifiedDate = p133.ModifiedDate,
                IsDeleted = p133.IsDeleted,
                DeletedBy = p133.DeletedBy,
                DeletedDate = p133.DeletedDate
            };
        }
        
        private static ICollection<AppRoleReadModel> funcMain115(ICollection<AppRole> p135)
        {
            if (p135 == null)
            {
                return null;
            }
            ICollection<AppRoleReadModel> result = new List<AppRoleReadModel>(p135.Count);
            
            IEnumerator<AppRole> enumerator = p135.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRole item = enumerator.Current;
                result.Add(funcMain116(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserReadModel> funcMain119(ICollection<AppUser> p139)
        {
            if (p139 == null)
            {
                return null;
            }
            ICollection<AppUserReadModel> result = new List<AppUserReadModel>(p139.Count);
            
            IEnumerator<AppUser> enumerator = p139.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUser item = enumerator.Current;
                result.Add(TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static AppUserReadModel funcMain123(AppUser p145)
        {
            return p145 == null ? null : new AppUserReadModel()
            {
                Hash = p145.Hash,
                FirstName = p145.FirstName,
                LastName = p145.LastName,
                Mobile = p145.Mobile,
                CountryCode = p145.CountryCode,
                TwoFactorMethod = p145.TwoFactorMethod,
                CreatedBy = p145.CreatedBy,
                CreatedDate = p145.CreatedDate,
                ModifiedBy = p145.ModifiedBy,
                ModifiedDate = p145.ModifiedDate,
                IsDeleted = p145.IsDeleted,
                DeletedBy = p145.DeletedBy,
                DeletedDate = p145.DeletedDate,
                MembershipType = p145.MembershipType,
                UserRoles = TypeAdapter<ICollection<AppUserRole>, ICollection<AppUserRoleReadModel>>.Map.Invoke(p145.UserRoles),
                UserTokens = funcMain124(p145.UserTokens),
                RefreshTokens = funcMain125(p145.RefreshTokens),
                AccessControlEntries = funcMain126(p145.AccessControlEntries),
                Id = p145.Id,
                UserName = p145.UserName,
                NormalizedUserName = p145.NormalizedUserName,
                Email = p145.Email,
                NormalizedEmail = p145.NormalizedEmail,
                EmailConfirmed = p145.EmailConfirmed,
                PasswordHash = p145.PasswordHash,
                SecurityStamp = p145.SecurityStamp,
                ConcurrencyStamp = p145.ConcurrencyStamp,
                PhoneNumber = p145.PhoneNumber,
                PhoneNumberConfirmed = p145.PhoneNumberConfirmed,
                TwoFactorEnabled = p145.TwoFactorEnabled,
                LockoutEnd = p145.LockoutEnd,
                LockoutEnabled = p145.LockoutEnabled,
                AccessFailedCount = p145.AccessFailedCount
            };
        }
        
        private static AppFeatureReadModel funcMain135(AppFeature p159)
        {
            return p159 == null ? null : new AppFeatureReadModel()
            {
                Name = p159.Name,
                Description = p159.Description,
                IsEnabled = p159.IsEnabled,
                Scope = p159.Scope,
                FeatureFlags = funcMain136(p159.FeatureFlags),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p159.AccessControlEntries),
                Id = p159.Id,
                CreatedBy = p159.CreatedBy,
                CreatedDate = p159.CreatedDate,
                ModifiedBy = p159.ModifiedBy,
                ModifiedDate = p159.ModifiedDate,
                IsDeleted = p159.IsDeleted,
                DeletedBy = p159.DeletedBy,
                DeletedDate = p159.DeletedDate
            };
        }
        
        private static ICollection<AppRoleReadModel> funcMain137(ICollection<AppRole> p161)
        {
            if (p161 == null)
            {
                return null;
            }
            ICollection<AppRoleReadModel> result = new List<AppRoleReadModel>(p161.Count);
            
            IEnumerator<AppRole> enumerator = p161.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRole item = enumerator.Current;
                result.Add(TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserReadModel> funcMain138(ICollection<AppUser> p162)
        {
            if (p162 == null)
            {
                return null;
            }
            ICollection<AppUserReadModel> result = new List<AppUserReadModel>(p162.Count);
            
            IEnumerator<AppUser> enumerator = p162.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUser item = enumerator.Current;
                result.Add(funcMain139(item));
            }
            return result;
            
        }
        
        private static ICollection<AppFeatureFlagReadModel> funcMain8(ICollection<AppFeatureFlag> p9)
        {
            if (p9 == null)
            {
                return null;
            }
            ICollection<AppFeatureFlagReadModel> result = new List<AppFeatureFlagReadModel>(p9.Count);
            
            IEnumerator<AppFeatureFlag> enumerator = p9.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppFeatureFlag item = enumerator.Current;
                result.Add(item == null ? null : new AppFeatureFlagReadModel()
                {
                    FeatureId = item.FeatureId,
                    ScopeIdentifier = item.ScopeIdentifier,
                    IsEnabled = item.IsEnabled,
                    Feature = TypeAdapter<AppFeature, AppFeatureReadModel>.Map.Invoke(item.Feature),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static AppRoleReadModel funcMain10(AppRole p11)
        {
            return p11 == null ? null : new AppRoleReadModel()
            {
                CreatedBy = p11.CreatedBy,
                CreatedDate = p11.CreatedDate,
                ModifiedBy = p11.ModifiedBy,
                ModifiedDate = p11.ModifiedDate,
                IsDeleted = p11.IsDeleted,
                DeletedBy = p11.DeletedBy,
                DeletedDate = p11.DeletedDate,
                AppUserRoles = funcMain11(p11.AppUserRoles),
                AppRoleClaims = funcMain12(p11.AppRoleClaims),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p11.AccessControlEntries),
                Hash = p11.Hash,
                Id = p11.Id,
                Name = p11.Name,
                NormalizedName = p11.NormalizedName,
                ConcurrencyStamp = p11.ConcurrencyStamp
            };
        }
        
        private static ICollection<AppFeatureFlagReadModel> funcMain20(ICollection<AppFeatureFlag> p21)
        {
            if (p21 == null)
            {
                return null;
            }
            ICollection<AppFeatureFlagReadModel> result = new List<AppFeatureFlagReadModel>(p21.Count);
            
            IEnumerator<AppFeatureFlag> enumerator = p21.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppFeatureFlag item = enumerator.Current;
                result.Add(item == null ? null : new AppFeatureFlagReadModel()
                {
                    FeatureId = item.FeatureId,
                    ScopeIdentifier = item.ScopeIdentifier,
                    IsEnabled = item.IsEnabled,
                    Feature = TypeAdapter<AppFeature, AppFeatureReadModel>.Map.Invoke(item.Feature),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static AppUserReadModel funcMain23(AppUser p24)
        {
            return p24 == null ? null : new AppUserReadModel()
            {
                Hash = p24.Hash,
                FirstName = p24.FirstName,
                LastName = p24.LastName,
                Mobile = p24.Mobile,
                CountryCode = p24.CountryCode,
                TwoFactorMethod = p24.TwoFactorMethod,
                CreatedBy = p24.CreatedBy,
                CreatedDate = p24.CreatedDate,
                ModifiedBy = p24.ModifiedBy,
                ModifiedDate = p24.ModifiedDate,
                IsDeleted = p24.IsDeleted,
                DeletedBy = p24.DeletedBy,
                DeletedDate = p24.DeletedDate,
                MembershipType = p24.MembershipType,
                UserRoles = funcMain24(p24.UserRoles),
                UserTokens = funcMain25(p24.UserTokens),
                RefreshTokens = funcMain26(p24.RefreshTokens),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p24.AccessControlEntries),
                Id = p24.Id,
                UserName = p24.UserName,
                NormalizedUserName = p24.NormalizedUserName,
                Email = p24.Email,
                NormalizedEmail = p24.NormalizedEmail,
                EmailConfirmed = p24.EmailConfirmed,
                PasswordHash = p24.PasswordHash,
                SecurityStamp = p24.SecurityStamp,
                ConcurrencyStamp = p24.ConcurrencyStamp,
                PhoneNumber = p24.PhoneNumber,
                PhoneNumberConfirmed = p24.PhoneNumberConfirmed,
                TwoFactorEnabled = p24.TwoFactorEnabled,
                LockoutEnd = p24.LockoutEnd,
                LockoutEnabled = p24.LockoutEnabled,
                AccessFailedCount = p24.AccessFailedCount
            };
        }
        
        private static ICollection<AppFeatureFlagReadModel> funcMain34(ICollection<AppFeatureFlag> p42)
        {
            if (p42 == null)
            {
                return null;
            }
            ICollection<AppFeatureFlagReadModel> result = new List<AppFeatureFlagReadModel>(p42.Count);
            
            IEnumerator<AppFeatureFlag> enumerator = p42.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppFeatureFlag item = enumerator.Current;
                result.Add(item == null ? null : new AppFeatureFlagReadModel()
                {
                    FeatureId = item.FeatureId,
                    ScopeIdentifier = item.ScopeIdentifier,
                    IsEnabled = item.IsEnabled,
                    Feature = TypeAdapter<AppFeature, AppFeatureReadModel>.Map.Invoke(item.Feature),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static AppRoleReadModel funcMain36(AppRole p44)
        {
            return p44 == null ? null : new AppRoleReadModel()
            {
                CreatedBy = p44.CreatedBy,
                CreatedDate = p44.CreatedDate,
                ModifiedBy = p44.ModifiedBy,
                ModifiedDate = p44.ModifiedDate,
                IsDeleted = p44.IsDeleted,
                DeletedBy = p44.DeletedBy,
                DeletedDate = p44.DeletedDate,
                AppUserRoles = funcMain37(p44.AppUserRoles),
                AppRoleClaims = funcMain38(p44.AppRoleClaims),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p44.AccessControlEntries),
                Hash = p44.Hash,
                Id = p44.Id,
                Name = p44.Name,
                NormalizedName = p44.NormalizedName,
                ConcurrencyStamp = p44.ConcurrencyStamp
            };
        }
        
        private static ICollection<AppFeatureFlagReadModel> funcMain46(ICollection<AppFeatureFlag> p58)
        {
            if (p58 == null)
            {
                return null;
            }
            ICollection<AppFeatureFlagReadModel> result = new List<AppFeatureFlagReadModel>(p58.Count);
            
            IEnumerator<AppFeatureFlag> enumerator = p58.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppFeatureFlag item = enumerator.Current;
                result.Add(item == null ? null : new AppFeatureFlagReadModel()
                {
                    FeatureId = item.FeatureId,
                    ScopeIdentifier = item.ScopeIdentifier,
                    IsEnabled = item.IsEnabled,
                    Feature = TypeAdapter<AppFeature, AppFeatureReadModel>.Map.Invoke(item.Feature),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static AppUserReadModel funcMain49(AppUser p61)
        {
            return p61 == null ? null : new AppUserReadModel()
            {
                Hash = p61.Hash,
                FirstName = p61.FirstName,
                LastName = p61.LastName,
                Mobile = p61.Mobile,
                CountryCode = p61.CountryCode,
                TwoFactorMethod = p61.TwoFactorMethod,
                CreatedBy = p61.CreatedBy,
                CreatedDate = p61.CreatedDate,
                ModifiedBy = p61.ModifiedBy,
                ModifiedDate = p61.ModifiedDate,
                IsDeleted = p61.IsDeleted,
                DeletedBy = p61.DeletedBy,
                DeletedDate = p61.DeletedDate,
                MembershipType = p61.MembershipType,
                UserRoles = funcMain50(p61.UserRoles),
                UserTokens = funcMain51(p61.UserTokens),
                RefreshTokens = funcMain52(p61.RefreshTokens),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p61.AccessControlEntries),
                Id = p61.Id,
                UserName = p61.UserName,
                NormalizedUserName = p61.NormalizedUserName,
                Email = p61.Email,
                NormalizedEmail = p61.NormalizedEmail,
                EmailConfirmed = p61.EmailConfirmed,
                PasswordHash = p61.PasswordHash,
                SecurityStamp = p61.SecurityStamp,
                ConcurrencyStamp = p61.ConcurrencyStamp,
                PhoneNumber = p61.PhoneNumber,
                PhoneNumberConfirmed = p61.PhoneNumberConfirmed,
                TwoFactorEnabled = p61.TwoFactorEnabled,
                LockoutEnd = p61.LockoutEnd,
                LockoutEnabled = p61.LockoutEnabled,
                AccessFailedCount = p61.AccessFailedCount
            };
        }
        
        private static ICollection<AppRoleClaimReadModel> funcMain57(ICollection<AppRoleClaim> p70)
        {
            if (p70 == null)
            {
                return null;
            }
            ICollection<AppRoleClaimReadModel> result = new List<AppRoleClaimReadModel>(p70.Count);
            
            IEnumerator<AppRoleClaim> enumerator = p70.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRoleClaim item = enumerator.Current;
                result.Add(item == null ? null : new AppRoleClaimReadModel()
                {
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Id = item.Id,
                    RoleId = item.RoleId,
                    ClaimType = item.ClaimType,
                    ClaimValue = item.ClaimValue
                });
            }
            return result;
            
        }
        
        private static ICollection<AppAccessControlEntryReadModel> funcMain58(ICollection<AppAccessControlEntry> p71)
        {
            if (p71 == null)
            {
                return null;
            }
            ICollection<AppAccessControlEntryReadModel> result = new List<AppAccessControlEntryReadModel>(p71.Count);
            
            IEnumerator<AppAccessControlEntry> enumerator = p71.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppAccessControlEntry item = enumerator.Current;
                result.Add(funcMain59(item));
            }
            return result;
            
        }
        
        private static ICollection<AppFeatureFlagReadModel> funcMain69(ICollection<AppFeatureFlag> p82)
        {
            if (p82 == null)
            {
                return null;
            }
            ICollection<AppFeatureFlagReadModel> result = new List<AppFeatureFlagReadModel>(p82.Count);
            
            IEnumerator<AppFeatureFlag> enumerator = p82.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppFeatureFlag item = enumerator.Current;
                result.Add(item == null ? null : new AppFeatureFlagReadModel()
                {
                    FeatureId = item.FeatureId,
                    ScopeIdentifier = item.ScopeIdentifier,
                    IsEnabled = item.IsEnabled,
                    Feature = TypeAdapter<AppFeature, AppFeatureReadModel>.Map.Invoke(item.Feature),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static AppRoleReadModel funcMain71(AppRole p84)
        {
            return p84 == null ? null : new AppRoleReadModel()
            {
                CreatedBy = p84.CreatedBy,
                CreatedDate = p84.CreatedDate,
                ModifiedBy = p84.ModifiedBy,
                ModifiedDate = p84.ModifiedDate,
                IsDeleted = p84.IsDeleted,
                DeletedBy = p84.DeletedBy,
                DeletedDate = p84.DeletedDate,
                AppUserRoles = funcMain72(p84.AppUserRoles),
                AppRoleClaims = funcMain73(p84.AppRoleClaims),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p84.AccessControlEntries),
                Hash = p84.Hash,
                Id = p84.Id,
                Name = p84.Name,
                NormalizedName = p84.NormalizedName,
                ConcurrencyStamp = p84.ConcurrencyStamp
            };
        }
        
        private static ICollection<AppUserTokenReadModel> funcMain79(ICollection<AppUserToken> p92)
        {
            if (p92 == null)
            {
                return null;
            }
            ICollection<AppUserTokenReadModel> result = new List<AppUserTokenReadModel>(p92.Count);
            
            IEnumerator<AppUserToken> enumerator = p92.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserToken item = enumerator.Current;
                result.Add(item == null ? null : new AppUserTokenReadModel()
                {
                    Token = item.Token,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    LoginProvider = item.LoginProvider,
                    Name = item.Name,
                    Value = item.Value
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRefreshTokenReadModel> funcMain80(ICollection<AppRefreshToken> p93)
        {
            if (p93 == null)
            {
                return null;
            }
            ICollection<AppRefreshTokenReadModel> result = new List<AppRefreshTokenReadModel>(p93.Count);
            
            IEnumerator<AppRefreshToken> enumerator = p93.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRefreshToken item = enumerator.Current;
                result.Add(item == null ? null : new AppRefreshTokenReadModel()
                {
                    UserId = item.UserId,
                    Token = item.Token,
                    JwtId = item.JwtId,
                    IsUsed = item.IsUsed,
                    IsRevoked = item.IsRevoked,
                    ExpiryDate = item.ExpiryDate,
                    Hash = item.Hash,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static ICollection<AppAccessControlEntryReadModel> funcMain81(ICollection<AppAccessControlEntry> p94)
        {
            if (p94 == null)
            {
                return null;
            }
            ICollection<AppAccessControlEntryReadModel> result = new List<AppAccessControlEntryReadModel>(p94.Count);
            
            IEnumerator<AppAccessControlEntry> enumerator = p94.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppAccessControlEntry item = enumerator.Current;
                result.Add(funcMain82(item));
            }
            return result;
            
        }
        
        private static ICollection<AppFeatureFlagReadModel> funcMain91(ICollection<AppFeatureFlag> p104)
        {
            if (p104 == null)
            {
                return null;
            }
            ICollection<AppFeatureFlagReadModel> result = new List<AppFeatureFlagReadModel>(p104.Count);
            
            IEnumerator<AppFeatureFlag> enumerator = p104.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppFeatureFlag item = enumerator.Current;
                result.Add(item == null ? null : new AppFeatureFlagReadModel()
                {
                    FeatureId = item.FeatureId,
                    ScopeIdentifier = item.ScopeIdentifier,
                    IsEnabled = item.IsEnabled,
                    Feature = TypeAdapter<AppFeature, AppFeatureReadModel>.Map.Invoke(item.Feature),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static AppUserReadModel funcMain94(AppUser p107)
        {
            return p107 == null ? null : new AppUserReadModel()
            {
                Hash = p107.Hash,
                FirstName = p107.FirstName,
                LastName = p107.LastName,
                Mobile = p107.Mobile,
                CountryCode = p107.CountryCode,
                TwoFactorMethod = p107.TwoFactorMethod,
                CreatedBy = p107.CreatedBy,
                CreatedDate = p107.CreatedDate,
                ModifiedBy = p107.ModifiedBy,
                ModifiedDate = p107.ModifiedDate,
                IsDeleted = p107.IsDeleted,
                DeletedBy = p107.DeletedBy,
                DeletedDate = p107.DeletedDate,
                MembershipType = p107.MembershipType,
                UserRoles = funcMain95(p107.UserRoles),
                UserTokens = funcMain96(p107.UserTokens),
                RefreshTokens = funcMain97(p107.RefreshTokens),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p107.AccessControlEntries),
                Id = p107.Id,
                UserName = p107.UserName,
                NormalizedUserName = p107.NormalizedUserName,
                Email = p107.Email,
                NormalizedEmail = p107.NormalizedEmail,
                EmailConfirmed = p107.EmailConfirmed,
                PasswordHash = p107.PasswordHash,
                SecurityStamp = p107.SecurityStamp,
                ConcurrencyStamp = p107.ConcurrencyStamp,
                PhoneNumber = p107.PhoneNumber,
                PhoneNumberConfirmed = p107.PhoneNumberConfirmed,
                TwoFactorEnabled = p107.TwoFactorEnabled,
                LockoutEnd = p107.LockoutEnd,
                LockoutEnabled = p107.LockoutEnabled,
                AccessFailedCount = p107.AccessFailedCount
            };
        }
        
        private static ICollection<AppRoleClaimReadModel> funcMain102(ICollection<AppRoleClaim> p119)
        {
            if (p119 == null)
            {
                return null;
            }
            ICollection<AppRoleClaimReadModel> result = new List<AppRoleClaimReadModel>(p119.Count);
            
            IEnumerator<AppRoleClaim> enumerator = p119.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRoleClaim item = enumerator.Current;
                result.Add(item == null ? null : new AppRoleClaimReadModel()
                {
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Id = item.Id,
                    RoleId = item.RoleId,
                    ClaimType = item.ClaimType,
                    ClaimValue = item.ClaimValue
                });
            }
            return result;
            
        }
        
        private static ICollection<AppAccessControlEntryReadModel> funcMain103(ICollection<AppAccessControlEntry> p120)
        {
            if (p120 == null)
            {
                return null;
            }
            ICollection<AppAccessControlEntryReadModel> result = new List<AppAccessControlEntryReadModel>(p120.Count);
            
            IEnumerator<AppAccessControlEntry> enumerator = p120.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppAccessControlEntry item = enumerator.Current;
                result.Add(funcMain104(item));
            }
            return result;
            
        }
        
        private static ICollection<AppFeatureFlagReadModel> funcMain114(ICollection<AppFeatureFlag> p134)
        {
            if (p134 == null)
            {
                return null;
            }
            ICollection<AppFeatureFlagReadModel> result = new List<AppFeatureFlagReadModel>(p134.Count);
            
            IEnumerator<AppFeatureFlag> enumerator = p134.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppFeatureFlag item = enumerator.Current;
                result.Add(item == null ? null : new AppFeatureFlagReadModel()
                {
                    FeatureId = item.FeatureId,
                    ScopeIdentifier = item.ScopeIdentifier,
                    IsEnabled = item.IsEnabled,
                    Feature = TypeAdapter<AppFeature, AppFeatureReadModel>.Map.Invoke(item.Feature),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static AppRoleReadModel funcMain116(AppRole p136)
        {
            return p136 == null ? null : new AppRoleReadModel()
            {
                CreatedBy = p136.CreatedBy,
                CreatedDate = p136.CreatedDate,
                ModifiedBy = p136.ModifiedBy,
                ModifiedDate = p136.ModifiedDate,
                IsDeleted = p136.IsDeleted,
                DeletedBy = p136.DeletedBy,
                DeletedDate = p136.DeletedDate,
                AppUserRoles = funcMain117(p136.AppUserRoles),
                AppRoleClaims = funcMain118(p136.AppRoleClaims),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p136.AccessControlEntries),
                Hash = p136.Hash,
                Id = p136.Id,
                Name = p136.Name,
                NormalizedName = p136.NormalizedName,
                ConcurrencyStamp = p136.ConcurrencyStamp
            };
        }
        
        private static ICollection<AppUserTokenReadModel> funcMain124(ICollection<AppUserToken> p146)
        {
            if (p146 == null)
            {
                return null;
            }
            ICollection<AppUserTokenReadModel> result = new List<AppUserTokenReadModel>(p146.Count);
            
            IEnumerator<AppUserToken> enumerator = p146.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserToken item = enumerator.Current;
                result.Add(item == null ? null : new AppUserTokenReadModel()
                {
                    Token = item.Token,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    LoginProvider = item.LoginProvider,
                    Name = item.Name,
                    Value = item.Value
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRefreshTokenReadModel> funcMain125(ICollection<AppRefreshToken> p147)
        {
            if (p147 == null)
            {
                return null;
            }
            ICollection<AppRefreshTokenReadModel> result = new List<AppRefreshTokenReadModel>(p147.Count);
            
            IEnumerator<AppRefreshToken> enumerator = p147.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRefreshToken item = enumerator.Current;
                result.Add(item == null ? null : new AppRefreshTokenReadModel()
                {
                    UserId = item.UserId,
                    Token = item.Token,
                    JwtId = item.JwtId,
                    IsUsed = item.IsUsed,
                    IsRevoked = item.IsRevoked,
                    ExpiryDate = item.ExpiryDate,
                    Hash = item.Hash,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static ICollection<AppAccessControlEntryReadModel> funcMain126(ICollection<AppAccessControlEntry> p148)
        {
            if (p148 == null)
            {
                return null;
            }
            ICollection<AppAccessControlEntryReadModel> result = new List<AppAccessControlEntryReadModel>(p148.Count);
            
            IEnumerator<AppAccessControlEntry> enumerator = p148.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppAccessControlEntry item = enumerator.Current;
                result.Add(funcMain127(item));
            }
            return result;
            
        }
        
        private static ICollection<AppFeatureFlagReadModel> funcMain136(ICollection<AppFeatureFlag> p160)
        {
            if (p160 == null)
            {
                return null;
            }
            ICollection<AppFeatureFlagReadModel> result = new List<AppFeatureFlagReadModel>(p160.Count);
            
            IEnumerator<AppFeatureFlag> enumerator = p160.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppFeatureFlag item = enumerator.Current;
                result.Add(item == null ? null : new AppFeatureFlagReadModel()
                {
                    FeatureId = item.FeatureId,
                    ScopeIdentifier = item.ScopeIdentifier,
                    IsEnabled = item.IsEnabled,
                    Feature = TypeAdapter<AppFeature, AppFeatureReadModel>.Map.Invoke(item.Feature),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static AppUserReadModel funcMain139(AppUser p163)
        {
            return p163 == null ? null : new AppUserReadModel()
            {
                Hash = p163.Hash,
                FirstName = p163.FirstName,
                LastName = p163.LastName,
                Mobile = p163.Mobile,
                CountryCode = p163.CountryCode,
                TwoFactorMethod = p163.TwoFactorMethod,
                CreatedBy = p163.CreatedBy,
                CreatedDate = p163.CreatedDate,
                ModifiedBy = p163.ModifiedBy,
                ModifiedDate = p163.ModifiedDate,
                IsDeleted = p163.IsDeleted,
                DeletedBy = p163.DeletedBy,
                DeletedDate = p163.DeletedDate,
                MembershipType = p163.MembershipType,
                UserRoles = funcMain140(p163.UserRoles),
                UserTokens = funcMain141(p163.UserTokens),
                RefreshTokens = funcMain142(p163.RefreshTokens),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p163.AccessControlEntries),
                Id = p163.Id,
                UserName = p163.UserName,
                NormalizedUserName = p163.NormalizedUserName,
                Email = p163.Email,
                NormalizedEmail = p163.NormalizedEmail,
                EmailConfirmed = p163.EmailConfirmed,
                PasswordHash = p163.PasswordHash,
                SecurityStamp = p163.SecurityStamp,
                ConcurrencyStamp = p163.ConcurrencyStamp,
                PhoneNumber = p163.PhoneNumber,
                PhoneNumberConfirmed = p163.PhoneNumberConfirmed,
                TwoFactorEnabled = p163.TwoFactorEnabled,
                LockoutEnd = p163.LockoutEnd,
                LockoutEnabled = p163.LockoutEnabled,
                AccessFailedCount = p163.AccessFailedCount
            };
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain11(ICollection<AppUserRole> p12)
        {
            if (p12 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p12.Count);
            
            IEnumerator<AppUserRole> enumerator = p12.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(TypeAdapter<AppUserRole, AppUserRoleReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static ICollection<AppRoleClaimReadModel> funcMain12(ICollection<AppRoleClaim> p13)
        {
            if (p13 == null)
            {
                return null;
            }
            ICollection<AppRoleClaimReadModel> result = new List<AppRoleClaimReadModel>(p13.Count);
            
            IEnumerator<AppRoleClaim> enumerator = p13.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRoleClaim item = enumerator.Current;
                result.Add(item == null ? null : new AppRoleClaimReadModel()
                {
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Id = item.Id,
                    RoleId = item.RoleId,
                    ClaimType = item.ClaimType,
                    ClaimValue = item.ClaimValue
                });
            }
            return result;
            
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain24(ICollection<AppUserRole> p25)
        {
            if (p25 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p25.Count);
            
            IEnumerator<AppUserRole> enumerator = p25.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(TypeAdapter<AppUserRole, AppUserRoleReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserTokenReadModel> funcMain25(ICollection<AppUserToken> p26)
        {
            if (p26 == null)
            {
                return null;
            }
            ICollection<AppUserTokenReadModel> result = new List<AppUserTokenReadModel>(p26.Count);
            
            IEnumerator<AppUserToken> enumerator = p26.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserToken item = enumerator.Current;
                result.Add(item == null ? null : new AppUserTokenReadModel()
                {
                    Token = item.Token,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    LoginProvider = item.LoginProvider,
                    Name = item.Name,
                    Value = item.Value
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRefreshTokenReadModel> funcMain26(ICollection<AppRefreshToken> p27)
        {
            if (p27 == null)
            {
                return null;
            }
            ICollection<AppRefreshTokenReadModel> result = new List<AppRefreshTokenReadModel>(p27.Count);
            
            IEnumerator<AppRefreshToken> enumerator = p27.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRefreshToken item = enumerator.Current;
                result.Add(item == null ? null : new AppRefreshTokenReadModel()
                {
                    UserId = item.UserId,
                    Token = item.Token,
                    JwtId = item.JwtId,
                    IsUsed = item.IsUsed,
                    IsRevoked = item.IsRevoked,
                    ExpiryDate = item.ExpiryDate,
                    Hash = item.Hash,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain37(ICollection<AppUserRole> p45)
        {
            if (p45 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p45.Count);
            
            IEnumerator<AppUserRole> enumerator = p45.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(TypeAdapter<AppUserRole, AppUserRoleReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static ICollection<AppRoleClaimReadModel> funcMain38(ICollection<AppRoleClaim> p46)
        {
            if (p46 == null)
            {
                return null;
            }
            ICollection<AppRoleClaimReadModel> result = new List<AppRoleClaimReadModel>(p46.Count);
            
            IEnumerator<AppRoleClaim> enumerator = p46.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRoleClaim item = enumerator.Current;
                result.Add(item == null ? null : new AppRoleClaimReadModel()
                {
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Id = item.Id,
                    RoleId = item.RoleId,
                    ClaimType = item.ClaimType,
                    ClaimValue = item.ClaimValue
                });
            }
            return result;
            
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain50(ICollection<AppUserRole> p62)
        {
            if (p62 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p62.Count);
            
            IEnumerator<AppUserRole> enumerator = p62.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(TypeAdapter<AppUserRole, AppUserRoleReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserTokenReadModel> funcMain51(ICollection<AppUserToken> p63)
        {
            if (p63 == null)
            {
                return null;
            }
            ICollection<AppUserTokenReadModel> result = new List<AppUserTokenReadModel>(p63.Count);
            
            IEnumerator<AppUserToken> enumerator = p63.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserToken item = enumerator.Current;
                result.Add(item == null ? null : new AppUserTokenReadModel()
                {
                    Token = item.Token,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    LoginProvider = item.LoginProvider,
                    Name = item.Name,
                    Value = item.Value
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRefreshTokenReadModel> funcMain52(ICollection<AppRefreshToken> p64)
        {
            if (p64 == null)
            {
                return null;
            }
            ICollection<AppRefreshTokenReadModel> result = new List<AppRefreshTokenReadModel>(p64.Count);
            
            IEnumerator<AppRefreshToken> enumerator = p64.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRefreshToken item = enumerator.Current;
                result.Add(item == null ? null : new AppRefreshTokenReadModel()
                {
                    UserId = item.UserId,
                    Token = item.Token,
                    JwtId = item.JwtId,
                    IsUsed = item.IsUsed,
                    IsRevoked = item.IsRevoked,
                    ExpiryDate = item.ExpiryDate,
                    Hash = item.Hash,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static AppAccessControlEntryReadModel funcMain59(AppAccessControlEntry p72)
        {
            return p72 == null ? null : new AppAccessControlEntryReadModel()
            {
                ResourcePattern = p72.ResourcePattern,
                PermissionPattern = p72.PermissionPattern,
                FeatureId = p72.FeatureId,
                Feature = funcMain60(p72.Feature),
                AppRoles = funcMain62(p72.AppRoles),
                AppUsers = funcMain63(p72.AppUsers),
                AppResource = p72.AppResource == null ? null : new AppResourceReadModel()
                {
                    Url = p72.AppResource.Url,
                    Description = p72.AppResource.Description,
                    ResourceType = p72.AppResource.ResourceType,
                    AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p72.AppResource.AccessControlEntries),
                    Id = p72.AppResource.Id,
                    CreatedBy = p72.AppResource.CreatedBy,
                    CreatedDate = p72.AppResource.CreatedDate,
                    ModifiedBy = p72.AppResource.ModifiedBy,
                    ModifiedDate = p72.AppResource.ModifiedDate,
                    IsDeleted = p72.AppResource.IsDeleted,
                    DeletedBy = p72.AppResource.DeletedBy,
                    DeletedDate = p72.AppResource.DeletedDate
                },
                ResourceId = p72.ResourceId,
                Id = p72.Id,
                CreatedBy = p72.CreatedBy,
                CreatedDate = p72.CreatedDate,
                ModifiedBy = p72.ModifiedBy,
                ModifiedDate = p72.ModifiedDate,
                IsDeleted = p72.IsDeleted,
                DeletedBy = p72.DeletedBy,
                DeletedDate = p72.DeletedDate
            };
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain72(ICollection<AppUserRole> p85)
        {
            if (p85 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p85.Count);
            
            IEnumerator<AppUserRole> enumerator = p85.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(item == null ? null : new AppUserRoleReadModel()
                {
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Hash = item.Hash,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    RoleId = item.RoleId
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRoleClaimReadModel> funcMain73(ICollection<AppRoleClaim> p86)
        {
            if (p86 == null)
            {
                return null;
            }
            ICollection<AppRoleClaimReadModel> result = new List<AppRoleClaimReadModel>(p86.Count);
            
            IEnumerator<AppRoleClaim> enumerator = p86.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRoleClaim item = enumerator.Current;
                result.Add(item == null ? null : new AppRoleClaimReadModel()
                {
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Id = item.Id,
                    RoleId = item.RoleId,
                    ClaimType = item.ClaimType,
                    ClaimValue = item.ClaimValue
                });
            }
            return result;
            
        }
        
        private static AppAccessControlEntryReadModel funcMain82(AppAccessControlEntry p95)
        {
            return p95 == null ? null : new AppAccessControlEntryReadModel()
            {
                ResourcePattern = p95.ResourcePattern,
                PermissionPattern = p95.PermissionPattern,
                FeatureId = p95.FeatureId,
                Feature = funcMain83(p95.Feature),
                AppRoles = funcMain85(p95.AppRoles),
                AppUsers = funcMain86(p95.AppUsers),
                AppResource = p95.AppResource == null ? null : new AppResourceReadModel()
                {
                    Url = p95.AppResource.Url,
                    Description = p95.AppResource.Description,
                    ResourceType = p95.AppResource.ResourceType,
                    AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p95.AppResource.AccessControlEntries),
                    Id = p95.AppResource.Id,
                    CreatedBy = p95.AppResource.CreatedBy,
                    CreatedDate = p95.AppResource.CreatedDate,
                    ModifiedBy = p95.AppResource.ModifiedBy,
                    ModifiedDate = p95.AppResource.ModifiedDate,
                    IsDeleted = p95.AppResource.IsDeleted,
                    DeletedBy = p95.AppResource.DeletedBy,
                    DeletedDate = p95.AppResource.DeletedDate
                },
                ResourceId = p95.ResourceId,
                Id = p95.Id,
                CreatedBy = p95.CreatedBy,
                CreatedDate = p95.CreatedDate,
                ModifiedBy = p95.ModifiedBy,
                ModifiedDate = p95.ModifiedDate,
                IsDeleted = p95.IsDeleted,
                DeletedBy = p95.DeletedBy,
                DeletedDate = p95.DeletedDate
            };
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain95(ICollection<AppUserRole> p108)
        {
            if (p108 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p108.Count);
            
            IEnumerator<AppUserRole> enumerator = p108.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(item == null ? null : new AppUserRoleReadModel()
                {
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Hash = item.Hash,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    RoleId = item.RoleId
                });
            }
            return result;
            
        }
        
        private static ICollection<AppUserTokenReadModel> funcMain96(ICollection<AppUserToken> p109)
        {
            if (p109 == null)
            {
                return null;
            }
            ICollection<AppUserTokenReadModel> result = new List<AppUserTokenReadModel>(p109.Count);
            
            IEnumerator<AppUserToken> enumerator = p109.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserToken item = enumerator.Current;
                result.Add(item == null ? null : new AppUserTokenReadModel()
                {
                    Token = item.Token,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    LoginProvider = item.LoginProvider,
                    Name = item.Name,
                    Value = item.Value
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRefreshTokenReadModel> funcMain97(ICollection<AppRefreshToken> p110)
        {
            if (p110 == null)
            {
                return null;
            }
            ICollection<AppRefreshTokenReadModel> result = new List<AppRefreshTokenReadModel>(p110.Count);
            
            IEnumerator<AppRefreshToken> enumerator = p110.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRefreshToken item = enumerator.Current;
                result.Add(item == null ? null : new AppRefreshTokenReadModel()
                {
                    UserId = item.UserId,
                    Token = item.Token,
                    JwtId = item.JwtId,
                    IsUsed = item.IsUsed,
                    IsRevoked = item.IsRevoked,
                    ExpiryDate = item.ExpiryDate,
                    Hash = item.Hash,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static AppAccessControlEntryReadModel funcMain104(AppAccessControlEntry p121)
        {
            return p121 == null ? null : new AppAccessControlEntryReadModel()
            {
                ResourcePattern = p121.ResourcePattern,
                PermissionPattern = p121.PermissionPattern,
                FeatureId = p121.FeatureId,
                Feature = funcMain105(p121.Feature),
                AppRoles = funcMain107(p121.AppRoles),
                AppUsers = funcMain108(p121.AppUsers),
                AppResource = p121.AppResource == null ? null : new AppResourceReadModel()
                {
                    Url = p121.AppResource.Url,
                    Description = p121.AppResource.Description,
                    ResourceType = p121.AppResource.ResourceType,
                    AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p121.AppResource.AccessControlEntries),
                    Id = p121.AppResource.Id,
                    CreatedBy = p121.AppResource.CreatedBy,
                    CreatedDate = p121.AppResource.CreatedDate,
                    ModifiedBy = p121.AppResource.ModifiedBy,
                    ModifiedDate = p121.AppResource.ModifiedDate,
                    IsDeleted = p121.AppResource.IsDeleted,
                    DeletedBy = p121.AppResource.DeletedBy,
                    DeletedDate = p121.AppResource.DeletedDate
                },
                ResourceId = p121.ResourceId,
                Id = p121.Id,
                CreatedBy = p121.CreatedBy,
                CreatedDate = p121.CreatedDate,
                ModifiedBy = p121.ModifiedBy,
                ModifiedDate = p121.ModifiedDate,
                IsDeleted = p121.IsDeleted,
                DeletedBy = p121.DeletedBy,
                DeletedDate = p121.DeletedDate
            };
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain117(ICollection<AppUserRole> p137)
        {
            if (p137 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p137.Count);
            
            IEnumerator<AppUserRole> enumerator = p137.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(item == null ? null : new AppUserRoleReadModel()
                {
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Hash = item.Hash,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    RoleId = item.RoleId
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRoleClaimReadModel> funcMain118(ICollection<AppRoleClaim> p138)
        {
            if (p138 == null)
            {
                return null;
            }
            ICollection<AppRoleClaimReadModel> result = new List<AppRoleClaimReadModel>(p138.Count);
            
            IEnumerator<AppRoleClaim> enumerator = p138.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRoleClaim item = enumerator.Current;
                result.Add(item == null ? null : new AppRoleClaimReadModel()
                {
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Id = item.Id,
                    RoleId = item.RoleId,
                    ClaimType = item.ClaimType,
                    ClaimValue = item.ClaimValue
                });
            }
            return result;
            
        }
        
        private static AppAccessControlEntryReadModel funcMain127(AppAccessControlEntry p149)
        {
            return p149 == null ? null : new AppAccessControlEntryReadModel()
            {
                ResourcePattern = p149.ResourcePattern,
                PermissionPattern = p149.PermissionPattern,
                FeatureId = p149.FeatureId,
                Feature = funcMain128(p149.Feature),
                AppRoles = funcMain130(p149.AppRoles),
                AppUsers = funcMain131(p149.AppUsers),
                AppResource = p149.AppResource == null ? null : new AppResourceReadModel()
                {
                    Url = p149.AppResource.Url,
                    Description = p149.AppResource.Description,
                    ResourceType = p149.AppResource.ResourceType,
                    AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p149.AppResource.AccessControlEntries),
                    Id = p149.AppResource.Id,
                    CreatedBy = p149.AppResource.CreatedBy,
                    CreatedDate = p149.AppResource.CreatedDate,
                    ModifiedBy = p149.AppResource.ModifiedBy,
                    ModifiedDate = p149.AppResource.ModifiedDate,
                    IsDeleted = p149.AppResource.IsDeleted,
                    DeletedBy = p149.AppResource.DeletedBy,
                    DeletedDate = p149.AppResource.DeletedDate
                },
                ResourceId = p149.ResourceId,
                Id = p149.Id,
                CreatedBy = p149.CreatedBy,
                CreatedDate = p149.CreatedDate,
                ModifiedBy = p149.ModifiedBy,
                ModifiedDate = p149.ModifiedDate,
                IsDeleted = p149.IsDeleted,
                DeletedBy = p149.DeletedBy,
                DeletedDate = p149.DeletedDate
            };
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain140(ICollection<AppUserRole> p164)
        {
            if (p164 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p164.Count);
            
            IEnumerator<AppUserRole> enumerator = p164.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(item == null ? null : new AppUserRoleReadModel()
                {
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Hash = item.Hash,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    RoleId = item.RoleId
                });
            }
            return result;
            
        }
        
        private static ICollection<AppUserTokenReadModel> funcMain141(ICollection<AppUserToken> p165)
        {
            if (p165 == null)
            {
                return null;
            }
            ICollection<AppUserTokenReadModel> result = new List<AppUserTokenReadModel>(p165.Count);
            
            IEnumerator<AppUserToken> enumerator = p165.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserToken item = enumerator.Current;
                result.Add(item == null ? null : new AppUserTokenReadModel()
                {
                    Token = item.Token,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    LoginProvider = item.LoginProvider,
                    Name = item.Name,
                    Value = item.Value
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRefreshTokenReadModel> funcMain142(ICollection<AppRefreshToken> p166)
        {
            if (p166 == null)
            {
                return null;
            }
            ICollection<AppRefreshTokenReadModel> result = new List<AppRefreshTokenReadModel>(p166.Count);
            
            IEnumerator<AppRefreshToken> enumerator = p166.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRefreshToken item = enumerator.Current;
                result.Add(item == null ? null : new AppRefreshTokenReadModel()
                {
                    UserId = item.UserId,
                    Token = item.Token,
                    JwtId = item.JwtId,
                    IsUsed = item.IsUsed,
                    IsRevoked = item.IsRevoked,
                    ExpiryDate = item.ExpiryDate,
                    Hash = item.Hash,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static AppFeatureReadModel funcMain60(AppFeature p73)
        {
            return p73 == null ? null : new AppFeatureReadModel()
            {
                Name = p73.Name,
                Description = p73.Description,
                IsEnabled = p73.IsEnabled,
                Scope = p73.Scope,
                FeatureFlags = funcMain61(p73.FeatureFlags),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p73.AccessControlEntries),
                Id = p73.Id,
                CreatedBy = p73.CreatedBy,
                CreatedDate = p73.CreatedDate,
                ModifiedBy = p73.ModifiedBy,
                ModifiedDate = p73.ModifiedDate,
                IsDeleted = p73.IsDeleted,
                DeletedBy = p73.DeletedBy,
                DeletedDate = p73.DeletedDate
            };
        }
        
        private static ICollection<AppRoleReadModel> funcMain62(ICollection<AppRole> p75)
        {
            if (p75 == null)
            {
                return null;
            }
            ICollection<AppRoleReadModel> result = new List<AppRoleReadModel>(p75.Count);
            
            IEnumerator<AppRole> enumerator = p75.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRole item = enumerator.Current;
                result.Add(TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserReadModel> funcMain63(ICollection<AppUser> p76)
        {
            if (p76 == null)
            {
                return null;
            }
            ICollection<AppUserReadModel> result = new List<AppUserReadModel>(p76.Count);
            
            IEnumerator<AppUser> enumerator = p76.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUser item = enumerator.Current;
                result.Add(TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static AppFeatureReadModel funcMain83(AppFeature p96)
        {
            return p96 == null ? null : new AppFeatureReadModel()
            {
                Name = p96.Name,
                Description = p96.Description,
                IsEnabled = p96.IsEnabled,
                Scope = p96.Scope,
                FeatureFlags = funcMain84(p96.FeatureFlags),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p96.AccessControlEntries),
                Id = p96.Id,
                CreatedBy = p96.CreatedBy,
                CreatedDate = p96.CreatedDate,
                ModifiedBy = p96.ModifiedBy,
                ModifiedDate = p96.ModifiedDate,
                IsDeleted = p96.IsDeleted,
                DeletedBy = p96.DeletedBy,
                DeletedDate = p96.DeletedDate
            };
        }
        
        private static ICollection<AppRoleReadModel> funcMain85(ICollection<AppRole> p98)
        {
            if (p98 == null)
            {
                return null;
            }
            ICollection<AppRoleReadModel> result = new List<AppRoleReadModel>(p98.Count);
            
            IEnumerator<AppRole> enumerator = p98.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRole item = enumerator.Current;
                result.Add(TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserReadModel> funcMain86(ICollection<AppUser> p99)
        {
            if (p99 == null)
            {
                return null;
            }
            ICollection<AppUserReadModel> result = new List<AppUserReadModel>(p99.Count);
            
            IEnumerator<AppUser> enumerator = p99.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUser item = enumerator.Current;
                result.Add(TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static AppFeatureReadModel funcMain105(AppFeature p122)
        {
            return p122 == null ? null : new AppFeatureReadModel()
            {
                Name = p122.Name,
                Description = p122.Description,
                IsEnabled = p122.IsEnabled,
                Scope = p122.Scope,
                FeatureFlags = funcMain106(p122.FeatureFlags),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p122.AccessControlEntries),
                Id = p122.Id,
                CreatedBy = p122.CreatedBy,
                CreatedDate = p122.CreatedDate,
                ModifiedBy = p122.ModifiedBy,
                ModifiedDate = p122.ModifiedDate,
                IsDeleted = p122.IsDeleted,
                DeletedBy = p122.DeletedBy,
                DeletedDate = p122.DeletedDate
            };
        }
        
        private static ICollection<AppRoleReadModel> funcMain107(ICollection<AppRole> p124)
        {
            if (p124 == null)
            {
                return null;
            }
            ICollection<AppRoleReadModel> result = new List<AppRoleReadModel>(p124.Count);
            
            IEnumerator<AppRole> enumerator = p124.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRole item = enumerator.Current;
                result.Add(TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserReadModel> funcMain108(ICollection<AppUser> p125)
        {
            if (p125 == null)
            {
                return null;
            }
            ICollection<AppUserReadModel> result = new List<AppUserReadModel>(p125.Count);
            
            IEnumerator<AppUser> enumerator = p125.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUser item = enumerator.Current;
                result.Add(TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static AppFeatureReadModel funcMain128(AppFeature p150)
        {
            return p150 == null ? null : new AppFeatureReadModel()
            {
                Name = p150.Name,
                Description = p150.Description,
                IsEnabled = p150.IsEnabled,
                Scope = p150.Scope,
                FeatureFlags = funcMain129(p150.FeatureFlags),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p150.AccessControlEntries),
                Id = p150.Id,
                CreatedBy = p150.CreatedBy,
                CreatedDate = p150.CreatedDate,
                ModifiedBy = p150.ModifiedBy,
                ModifiedDate = p150.ModifiedDate,
                IsDeleted = p150.IsDeleted,
                DeletedBy = p150.DeletedBy,
                DeletedDate = p150.DeletedDate
            };
        }
        
        private static ICollection<AppRoleReadModel> funcMain130(ICollection<AppRole> p152)
        {
            if (p152 == null)
            {
                return null;
            }
            ICollection<AppRoleReadModel> result = new List<AppRoleReadModel>(p152.Count);
            
            IEnumerator<AppRole> enumerator = p152.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRole item = enumerator.Current;
                result.Add(TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserReadModel> funcMain131(ICollection<AppUser> p153)
        {
            if (p153 == null)
            {
                return null;
            }
            ICollection<AppUserReadModel> result = new List<AppUserReadModel>(p153.Count);
            
            IEnumerator<AppUser> enumerator = p153.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUser item = enumerator.Current;
                result.Add(TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static ICollection<AppFeatureFlagReadModel> funcMain61(ICollection<AppFeatureFlag> p74)
        {
            if (p74 == null)
            {
                return null;
            }
            ICollection<AppFeatureFlagReadModel> result = new List<AppFeatureFlagReadModel>(p74.Count);
            
            IEnumerator<AppFeatureFlag> enumerator = p74.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppFeatureFlag item = enumerator.Current;
                result.Add(item == null ? null : new AppFeatureFlagReadModel()
                {
                    FeatureId = item.FeatureId,
                    ScopeIdentifier = item.ScopeIdentifier,
                    IsEnabled = item.IsEnabled,
                    Feature = TypeAdapter<AppFeature, AppFeatureReadModel>.Map.Invoke(item.Feature),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static ICollection<AppFeatureFlagReadModel> funcMain84(ICollection<AppFeatureFlag> p97)
        {
            if (p97 == null)
            {
                return null;
            }
            ICollection<AppFeatureFlagReadModel> result = new List<AppFeatureFlagReadModel>(p97.Count);
            
            IEnumerator<AppFeatureFlag> enumerator = p97.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppFeatureFlag item = enumerator.Current;
                result.Add(item == null ? null : new AppFeatureFlagReadModel()
                {
                    FeatureId = item.FeatureId,
                    ScopeIdentifier = item.ScopeIdentifier,
                    IsEnabled = item.IsEnabled,
                    Feature = TypeAdapter<AppFeature, AppFeatureReadModel>.Map.Invoke(item.Feature),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static ICollection<AppFeatureFlagReadModel> funcMain106(ICollection<AppFeatureFlag> p123)
        {
            if (p123 == null)
            {
                return null;
            }
            ICollection<AppFeatureFlagReadModel> result = new List<AppFeatureFlagReadModel>(p123.Count);
            
            IEnumerator<AppFeatureFlag> enumerator = p123.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppFeatureFlag item = enumerator.Current;
                result.Add(item == null ? null : new AppFeatureFlagReadModel()
                {
                    FeatureId = item.FeatureId,
                    ScopeIdentifier = item.ScopeIdentifier,
                    IsEnabled = item.IsEnabled,
                    Feature = TypeAdapter<AppFeature, AppFeatureReadModel>.Map.Invoke(item.Feature),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static ICollection<AppFeatureFlagReadModel> funcMain129(ICollection<AppFeatureFlag> p151)
        {
            if (p151 == null)
            {
                return null;
            }
            ICollection<AppFeatureFlagReadModel> result = new List<AppFeatureFlagReadModel>(p151.Count);
            
            IEnumerator<AppFeatureFlag> enumerator = p151.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppFeatureFlag item = enumerator.Current;
                result.Add(item == null ? null : new AppFeatureFlagReadModel()
                {
                    FeatureId = item.FeatureId,
                    ScopeIdentifier = item.ScopeIdentifier,
                    IsEnabled = item.IsEnabled,
                    Feature = TypeAdapter<AppFeature, AppFeatureReadModel>.Map.Invoke(item.Feature),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
    }
}