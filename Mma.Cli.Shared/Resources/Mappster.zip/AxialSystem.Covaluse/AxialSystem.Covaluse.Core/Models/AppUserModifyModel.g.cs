using System;
using System.Collections.Generic;
using AxialSystem.Covaluse.Core.Database.Identity;
using AxialSystem.Covaluse.Core.Enums;

namespace AxialSystem.Covaluse.Core.Database.Identity
{
    public partial class AppUserModifyModel
    {
        public int Hash { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Mobile { get; set; }
        public string CountryCode { get; set; }
        public TwoFactorMethods TwoFactorMethod { get; set; }
        public Guid? CreatedBy { get; set; }
        public DateTime? CreatedDate { get; set; }
        public Guid? ModifiedBy { get; set; }
        public DateTime? ModifiedDate { get; set; }
        public bool? IsDeleted { get; set; }
        public Guid? DeletedBy { get; set; }
        public DateTime? DeletedDate { get; set; }
        public MembershipTypes MembershipType { get; set; }
        public ICollection<AppUserRoleReadModel> UserRoles { get; set; }
        public ICollection<AppUserTokenReadModel> UserTokens { get; set; }
        public ICollection<AppRefreshTokenReadModel> RefreshTokens { get; set; }
        public ICollection<AppAccessControlEntryReadModel> AccessControlEntries { get; set; }
        public Guid Id { get; set; }
        public string UserName { get; set; }
        public string NormalizedUserName { get; set; }
        public string Email { get; set; }
        public string NormalizedEmail { get; set; }
        public bool EmailConfirmed { get; set; }
        public string PasswordHash { get; set; }
        public string SecurityStamp { get; set; }
        public string ConcurrencyStamp { get; set; }
        public string PhoneNumber { get; set; }
        public bool PhoneNumberConfirmed { get; set; }
        public bool TwoFactorEnabled { get; set; }
        public DateTimeOffset? LockoutEnd { get; set; }
        public bool LockoutEnabled { get; set; }
        public int AccessFailedCount { get; set; }
    }
}