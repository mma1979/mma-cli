using System;
using AxialSystem.Covaluse.Core.Enums;

namespace AxialSystem.Covaluse.Core.Database.Tables
{
    public partial class SysSettingDto
    {
        public string SysKey { get; set; }
        public string SysValue { get; set; }
        public SettingsTypeEnum Enviroment { get; set; }
        public int Id { get; set; }
        public long? CreatedBy { get; set; }
        public DateTime? CreatedDate { get; set; }
        public long? ModifiedBy { get; set; }
        public DateTime? ModifiedDate { get; set; }
        public bool? IsDeleted { get; set; }
        public long? DeletedBy { get; set; }
        public DateTime? DeletedDate { get; set; }
    }
}