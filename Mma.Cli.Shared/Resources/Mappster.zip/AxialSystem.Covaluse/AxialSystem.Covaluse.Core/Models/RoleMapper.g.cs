using System.Collections.Generic;
using AxialSystem.Covaluse.Core.Database.Identity;
using Mapster;

namespace AxialSystem.Covaluse.Core.Database.Identity
{
    public static partial class RoleMapper
    {
        public static RoleDto AdaptToDto(this Role p1)
        {
            return p1 == null ? null : new RoleDto()
            {
                CreatedBy = p1.CreatedBy,
                CreatedDate = p1.CreatedDate,
                ModifiedBy = p1.ModifiedBy,
                ModifiedDate = p1.ModifiedDate,
                IsDeleted = p1.IsDeleted,
                DeletedBy = p1.DeletedBy,
                DeletedDate = p1.DeletedDate,
                UserRoles = funcMain1(p1.UserRoles),
                Id = p1.Id,
                Name = p1.Name,
                NormalizedName = p1.NormalizedName,
                ConcurrencyStamp = p1.ConcurrencyStamp
            };
        }
        public static RoleDto AdaptTo(this Role p7, RoleDto p8)
        {
            if (p7 == null)
            {
                return null;
            }
            RoleDto result = p8 ?? new RoleDto();
            
            result.CreatedBy = p7.CreatedBy;
            result.CreatedDate = p7.CreatedDate;
            result.ModifiedBy = p7.ModifiedBy;
            result.ModifiedDate = p7.ModifiedDate;
            result.IsDeleted = p7.IsDeleted;
            result.DeletedBy = p7.DeletedBy;
            result.DeletedDate = p7.DeletedDate;
            result.UserRoles = funcMain6(p7.UserRoles, result.UserRoles);
            result.Id = p7.Id;
            result.Name = p7.Name;
            result.NormalizedName = p7.NormalizedName;
            result.ConcurrencyStamp = p7.ConcurrencyStamp;
            return result;
            
        }
        
        private static ICollection<UserRoleDto> funcMain1(ICollection<UserRole> p2)
        {
            if (p2 == null)
            {
                return null;
            }
            ICollection<UserRoleDto> result = new List<UserRoleDto>(p2.Count);
            
            IEnumerator<UserRole> enumerator = p2.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                UserRole item = enumerator.Current;
                result.Add(funcMain2(item));
            }
            return result;
            
        }
        
        private static ICollection<UserRoleDto> funcMain6(ICollection<UserRole> p9, ICollection<UserRoleDto> p10)
        {
            if (p9 == null)
            {
                return null;
            }
            ICollection<UserRoleDto> result = new List<UserRoleDto>(p9.Count);
            
            IEnumerator<UserRole> enumerator = p9.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                UserRole item = enumerator.Current;
                result.Add(funcMain7(item));
            }
            return result;
            
        }
        
        private static UserRoleDto funcMain2(UserRole p3)
        {
            return p3 == null ? null : new UserRoleDto()
            {
                AppUser = funcMain3(p3.AppUser),
                Role = TypeAdapter<Role, RoleDto>.Map.Invoke(p3.Role),
                CreatedBy = p3.CreatedBy,
                CreatedDate = p3.CreatedDate,
                ModifiedBy = p3.ModifiedBy,
                ModifiedDate = p3.ModifiedDate,
                IsDeleted = p3.IsDeleted,
                DeletedBy = p3.DeletedBy,
                DeletedDate = p3.DeletedDate,
                UserId = p3.UserId,
                RoleId = p3.RoleId
            };
        }
        
        private static UserRoleDto funcMain7(UserRole p11)
        {
            return p11 == null ? null : new UserRoleDto()
            {
                AppUser = funcMain8(p11.AppUser),
                Role = TypeAdapter<Role, RoleDto>.Map.Invoke(p11.Role),
                CreatedBy = p11.CreatedBy,
                CreatedDate = p11.CreatedDate,
                ModifiedBy = p11.ModifiedBy,
                ModifiedDate = p11.ModifiedDate,
                IsDeleted = p11.IsDeleted,
                DeletedBy = p11.DeletedBy,
                DeletedDate = p11.DeletedDate,
                UserId = p11.UserId,
                RoleId = p11.RoleId
            };
        }
        
        private static AppUserDto funcMain3(AppUser p4)
        {
            return p4 == null ? null : new AppUserDto()
            {
                Hash = p4.Hash,
                FirstName = p4.FirstName,
                LastName = p4.LastName,
                Mobile = p4.Mobile,
                CountryCode = p4.CountryCode,
                TwoFactorMethod = p4.TwoFactorMethod,
                CreatedBy = p4.CreatedBy,
                CreatedDate = p4.CreatedDate,
                ModifiedBy = p4.ModifiedBy,
                ModifiedDate = p4.ModifiedDate,
                IsDeleted = p4.IsDeleted,
                DeletedBy = p4.DeletedBy,
                DeletedDate = p4.DeletedDate,
                MembershipType = p4.MembershipType,
                UserRoles = TypeAdapter<ICollection<UserRole>, ICollection<UserRoleDto>>.Map.Invoke(p4.UserRoles),
                UserTokens = funcMain4(p4.UserTokens),
                RefreshTokens = funcMain5(p4.RefreshTokens),
                Id = p4.Id,
                UserName = p4.UserName,
                NormalizedUserName = p4.NormalizedUserName,
                Email = p4.Email,
                NormalizedEmail = p4.NormalizedEmail,
                EmailConfirmed = p4.EmailConfirmed,
                PasswordHash = p4.PasswordHash,
                SecurityStamp = p4.SecurityStamp,
                ConcurrencyStamp = p4.ConcurrencyStamp,
                PhoneNumber = p4.PhoneNumber,
                PhoneNumberConfirmed = p4.PhoneNumberConfirmed,
                TwoFactorEnabled = p4.TwoFactorEnabled,
                LockoutEnd = p4.LockoutEnd,
                LockoutEnabled = p4.LockoutEnabled,
                AccessFailedCount = p4.AccessFailedCount
            };
        }
        
        private static AppUserDto funcMain8(AppUser p12)
        {
            return p12 == null ? null : new AppUserDto()
            {
                Hash = p12.Hash,
                FirstName = p12.FirstName,
                LastName = p12.LastName,
                Mobile = p12.Mobile,
                CountryCode = p12.CountryCode,
                TwoFactorMethod = p12.TwoFactorMethod,
                CreatedBy = p12.CreatedBy,
                CreatedDate = p12.CreatedDate,
                ModifiedBy = p12.ModifiedBy,
                ModifiedDate = p12.ModifiedDate,
                IsDeleted = p12.IsDeleted,
                DeletedBy = p12.DeletedBy,
                DeletedDate = p12.DeletedDate,
                MembershipType = p12.MembershipType,
                UserRoles = TypeAdapter<ICollection<UserRole>, ICollection<UserRoleDto>>.Map.Invoke(p12.UserRoles),
                UserTokens = funcMain9(p12.UserTokens),
                RefreshTokens = funcMain10(p12.RefreshTokens),
                Id = p12.Id,
                UserName = p12.UserName,
                NormalizedUserName = p12.NormalizedUserName,
                Email = p12.Email,
                NormalizedEmail = p12.NormalizedEmail,
                EmailConfirmed = p12.EmailConfirmed,
                PasswordHash = p12.PasswordHash,
                SecurityStamp = p12.SecurityStamp,
                ConcurrencyStamp = p12.ConcurrencyStamp,
                PhoneNumber = p12.PhoneNumber,
                PhoneNumberConfirmed = p12.PhoneNumberConfirmed,
                TwoFactorEnabled = p12.TwoFactorEnabled,
                LockoutEnd = p12.LockoutEnd,
                LockoutEnabled = p12.LockoutEnabled,
                AccessFailedCount = p12.AccessFailedCount
            };
        }
        
        private static ICollection<UserTokenDto> funcMain4(ICollection<UserToken> p5)
        {
            if (p5 == null)
            {
                return null;
            }
            ICollection<UserTokenDto> result = new List<UserTokenDto>(p5.Count);
            
            IEnumerator<UserToken> enumerator = p5.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                UserToken item = enumerator.Current;
                result.Add(item == null ? null : new UserTokenDto()
                {
                    Token = item.Token,
                    AppUser = TypeAdapter<AppUser, AppUserDto>.Map.Invoke(item.AppUser),
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    LoginProvider = item.LoginProvider,
                    Name = item.Name,
                    Value = item.Value
                });
            }
            return result;
            
        }
        
        private static ICollection<RefreshTokenDto> funcMain5(ICollection<RefreshToken> p6)
        {
            if (p6 == null)
            {
                return null;
            }
            ICollection<RefreshTokenDto> result = new List<RefreshTokenDto>(p6.Count);
            
            IEnumerator<RefreshToken> enumerator = p6.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                RefreshToken item = enumerator.Current;
                result.Add(item == null ? null : new RefreshTokenDto()
                {
                    UserId = item.UserId,
                    Token = item.Token,
                    JwtId = item.JwtId,
                    IsUsed = item.IsUsed,
                    IsRevoked = item.IsRevoked,
                    ExpiryDate = item.ExpiryDate,
                    Hash = item.Hash,
                    AppUser = TypeAdapter<AppUser, AppUserDto>.Map.Invoke(item.AppUser),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static ICollection<UserTokenDto> funcMain9(ICollection<UserToken> p13)
        {
            if (p13 == null)
            {
                return null;
            }
            ICollection<UserTokenDto> result = new List<UserTokenDto>(p13.Count);
            
            IEnumerator<UserToken> enumerator = p13.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                UserToken item = enumerator.Current;
                result.Add(item == null ? null : new UserTokenDto()
                {
                    Token = item.Token,
                    AppUser = TypeAdapter<AppUser, AppUserDto>.Map.Invoke(item.AppUser),
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    LoginProvider = item.LoginProvider,
                    Name = item.Name,
                    Value = item.Value
                });
            }
            return result;
            
        }
        
        private static ICollection<RefreshTokenDto> funcMain10(ICollection<RefreshToken> p14)
        {
            if (p14 == null)
            {
                return null;
            }
            ICollection<RefreshTokenDto> result = new List<RefreshTokenDto>(p14.Count);
            
            IEnumerator<RefreshToken> enumerator = p14.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                RefreshToken item = enumerator.Current;
                result.Add(item == null ? null : new RefreshTokenDto()
                {
                    UserId = item.UserId,
                    Token = item.Token,
                    JwtId = item.JwtId,
                    IsUsed = item.IsUsed,
                    IsRevoked = item.IsRevoked,
                    ExpiryDate = item.ExpiryDate,
                    Hash = item.Hash,
                    AppUser = TypeAdapter<AppUser, AppUserDto>.Map.Invoke(item.AppUser),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
    }
}