namespace AxialSystem.Covaluse.Core.Models.Stripe
{
    public class ProductModel
    {
        public string ProductId { get; set; }
        public string ProductName { get; set; }
    }
}
