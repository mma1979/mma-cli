using AxialSystem.Covaluse.Core.Database.Identity;

namespace AxialSystem.Covaluse.Core.Database.Identity
{
    public static partial class UserClaimMapper
    {
        public static UserClaimDto AdaptToDto(this UserClaim p1)
        {
            return p1 == null ? null : new UserClaimDto()
            {
                CreatedBy = p1.CreatedBy,
                CreatedDate = p1.CreatedDate,
                ModifiedBy = p1.ModifiedBy,
                ModifiedDate = p1.ModifiedDate,
                IsDeleted = p1.IsDeleted,
                DeletedBy = p1.DeletedBy,
                DeletedDate = p1.DeletedDate,
                Id = p1.Id,
                UserId = p1.UserId,
                ClaimType = p1.ClaimType,
                ClaimValue = p1.ClaimValue
            };
        }
        public static UserClaimDto AdaptTo(this UserClaim p2, UserClaimDto p3)
        {
            if (p2 == null)
            {
                return null;
            }
            UserClaimDto result = p3 ?? new UserClaimDto();
            
            result.CreatedBy = p2.CreatedBy;
            result.CreatedDate = p2.CreatedDate;
            result.ModifiedBy = p2.ModifiedBy;
            result.ModifiedDate = p2.ModifiedDate;
            result.IsDeleted = p2.IsDeleted;
            result.DeletedBy = p2.DeletedBy;
            result.DeletedDate = p2.DeletedDate;
            result.Id = p2.Id;
            result.UserId = p2.UserId;
            result.ClaimType = p2.ClaimType;
            result.ClaimValue = p2.ClaimValue;
            return result;
            
        }
    }
}