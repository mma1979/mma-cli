using System;

namespace AxialSystem.Covaluse.Core.Database.LogTables
{
    public partial class AppLogReadModel
    {
        public Guid Id { get; set; }
        public string Message { get; set; }
        public string MessageTemplate { get; set; }
        public string Level { get; set; }
        public DateTime TimeStamp { get; set; }
        public string Exception { get; set; }
        public string Properties { get; set; }
    }
}