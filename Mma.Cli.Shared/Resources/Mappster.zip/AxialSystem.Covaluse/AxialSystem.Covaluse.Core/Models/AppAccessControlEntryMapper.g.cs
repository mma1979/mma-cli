using System.Collections.Generic;
using AxialSystem.Covaluse.Core.Database.Identity;
using Mapster;

namespace AxialSystem.Covaluse.Core.Database.Identity
{
    public static partial class AppAccessControlEntryMapper
    {
        public static AppAccessControlEntryReadModel AdaptToReadModel(this AppAccessControlEntry p1)
        {
            return p1 == null ? null : new AppAccessControlEntryReadModel()
            {
                ResourcePattern = p1.ResourcePattern,
                PermissionPattern = p1.PermissionPattern,
                FeatureId = p1.FeatureId,
                Feature = funcMain1(p1.Feature),
                AppRoles = funcMain4(p1.AppRoles),
                AppUsers = funcMain14(p1.AppUsers),
                AppResource = funcMain24(p1.AppResource),
                ResourceId = p1.ResourceId,
                Id = p1.Id,
                CreatedBy = p1.CreatedBy,
                CreatedDate = p1.CreatedDate,
                ModifiedBy = p1.ModifiedBy,
                ModifiedDate = p1.ModifiedDate,
                IsDeleted = p1.IsDeleted,
                DeletedBy = p1.DeletedBy,
                DeletedDate = p1.DeletedDate
            };
        }
        public static AppAccessControlEntryReadModel AdaptTo(this AppAccessControlEntry p27, AppAccessControlEntryReadModel p28)
        {
            if (p27 == null)
            {
                return null;
            }
            AppAccessControlEntryReadModel result = p28 ?? new AppAccessControlEntryReadModel();
            
            result.ResourcePattern = p27.ResourcePattern;
            result.PermissionPattern = p27.PermissionPattern;
            result.FeatureId = p27.FeatureId;
            result.Feature = funcMain26(p27.Feature, result.Feature);
            result.AppRoles = funcMain29(p27.AppRoles, result.AppRoles);
            result.AppUsers = funcMain39(p27.AppUsers, result.AppUsers);
            result.AppResource = funcMain49(p27.AppResource, result.AppResource);
            result.ResourceId = p27.ResourceId;
            result.Id = p27.Id;
            result.CreatedBy = p27.CreatedBy;
            result.CreatedDate = p27.CreatedDate;
            result.ModifiedBy = p27.ModifiedBy;
            result.ModifiedDate = p27.ModifiedDate;
            result.IsDeleted = p27.IsDeleted;
            result.DeletedBy = p27.DeletedBy;
            result.DeletedDate = p27.DeletedDate;
            return result;
            
        }
        public static AppAccessControlEntryModifyModel AdaptToModifyModel(this AppAccessControlEntry p61)
        {
            return p61 == null ? null : new AppAccessControlEntryModifyModel()
            {
                ResourcePattern = p61.ResourcePattern,
                PermissionPattern = p61.PermissionPattern,
                FeatureId = p61.FeatureId,
                Feature = funcMain51(p61.Feature),
                AppRoles = funcMain71(p61.AppRoles),
                AppUsers = funcMain93(p61.AppUsers),
                AppResource = funcMain114(p61.AppResource),
                ResourceId = p61.ResourceId,
                Id = p61.Id,
                CreatedBy = p61.CreatedBy,
                CreatedDate = p61.CreatedDate,
                ModifiedBy = p61.ModifiedBy,
                ModifiedDate = p61.ModifiedDate,
                IsDeleted = p61.IsDeleted,
                DeletedBy = p61.DeletedBy,
                DeletedDate = p61.DeletedDate
            };
        }
        public static AppAccessControlEntryModifyModel AdaptTo(this AppAccessControlEntry p146, AppAccessControlEntryModifyModel p147)
        {
            if (p146 == null)
            {
                return null;
            }
            AppAccessControlEntryModifyModel result = p147 ?? new AppAccessControlEntryModifyModel();
            
            result.ResourcePattern = p146.ResourcePattern;
            result.PermissionPattern = p146.PermissionPattern;
            result.FeatureId = p146.FeatureId;
            result.Feature = funcMain135(p146.Feature, result.Feature);
            result.AppRoles = funcMain155(p146.AppRoles, result.AppRoles);
            result.AppUsers = funcMain177(p146.AppUsers, result.AppUsers);
            result.AppResource = funcMain198(p146.AppResource, result.AppResource);
            result.ResourceId = p146.ResourceId;
            result.Id = p146.Id;
            result.CreatedBy = p146.CreatedBy;
            result.CreatedDate = p146.CreatedDate;
            result.ModifiedBy = p146.ModifiedBy;
            result.ModifiedDate = p146.ModifiedDate;
            result.IsDeleted = p146.IsDeleted;
            result.DeletedBy = p146.DeletedBy;
            result.DeletedDate = p146.DeletedDate;
            return result;
            
        }
        
        private static AppFeatureReadModel funcMain1(AppFeature p2)
        {
            return p2 == null ? null : new AppFeatureReadModel()
            {
                Name = p2.Name,
                Description = p2.Description,
                IsEnabled = p2.IsEnabled,
                Scope = p2.Scope,
                FeatureFlags = funcMain2(p2.FeatureFlags),
                AccessControlEntries = funcMain3(p2.AccessControlEntries),
                Id = p2.Id,
                CreatedBy = p2.CreatedBy,
                CreatedDate = p2.CreatedDate,
                ModifiedBy = p2.ModifiedBy,
                ModifiedDate = p2.ModifiedDate,
                IsDeleted = p2.IsDeleted,
                DeletedBy = p2.DeletedBy,
                DeletedDate = p2.DeletedDate
            };
        }
        
        private static ICollection<AppRoleReadModel> funcMain4(ICollection<AppRole> p5)
        {
            if (p5 == null)
            {
                return null;
            }
            ICollection<AppRoleReadModel> result = new List<AppRoleReadModel>(p5.Count);
            
            IEnumerator<AppRole> enumerator = p5.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRole item = enumerator.Current;
                result.Add(funcMain5(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserReadModel> funcMain14(ICollection<AppUser> p15)
        {
            if (p15 == null)
            {
                return null;
            }
            ICollection<AppUserReadModel> result = new List<AppUserReadModel>(p15.Count);
            
            IEnumerator<AppUser> enumerator = p15.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUser item = enumerator.Current;
                result.Add(funcMain15(item));
            }
            return result;
            
        }
        
        private static AppResourceReadModel funcMain24(AppResource p25)
        {
            return p25 == null ? null : new AppResourceReadModel()
            {
                Url = p25.Url,
                Description = p25.Description,
                ResourceType = p25.ResourceType,
                AccessControlEntries = funcMain25(p25.AccessControlEntries),
                Id = p25.Id,
                CreatedBy = p25.CreatedBy,
                CreatedDate = p25.CreatedDate,
                ModifiedBy = p25.ModifiedBy,
                ModifiedDate = p25.ModifiedDate,
                IsDeleted = p25.IsDeleted,
                DeletedBy = p25.DeletedBy,
                DeletedDate = p25.DeletedDate
            };
        }
        
        private static AppFeatureReadModel funcMain26(AppFeature p29, AppFeatureReadModel p30)
        {
            if (p29 == null)
            {
                return null;
            }
            AppFeatureReadModel result = p30 ?? new AppFeatureReadModel();
            
            result.Name = p29.Name;
            result.Description = p29.Description;
            result.IsEnabled = p29.IsEnabled;
            result.Scope = p29.Scope;
            result.FeatureFlags = funcMain27(p29.FeatureFlags, result.FeatureFlags);
            result.AccessControlEntries = funcMain28(p29.AccessControlEntries, result.AccessControlEntries);
            result.Id = p29.Id;
            result.CreatedBy = p29.CreatedBy;
            result.CreatedDate = p29.CreatedDate;
            result.ModifiedBy = p29.ModifiedBy;
            result.ModifiedDate = p29.ModifiedDate;
            result.IsDeleted = p29.IsDeleted;
            result.DeletedBy = p29.DeletedBy;
            result.DeletedDate = p29.DeletedDate;
            return result;
            
        }
        
        private static ICollection<AppRoleReadModel> funcMain29(ICollection<AppRole> p35, ICollection<AppRoleReadModel> p36)
        {
            if (p35 == null)
            {
                return null;
            }
            ICollection<AppRoleReadModel> result = new List<AppRoleReadModel>(p35.Count);
            
            IEnumerator<AppRole> enumerator = p35.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRole item = enumerator.Current;
                result.Add(funcMain30(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserReadModel> funcMain39(ICollection<AppUser> p46, ICollection<AppUserReadModel> p47)
        {
            if (p46 == null)
            {
                return null;
            }
            ICollection<AppUserReadModel> result = new List<AppUserReadModel>(p46.Count);
            
            IEnumerator<AppUser> enumerator = p46.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUser item = enumerator.Current;
                result.Add(funcMain40(item));
            }
            return result;
            
        }
        
        private static AppResourceReadModel funcMain49(AppResource p57, AppResourceReadModel p58)
        {
            if (p57 == null)
            {
                return null;
            }
            AppResourceReadModel result = p58 ?? new AppResourceReadModel();
            
            result.Url = p57.Url;
            result.Description = p57.Description;
            result.ResourceType = p57.ResourceType;
            result.AccessControlEntries = funcMain50(p57.AccessControlEntries, result.AccessControlEntries);
            result.Id = p57.Id;
            result.CreatedBy = p57.CreatedBy;
            result.CreatedDate = p57.CreatedDate;
            result.ModifiedBy = p57.ModifiedBy;
            result.ModifiedDate = p57.ModifiedDate;
            result.IsDeleted = p57.IsDeleted;
            result.DeletedBy = p57.DeletedBy;
            result.DeletedDate = p57.DeletedDate;
            return result;
            
        }
        
        private static AppFeatureReadModel funcMain51(AppFeature p62)
        {
            return p62 == null ? null : new AppFeatureReadModel()
            {
                Name = p62.Name,
                Description = p62.Description,
                IsEnabled = p62.IsEnabled,
                Scope = p62.Scope,
                FeatureFlags = funcMain52(p62.FeatureFlags),
                AccessControlEntries = funcMain53(p62.AccessControlEntries),
                Id = p62.Id,
                CreatedBy = p62.CreatedBy,
                CreatedDate = p62.CreatedDate,
                ModifiedBy = p62.ModifiedBy,
                ModifiedDate = p62.ModifiedDate,
                IsDeleted = p62.IsDeleted,
                DeletedBy = p62.DeletedBy,
                DeletedDate = p62.DeletedDate
            };
        }
        
        private static ICollection<AppRoleReadModel> funcMain71(ICollection<AppRole> p82)
        {
            if (p82 == null)
            {
                return null;
            }
            ICollection<AppRoleReadModel> result = new List<AppRoleReadModel>(p82.Count);
            
            IEnumerator<AppRole> enumerator = p82.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRole item = enumerator.Current;
                result.Add(funcMain72(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserReadModel> funcMain93(ICollection<AppUser> p104)
        {
            if (p104 == null)
            {
                return null;
            }
            ICollection<AppUserReadModel> result = new List<AppUserReadModel>(p104.Count);
            
            IEnumerator<AppUser> enumerator = p104.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUser item = enumerator.Current;
                result.Add(funcMain94(item));
            }
            return result;
            
        }
        
        private static AppResourceReadModel funcMain114(AppResource p125)
        {
            return p125 == null ? null : new AppResourceReadModel()
            {
                Url = p125.Url,
                Description = p125.Description,
                ResourceType = p125.ResourceType,
                AccessControlEntries = funcMain115(p125.AccessControlEntries),
                Id = p125.Id,
                CreatedBy = p125.CreatedBy,
                CreatedDate = p125.CreatedDate,
                ModifiedBy = p125.ModifiedBy,
                ModifiedDate = p125.ModifiedDate,
                IsDeleted = p125.IsDeleted,
                DeletedBy = p125.DeletedBy,
                DeletedDate = p125.DeletedDate
            };
        }
        
        private static AppFeatureReadModel funcMain135(AppFeature p148, AppFeatureReadModel p149)
        {
            if (p148 == null)
            {
                return null;
            }
            AppFeatureReadModel result = p149 ?? new AppFeatureReadModel();
            
            result.Name = p148.Name;
            result.Description = p148.Description;
            result.IsEnabled = p148.IsEnabled;
            result.Scope = p148.Scope;
            result.FeatureFlags = funcMain136(p148.FeatureFlags, result.FeatureFlags);
            result.AccessControlEntries = funcMain137(p148.AccessControlEntries, result.AccessControlEntries);
            result.Id = p148.Id;
            result.CreatedBy = p148.CreatedBy;
            result.CreatedDate = p148.CreatedDate;
            result.ModifiedBy = p148.ModifiedBy;
            result.ModifiedDate = p148.ModifiedDate;
            result.IsDeleted = p148.IsDeleted;
            result.DeletedBy = p148.DeletedBy;
            result.DeletedDate = p148.DeletedDate;
            return result;
            
        }
        
        private static ICollection<AppRoleReadModel> funcMain155(ICollection<AppRole> p171, ICollection<AppRoleReadModel> p172)
        {
            if (p171 == null)
            {
                return null;
            }
            ICollection<AppRoleReadModel> result = new List<AppRoleReadModel>(p171.Count);
            
            IEnumerator<AppRole> enumerator = p171.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRole item = enumerator.Current;
                result.Add(funcMain156(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserReadModel> funcMain177(ICollection<AppUser> p194, ICollection<AppUserReadModel> p195)
        {
            if (p194 == null)
            {
                return null;
            }
            ICollection<AppUserReadModel> result = new List<AppUserReadModel>(p194.Count);
            
            IEnumerator<AppUser> enumerator = p194.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUser item = enumerator.Current;
                result.Add(funcMain178(item));
            }
            return result;
            
        }
        
        private static AppResourceReadModel funcMain198(AppResource p216, AppResourceReadModel p217)
        {
            if (p216 == null)
            {
                return null;
            }
            AppResourceReadModel result = p217 ?? new AppResourceReadModel();
            
            result.Url = p216.Url;
            result.Description = p216.Description;
            result.ResourceType = p216.ResourceType;
            result.AccessControlEntries = funcMain199(p216.AccessControlEntries, result.AccessControlEntries);
            result.Id = p216.Id;
            result.CreatedBy = p216.CreatedBy;
            result.CreatedDate = p216.CreatedDate;
            result.ModifiedBy = p216.ModifiedBy;
            result.ModifiedDate = p216.ModifiedDate;
            result.IsDeleted = p216.IsDeleted;
            result.DeletedBy = p216.DeletedBy;
            result.DeletedDate = p216.DeletedDate;
            return result;
            
        }
        
        private static ICollection<AppFeatureFlagReadModel> funcMain2(ICollection<AppFeatureFlag> p3)
        {
            if (p3 == null)
            {
                return null;
            }
            ICollection<AppFeatureFlagReadModel> result = new List<AppFeatureFlagReadModel>(p3.Count);
            
            IEnumerator<AppFeatureFlag> enumerator = p3.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppFeatureFlag item = enumerator.Current;
                result.Add(item == null ? null : new AppFeatureFlagReadModel()
                {
                    FeatureId = item.FeatureId,
                    ScopeIdentifier = item.ScopeIdentifier,
                    IsEnabled = item.IsEnabled,
                    Feature = TypeAdapter<AppFeature, AppFeatureReadModel>.Map.Invoke(item.Feature),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static ICollection<AppAccessControlEntryReadModel> funcMain3(ICollection<AppAccessControlEntry> p4)
        {
            if (p4 == null)
            {
                return null;
            }
            ICollection<AppAccessControlEntryReadModel> result = new List<AppAccessControlEntryReadModel>(p4.Count);
            
            IEnumerator<AppAccessControlEntry> enumerator = p4.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppAccessControlEntry item = enumerator.Current;
                result.Add(TypeAdapter<AppAccessControlEntry, AppAccessControlEntryReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static AppRoleReadModel funcMain5(AppRole p6)
        {
            return p6 == null ? null : new AppRoleReadModel()
            {
                CreatedBy = p6.CreatedBy,
                CreatedDate = p6.CreatedDate,
                ModifiedBy = p6.ModifiedBy,
                ModifiedDate = p6.ModifiedDate,
                IsDeleted = p6.IsDeleted,
                DeletedBy = p6.DeletedBy,
                DeletedDate = p6.DeletedDate,
                AppUserRoles = funcMain6(p6.AppUserRoles),
                AppRoleClaims = funcMain12(p6.AppRoleClaims),
                AccessControlEntries = funcMain13(p6.AccessControlEntries),
                Hash = p6.Hash,
                Id = p6.Id,
                Name = p6.Name,
                NormalizedName = p6.NormalizedName,
                ConcurrencyStamp = p6.ConcurrencyStamp
            };
        }
        
        private static AppUserReadModel funcMain15(AppUser p16)
        {
            return p16 == null ? null : new AppUserReadModel()
            {
                Hash = p16.Hash,
                FirstName = p16.FirstName,
                LastName = p16.LastName,
                Mobile = p16.Mobile,
                CountryCode = p16.CountryCode,
                TwoFactorMethod = p16.TwoFactorMethod,
                CreatedBy = p16.CreatedBy,
                CreatedDate = p16.CreatedDate,
                ModifiedBy = p16.ModifiedBy,
                ModifiedDate = p16.ModifiedDate,
                IsDeleted = p16.IsDeleted,
                DeletedBy = p16.DeletedBy,
                DeletedDate = p16.DeletedDate,
                MembershipType = p16.MembershipType,
                UserRoles = funcMain16(p16.UserRoles),
                UserTokens = funcMain21(p16.UserTokens),
                RefreshTokens = funcMain22(p16.RefreshTokens),
                AccessControlEntries = funcMain23(p16.AccessControlEntries),
                Id = p16.Id,
                UserName = p16.UserName,
                NormalizedUserName = p16.NormalizedUserName,
                Email = p16.Email,
                NormalizedEmail = p16.NormalizedEmail,
                EmailConfirmed = p16.EmailConfirmed,
                PasswordHash = p16.PasswordHash,
                SecurityStamp = p16.SecurityStamp,
                ConcurrencyStamp = p16.ConcurrencyStamp,
                PhoneNumber = p16.PhoneNumber,
                PhoneNumberConfirmed = p16.PhoneNumberConfirmed,
                TwoFactorEnabled = p16.TwoFactorEnabled,
                LockoutEnd = p16.LockoutEnd,
                LockoutEnabled = p16.LockoutEnabled,
                AccessFailedCount = p16.AccessFailedCount
            };
        }
        
        private static ICollection<AppAccessControlEntryReadModel> funcMain25(ICollection<AppAccessControlEntry> p26)
        {
            if (p26 == null)
            {
                return null;
            }
            ICollection<AppAccessControlEntryReadModel> result = new List<AppAccessControlEntryReadModel>(p26.Count);
            
            IEnumerator<AppAccessControlEntry> enumerator = p26.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppAccessControlEntry item = enumerator.Current;
                result.Add(TypeAdapter<AppAccessControlEntry, AppAccessControlEntryReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static ICollection<AppFeatureFlagReadModel> funcMain27(ICollection<AppFeatureFlag> p31, ICollection<AppFeatureFlagReadModel> p32)
        {
            if (p31 == null)
            {
                return null;
            }
            ICollection<AppFeatureFlagReadModel> result = new List<AppFeatureFlagReadModel>(p31.Count);
            
            IEnumerator<AppFeatureFlag> enumerator = p31.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppFeatureFlag item = enumerator.Current;
                result.Add(item == null ? null : new AppFeatureFlagReadModel()
                {
                    FeatureId = item.FeatureId,
                    ScopeIdentifier = item.ScopeIdentifier,
                    IsEnabled = item.IsEnabled,
                    Feature = TypeAdapter<AppFeature, AppFeatureReadModel>.Map.Invoke(item.Feature),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static ICollection<AppAccessControlEntryReadModel> funcMain28(ICollection<AppAccessControlEntry> p33, ICollection<AppAccessControlEntryReadModel> p34)
        {
            if (p33 == null)
            {
                return null;
            }
            ICollection<AppAccessControlEntryReadModel> result = new List<AppAccessControlEntryReadModel>(p33.Count);
            
            IEnumerator<AppAccessControlEntry> enumerator = p33.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppAccessControlEntry item = enumerator.Current;
                result.Add(TypeAdapter<AppAccessControlEntry, AppAccessControlEntryReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static AppRoleReadModel funcMain30(AppRole p37)
        {
            return p37 == null ? null : new AppRoleReadModel()
            {
                CreatedBy = p37.CreatedBy,
                CreatedDate = p37.CreatedDate,
                ModifiedBy = p37.ModifiedBy,
                ModifiedDate = p37.ModifiedDate,
                IsDeleted = p37.IsDeleted,
                DeletedBy = p37.DeletedBy,
                DeletedDate = p37.DeletedDate,
                AppUserRoles = funcMain31(p37.AppUserRoles),
                AppRoleClaims = funcMain37(p37.AppRoleClaims),
                AccessControlEntries = funcMain38(p37.AccessControlEntries),
                Hash = p37.Hash,
                Id = p37.Id,
                Name = p37.Name,
                NormalizedName = p37.NormalizedName,
                ConcurrencyStamp = p37.ConcurrencyStamp
            };
        }
        
        private static AppUserReadModel funcMain40(AppUser p48)
        {
            return p48 == null ? null : new AppUserReadModel()
            {
                Hash = p48.Hash,
                FirstName = p48.FirstName,
                LastName = p48.LastName,
                Mobile = p48.Mobile,
                CountryCode = p48.CountryCode,
                TwoFactorMethod = p48.TwoFactorMethod,
                CreatedBy = p48.CreatedBy,
                CreatedDate = p48.CreatedDate,
                ModifiedBy = p48.ModifiedBy,
                ModifiedDate = p48.ModifiedDate,
                IsDeleted = p48.IsDeleted,
                DeletedBy = p48.DeletedBy,
                DeletedDate = p48.DeletedDate,
                MembershipType = p48.MembershipType,
                UserRoles = funcMain41(p48.UserRoles),
                UserTokens = funcMain46(p48.UserTokens),
                RefreshTokens = funcMain47(p48.RefreshTokens),
                AccessControlEntries = funcMain48(p48.AccessControlEntries),
                Id = p48.Id,
                UserName = p48.UserName,
                NormalizedUserName = p48.NormalizedUserName,
                Email = p48.Email,
                NormalizedEmail = p48.NormalizedEmail,
                EmailConfirmed = p48.EmailConfirmed,
                PasswordHash = p48.PasswordHash,
                SecurityStamp = p48.SecurityStamp,
                ConcurrencyStamp = p48.ConcurrencyStamp,
                PhoneNumber = p48.PhoneNumber,
                PhoneNumberConfirmed = p48.PhoneNumberConfirmed,
                TwoFactorEnabled = p48.TwoFactorEnabled,
                LockoutEnd = p48.LockoutEnd,
                LockoutEnabled = p48.LockoutEnabled,
                AccessFailedCount = p48.AccessFailedCount
            };
        }
        
        private static ICollection<AppAccessControlEntryReadModel> funcMain50(ICollection<AppAccessControlEntry> p59, ICollection<AppAccessControlEntryReadModel> p60)
        {
            if (p59 == null)
            {
                return null;
            }
            ICollection<AppAccessControlEntryReadModel> result = new List<AppAccessControlEntryReadModel>(p59.Count);
            
            IEnumerator<AppAccessControlEntry> enumerator = p59.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppAccessControlEntry item = enumerator.Current;
                result.Add(TypeAdapter<AppAccessControlEntry, AppAccessControlEntryReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static ICollection<AppFeatureFlagReadModel> funcMain52(ICollection<AppFeatureFlag> p63)
        {
            if (p63 == null)
            {
                return null;
            }
            ICollection<AppFeatureFlagReadModel> result = new List<AppFeatureFlagReadModel>(p63.Count);
            
            IEnumerator<AppFeatureFlag> enumerator = p63.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppFeatureFlag item = enumerator.Current;
                result.Add(item == null ? null : new AppFeatureFlagReadModel()
                {
                    FeatureId = item.FeatureId,
                    ScopeIdentifier = item.ScopeIdentifier,
                    IsEnabled = item.IsEnabled,
                    Feature = TypeAdapter<AppFeature, AppFeatureReadModel>.Map.Invoke(item.Feature),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static ICollection<AppAccessControlEntryReadModel> funcMain53(ICollection<AppAccessControlEntry> p64)
        {
            if (p64 == null)
            {
                return null;
            }
            ICollection<AppAccessControlEntryReadModel> result = new List<AppAccessControlEntryReadModel>(p64.Count);
            
            IEnumerator<AppAccessControlEntry> enumerator = p64.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppAccessControlEntry item = enumerator.Current;
                result.Add(funcMain54(item));
            }
            return result;
            
        }
        
        private static AppRoleReadModel funcMain72(AppRole p83)
        {
            return p83 == null ? null : new AppRoleReadModel()
            {
                CreatedBy = p83.CreatedBy,
                CreatedDate = p83.CreatedDate,
                ModifiedBy = p83.ModifiedBy,
                ModifiedDate = p83.ModifiedDate,
                IsDeleted = p83.IsDeleted,
                DeletedBy = p83.DeletedBy,
                DeletedDate = p83.DeletedDate,
                AppUserRoles = funcMain73(p83.AppUserRoles),
                AppRoleClaims = funcMain83(p83.AppRoleClaims),
                AccessControlEntries = funcMain84(p83.AccessControlEntries),
                Hash = p83.Hash,
                Id = p83.Id,
                Name = p83.Name,
                NormalizedName = p83.NormalizedName,
                ConcurrencyStamp = p83.ConcurrencyStamp
            };
        }
        
        private static AppUserReadModel funcMain94(AppUser p105)
        {
            return p105 == null ? null : new AppUserReadModel()
            {
                Hash = p105.Hash,
                FirstName = p105.FirstName,
                LastName = p105.LastName,
                Mobile = p105.Mobile,
                CountryCode = p105.CountryCode,
                TwoFactorMethod = p105.TwoFactorMethod,
                CreatedBy = p105.CreatedBy,
                CreatedDate = p105.CreatedDate,
                ModifiedBy = p105.ModifiedBy,
                ModifiedDate = p105.ModifiedDate,
                IsDeleted = p105.IsDeleted,
                DeletedBy = p105.DeletedBy,
                DeletedDate = p105.DeletedDate,
                MembershipType = p105.MembershipType,
                UserRoles = funcMain95(p105.UserRoles),
                UserTokens = funcMain104(p105.UserTokens),
                RefreshTokens = funcMain105(p105.RefreshTokens),
                AccessControlEntries = funcMain106(p105.AccessControlEntries),
                Id = p105.Id,
                UserName = p105.UserName,
                NormalizedUserName = p105.NormalizedUserName,
                Email = p105.Email,
                NormalizedEmail = p105.NormalizedEmail,
                EmailConfirmed = p105.EmailConfirmed,
                PasswordHash = p105.PasswordHash,
                SecurityStamp = p105.SecurityStamp,
                ConcurrencyStamp = p105.ConcurrencyStamp,
                PhoneNumber = p105.PhoneNumber,
                PhoneNumberConfirmed = p105.PhoneNumberConfirmed,
                TwoFactorEnabled = p105.TwoFactorEnabled,
                LockoutEnd = p105.LockoutEnd,
                LockoutEnabled = p105.LockoutEnabled,
                AccessFailedCount = p105.AccessFailedCount
            };
        }
        
        private static ICollection<AppAccessControlEntryReadModel> funcMain115(ICollection<AppAccessControlEntry> p126)
        {
            if (p126 == null)
            {
                return null;
            }
            ICollection<AppAccessControlEntryReadModel> result = new List<AppAccessControlEntryReadModel>(p126.Count);
            
            IEnumerator<AppAccessControlEntry> enumerator = p126.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppAccessControlEntry item = enumerator.Current;
                result.Add(funcMain116(item));
            }
            return result;
            
        }
        
        private static ICollection<AppFeatureFlagReadModel> funcMain136(ICollection<AppFeatureFlag> p150, ICollection<AppFeatureFlagReadModel> p151)
        {
            if (p150 == null)
            {
                return null;
            }
            ICollection<AppFeatureFlagReadModel> result = new List<AppFeatureFlagReadModel>(p150.Count);
            
            IEnumerator<AppFeatureFlag> enumerator = p150.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppFeatureFlag item = enumerator.Current;
                result.Add(item == null ? null : new AppFeatureFlagReadModel()
                {
                    FeatureId = item.FeatureId,
                    ScopeIdentifier = item.ScopeIdentifier,
                    IsEnabled = item.IsEnabled,
                    Feature = TypeAdapter<AppFeature, AppFeatureReadModel>.Map.Invoke(item.Feature),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static ICollection<AppAccessControlEntryReadModel> funcMain137(ICollection<AppAccessControlEntry> p152, ICollection<AppAccessControlEntryReadModel> p153)
        {
            if (p152 == null)
            {
                return null;
            }
            ICollection<AppAccessControlEntryReadModel> result = new List<AppAccessControlEntryReadModel>(p152.Count);
            
            IEnumerator<AppAccessControlEntry> enumerator = p152.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppAccessControlEntry item = enumerator.Current;
                result.Add(funcMain138(item));
            }
            return result;
            
        }
        
        private static AppRoleReadModel funcMain156(AppRole p173)
        {
            return p173 == null ? null : new AppRoleReadModel()
            {
                CreatedBy = p173.CreatedBy,
                CreatedDate = p173.CreatedDate,
                ModifiedBy = p173.ModifiedBy,
                ModifiedDate = p173.ModifiedDate,
                IsDeleted = p173.IsDeleted,
                DeletedBy = p173.DeletedBy,
                DeletedDate = p173.DeletedDate,
                AppUserRoles = funcMain157(p173.AppUserRoles),
                AppRoleClaims = funcMain167(p173.AppRoleClaims),
                AccessControlEntries = funcMain168(p173.AccessControlEntries),
                Hash = p173.Hash,
                Id = p173.Id,
                Name = p173.Name,
                NormalizedName = p173.NormalizedName,
                ConcurrencyStamp = p173.ConcurrencyStamp
            };
        }
        
        private static AppUserReadModel funcMain178(AppUser p196)
        {
            return p196 == null ? null : new AppUserReadModel()
            {
                Hash = p196.Hash,
                FirstName = p196.FirstName,
                LastName = p196.LastName,
                Mobile = p196.Mobile,
                CountryCode = p196.CountryCode,
                TwoFactorMethod = p196.TwoFactorMethod,
                CreatedBy = p196.CreatedBy,
                CreatedDate = p196.CreatedDate,
                ModifiedBy = p196.ModifiedBy,
                ModifiedDate = p196.ModifiedDate,
                IsDeleted = p196.IsDeleted,
                DeletedBy = p196.DeletedBy,
                DeletedDate = p196.DeletedDate,
                MembershipType = p196.MembershipType,
                UserRoles = funcMain179(p196.UserRoles),
                UserTokens = funcMain188(p196.UserTokens),
                RefreshTokens = funcMain189(p196.RefreshTokens),
                AccessControlEntries = funcMain190(p196.AccessControlEntries),
                Id = p196.Id,
                UserName = p196.UserName,
                NormalizedUserName = p196.NormalizedUserName,
                Email = p196.Email,
                NormalizedEmail = p196.NormalizedEmail,
                EmailConfirmed = p196.EmailConfirmed,
                PasswordHash = p196.PasswordHash,
                SecurityStamp = p196.SecurityStamp,
                ConcurrencyStamp = p196.ConcurrencyStamp,
                PhoneNumber = p196.PhoneNumber,
                PhoneNumberConfirmed = p196.PhoneNumberConfirmed,
                TwoFactorEnabled = p196.TwoFactorEnabled,
                LockoutEnd = p196.LockoutEnd,
                LockoutEnabled = p196.LockoutEnabled,
                AccessFailedCount = p196.AccessFailedCount
            };
        }
        
        private static ICollection<AppAccessControlEntryReadModel> funcMain199(ICollection<AppAccessControlEntry> p218, ICollection<AppAccessControlEntryReadModel> p219)
        {
            if (p218 == null)
            {
                return null;
            }
            ICollection<AppAccessControlEntryReadModel> result = new List<AppAccessControlEntryReadModel>(p218.Count);
            
            IEnumerator<AppAccessControlEntry> enumerator = p218.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppAccessControlEntry item = enumerator.Current;
                result.Add(funcMain200(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain6(ICollection<AppUserRole> p7)
        {
            if (p7 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p7.Count);
            
            IEnumerator<AppUserRole> enumerator = p7.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(funcMain7(item));
            }
            return result;
            
        }
        
        private static ICollection<AppRoleClaimReadModel> funcMain12(ICollection<AppRoleClaim> p13)
        {
            if (p13 == null)
            {
                return null;
            }
            ICollection<AppRoleClaimReadModel> result = new List<AppRoleClaimReadModel>(p13.Count);
            
            IEnumerator<AppRoleClaim> enumerator = p13.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRoleClaim item = enumerator.Current;
                result.Add(item == null ? null : new AppRoleClaimReadModel()
                {
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Id = item.Id,
                    RoleId = item.RoleId,
                    ClaimType = item.ClaimType,
                    ClaimValue = item.ClaimValue
                });
            }
            return result;
            
        }
        
        private static ICollection<AppAccessControlEntryReadModel> funcMain13(ICollection<AppAccessControlEntry> p14)
        {
            if (p14 == null)
            {
                return null;
            }
            ICollection<AppAccessControlEntryReadModel> result = new List<AppAccessControlEntryReadModel>(p14.Count);
            
            IEnumerator<AppAccessControlEntry> enumerator = p14.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppAccessControlEntry item = enumerator.Current;
                result.Add(TypeAdapter<AppAccessControlEntry, AppAccessControlEntryReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain16(ICollection<AppUserRole> p17)
        {
            if (p17 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p17.Count);
            
            IEnumerator<AppUserRole> enumerator = p17.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(funcMain17(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserTokenReadModel> funcMain21(ICollection<AppUserToken> p22)
        {
            if (p22 == null)
            {
                return null;
            }
            ICollection<AppUserTokenReadModel> result = new List<AppUserTokenReadModel>(p22.Count);
            
            IEnumerator<AppUserToken> enumerator = p22.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserToken item = enumerator.Current;
                result.Add(item == null ? null : new AppUserTokenReadModel()
                {
                    Token = item.Token,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    LoginProvider = item.LoginProvider,
                    Name = item.Name,
                    Value = item.Value
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRefreshTokenReadModel> funcMain22(ICollection<AppRefreshToken> p23)
        {
            if (p23 == null)
            {
                return null;
            }
            ICollection<AppRefreshTokenReadModel> result = new List<AppRefreshTokenReadModel>(p23.Count);
            
            IEnumerator<AppRefreshToken> enumerator = p23.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRefreshToken item = enumerator.Current;
                result.Add(item == null ? null : new AppRefreshTokenReadModel()
                {
                    UserId = item.UserId,
                    Token = item.Token,
                    JwtId = item.JwtId,
                    IsUsed = item.IsUsed,
                    IsRevoked = item.IsRevoked,
                    ExpiryDate = item.ExpiryDate,
                    Hash = item.Hash,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static ICollection<AppAccessControlEntryReadModel> funcMain23(ICollection<AppAccessControlEntry> p24)
        {
            if (p24 == null)
            {
                return null;
            }
            ICollection<AppAccessControlEntryReadModel> result = new List<AppAccessControlEntryReadModel>(p24.Count);
            
            IEnumerator<AppAccessControlEntry> enumerator = p24.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppAccessControlEntry item = enumerator.Current;
                result.Add(TypeAdapter<AppAccessControlEntry, AppAccessControlEntryReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain31(ICollection<AppUserRole> p38)
        {
            if (p38 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p38.Count);
            
            IEnumerator<AppUserRole> enumerator = p38.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(funcMain32(item));
            }
            return result;
            
        }
        
        private static ICollection<AppRoleClaimReadModel> funcMain37(ICollection<AppRoleClaim> p44)
        {
            if (p44 == null)
            {
                return null;
            }
            ICollection<AppRoleClaimReadModel> result = new List<AppRoleClaimReadModel>(p44.Count);
            
            IEnumerator<AppRoleClaim> enumerator = p44.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRoleClaim item = enumerator.Current;
                result.Add(item == null ? null : new AppRoleClaimReadModel()
                {
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Id = item.Id,
                    RoleId = item.RoleId,
                    ClaimType = item.ClaimType,
                    ClaimValue = item.ClaimValue
                });
            }
            return result;
            
        }
        
        private static ICollection<AppAccessControlEntryReadModel> funcMain38(ICollection<AppAccessControlEntry> p45)
        {
            if (p45 == null)
            {
                return null;
            }
            ICollection<AppAccessControlEntryReadModel> result = new List<AppAccessControlEntryReadModel>(p45.Count);
            
            IEnumerator<AppAccessControlEntry> enumerator = p45.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppAccessControlEntry item = enumerator.Current;
                result.Add(TypeAdapter<AppAccessControlEntry, AppAccessControlEntryReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain41(ICollection<AppUserRole> p49)
        {
            if (p49 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p49.Count);
            
            IEnumerator<AppUserRole> enumerator = p49.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(funcMain42(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserTokenReadModel> funcMain46(ICollection<AppUserToken> p54)
        {
            if (p54 == null)
            {
                return null;
            }
            ICollection<AppUserTokenReadModel> result = new List<AppUserTokenReadModel>(p54.Count);
            
            IEnumerator<AppUserToken> enumerator = p54.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserToken item = enumerator.Current;
                result.Add(item == null ? null : new AppUserTokenReadModel()
                {
                    Token = item.Token,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    LoginProvider = item.LoginProvider,
                    Name = item.Name,
                    Value = item.Value
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRefreshTokenReadModel> funcMain47(ICollection<AppRefreshToken> p55)
        {
            if (p55 == null)
            {
                return null;
            }
            ICollection<AppRefreshTokenReadModel> result = new List<AppRefreshTokenReadModel>(p55.Count);
            
            IEnumerator<AppRefreshToken> enumerator = p55.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRefreshToken item = enumerator.Current;
                result.Add(item == null ? null : new AppRefreshTokenReadModel()
                {
                    UserId = item.UserId,
                    Token = item.Token,
                    JwtId = item.JwtId,
                    IsUsed = item.IsUsed,
                    IsRevoked = item.IsRevoked,
                    ExpiryDate = item.ExpiryDate,
                    Hash = item.Hash,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static ICollection<AppAccessControlEntryReadModel> funcMain48(ICollection<AppAccessControlEntry> p56)
        {
            if (p56 == null)
            {
                return null;
            }
            ICollection<AppAccessControlEntryReadModel> result = new List<AppAccessControlEntryReadModel>(p56.Count);
            
            IEnumerator<AppAccessControlEntry> enumerator = p56.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppAccessControlEntry item = enumerator.Current;
                result.Add(TypeAdapter<AppAccessControlEntry, AppAccessControlEntryReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static AppAccessControlEntryReadModel funcMain54(AppAccessControlEntry p65)
        {
            return p65 == null ? null : new AppAccessControlEntryReadModel()
            {
                ResourcePattern = p65.ResourcePattern,
                PermissionPattern = p65.PermissionPattern,
                FeatureId = p65.FeatureId,
                Feature = TypeAdapter<AppFeature, AppFeatureReadModel>.Map.Invoke(p65.Feature),
                AppRoles = funcMain55(p65.AppRoles),
                AppUsers = funcMain63(p65.AppUsers),
                AppResource = p65.AppResource == null ? null : new AppResourceReadModel()
                {
                    Url = p65.AppResource.Url,
                    Description = p65.AppResource.Description,
                    ResourceType = p65.AppResource.ResourceType,
                    AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p65.AppResource.AccessControlEntries),
                    Id = p65.AppResource.Id,
                    CreatedBy = p65.AppResource.CreatedBy,
                    CreatedDate = p65.AppResource.CreatedDate,
                    ModifiedBy = p65.AppResource.ModifiedBy,
                    ModifiedDate = p65.AppResource.ModifiedDate,
                    IsDeleted = p65.AppResource.IsDeleted,
                    DeletedBy = p65.AppResource.DeletedBy,
                    DeletedDate = p65.AppResource.DeletedDate
                },
                ResourceId = p65.ResourceId,
                Id = p65.Id,
                CreatedBy = p65.CreatedBy,
                CreatedDate = p65.CreatedDate,
                ModifiedBy = p65.ModifiedBy,
                ModifiedDate = p65.ModifiedDate,
                IsDeleted = p65.IsDeleted,
                DeletedBy = p65.DeletedBy,
                DeletedDate = p65.DeletedDate
            };
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain73(ICollection<AppUserRole> p84)
        {
            if (p84 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p84.Count);
            
            IEnumerator<AppUserRole> enumerator = p84.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(funcMain74(item));
            }
            return result;
            
        }
        
        private static ICollection<AppRoleClaimReadModel> funcMain83(ICollection<AppRoleClaim> p94)
        {
            if (p94 == null)
            {
                return null;
            }
            ICollection<AppRoleClaimReadModel> result = new List<AppRoleClaimReadModel>(p94.Count);
            
            IEnumerator<AppRoleClaim> enumerator = p94.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRoleClaim item = enumerator.Current;
                result.Add(item == null ? null : new AppRoleClaimReadModel()
                {
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Id = item.Id,
                    RoleId = item.RoleId,
                    ClaimType = item.ClaimType,
                    ClaimValue = item.ClaimValue
                });
            }
            return result;
            
        }
        
        private static ICollection<AppAccessControlEntryReadModel> funcMain84(ICollection<AppAccessControlEntry> p95)
        {
            if (p95 == null)
            {
                return null;
            }
            ICollection<AppAccessControlEntryReadModel> result = new List<AppAccessControlEntryReadModel>(p95.Count);
            
            IEnumerator<AppAccessControlEntry> enumerator = p95.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppAccessControlEntry item = enumerator.Current;
                result.Add(funcMain85(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain95(ICollection<AppUserRole> p106)
        {
            if (p106 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p106.Count);
            
            IEnumerator<AppUserRole> enumerator = p106.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(funcMain96(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserTokenReadModel> funcMain104(ICollection<AppUserToken> p115)
        {
            if (p115 == null)
            {
                return null;
            }
            ICollection<AppUserTokenReadModel> result = new List<AppUserTokenReadModel>(p115.Count);
            
            IEnumerator<AppUserToken> enumerator = p115.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserToken item = enumerator.Current;
                result.Add(item == null ? null : new AppUserTokenReadModel()
                {
                    Token = item.Token,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    LoginProvider = item.LoginProvider,
                    Name = item.Name,
                    Value = item.Value
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRefreshTokenReadModel> funcMain105(ICollection<AppRefreshToken> p116)
        {
            if (p116 == null)
            {
                return null;
            }
            ICollection<AppRefreshTokenReadModel> result = new List<AppRefreshTokenReadModel>(p116.Count);
            
            IEnumerator<AppRefreshToken> enumerator = p116.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRefreshToken item = enumerator.Current;
                result.Add(item == null ? null : new AppRefreshTokenReadModel()
                {
                    UserId = item.UserId,
                    Token = item.Token,
                    JwtId = item.JwtId,
                    IsUsed = item.IsUsed,
                    IsRevoked = item.IsRevoked,
                    ExpiryDate = item.ExpiryDate,
                    Hash = item.Hash,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static ICollection<AppAccessControlEntryReadModel> funcMain106(ICollection<AppAccessControlEntry> p117)
        {
            if (p117 == null)
            {
                return null;
            }
            ICollection<AppAccessControlEntryReadModel> result = new List<AppAccessControlEntryReadModel>(p117.Count);
            
            IEnumerator<AppAccessControlEntry> enumerator = p117.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppAccessControlEntry item = enumerator.Current;
                result.Add(funcMain107(item));
            }
            return result;
            
        }
        
        private static AppAccessControlEntryReadModel funcMain116(AppAccessControlEntry p127)
        {
            return p127 == null ? null : new AppAccessControlEntryReadModel()
            {
                ResourcePattern = p127.ResourcePattern,
                PermissionPattern = p127.PermissionPattern,
                FeatureId = p127.FeatureId,
                Feature = funcMain117(p127.Feature),
                AppRoles = funcMain119(p127.AppRoles),
                AppUsers = funcMain127(p127.AppUsers),
                AppResource = TypeAdapter<AppResource, AppResourceReadModel>.Map.Invoke(p127.AppResource),
                ResourceId = p127.ResourceId,
                Id = p127.Id,
                CreatedBy = p127.CreatedBy,
                CreatedDate = p127.CreatedDate,
                ModifiedBy = p127.ModifiedBy,
                ModifiedDate = p127.ModifiedDate,
                IsDeleted = p127.IsDeleted,
                DeletedBy = p127.DeletedBy,
                DeletedDate = p127.DeletedDate
            };
        }
        
        private static AppAccessControlEntryReadModel funcMain138(AppAccessControlEntry p154)
        {
            return p154 == null ? null : new AppAccessControlEntryReadModel()
            {
                ResourcePattern = p154.ResourcePattern,
                PermissionPattern = p154.PermissionPattern,
                FeatureId = p154.FeatureId,
                Feature = TypeAdapter<AppFeature, AppFeatureReadModel>.Map.Invoke(p154.Feature),
                AppRoles = funcMain139(p154.AppRoles),
                AppUsers = funcMain147(p154.AppUsers),
                AppResource = p154.AppResource == null ? null : new AppResourceReadModel()
                {
                    Url = p154.AppResource.Url,
                    Description = p154.AppResource.Description,
                    ResourceType = p154.AppResource.ResourceType,
                    AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p154.AppResource.AccessControlEntries),
                    Id = p154.AppResource.Id,
                    CreatedBy = p154.AppResource.CreatedBy,
                    CreatedDate = p154.AppResource.CreatedDate,
                    ModifiedBy = p154.AppResource.ModifiedBy,
                    ModifiedDate = p154.AppResource.ModifiedDate,
                    IsDeleted = p154.AppResource.IsDeleted,
                    DeletedBy = p154.AppResource.DeletedBy,
                    DeletedDate = p154.AppResource.DeletedDate
                },
                ResourceId = p154.ResourceId,
                Id = p154.Id,
                CreatedBy = p154.CreatedBy,
                CreatedDate = p154.CreatedDate,
                ModifiedBy = p154.ModifiedBy,
                ModifiedDate = p154.ModifiedDate,
                IsDeleted = p154.IsDeleted,
                DeletedBy = p154.DeletedBy,
                DeletedDate = p154.DeletedDate
            };
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain157(ICollection<AppUserRole> p174)
        {
            if (p174 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p174.Count);
            
            IEnumerator<AppUserRole> enumerator = p174.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(funcMain158(item));
            }
            return result;
            
        }
        
        private static ICollection<AppRoleClaimReadModel> funcMain167(ICollection<AppRoleClaim> p184)
        {
            if (p184 == null)
            {
                return null;
            }
            ICollection<AppRoleClaimReadModel> result = new List<AppRoleClaimReadModel>(p184.Count);
            
            IEnumerator<AppRoleClaim> enumerator = p184.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRoleClaim item = enumerator.Current;
                result.Add(item == null ? null : new AppRoleClaimReadModel()
                {
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Id = item.Id,
                    RoleId = item.RoleId,
                    ClaimType = item.ClaimType,
                    ClaimValue = item.ClaimValue
                });
            }
            return result;
            
        }
        
        private static ICollection<AppAccessControlEntryReadModel> funcMain168(ICollection<AppAccessControlEntry> p185)
        {
            if (p185 == null)
            {
                return null;
            }
            ICollection<AppAccessControlEntryReadModel> result = new List<AppAccessControlEntryReadModel>(p185.Count);
            
            IEnumerator<AppAccessControlEntry> enumerator = p185.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppAccessControlEntry item = enumerator.Current;
                result.Add(funcMain169(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain179(ICollection<AppUserRole> p197)
        {
            if (p197 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p197.Count);
            
            IEnumerator<AppUserRole> enumerator = p197.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(funcMain180(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserTokenReadModel> funcMain188(ICollection<AppUserToken> p206)
        {
            if (p206 == null)
            {
                return null;
            }
            ICollection<AppUserTokenReadModel> result = new List<AppUserTokenReadModel>(p206.Count);
            
            IEnumerator<AppUserToken> enumerator = p206.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserToken item = enumerator.Current;
                result.Add(item == null ? null : new AppUserTokenReadModel()
                {
                    Token = item.Token,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    LoginProvider = item.LoginProvider,
                    Name = item.Name,
                    Value = item.Value
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRefreshTokenReadModel> funcMain189(ICollection<AppRefreshToken> p207)
        {
            if (p207 == null)
            {
                return null;
            }
            ICollection<AppRefreshTokenReadModel> result = new List<AppRefreshTokenReadModel>(p207.Count);
            
            IEnumerator<AppRefreshToken> enumerator = p207.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRefreshToken item = enumerator.Current;
                result.Add(item == null ? null : new AppRefreshTokenReadModel()
                {
                    UserId = item.UserId,
                    Token = item.Token,
                    JwtId = item.JwtId,
                    IsUsed = item.IsUsed,
                    IsRevoked = item.IsRevoked,
                    ExpiryDate = item.ExpiryDate,
                    Hash = item.Hash,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static ICollection<AppAccessControlEntryReadModel> funcMain190(ICollection<AppAccessControlEntry> p208)
        {
            if (p208 == null)
            {
                return null;
            }
            ICollection<AppAccessControlEntryReadModel> result = new List<AppAccessControlEntryReadModel>(p208.Count);
            
            IEnumerator<AppAccessControlEntry> enumerator = p208.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppAccessControlEntry item = enumerator.Current;
                result.Add(funcMain191(item));
            }
            return result;
            
        }
        
        private static AppAccessControlEntryReadModel funcMain200(AppAccessControlEntry p220)
        {
            return p220 == null ? null : new AppAccessControlEntryReadModel()
            {
                ResourcePattern = p220.ResourcePattern,
                PermissionPattern = p220.PermissionPattern,
                FeatureId = p220.FeatureId,
                Feature = funcMain201(p220.Feature),
                AppRoles = funcMain203(p220.AppRoles),
                AppUsers = funcMain211(p220.AppUsers),
                AppResource = TypeAdapter<AppResource, AppResourceReadModel>.Map.Invoke(p220.AppResource),
                ResourceId = p220.ResourceId,
                Id = p220.Id,
                CreatedBy = p220.CreatedBy,
                CreatedDate = p220.CreatedDate,
                ModifiedBy = p220.ModifiedBy,
                ModifiedDate = p220.ModifiedDate,
                IsDeleted = p220.IsDeleted,
                DeletedBy = p220.DeletedBy,
                DeletedDate = p220.DeletedDate
            };
        }
        
        private static AppUserRoleReadModel funcMain7(AppUserRole p8)
        {
            return p8 == null ? null : new AppUserRoleReadModel()
            {
                AppUser = funcMain8(p8.AppUser),
                AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(p8.AppRole),
                Hash = p8.Hash,
                CreatedBy = p8.CreatedBy,
                CreatedDate = p8.CreatedDate,
                ModifiedBy = p8.ModifiedBy,
                ModifiedDate = p8.ModifiedDate,
                IsDeleted = p8.IsDeleted,
                DeletedBy = p8.DeletedBy,
                DeletedDate = p8.DeletedDate,
                UserId = p8.UserId,
                RoleId = p8.RoleId
            };
        }
        
        private static AppUserRoleReadModel funcMain17(AppUserRole p18)
        {
            return p18 == null ? null : new AppUserRoleReadModel()
            {
                AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(p18.AppUser),
                AppRole = funcMain18(p18.AppRole),
                Hash = p18.Hash,
                CreatedBy = p18.CreatedBy,
                CreatedDate = p18.CreatedDate,
                ModifiedBy = p18.ModifiedBy,
                ModifiedDate = p18.ModifiedDate,
                IsDeleted = p18.IsDeleted,
                DeletedBy = p18.DeletedBy,
                DeletedDate = p18.DeletedDate,
                UserId = p18.UserId,
                RoleId = p18.RoleId
            };
        }
        
        private static AppUserRoleReadModel funcMain32(AppUserRole p39)
        {
            return p39 == null ? null : new AppUserRoleReadModel()
            {
                AppUser = funcMain33(p39.AppUser),
                AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(p39.AppRole),
                Hash = p39.Hash,
                CreatedBy = p39.CreatedBy,
                CreatedDate = p39.CreatedDate,
                ModifiedBy = p39.ModifiedBy,
                ModifiedDate = p39.ModifiedDate,
                IsDeleted = p39.IsDeleted,
                DeletedBy = p39.DeletedBy,
                DeletedDate = p39.DeletedDate,
                UserId = p39.UserId,
                RoleId = p39.RoleId
            };
        }
        
        private static AppUserRoleReadModel funcMain42(AppUserRole p50)
        {
            return p50 == null ? null : new AppUserRoleReadModel()
            {
                AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(p50.AppUser),
                AppRole = funcMain43(p50.AppRole),
                Hash = p50.Hash,
                CreatedBy = p50.CreatedBy,
                CreatedDate = p50.CreatedDate,
                ModifiedBy = p50.ModifiedBy,
                ModifiedDate = p50.ModifiedDate,
                IsDeleted = p50.IsDeleted,
                DeletedBy = p50.DeletedBy,
                DeletedDate = p50.DeletedDate,
                UserId = p50.UserId,
                RoleId = p50.RoleId
            };
        }
        
        private static ICollection<AppRoleReadModel> funcMain55(ICollection<AppRole> p66)
        {
            if (p66 == null)
            {
                return null;
            }
            ICollection<AppRoleReadModel> result = new List<AppRoleReadModel>(p66.Count);
            
            IEnumerator<AppRole> enumerator = p66.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRole item = enumerator.Current;
                result.Add(funcMain56(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserReadModel> funcMain63(ICollection<AppUser> p74)
        {
            if (p74 == null)
            {
                return null;
            }
            ICollection<AppUserReadModel> result = new List<AppUserReadModel>(p74.Count);
            
            IEnumerator<AppUser> enumerator = p74.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUser item = enumerator.Current;
                result.Add(funcMain64(item));
            }
            return result;
            
        }
        
        private static AppUserRoleReadModel funcMain74(AppUserRole p85)
        {
            return p85 == null ? null : new AppUserRoleReadModel()
            {
                AppUser = funcMain75(p85.AppUser),
                AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(p85.AppRole),
                Hash = p85.Hash,
                CreatedBy = p85.CreatedBy,
                CreatedDate = p85.CreatedDate,
                ModifiedBy = p85.ModifiedBy,
                ModifiedDate = p85.ModifiedDate,
                IsDeleted = p85.IsDeleted,
                DeletedBy = p85.DeletedBy,
                DeletedDate = p85.DeletedDate,
                UserId = p85.UserId,
                RoleId = p85.RoleId
            };
        }
        
        private static AppAccessControlEntryReadModel funcMain85(AppAccessControlEntry p96)
        {
            return p96 == null ? null : new AppAccessControlEntryReadModel()
            {
                ResourcePattern = p96.ResourcePattern,
                PermissionPattern = p96.PermissionPattern,
                FeatureId = p96.FeatureId,
                Feature = funcMain86(p96.Feature),
                AppRoles = TypeAdapter<ICollection<AppRole>, ICollection<AppRoleReadModel>>.Map.Invoke(p96.AppRoles),
                AppUsers = funcMain88(p96.AppUsers),
                AppResource = p96.AppResource == null ? null : new AppResourceReadModel()
                {
                    Url = p96.AppResource.Url,
                    Description = p96.AppResource.Description,
                    ResourceType = p96.AppResource.ResourceType,
                    AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p96.AppResource.AccessControlEntries),
                    Id = p96.AppResource.Id,
                    CreatedBy = p96.AppResource.CreatedBy,
                    CreatedDate = p96.AppResource.CreatedDate,
                    ModifiedBy = p96.AppResource.ModifiedBy,
                    ModifiedDate = p96.AppResource.ModifiedDate,
                    IsDeleted = p96.AppResource.IsDeleted,
                    DeletedBy = p96.AppResource.DeletedBy,
                    DeletedDate = p96.AppResource.DeletedDate
                },
                ResourceId = p96.ResourceId,
                Id = p96.Id,
                CreatedBy = p96.CreatedBy,
                CreatedDate = p96.CreatedDate,
                ModifiedBy = p96.ModifiedBy,
                ModifiedDate = p96.ModifiedDate,
                IsDeleted = p96.IsDeleted,
                DeletedBy = p96.DeletedBy,
                DeletedDate = p96.DeletedDate
            };
        }
        
        private static AppUserRoleReadModel funcMain96(AppUserRole p107)
        {
            return p107 == null ? null : new AppUserRoleReadModel()
            {
                AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(p107.AppUser),
                AppRole = funcMain97(p107.AppRole),
                Hash = p107.Hash,
                CreatedBy = p107.CreatedBy,
                CreatedDate = p107.CreatedDate,
                ModifiedBy = p107.ModifiedBy,
                ModifiedDate = p107.ModifiedDate,
                IsDeleted = p107.IsDeleted,
                DeletedBy = p107.DeletedBy,
                DeletedDate = p107.DeletedDate,
                UserId = p107.UserId,
                RoleId = p107.RoleId
            };
        }
        
        private static AppAccessControlEntryReadModel funcMain107(AppAccessControlEntry p118)
        {
            return p118 == null ? null : new AppAccessControlEntryReadModel()
            {
                ResourcePattern = p118.ResourcePattern,
                PermissionPattern = p118.PermissionPattern,
                FeatureId = p118.FeatureId,
                Feature = funcMain108(p118.Feature),
                AppRoles = funcMain110(p118.AppRoles),
                AppUsers = TypeAdapter<ICollection<AppUser>, ICollection<AppUserReadModel>>.Map.Invoke(p118.AppUsers),
                AppResource = p118.AppResource == null ? null : new AppResourceReadModel()
                {
                    Url = p118.AppResource.Url,
                    Description = p118.AppResource.Description,
                    ResourceType = p118.AppResource.ResourceType,
                    AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p118.AppResource.AccessControlEntries),
                    Id = p118.AppResource.Id,
                    CreatedBy = p118.AppResource.CreatedBy,
                    CreatedDate = p118.AppResource.CreatedDate,
                    ModifiedBy = p118.AppResource.ModifiedBy,
                    ModifiedDate = p118.AppResource.ModifiedDate,
                    IsDeleted = p118.AppResource.IsDeleted,
                    DeletedBy = p118.AppResource.DeletedBy,
                    DeletedDate = p118.AppResource.DeletedDate
                },
                ResourceId = p118.ResourceId,
                Id = p118.Id,
                CreatedBy = p118.CreatedBy,
                CreatedDate = p118.CreatedDate,
                ModifiedBy = p118.ModifiedBy,
                ModifiedDate = p118.ModifiedDate,
                IsDeleted = p118.IsDeleted,
                DeletedBy = p118.DeletedBy,
                DeletedDate = p118.DeletedDate
            };
        }
        
        private static AppFeatureReadModel funcMain117(AppFeature p128)
        {
            return p128 == null ? null : new AppFeatureReadModel()
            {
                Name = p128.Name,
                Description = p128.Description,
                IsEnabled = p128.IsEnabled,
                Scope = p128.Scope,
                FeatureFlags = funcMain118(p128.FeatureFlags),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p128.AccessControlEntries),
                Id = p128.Id,
                CreatedBy = p128.CreatedBy,
                CreatedDate = p128.CreatedDate,
                ModifiedBy = p128.ModifiedBy,
                ModifiedDate = p128.ModifiedDate,
                IsDeleted = p128.IsDeleted,
                DeletedBy = p128.DeletedBy,
                DeletedDate = p128.DeletedDate
            };
        }
        
        private static ICollection<AppRoleReadModel> funcMain119(ICollection<AppRole> p130)
        {
            if (p130 == null)
            {
                return null;
            }
            ICollection<AppRoleReadModel> result = new List<AppRoleReadModel>(p130.Count);
            
            IEnumerator<AppRole> enumerator = p130.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRole item = enumerator.Current;
                result.Add(funcMain120(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserReadModel> funcMain127(ICollection<AppUser> p138)
        {
            if (p138 == null)
            {
                return null;
            }
            ICollection<AppUserReadModel> result = new List<AppUserReadModel>(p138.Count);
            
            IEnumerator<AppUser> enumerator = p138.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUser item = enumerator.Current;
                result.Add(funcMain128(item));
            }
            return result;
            
        }
        
        private static ICollection<AppRoleReadModel> funcMain139(ICollection<AppRole> p155)
        {
            if (p155 == null)
            {
                return null;
            }
            ICollection<AppRoleReadModel> result = new List<AppRoleReadModel>(p155.Count);
            
            IEnumerator<AppRole> enumerator = p155.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRole item = enumerator.Current;
                result.Add(funcMain140(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserReadModel> funcMain147(ICollection<AppUser> p163)
        {
            if (p163 == null)
            {
                return null;
            }
            ICollection<AppUserReadModel> result = new List<AppUserReadModel>(p163.Count);
            
            IEnumerator<AppUser> enumerator = p163.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUser item = enumerator.Current;
                result.Add(funcMain148(item));
            }
            return result;
            
        }
        
        private static AppUserRoleReadModel funcMain158(AppUserRole p175)
        {
            return p175 == null ? null : new AppUserRoleReadModel()
            {
                AppUser = funcMain159(p175.AppUser),
                AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(p175.AppRole),
                Hash = p175.Hash,
                CreatedBy = p175.CreatedBy,
                CreatedDate = p175.CreatedDate,
                ModifiedBy = p175.ModifiedBy,
                ModifiedDate = p175.ModifiedDate,
                IsDeleted = p175.IsDeleted,
                DeletedBy = p175.DeletedBy,
                DeletedDate = p175.DeletedDate,
                UserId = p175.UserId,
                RoleId = p175.RoleId
            };
        }
        
        private static AppAccessControlEntryReadModel funcMain169(AppAccessControlEntry p186)
        {
            return p186 == null ? null : new AppAccessControlEntryReadModel()
            {
                ResourcePattern = p186.ResourcePattern,
                PermissionPattern = p186.PermissionPattern,
                FeatureId = p186.FeatureId,
                Feature = funcMain170(p186.Feature),
                AppRoles = TypeAdapter<ICollection<AppRole>, ICollection<AppRoleReadModel>>.Map.Invoke(p186.AppRoles),
                AppUsers = funcMain172(p186.AppUsers),
                AppResource = p186.AppResource == null ? null : new AppResourceReadModel()
                {
                    Url = p186.AppResource.Url,
                    Description = p186.AppResource.Description,
                    ResourceType = p186.AppResource.ResourceType,
                    AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p186.AppResource.AccessControlEntries),
                    Id = p186.AppResource.Id,
                    CreatedBy = p186.AppResource.CreatedBy,
                    CreatedDate = p186.AppResource.CreatedDate,
                    ModifiedBy = p186.AppResource.ModifiedBy,
                    ModifiedDate = p186.AppResource.ModifiedDate,
                    IsDeleted = p186.AppResource.IsDeleted,
                    DeletedBy = p186.AppResource.DeletedBy,
                    DeletedDate = p186.AppResource.DeletedDate
                },
                ResourceId = p186.ResourceId,
                Id = p186.Id,
                CreatedBy = p186.CreatedBy,
                CreatedDate = p186.CreatedDate,
                ModifiedBy = p186.ModifiedBy,
                ModifiedDate = p186.ModifiedDate,
                IsDeleted = p186.IsDeleted,
                DeletedBy = p186.DeletedBy,
                DeletedDate = p186.DeletedDate
            };
        }
        
        private static AppUserRoleReadModel funcMain180(AppUserRole p198)
        {
            return p198 == null ? null : new AppUserRoleReadModel()
            {
                AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(p198.AppUser),
                AppRole = funcMain181(p198.AppRole),
                Hash = p198.Hash,
                CreatedBy = p198.CreatedBy,
                CreatedDate = p198.CreatedDate,
                ModifiedBy = p198.ModifiedBy,
                ModifiedDate = p198.ModifiedDate,
                IsDeleted = p198.IsDeleted,
                DeletedBy = p198.DeletedBy,
                DeletedDate = p198.DeletedDate,
                UserId = p198.UserId,
                RoleId = p198.RoleId
            };
        }
        
        private static AppAccessControlEntryReadModel funcMain191(AppAccessControlEntry p209)
        {
            return p209 == null ? null : new AppAccessControlEntryReadModel()
            {
                ResourcePattern = p209.ResourcePattern,
                PermissionPattern = p209.PermissionPattern,
                FeatureId = p209.FeatureId,
                Feature = funcMain192(p209.Feature),
                AppRoles = funcMain194(p209.AppRoles),
                AppUsers = TypeAdapter<ICollection<AppUser>, ICollection<AppUserReadModel>>.Map.Invoke(p209.AppUsers),
                AppResource = p209.AppResource == null ? null : new AppResourceReadModel()
                {
                    Url = p209.AppResource.Url,
                    Description = p209.AppResource.Description,
                    ResourceType = p209.AppResource.ResourceType,
                    AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p209.AppResource.AccessControlEntries),
                    Id = p209.AppResource.Id,
                    CreatedBy = p209.AppResource.CreatedBy,
                    CreatedDate = p209.AppResource.CreatedDate,
                    ModifiedBy = p209.AppResource.ModifiedBy,
                    ModifiedDate = p209.AppResource.ModifiedDate,
                    IsDeleted = p209.AppResource.IsDeleted,
                    DeletedBy = p209.AppResource.DeletedBy,
                    DeletedDate = p209.AppResource.DeletedDate
                },
                ResourceId = p209.ResourceId,
                Id = p209.Id,
                CreatedBy = p209.CreatedBy,
                CreatedDate = p209.CreatedDate,
                ModifiedBy = p209.ModifiedBy,
                ModifiedDate = p209.ModifiedDate,
                IsDeleted = p209.IsDeleted,
                DeletedBy = p209.DeletedBy,
                DeletedDate = p209.DeletedDate
            };
        }
        
        private static AppFeatureReadModel funcMain201(AppFeature p221)
        {
            return p221 == null ? null : new AppFeatureReadModel()
            {
                Name = p221.Name,
                Description = p221.Description,
                IsEnabled = p221.IsEnabled,
                Scope = p221.Scope,
                FeatureFlags = funcMain202(p221.FeatureFlags),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p221.AccessControlEntries),
                Id = p221.Id,
                CreatedBy = p221.CreatedBy,
                CreatedDate = p221.CreatedDate,
                ModifiedBy = p221.ModifiedBy,
                ModifiedDate = p221.ModifiedDate,
                IsDeleted = p221.IsDeleted,
                DeletedBy = p221.DeletedBy,
                DeletedDate = p221.DeletedDate
            };
        }
        
        private static ICollection<AppRoleReadModel> funcMain203(ICollection<AppRole> p223)
        {
            if (p223 == null)
            {
                return null;
            }
            ICollection<AppRoleReadModel> result = new List<AppRoleReadModel>(p223.Count);
            
            IEnumerator<AppRole> enumerator = p223.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRole item = enumerator.Current;
                result.Add(funcMain204(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserReadModel> funcMain211(ICollection<AppUser> p231)
        {
            if (p231 == null)
            {
                return null;
            }
            ICollection<AppUserReadModel> result = new List<AppUserReadModel>(p231.Count);
            
            IEnumerator<AppUser> enumerator = p231.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUser item = enumerator.Current;
                result.Add(funcMain212(item));
            }
            return result;
            
        }
        
        private static AppUserReadModel funcMain8(AppUser p9)
        {
            return p9 == null ? null : new AppUserReadModel()
            {
                Hash = p9.Hash,
                FirstName = p9.FirstName,
                LastName = p9.LastName,
                Mobile = p9.Mobile,
                CountryCode = p9.CountryCode,
                TwoFactorMethod = p9.TwoFactorMethod,
                CreatedBy = p9.CreatedBy,
                CreatedDate = p9.CreatedDate,
                ModifiedBy = p9.ModifiedBy,
                ModifiedDate = p9.ModifiedDate,
                IsDeleted = p9.IsDeleted,
                DeletedBy = p9.DeletedBy,
                DeletedDate = p9.DeletedDate,
                MembershipType = p9.MembershipType,
                UserRoles = TypeAdapter<ICollection<AppUserRole>, ICollection<AppUserRoleReadModel>>.Map.Invoke(p9.UserRoles),
                UserTokens = funcMain9(p9.UserTokens),
                RefreshTokens = funcMain10(p9.RefreshTokens),
                AccessControlEntries = funcMain11(p9.AccessControlEntries),
                Id = p9.Id,
                UserName = p9.UserName,
                NormalizedUserName = p9.NormalizedUserName,
                Email = p9.Email,
                NormalizedEmail = p9.NormalizedEmail,
                EmailConfirmed = p9.EmailConfirmed,
                PasswordHash = p9.PasswordHash,
                SecurityStamp = p9.SecurityStamp,
                ConcurrencyStamp = p9.ConcurrencyStamp,
                PhoneNumber = p9.PhoneNumber,
                PhoneNumberConfirmed = p9.PhoneNumberConfirmed,
                TwoFactorEnabled = p9.TwoFactorEnabled,
                LockoutEnd = p9.LockoutEnd,
                LockoutEnabled = p9.LockoutEnabled,
                AccessFailedCount = p9.AccessFailedCount
            };
        }
        
        private static AppRoleReadModel funcMain18(AppRole p19)
        {
            return p19 == null ? null : new AppRoleReadModel()
            {
                CreatedBy = p19.CreatedBy,
                CreatedDate = p19.CreatedDate,
                ModifiedBy = p19.ModifiedBy,
                ModifiedDate = p19.ModifiedDate,
                IsDeleted = p19.IsDeleted,
                DeletedBy = p19.DeletedBy,
                DeletedDate = p19.DeletedDate,
                AppUserRoles = TypeAdapter<ICollection<AppUserRole>, ICollection<AppUserRoleReadModel>>.Map.Invoke(p19.AppUserRoles),
                AppRoleClaims = funcMain19(p19.AppRoleClaims),
                AccessControlEntries = funcMain20(p19.AccessControlEntries),
                Hash = p19.Hash,
                Id = p19.Id,
                Name = p19.Name,
                NormalizedName = p19.NormalizedName,
                ConcurrencyStamp = p19.ConcurrencyStamp
            };
        }
        
        private static AppUserReadModel funcMain33(AppUser p40)
        {
            return p40 == null ? null : new AppUserReadModel()
            {
                Hash = p40.Hash,
                FirstName = p40.FirstName,
                LastName = p40.LastName,
                Mobile = p40.Mobile,
                CountryCode = p40.CountryCode,
                TwoFactorMethod = p40.TwoFactorMethod,
                CreatedBy = p40.CreatedBy,
                CreatedDate = p40.CreatedDate,
                ModifiedBy = p40.ModifiedBy,
                ModifiedDate = p40.ModifiedDate,
                IsDeleted = p40.IsDeleted,
                DeletedBy = p40.DeletedBy,
                DeletedDate = p40.DeletedDate,
                MembershipType = p40.MembershipType,
                UserRoles = TypeAdapter<ICollection<AppUserRole>, ICollection<AppUserRoleReadModel>>.Map.Invoke(p40.UserRoles),
                UserTokens = funcMain34(p40.UserTokens),
                RefreshTokens = funcMain35(p40.RefreshTokens),
                AccessControlEntries = funcMain36(p40.AccessControlEntries),
                Id = p40.Id,
                UserName = p40.UserName,
                NormalizedUserName = p40.NormalizedUserName,
                Email = p40.Email,
                NormalizedEmail = p40.NormalizedEmail,
                EmailConfirmed = p40.EmailConfirmed,
                PasswordHash = p40.PasswordHash,
                SecurityStamp = p40.SecurityStamp,
                ConcurrencyStamp = p40.ConcurrencyStamp,
                PhoneNumber = p40.PhoneNumber,
                PhoneNumberConfirmed = p40.PhoneNumberConfirmed,
                TwoFactorEnabled = p40.TwoFactorEnabled,
                LockoutEnd = p40.LockoutEnd,
                LockoutEnabled = p40.LockoutEnabled,
                AccessFailedCount = p40.AccessFailedCount
            };
        }
        
        private static AppRoleReadModel funcMain43(AppRole p51)
        {
            return p51 == null ? null : new AppRoleReadModel()
            {
                CreatedBy = p51.CreatedBy,
                CreatedDate = p51.CreatedDate,
                ModifiedBy = p51.ModifiedBy,
                ModifiedDate = p51.ModifiedDate,
                IsDeleted = p51.IsDeleted,
                DeletedBy = p51.DeletedBy,
                DeletedDate = p51.DeletedDate,
                AppUserRoles = TypeAdapter<ICollection<AppUserRole>, ICollection<AppUserRoleReadModel>>.Map.Invoke(p51.AppUserRoles),
                AppRoleClaims = funcMain44(p51.AppRoleClaims),
                AccessControlEntries = funcMain45(p51.AccessControlEntries),
                Hash = p51.Hash,
                Id = p51.Id,
                Name = p51.Name,
                NormalizedName = p51.NormalizedName,
                ConcurrencyStamp = p51.ConcurrencyStamp
            };
        }
        
        private static AppRoleReadModel funcMain56(AppRole p67)
        {
            return p67 == null ? null : new AppRoleReadModel()
            {
                CreatedBy = p67.CreatedBy,
                CreatedDate = p67.CreatedDate,
                ModifiedBy = p67.ModifiedBy,
                ModifiedDate = p67.ModifiedDate,
                IsDeleted = p67.IsDeleted,
                DeletedBy = p67.DeletedBy,
                DeletedDate = p67.DeletedDate,
                AppUserRoles = funcMain57(p67.AppUserRoles),
                AppRoleClaims = funcMain62(p67.AppRoleClaims),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p67.AccessControlEntries),
                Hash = p67.Hash,
                Id = p67.Id,
                Name = p67.Name,
                NormalizedName = p67.NormalizedName,
                ConcurrencyStamp = p67.ConcurrencyStamp
            };
        }
        
        private static AppUserReadModel funcMain64(AppUser p75)
        {
            return p75 == null ? null : new AppUserReadModel()
            {
                Hash = p75.Hash,
                FirstName = p75.FirstName,
                LastName = p75.LastName,
                Mobile = p75.Mobile,
                CountryCode = p75.CountryCode,
                TwoFactorMethod = p75.TwoFactorMethod,
                CreatedBy = p75.CreatedBy,
                CreatedDate = p75.CreatedDate,
                ModifiedBy = p75.ModifiedBy,
                ModifiedDate = p75.ModifiedDate,
                IsDeleted = p75.IsDeleted,
                DeletedBy = p75.DeletedBy,
                DeletedDate = p75.DeletedDate,
                MembershipType = p75.MembershipType,
                UserRoles = funcMain65(p75.UserRoles),
                UserTokens = funcMain69(p75.UserTokens),
                RefreshTokens = funcMain70(p75.RefreshTokens),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p75.AccessControlEntries),
                Id = p75.Id,
                UserName = p75.UserName,
                NormalizedUserName = p75.NormalizedUserName,
                Email = p75.Email,
                NormalizedEmail = p75.NormalizedEmail,
                EmailConfirmed = p75.EmailConfirmed,
                PasswordHash = p75.PasswordHash,
                SecurityStamp = p75.SecurityStamp,
                ConcurrencyStamp = p75.ConcurrencyStamp,
                PhoneNumber = p75.PhoneNumber,
                PhoneNumberConfirmed = p75.PhoneNumberConfirmed,
                TwoFactorEnabled = p75.TwoFactorEnabled,
                LockoutEnd = p75.LockoutEnd,
                LockoutEnabled = p75.LockoutEnabled,
                AccessFailedCount = p75.AccessFailedCount
            };
        }
        
        private static AppUserReadModel funcMain75(AppUser p86)
        {
            return p86 == null ? null : new AppUserReadModel()
            {
                Hash = p86.Hash,
                FirstName = p86.FirstName,
                LastName = p86.LastName,
                Mobile = p86.Mobile,
                CountryCode = p86.CountryCode,
                TwoFactorMethod = p86.TwoFactorMethod,
                CreatedBy = p86.CreatedBy,
                CreatedDate = p86.CreatedDate,
                ModifiedBy = p86.ModifiedBy,
                ModifiedDate = p86.ModifiedDate,
                IsDeleted = p86.IsDeleted,
                DeletedBy = p86.DeletedBy,
                DeletedDate = p86.DeletedDate,
                MembershipType = p86.MembershipType,
                UserRoles = TypeAdapter<ICollection<AppUserRole>, ICollection<AppUserRoleReadModel>>.Map.Invoke(p86.UserRoles),
                UserTokens = funcMain76(p86.UserTokens),
                RefreshTokens = funcMain77(p86.RefreshTokens),
                AccessControlEntries = funcMain78(p86.AccessControlEntries),
                Id = p86.Id,
                UserName = p86.UserName,
                NormalizedUserName = p86.NormalizedUserName,
                Email = p86.Email,
                NormalizedEmail = p86.NormalizedEmail,
                EmailConfirmed = p86.EmailConfirmed,
                PasswordHash = p86.PasswordHash,
                SecurityStamp = p86.SecurityStamp,
                ConcurrencyStamp = p86.ConcurrencyStamp,
                PhoneNumber = p86.PhoneNumber,
                PhoneNumberConfirmed = p86.PhoneNumberConfirmed,
                TwoFactorEnabled = p86.TwoFactorEnabled,
                LockoutEnd = p86.LockoutEnd,
                LockoutEnabled = p86.LockoutEnabled,
                AccessFailedCount = p86.AccessFailedCount
            };
        }
        
        private static AppFeatureReadModel funcMain86(AppFeature p97)
        {
            return p97 == null ? null : new AppFeatureReadModel()
            {
                Name = p97.Name,
                Description = p97.Description,
                IsEnabled = p97.IsEnabled,
                Scope = p97.Scope,
                FeatureFlags = funcMain87(p97.FeatureFlags),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p97.AccessControlEntries),
                Id = p97.Id,
                CreatedBy = p97.CreatedBy,
                CreatedDate = p97.CreatedDate,
                ModifiedBy = p97.ModifiedBy,
                ModifiedDate = p97.ModifiedDate,
                IsDeleted = p97.IsDeleted,
                DeletedBy = p97.DeletedBy,
                DeletedDate = p97.DeletedDate
            };
        }
        
        private static ICollection<AppUserReadModel> funcMain88(ICollection<AppUser> p99)
        {
            if (p99 == null)
            {
                return null;
            }
            ICollection<AppUserReadModel> result = new List<AppUserReadModel>(p99.Count);
            
            IEnumerator<AppUser> enumerator = p99.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUser item = enumerator.Current;
                result.Add(funcMain89(item));
            }
            return result;
            
        }
        
        private static AppRoleReadModel funcMain97(AppRole p108)
        {
            return p108 == null ? null : new AppRoleReadModel()
            {
                CreatedBy = p108.CreatedBy,
                CreatedDate = p108.CreatedDate,
                ModifiedBy = p108.ModifiedBy,
                ModifiedDate = p108.ModifiedDate,
                IsDeleted = p108.IsDeleted,
                DeletedBy = p108.DeletedBy,
                DeletedDate = p108.DeletedDate,
                AppUserRoles = TypeAdapter<ICollection<AppUserRole>, ICollection<AppUserRoleReadModel>>.Map.Invoke(p108.AppUserRoles),
                AppRoleClaims = funcMain98(p108.AppRoleClaims),
                AccessControlEntries = funcMain99(p108.AccessControlEntries),
                Hash = p108.Hash,
                Id = p108.Id,
                Name = p108.Name,
                NormalizedName = p108.NormalizedName,
                ConcurrencyStamp = p108.ConcurrencyStamp
            };
        }
        
        private static AppFeatureReadModel funcMain108(AppFeature p119)
        {
            return p119 == null ? null : new AppFeatureReadModel()
            {
                Name = p119.Name,
                Description = p119.Description,
                IsEnabled = p119.IsEnabled,
                Scope = p119.Scope,
                FeatureFlags = funcMain109(p119.FeatureFlags),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p119.AccessControlEntries),
                Id = p119.Id,
                CreatedBy = p119.CreatedBy,
                CreatedDate = p119.CreatedDate,
                ModifiedBy = p119.ModifiedBy,
                ModifiedDate = p119.ModifiedDate,
                IsDeleted = p119.IsDeleted,
                DeletedBy = p119.DeletedBy,
                DeletedDate = p119.DeletedDate
            };
        }
        
        private static ICollection<AppRoleReadModel> funcMain110(ICollection<AppRole> p121)
        {
            if (p121 == null)
            {
                return null;
            }
            ICollection<AppRoleReadModel> result = new List<AppRoleReadModel>(p121.Count);
            
            IEnumerator<AppRole> enumerator = p121.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRole item = enumerator.Current;
                result.Add(funcMain111(item));
            }
            return result;
            
        }
        
        private static ICollection<AppFeatureFlagReadModel> funcMain118(ICollection<AppFeatureFlag> p129)
        {
            if (p129 == null)
            {
                return null;
            }
            ICollection<AppFeatureFlagReadModel> result = new List<AppFeatureFlagReadModel>(p129.Count);
            
            IEnumerator<AppFeatureFlag> enumerator = p129.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppFeatureFlag item = enumerator.Current;
                result.Add(item == null ? null : new AppFeatureFlagReadModel()
                {
                    FeatureId = item.FeatureId,
                    ScopeIdentifier = item.ScopeIdentifier,
                    IsEnabled = item.IsEnabled,
                    Feature = TypeAdapter<AppFeature, AppFeatureReadModel>.Map.Invoke(item.Feature),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static AppRoleReadModel funcMain120(AppRole p131)
        {
            return p131 == null ? null : new AppRoleReadModel()
            {
                CreatedBy = p131.CreatedBy,
                CreatedDate = p131.CreatedDate,
                ModifiedBy = p131.ModifiedBy,
                ModifiedDate = p131.ModifiedDate,
                IsDeleted = p131.IsDeleted,
                DeletedBy = p131.DeletedBy,
                DeletedDate = p131.DeletedDate,
                AppUserRoles = funcMain121(p131.AppUserRoles),
                AppRoleClaims = funcMain126(p131.AppRoleClaims),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p131.AccessControlEntries),
                Hash = p131.Hash,
                Id = p131.Id,
                Name = p131.Name,
                NormalizedName = p131.NormalizedName,
                ConcurrencyStamp = p131.ConcurrencyStamp
            };
        }
        
        private static AppUserReadModel funcMain128(AppUser p139)
        {
            return p139 == null ? null : new AppUserReadModel()
            {
                Hash = p139.Hash,
                FirstName = p139.FirstName,
                LastName = p139.LastName,
                Mobile = p139.Mobile,
                CountryCode = p139.CountryCode,
                TwoFactorMethod = p139.TwoFactorMethod,
                CreatedBy = p139.CreatedBy,
                CreatedDate = p139.CreatedDate,
                ModifiedBy = p139.ModifiedBy,
                ModifiedDate = p139.ModifiedDate,
                IsDeleted = p139.IsDeleted,
                DeletedBy = p139.DeletedBy,
                DeletedDate = p139.DeletedDate,
                MembershipType = p139.MembershipType,
                UserRoles = funcMain129(p139.UserRoles),
                UserTokens = funcMain133(p139.UserTokens),
                RefreshTokens = funcMain134(p139.RefreshTokens),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p139.AccessControlEntries),
                Id = p139.Id,
                UserName = p139.UserName,
                NormalizedUserName = p139.NormalizedUserName,
                Email = p139.Email,
                NormalizedEmail = p139.NormalizedEmail,
                EmailConfirmed = p139.EmailConfirmed,
                PasswordHash = p139.PasswordHash,
                SecurityStamp = p139.SecurityStamp,
                ConcurrencyStamp = p139.ConcurrencyStamp,
                PhoneNumber = p139.PhoneNumber,
                PhoneNumberConfirmed = p139.PhoneNumberConfirmed,
                TwoFactorEnabled = p139.TwoFactorEnabled,
                LockoutEnd = p139.LockoutEnd,
                LockoutEnabled = p139.LockoutEnabled,
                AccessFailedCount = p139.AccessFailedCount
            };
        }
        
        private static AppRoleReadModel funcMain140(AppRole p156)
        {
            return p156 == null ? null : new AppRoleReadModel()
            {
                CreatedBy = p156.CreatedBy,
                CreatedDate = p156.CreatedDate,
                ModifiedBy = p156.ModifiedBy,
                ModifiedDate = p156.ModifiedDate,
                IsDeleted = p156.IsDeleted,
                DeletedBy = p156.DeletedBy,
                DeletedDate = p156.DeletedDate,
                AppUserRoles = funcMain141(p156.AppUserRoles),
                AppRoleClaims = funcMain146(p156.AppRoleClaims),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p156.AccessControlEntries),
                Hash = p156.Hash,
                Id = p156.Id,
                Name = p156.Name,
                NormalizedName = p156.NormalizedName,
                ConcurrencyStamp = p156.ConcurrencyStamp
            };
        }
        
        private static AppUserReadModel funcMain148(AppUser p164)
        {
            return p164 == null ? null : new AppUserReadModel()
            {
                Hash = p164.Hash,
                FirstName = p164.FirstName,
                LastName = p164.LastName,
                Mobile = p164.Mobile,
                CountryCode = p164.CountryCode,
                TwoFactorMethod = p164.TwoFactorMethod,
                CreatedBy = p164.CreatedBy,
                CreatedDate = p164.CreatedDate,
                ModifiedBy = p164.ModifiedBy,
                ModifiedDate = p164.ModifiedDate,
                IsDeleted = p164.IsDeleted,
                DeletedBy = p164.DeletedBy,
                DeletedDate = p164.DeletedDate,
                MembershipType = p164.MembershipType,
                UserRoles = funcMain149(p164.UserRoles),
                UserTokens = funcMain153(p164.UserTokens),
                RefreshTokens = funcMain154(p164.RefreshTokens),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p164.AccessControlEntries),
                Id = p164.Id,
                UserName = p164.UserName,
                NormalizedUserName = p164.NormalizedUserName,
                Email = p164.Email,
                NormalizedEmail = p164.NormalizedEmail,
                EmailConfirmed = p164.EmailConfirmed,
                PasswordHash = p164.PasswordHash,
                SecurityStamp = p164.SecurityStamp,
                ConcurrencyStamp = p164.ConcurrencyStamp,
                PhoneNumber = p164.PhoneNumber,
                PhoneNumberConfirmed = p164.PhoneNumberConfirmed,
                TwoFactorEnabled = p164.TwoFactorEnabled,
                LockoutEnd = p164.LockoutEnd,
                LockoutEnabled = p164.LockoutEnabled,
                AccessFailedCount = p164.AccessFailedCount
            };
        }
        
        private static AppUserReadModel funcMain159(AppUser p176)
        {
            return p176 == null ? null : new AppUserReadModel()
            {
                Hash = p176.Hash,
                FirstName = p176.FirstName,
                LastName = p176.LastName,
                Mobile = p176.Mobile,
                CountryCode = p176.CountryCode,
                TwoFactorMethod = p176.TwoFactorMethod,
                CreatedBy = p176.CreatedBy,
                CreatedDate = p176.CreatedDate,
                ModifiedBy = p176.ModifiedBy,
                ModifiedDate = p176.ModifiedDate,
                IsDeleted = p176.IsDeleted,
                DeletedBy = p176.DeletedBy,
                DeletedDate = p176.DeletedDate,
                MembershipType = p176.MembershipType,
                UserRoles = TypeAdapter<ICollection<AppUserRole>, ICollection<AppUserRoleReadModel>>.Map.Invoke(p176.UserRoles),
                UserTokens = funcMain160(p176.UserTokens),
                RefreshTokens = funcMain161(p176.RefreshTokens),
                AccessControlEntries = funcMain162(p176.AccessControlEntries),
                Id = p176.Id,
                UserName = p176.UserName,
                NormalizedUserName = p176.NormalizedUserName,
                Email = p176.Email,
                NormalizedEmail = p176.NormalizedEmail,
                EmailConfirmed = p176.EmailConfirmed,
                PasswordHash = p176.PasswordHash,
                SecurityStamp = p176.SecurityStamp,
                ConcurrencyStamp = p176.ConcurrencyStamp,
                PhoneNumber = p176.PhoneNumber,
                PhoneNumberConfirmed = p176.PhoneNumberConfirmed,
                TwoFactorEnabled = p176.TwoFactorEnabled,
                LockoutEnd = p176.LockoutEnd,
                LockoutEnabled = p176.LockoutEnabled,
                AccessFailedCount = p176.AccessFailedCount
            };
        }
        
        private static AppFeatureReadModel funcMain170(AppFeature p187)
        {
            return p187 == null ? null : new AppFeatureReadModel()
            {
                Name = p187.Name,
                Description = p187.Description,
                IsEnabled = p187.IsEnabled,
                Scope = p187.Scope,
                FeatureFlags = funcMain171(p187.FeatureFlags),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p187.AccessControlEntries),
                Id = p187.Id,
                CreatedBy = p187.CreatedBy,
                CreatedDate = p187.CreatedDate,
                ModifiedBy = p187.ModifiedBy,
                ModifiedDate = p187.ModifiedDate,
                IsDeleted = p187.IsDeleted,
                DeletedBy = p187.DeletedBy,
                DeletedDate = p187.DeletedDate
            };
        }
        
        private static ICollection<AppUserReadModel> funcMain172(ICollection<AppUser> p189)
        {
            if (p189 == null)
            {
                return null;
            }
            ICollection<AppUserReadModel> result = new List<AppUserReadModel>(p189.Count);
            
            IEnumerator<AppUser> enumerator = p189.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUser item = enumerator.Current;
                result.Add(funcMain173(item));
            }
            return result;
            
        }
        
        private static AppRoleReadModel funcMain181(AppRole p199)
        {
            return p199 == null ? null : new AppRoleReadModel()
            {
                CreatedBy = p199.CreatedBy,
                CreatedDate = p199.CreatedDate,
                ModifiedBy = p199.ModifiedBy,
                ModifiedDate = p199.ModifiedDate,
                IsDeleted = p199.IsDeleted,
                DeletedBy = p199.DeletedBy,
                DeletedDate = p199.DeletedDate,
                AppUserRoles = TypeAdapter<ICollection<AppUserRole>, ICollection<AppUserRoleReadModel>>.Map.Invoke(p199.AppUserRoles),
                AppRoleClaims = funcMain182(p199.AppRoleClaims),
                AccessControlEntries = funcMain183(p199.AccessControlEntries),
                Hash = p199.Hash,
                Id = p199.Id,
                Name = p199.Name,
                NormalizedName = p199.NormalizedName,
                ConcurrencyStamp = p199.ConcurrencyStamp
            };
        }
        
        private static AppFeatureReadModel funcMain192(AppFeature p210)
        {
            return p210 == null ? null : new AppFeatureReadModel()
            {
                Name = p210.Name,
                Description = p210.Description,
                IsEnabled = p210.IsEnabled,
                Scope = p210.Scope,
                FeatureFlags = funcMain193(p210.FeatureFlags),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p210.AccessControlEntries),
                Id = p210.Id,
                CreatedBy = p210.CreatedBy,
                CreatedDate = p210.CreatedDate,
                ModifiedBy = p210.ModifiedBy,
                ModifiedDate = p210.ModifiedDate,
                IsDeleted = p210.IsDeleted,
                DeletedBy = p210.DeletedBy,
                DeletedDate = p210.DeletedDate
            };
        }
        
        private static ICollection<AppRoleReadModel> funcMain194(ICollection<AppRole> p212)
        {
            if (p212 == null)
            {
                return null;
            }
            ICollection<AppRoleReadModel> result = new List<AppRoleReadModel>(p212.Count);
            
            IEnumerator<AppRole> enumerator = p212.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRole item = enumerator.Current;
                result.Add(funcMain195(item));
            }
            return result;
            
        }
        
        private static ICollection<AppFeatureFlagReadModel> funcMain202(ICollection<AppFeatureFlag> p222)
        {
            if (p222 == null)
            {
                return null;
            }
            ICollection<AppFeatureFlagReadModel> result = new List<AppFeatureFlagReadModel>(p222.Count);
            
            IEnumerator<AppFeatureFlag> enumerator = p222.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppFeatureFlag item = enumerator.Current;
                result.Add(item == null ? null : new AppFeatureFlagReadModel()
                {
                    FeatureId = item.FeatureId,
                    ScopeIdentifier = item.ScopeIdentifier,
                    IsEnabled = item.IsEnabled,
                    Feature = TypeAdapter<AppFeature, AppFeatureReadModel>.Map.Invoke(item.Feature),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static AppRoleReadModel funcMain204(AppRole p224)
        {
            return p224 == null ? null : new AppRoleReadModel()
            {
                CreatedBy = p224.CreatedBy,
                CreatedDate = p224.CreatedDate,
                ModifiedBy = p224.ModifiedBy,
                ModifiedDate = p224.ModifiedDate,
                IsDeleted = p224.IsDeleted,
                DeletedBy = p224.DeletedBy,
                DeletedDate = p224.DeletedDate,
                AppUserRoles = funcMain205(p224.AppUserRoles),
                AppRoleClaims = funcMain210(p224.AppRoleClaims),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p224.AccessControlEntries),
                Hash = p224.Hash,
                Id = p224.Id,
                Name = p224.Name,
                NormalizedName = p224.NormalizedName,
                ConcurrencyStamp = p224.ConcurrencyStamp
            };
        }
        
        private static AppUserReadModel funcMain212(AppUser p232)
        {
            return p232 == null ? null : new AppUserReadModel()
            {
                Hash = p232.Hash,
                FirstName = p232.FirstName,
                LastName = p232.LastName,
                Mobile = p232.Mobile,
                CountryCode = p232.CountryCode,
                TwoFactorMethod = p232.TwoFactorMethod,
                CreatedBy = p232.CreatedBy,
                CreatedDate = p232.CreatedDate,
                ModifiedBy = p232.ModifiedBy,
                ModifiedDate = p232.ModifiedDate,
                IsDeleted = p232.IsDeleted,
                DeletedBy = p232.DeletedBy,
                DeletedDate = p232.DeletedDate,
                MembershipType = p232.MembershipType,
                UserRoles = funcMain213(p232.UserRoles),
                UserTokens = funcMain217(p232.UserTokens),
                RefreshTokens = funcMain218(p232.RefreshTokens),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p232.AccessControlEntries),
                Id = p232.Id,
                UserName = p232.UserName,
                NormalizedUserName = p232.NormalizedUserName,
                Email = p232.Email,
                NormalizedEmail = p232.NormalizedEmail,
                EmailConfirmed = p232.EmailConfirmed,
                PasswordHash = p232.PasswordHash,
                SecurityStamp = p232.SecurityStamp,
                ConcurrencyStamp = p232.ConcurrencyStamp,
                PhoneNumber = p232.PhoneNumber,
                PhoneNumberConfirmed = p232.PhoneNumberConfirmed,
                TwoFactorEnabled = p232.TwoFactorEnabled,
                LockoutEnd = p232.LockoutEnd,
                LockoutEnabled = p232.LockoutEnabled,
                AccessFailedCount = p232.AccessFailedCount
            };
        }
        
        private static ICollection<AppUserTokenReadModel> funcMain9(ICollection<AppUserToken> p10)
        {
            if (p10 == null)
            {
                return null;
            }
            ICollection<AppUserTokenReadModel> result = new List<AppUserTokenReadModel>(p10.Count);
            
            IEnumerator<AppUserToken> enumerator = p10.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserToken item = enumerator.Current;
                result.Add(item == null ? null : new AppUserTokenReadModel()
                {
                    Token = item.Token,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    LoginProvider = item.LoginProvider,
                    Name = item.Name,
                    Value = item.Value
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRefreshTokenReadModel> funcMain10(ICollection<AppRefreshToken> p11)
        {
            if (p11 == null)
            {
                return null;
            }
            ICollection<AppRefreshTokenReadModel> result = new List<AppRefreshTokenReadModel>(p11.Count);
            
            IEnumerator<AppRefreshToken> enumerator = p11.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRefreshToken item = enumerator.Current;
                result.Add(item == null ? null : new AppRefreshTokenReadModel()
                {
                    UserId = item.UserId,
                    Token = item.Token,
                    JwtId = item.JwtId,
                    IsUsed = item.IsUsed,
                    IsRevoked = item.IsRevoked,
                    ExpiryDate = item.ExpiryDate,
                    Hash = item.Hash,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static ICollection<AppAccessControlEntryReadModel> funcMain11(ICollection<AppAccessControlEntry> p12)
        {
            if (p12 == null)
            {
                return null;
            }
            ICollection<AppAccessControlEntryReadModel> result = new List<AppAccessControlEntryReadModel>(p12.Count);
            
            IEnumerator<AppAccessControlEntry> enumerator = p12.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppAccessControlEntry item = enumerator.Current;
                result.Add(TypeAdapter<AppAccessControlEntry, AppAccessControlEntryReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static ICollection<AppRoleClaimReadModel> funcMain19(ICollection<AppRoleClaim> p20)
        {
            if (p20 == null)
            {
                return null;
            }
            ICollection<AppRoleClaimReadModel> result = new List<AppRoleClaimReadModel>(p20.Count);
            
            IEnumerator<AppRoleClaim> enumerator = p20.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRoleClaim item = enumerator.Current;
                result.Add(item == null ? null : new AppRoleClaimReadModel()
                {
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Id = item.Id,
                    RoleId = item.RoleId,
                    ClaimType = item.ClaimType,
                    ClaimValue = item.ClaimValue
                });
            }
            return result;
            
        }
        
        private static ICollection<AppAccessControlEntryReadModel> funcMain20(ICollection<AppAccessControlEntry> p21)
        {
            if (p21 == null)
            {
                return null;
            }
            ICollection<AppAccessControlEntryReadModel> result = new List<AppAccessControlEntryReadModel>(p21.Count);
            
            IEnumerator<AppAccessControlEntry> enumerator = p21.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppAccessControlEntry item = enumerator.Current;
                result.Add(TypeAdapter<AppAccessControlEntry, AppAccessControlEntryReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserTokenReadModel> funcMain34(ICollection<AppUserToken> p41)
        {
            if (p41 == null)
            {
                return null;
            }
            ICollection<AppUserTokenReadModel> result = new List<AppUserTokenReadModel>(p41.Count);
            
            IEnumerator<AppUserToken> enumerator = p41.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserToken item = enumerator.Current;
                result.Add(item == null ? null : new AppUserTokenReadModel()
                {
                    Token = item.Token,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    LoginProvider = item.LoginProvider,
                    Name = item.Name,
                    Value = item.Value
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRefreshTokenReadModel> funcMain35(ICollection<AppRefreshToken> p42)
        {
            if (p42 == null)
            {
                return null;
            }
            ICollection<AppRefreshTokenReadModel> result = new List<AppRefreshTokenReadModel>(p42.Count);
            
            IEnumerator<AppRefreshToken> enumerator = p42.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRefreshToken item = enumerator.Current;
                result.Add(item == null ? null : new AppRefreshTokenReadModel()
                {
                    UserId = item.UserId,
                    Token = item.Token,
                    JwtId = item.JwtId,
                    IsUsed = item.IsUsed,
                    IsRevoked = item.IsRevoked,
                    ExpiryDate = item.ExpiryDate,
                    Hash = item.Hash,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static ICollection<AppAccessControlEntryReadModel> funcMain36(ICollection<AppAccessControlEntry> p43)
        {
            if (p43 == null)
            {
                return null;
            }
            ICollection<AppAccessControlEntryReadModel> result = new List<AppAccessControlEntryReadModel>(p43.Count);
            
            IEnumerator<AppAccessControlEntry> enumerator = p43.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppAccessControlEntry item = enumerator.Current;
                result.Add(TypeAdapter<AppAccessControlEntry, AppAccessControlEntryReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static ICollection<AppRoleClaimReadModel> funcMain44(ICollection<AppRoleClaim> p52)
        {
            if (p52 == null)
            {
                return null;
            }
            ICollection<AppRoleClaimReadModel> result = new List<AppRoleClaimReadModel>(p52.Count);
            
            IEnumerator<AppRoleClaim> enumerator = p52.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRoleClaim item = enumerator.Current;
                result.Add(item == null ? null : new AppRoleClaimReadModel()
                {
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Id = item.Id,
                    RoleId = item.RoleId,
                    ClaimType = item.ClaimType,
                    ClaimValue = item.ClaimValue
                });
            }
            return result;
            
        }
        
        private static ICollection<AppAccessControlEntryReadModel> funcMain45(ICollection<AppAccessControlEntry> p53)
        {
            if (p53 == null)
            {
                return null;
            }
            ICollection<AppAccessControlEntryReadModel> result = new List<AppAccessControlEntryReadModel>(p53.Count);
            
            IEnumerator<AppAccessControlEntry> enumerator = p53.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppAccessControlEntry item = enumerator.Current;
                result.Add(TypeAdapter<AppAccessControlEntry, AppAccessControlEntryReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain57(ICollection<AppUserRole> p68)
        {
            if (p68 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p68.Count);
            
            IEnumerator<AppUserRole> enumerator = p68.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(funcMain58(item));
            }
            return result;
            
        }
        
        private static ICollection<AppRoleClaimReadModel> funcMain62(ICollection<AppRoleClaim> p73)
        {
            if (p73 == null)
            {
                return null;
            }
            ICollection<AppRoleClaimReadModel> result = new List<AppRoleClaimReadModel>(p73.Count);
            
            IEnumerator<AppRoleClaim> enumerator = p73.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRoleClaim item = enumerator.Current;
                result.Add(item == null ? null : new AppRoleClaimReadModel()
                {
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Id = item.Id,
                    RoleId = item.RoleId,
                    ClaimType = item.ClaimType,
                    ClaimValue = item.ClaimValue
                });
            }
            return result;
            
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain65(ICollection<AppUserRole> p76)
        {
            if (p76 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p76.Count);
            
            IEnumerator<AppUserRole> enumerator = p76.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(funcMain66(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserTokenReadModel> funcMain69(ICollection<AppUserToken> p80)
        {
            if (p80 == null)
            {
                return null;
            }
            ICollection<AppUserTokenReadModel> result = new List<AppUserTokenReadModel>(p80.Count);
            
            IEnumerator<AppUserToken> enumerator = p80.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserToken item = enumerator.Current;
                result.Add(item == null ? null : new AppUserTokenReadModel()
                {
                    Token = item.Token,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    LoginProvider = item.LoginProvider,
                    Name = item.Name,
                    Value = item.Value
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRefreshTokenReadModel> funcMain70(ICollection<AppRefreshToken> p81)
        {
            if (p81 == null)
            {
                return null;
            }
            ICollection<AppRefreshTokenReadModel> result = new List<AppRefreshTokenReadModel>(p81.Count);
            
            IEnumerator<AppRefreshToken> enumerator = p81.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRefreshToken item = enumerator.Current;
                result.Add(item == null ? null : new AppRefreshTokenReadModel()
                {
                    UserId = item.UserId,
                    Token = item.Token,
                    JwtId = item.JwtId,
                    IsUsed = item.IsUsed,
                    IsRevoked = item.IsRevoked,
                    ExpiryDate = item.ExpiryDate,
                    Hash = item.Hash,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static ICollection<AppUserTokenReadModel> funcMain76(ICollection<AppUserToken> p87)
        {
            if (p87 == null)
            {
                return null;
            }
            ICollection<AppUserTokenReadModel> result = new List<AppUserTokenReadModel>(p87.Count);
            
            IEnumerator<AppUserToken> enumerator = p87.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserToken item = enumerator.Current;
                result.Add(item == null ? null : new AppUserTokenReadModel()
                {
                    Token = item.Token,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    LoginProvider = item.LoginProvider,
                    Name = item.Name,
                    Value = item.Value
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRefreshTokenReadModel> funcMain77(ICollection<AppRefreshToken> p88)
        {
            if (p88 == null)
            {
                return null;
            }
            ICollection<AppRefreshTokenReadModel> result = new List<AppRefreshTokenReadModel>(p88.Count);
            
            IEnumerator<AppRefreshToken> enumerator = p88.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRefreshToken item = enumerator.Current;
                result.Add(item == null ? null : new AppRefreshTokenReadModel()
                {
                    UserId = item.UserId,
                    Token = item.Token,
                    JwtId = item.JwtId,
                    IsUsed = item.IsUsed,
                    IsRevoked = item.IsRevoked,
                    ExpiryDate = item.ExpiryDate,
                    Hash = item.Hash,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static ICollection<AppAccessControlEntryReadModel> funcMain78(ICollection<AppAccessControlEntry> p89)
        {
            if (p89 == null)
            {
                return null;
            }
            ICollection<AppAccessControlEntryReadModel> result = new List<AppAccessControlEntryReadModel>(p89.Count);
            
            IEnumerator<AppAccessControlEntry> enumerator = p89.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppAccessControlEntry item = enumerator.Current;
                result.Add(funcMain79(item));
            }
            return result;
            
        }
        
        private static ICollection<AppFeatureFlagReadModel> funcMain87(ICollection<AppFeatureFlag> p98)
        {
            if (p98 == null)
            {
                return null;
            }
            ICollection<AppFeatureFlagReadModel> result = new List<AppFeatureFlagReadModel>(p98.Count);
            
            IEnumerator<AppFeatureFlag> enumerator = p98.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppFeatureFlag item = enumerator.Current;
                result.Add(item == null ? null : new AppFeatureFlagReadModel()
                {
                    FeatureId = item.FeatureId,
                    ScopeIdentifier = item.ScopeIdentifier,
                    IsEnabled = item.IsEnabled,
                    Feature = TypeAdapter<AppFeature, AppFeatureReadModel>.Map.Invoke(item.Feature),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static AppUserReadModel funcMain89(AppUser p100)
        {
            return p100 == null ? null : new AppUserReadModel()
            {
                Hash = p100.Hash,
                FirstName = p100.FirstName,
                LastName = p100.LastName,
                Mobile = p100.Mobile,
                CountryCode = p100.CountryCode,
                TwoFactorMethod = p100.TwoFactorMethod,
                CreatedBy = p100.CreatedBy,
                CreatedDate = p100.CreatedDate,
                ModifiedBy = p100.ModifiedBy,
                ModifiedDate = p100.ModifiedDate,
                IsDeleted = p100.IsDeleted,
                DeletedBy = p100.DeletedBy,
                DeletedDate = p100.DeletedDate,
                MembershipType = p100.MembershipType,
                UserRoles = funcMain90(p100.UserRoles),
                UserTokens = funcMain91(p100.UserTokens),
                RefreshTokens = funcMain92(p100.RefreshTokens),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p100.AccessControlEntries),
                Id = p100.Id,
                UserName = p100.UserName,
                NormalizedUserName = p100.NormalizedUserName,
                Email = p100.Email,
                NormalizedEmail = p100.NormalizedEmail,
                EmailConfirmed = p100.EmailConfirmed,
                PasswordHash = p100.PasswordHash,
                SecurityStamp = p100.SecurityStamp,
                ConcurrencyStamp = p100.ConcurrencyStamp,
                PhoneNumber = p100.PhoneNumber,
                PhoneNumberConfirmed = p100.PhoneNumberConfirmed,
                TwoFactorEnabled = p100.TwoFactorEnabled,
                LockoutEnd = p100.LockoutEnd,
                LockoutEnabled = p100.LockoutEnabled,
                AccessFailedCount = p100.AccessFailedCount
            };
        }
        
        private static ICollection<AppRoleClaimReadModel> funcMain98(ICollection<AppRoleClaim> p109)
        {
            if (p109 == null)
            {
                return null;
            }
            ICollection<AppRoleClaimReadModel> result = new List<AppRoleClaimReadModel>(p109.Count);
            
            IEnumerator<AppRoleClaim> enumerator = p109.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRoleClaim item = enumerator.Current;
                result.Add(item == null ? null : new AppRoleClaimReadModel()
                {
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Id = item.Id,
                    RoleId = item.RoleId,
                    ClaimType = item.ClaimType,
                    ClaimValue = item.ClaimValue
                });
            }
            return result;
            
        }
        
        private static ICollection<AppAccessControlEntryReadModel> funcMain99(ICollection<AppAccessControlEntry> p110)
        {
            if (p110 == null)
            {
                return null;
            }
            ICollection<AppAccessControlEntryReadModel> result = new List<AppAccessControlEntryReadModel>(p110.Count);
            
            IEnumerator<AppAccessControlEntry> enumerator = p110.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppAccessControlEntry item = enumerator.Current;
                result.Add(funcMain100(item));
            }
            return result;
            
        }
        
        private static ICollection<AppFeatureFlagReadModel> funcMain109(ICollection<AppFeatureFlag> p120)
        {
            if (p120 == null)
            {
                return null;
            }
            ICollection<AppFeatureFlagReadModel> result = new List<AppFeatureFlagReadModel>(p120.Count);
            
            IEnumerator<AppFeatureFlag> enumerator = p120.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppFeatureFlag item = enumerator.Current;
                result.Add(item == null ? null : new AppFeatureFlagReadModel()
                {
                    FeatureId = item.FeatureId,
                    ScopeIdentifier = item.ScopeIdentifier,
                    IsEnabled = item.IsEnabled,
                    Feature = TypeAdapter<AppFeature, AppFeatureReadModel>.Map.Invoke(item.Feature),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static AppRoleReadModel funcMain111(AppRole p122)
        {
            return p122 == null ? null : new AppRoleReadModel()
            {
                CreatedBy = p122.CreatedBy,
                CreatedDate = p122.CreatedDate,
                ModifiedBy = p122.ModifiedBy,
                ModifiedDate = p122.ModifiedDate,
                IsDeleted = p122.IsDeleted,
                DeletedBy = p122.DeletedBy,
                DeletedDate = p122.DeletedDate,
                AppUserRoles = funcMain112(p122.AppUserRoles),
                AppRoleClaims = funcMain113(p122.AppRoleClaims),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p122.AccessControlEntries),
                Hash = p122.Hash,
                Id = p122.Id,
                Name = p122.Name,
                NormalizedName = p122.NormalizedName,
                ConcurrencyStamp = p122.ConcurrencyStamp
            };
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain121(ICollection<AppUserRole> p132)
        {
            if (p132 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p132.Count);
            
            IEnumerator<AppUserRole> enumerator = p132.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(funcMain122(item));
            }
            return result;
            
        }
        
        private static ICollection<AppRoleClaimReadModel> funcMain126(ICollection<AppRoleClaim> p137)
        {
            if (p137 == null)
            {
                return null;
            }
            ICollection<AppRoleClaimReadModel> result = new List<AppRoleClaimReadModel>(p137.Count);
            
            IEnumerator<AppRoleClaim> enumerator = p137.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRoleClaim item = enumerator.Current;
                result.Add(item == null ? null : new AppRoleClaimReadModel()
                {
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Id = item.Id,
                    RoleId = item.RoleId,
                    ClaimType = item.ClaimType,
                    ClaimValue = item.ClaimValue
                });
            }
            return result;
            
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain129(ICollection<AppUserRole> p140)
        {
            if (p140 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p140.Count);
            
            IEnumerator<AppUserRole> enumerator = p140.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(funcMain130(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserTokenReadModel> funcMain133(ICollection<AppUserToken> p144)
        {
            if (p144 == null)
            {
                return null;
            }
            ICollection<AppUserTokenReadModel> result = new List<AppUserTokenReadModel>(p144.Count);
            
            IEnumerator<AppUserToken> enumerator = p144.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserToken item = enumerator.Current;
                result.Add(item == null ? null : new AppUserTokenReadModel()
                {
                    Token = item.Token,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    LoginProvider = item.LoginProvider,
                    Name = item.Name,
                    Value = item.Value
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRefreshTokenReadModel> funcMain134(ICollection<AppRefreshToken> p145)
        {
            if (p145 == null)
            {
                return null;
            }
            ICollection<AppRefreshTokenReadModel> result = new List<AppRefreshTokenReadModel>(p145.Count);
            
            IEnumerator<AppRefreshToken> enumerator = p145.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRefreshToken item = enumerator.Current;
                result.Add(item == null ? null : new AppRefreshTokenReadModel()
                {
                    UserId = item.UserId,
                    Token = item.Token,
                    JwtId = item.JwtId,
                    IsUsed = item.IsUsed,
                    IsRevoked = item.IsRevoked,
                    ExpiryDate = item.ExpiryDate,
                    Hash = item.Hash,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain141(ICollection<AppUserRole> p157)
        {
            if (p157 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p157.Count);
            
            IEnumerator<AppUserRole> enumerator = p157.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(funcMain142(item));
            }
            return result;
            
        }
        
        private static ICollection<AppRoleClaimReadModel> funcMain146(ICollection<AppRoleClaim> p162)
        {
            if (p162 == null)
            {
                return null;
            }
            ICollection<AppRoleClaimReadModel> result = new List<AppRoleClaimReadModel>(p162.Count);
            
            IEnumerator<AppRoleClaim> enumerator = p162.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRoleClaim item = enumerator.Current;
                result.Add(item == null ? null : new AppRoleClaimReadModel()
                {
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Id = item.Id,
                    RoleId = item.RoleId,
                    ClaimType = item.ClaimType,
                    ClaimValue = item.ClaimValue
                });
            }
            return result;
            
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain149(ICollection<AppUserRole> p165)
        {
            if (p165 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p165.Count);
            
            IEnumerator<AppUserRole> enumerator = p165.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(funcMain150(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserTokenReadModel> funcMain153(ICollection<AppUserToken> p169)
        {
            if (p169 == null)
            {
                return null;
            }
            ICollection<AppUserTokenReadModel> result = new List<AppUserTokenReadModel>(p169.Count);
            
            IEnumerator<AppUserToken> enumerator = p169.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserToken item = enumerator.Current;
                result.Add(item == null ? null : new AppUserTokenReadModel()
                {
                    Token = item.Token,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    LoginProvider = item.LoginProvider,
                    Name = item.Name,
                    Value = item.Value
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRefreshTokenReadModel> funcMain154(ICollection<AppRefreshToken> p170)
        {
            if (p170 == null)
            {
                return null;
            }
            ICollection<AppRefreshTokenReadModel> result = new List<AppRefreshTokenReadModel>(p170.Count);
            
            IEnumerator<AppRefreshToken> enumerator = p170.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRefreshToken item = enumerator.Current;
                result.Add(item == null ? null : new AppRefreshTokenReadModel()
                {
                    UserId = item.UserId,
                    Token = item.Token,
                    JwtId = item.JwtId,
                    IsUsed = item.IsUsed,
                    IsRevoked = item.IsRevoked,
                    ExpiryDate = item.ExpiryDate,
                    Hash = item.Hash,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static ICollection<AppUserTokenReadModel> funcMain160(ICollection<AppUserToken> p177)
        {
            if (p177 == null)
            {
                return null;
            }
            ICollection<AppUserTokenReadModel> result = new List<AppUserTokenReadModel>(p177.Count);
            
            IEnumerator<AppUserToken> enumerator = p177.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserToken item = enumerator.Current;
                result.Add(item == null ? null : new AppUserTokenReadModel()
                {
                    Token = item.Token,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    LoginProvider = item.LoginProvider,
                    Name = item.Name,
                    Value = item.Value
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRefreshTokenReadModel> funcMain161(ICollection<AppRefreshToken> p178)
        {
            if (p178 == null)
            {
                return null;
            }
            ICollection<AppRefreshTokenReadModel> result = new List<AppRefreshTokenReadModel>(p178.Count);
            
            IEnumerator<AppRefreshToken> enumerator = p178.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRefreshToken item = enumerator.Current;
                result.Add(item == null ? null : new AppRefreshTokenReadModel()
                {
                    UserId = item.UserId,
                    Token = item.Token,
                    JwtId = item.JwtId,
                    IsUsed = item.IsUsed,
                    IsRevoked = item.IsRevoked,
                    ExpiryDate = item.ExpiryDate,
                    Hash = item.Hash,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static ICollection<AppAccessControlEntryReadModel> funcMain162(ICollection<AppAccessControlEntry> p179)
        {
            if (p179 == null)
            {
                return null;
            }
            ICollection<AppAccessControlEntryReadModel> result = new List<AppAccessControlEntryReadModel>(p179.Count);
            
            IEnumerator<AppAccessControlEntry> enumerator = p179.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppAccessControlEntry item = enumerator.Current;
                result.Add(funcMain163(item));
            }
            return result;
            
        }
        
        private static ICollection<AppFeatureFlagReadModel> funcMain171(ICollection<AppFeatureFlag> p188)
        {
            if (p188 == null)
            {
                return null;
            }
            ICollection<AppFeatureFlagReadModel> result = new List<AppFeatureFlagReadModel>(p188.Count);
            
            IEnumerator<AppFeatureFlag> enumerator = p188.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppFeatureFlag item = enumerator.Current;
                result.Add(item == null ? null : new AppFeatureFlagReadModel()
                {
                    FeatureId = item.FeatureId,
                    ScopeIdentifier = item.ScopeIdentifier,
                    IsEnabled = item.IsEnabled,
                    Feature = TypeAdapter<AppFeature, AppFeatureReadModel>.Map.Invoke(item.Feature),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static AppUserReadModel funcMain173(AppUser p190)
        {
            return p190 == null ? null : new AppUserReadModel()
            {
                Hash = p190.Hash,
                FirstName = p190.FirstName,
                LastName = p190.LastName,
                Mobile = p190.Mobile,
                CountryCode = p190.CountryCode,
                TwoFactorMethod = p190.TwoFactorMethod,
                CreatedBy = p190.CreatedBy,
                CreatedDate = p190.CreatedDate,
                ModifiedBy = p190.ModifiedBy,
                ModifiedDate = p190.ModifiedDate,
                IsDeleted = p190.IsDeleted,
                DeletedBy = p190.DeletedBy,
                DeletedDate = p190.DeletedDate,
                MembershipType = p190.MembershipType,
                UserRoles = funcMain174(p190.UserRoles),
                UserTokens = funcMain175(p190.UserTokens),
                RefreshTokens = funcMain176(p190.RefreshTokens),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p190.AccessControlEntries),
                Id = p190.Id,
                UserName = p190.UserName,
                NormalizedUserName = p190.NormalizedUserName,
                Email = p190.Email,
                NormalizedEmail = p190.NormalizedEmail,
                EmailConfirmed = p190.EmailConfirmed,
                PasswordHash = p190.PasswordHash,
                SecurityStamp = p190.SecurityStamp,
                ConcurrencyStamp = p190.ConcurrencyStamp,
                PhoneNumber = p190.PhoneNumber,
                PhoneNumberConfirmed = p190.PhoneNumberConfirmed,
                TwoFactorEnabled = p190.TwoFactorEnabled,
                LockoutEnd = p190.LockoutEnd,
                LockoutEnabled = p190.LockoutEnabled,
                AccessFailedCount = p190.AccessFailedCount
            };
        }
        
        private static ICollection<AppRoleClaimReadModel> funcMain182(ICollection<AppRoleClaim> p200)
        {
            if (p200 == null)
            {
                return null;
            }
            ICollection<AppRoleClaimReadModel> result = new List<AppRoleClaimReadModel>(p200.Count);
            
            IEnumerator<AppRoleClaim> enumerator = p200.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRoleClaim item = enumerator.Current;
                result.Add(item == null ? null : new AppRoleClaimReadModel()
                {
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Id = item.Id,
                    RoleId = item.RoleId,
                    ClaimType = item.ClaimType,
                    ClaimValue = item.ClaimValue
                });
            }
            return result;
            
        }
        
        private static ICollection<AppAccessControlEntryReadModel> funcMain183(ICollection<AppAccessControlEntry> p201)
        {
            if (p201 == null)
            {
                return null;
            }
            ICollection<AppAccessControlEntryReadModel> result = new List<AppAccessControlEntryReadModel>(p201.Count);
            
            IEnumerator<AppAccessControlEntry> enumerator = p201.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppAccessControlEntry item = enumerator.Current;
                result.Add(funcMain184(item));
            }
            return result;
            
        }
        
        private static ICollection<AppFeatureFlagReadModel> funcMain193(ICollection<AppFeatureFlag> p211)
        {
            if (p211 == null)
            {
                return null;
            }
            ICollection<AppFeatureFlagReadModel> result = new List<AppFeatureFlagReadModel>(p211.Count);
            
            IEnumerator<AppFeatureFlag> enumerator = p211.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppFeatureFlag item = enumerator.Current;
                result.Add(item == null ? null : new AppFeatureFlagReadModel()
                {
                    FeatureId = item.FeatureId,
                    ScopeIdentifier = item.ScopeIdentifier,
                    IsEnabled = item.IsEnabled,
                    Feature = TypeAdapter<AppFeature, AppFeatureReadModel>.Map.Invoke(item.Feature),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static AppRoleReadModel funcMain195(AppRole p213)
        {
            return p213 == null ? null : new AppRoleReadModel()
            {
                CreatedBy = p213.CreatedBy,
                CreatedDate = p213.CreatedDate,
                ModifiedBy = p213.ModifiedBy,
                ModifiedDate = p213.ModifiedDate,
                IsDeleted = p213.IsDeleted,
                DeletedBy = p213.DeletedBy,
                DeletedDate = p213.DeletedDate,
                AppUserRoles = funcMain196(p213.AppUserRoles),
                AppRoleClaims = funcMain197(p213.AppRoleClaims),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p213.AccessControlEntries),
                Hash = p213.Hash,
                Id = p213.Id,
                Name = p213.Name,
                NormalizedName = p213.NormalizedName,
                ConcurrencyStamp = p213.ConcurrencyStamp
            };
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain205(ICollection<AppUserRole> p225)
        {
            if (p225 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p225.Count);
            
            IEnumerator<AppUserRole> enumerator = p225.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(funcMain206(item));
            }
            return result;
            
        }
        
        private static ICollection<AppRoleClaimReadModel> funcMain210(ICollection<AppRoleClaim> p230)
        {
            if (p230 == null)
            {
                return null;
            }
            ICollection<AppRoleClaimReadModel> result = new List<AppRoleClaimReadModel>(p230.Count);
            
            IEnumerator<AppRoleClaim> enumerator = p230.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRoleClaim item = enumerator.Current;
                result.Add(item == null ? null : new AppRoleClaimReadModel()
                {
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Id = item.Id,
                    RoleId = item.RoleId,
                    ClaimType = item.ClaimType,
                    ClaimValue = item.ClaimValue
                });
            }
            return result;
            
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain213(ICollection<AppUserRole> p233)
        {
            if (p233 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p233.Count);
            
            IEnumerator<AppUserRole> enumerator = p233.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(funcMain214(item));
            }
            return result;
            
        }
        
        private static ICollection<AppUserTokenReadModel> funcMain217(ICollection<AppUserToken> p237)
        {
            if (p237 == null)
            {
                return null;
            }
            ICollection<AppUserTokenReadModel> result = new List<AppUserTokenReadModel>(p237.Count);
            
            IEnumerator<AppUserToken> enumerator = p237.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserToken item = enumerator.Current;
                result.Add(item == null ? null : new AppUserTokenReadModel()
                {
                    Token = item.Token,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    LoginProvider = item.LoginProvider,
                    Name = item.Name,
                    Value = item.Value
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRefreshTokenReadModel> funcMain218(ICollection<AppRefreshToken> p238)
        {
            if (p238 == null)
            {
                return null;
            }
            ICollection<AppRefreshTokenReadModel> result = new List<AppRefreshTokenReadModel>(p238.Count);
            
            IEnumerator<AppRefreshToken> enumerator = p238.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRefreshToken item = enumerator.Current;
                result.Add(item == null ? null : new AppRefreshTokenReadModel()
                {
                    UserId = item.UserId,
                    Token = item.Token,
                    JwtId = item.JwtId,
                    IsUsed = item.IsUsed,
                    IsRevoked = item.IsRevoked,
                    ExpiryDate = item.ExpiryDate,
                    Hash = item.Hash,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static AppUserRoleReadModel funcMain58(AppUserRole p69)
        {
            return p69 == null ? null : new AppUserRoleReadModel()
            {
                AppUser = funcMain59(p69.AppUser),
                AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(p69.AppRole),
                Hash = p69.Hash,
                CreatedBy = p69.CreatedBy,
                CreatedDate = p69.CreatedDate,
                ModifiedBy = p69.ModifiedBy,
                ModifiedDate = p69.ModifiedDate,
                IsDeleted = p69.IsDeleted,
                DeletedBy = p69.DeletedBy,
                DeletedDate = p69.DeletedDate,
                UserId = p69.UserId,
                RoleId = p69.RoleId
            };
        }
        
        private static AppUserRoleReadModel funcMain66(AppUserRole p77)
        {
            return p77 == null ? null : new AppUserRoleReadModel()
            {
                AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(p77.AppUser),
                AppRole = funcMain67(p77.AppRole),
                Hash = p77.Hash,
                CreatedBy = p77.CreatedBy,
                CreatedDate = p77.CreatedDate,
                ModifiedBy = p77.ModifiedBy,
                ModifiedDate = p77.ModifiedDate,
                IsDeleted = p77.IsDeleted,
                DeletedBy = p77.DeletedBy,
                DeletedDate = p77.DeletedDate,
                UserId = p77.UserId,
                RoleId = p77.RoleId
            };
        }
        
        private static AppAccessControlEntryReadModel funcMain79(AppAccessControlEntry p90)
        {
            return p90 == null ? null : new AppAccessControlEntryReadModel()
            {
                ResourcePattern = p90.ResourcePattern,
                PermissionPattern = p90.PermissionPattern,
                FeatureId = p90.FeatureId,
                Feature = funcMain80(p90.Feature),
                AppRoles = TypeAdapter<ICollection<AppRole>, ICollection<AppRoleReadModel>>.Map.Invoke(p90.AppRoles),
                AppUsers = funcMain82(p90.AppUsers),
                AppResource = p90.AppResource == null ? null : new AppResourceReadModel()
                {
                    Url = p90.AppResource.Url,
                    Description = p90.AppResource.Description,
                    ResourceType = p90.AppResource.ResourceType,
                    AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p90.AppResource.AccessControlEntries),
                    Id = p90.AppResource.Id,
                    CreatedBy = p90.AppResource.CreatedBy,
                    CreatedDate = p90.AppResource.CreatedDate,
                    ModifiedBy = p90.AppResource.ModifiedBy,
                    ModifiedDate = p90.AppResource.ModifiedDate,
                    IsDeleted = p90.AppResource.IsDeleted,
                    DeletedBy = p90.AppResource.DeletedBy,
                    DeletedDate = p90.AppResource.DeletedDate
                },
                ResourceId = p90.ResourceId,
                Id = p90.Id,
                CreatedBy = p90.CreatedBy,
                CreatedDate = p90.CreatedDate,
                ModifiedBy = p90.ModifiedBy,
                ModifiedDate = p90.ModifiedDate,
                IsDeleted = p90.IsDeleted,
                DeletedBy = p90.DeletedBy,
                DeletedDate = p90.DeletedDate
            };
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain90(ICollection<AppUserRole> p101)
        {
            if (p101 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p101.Count);
            
            IEnumerator<AppUserRole> enumerator = p101.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(item == null ? null : new AppUserRoleReadModel()
                {
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Hash = item.Hash,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    RoleId = item.RoleId
                });
            }
            return result;
            
        }
        
        private static ICollection<AppUserTokenReadModel> funcMain91(ICollection<AppUserToken> p102)
        {
            if (p102 == null)
            {
                return null;
            }
            ICollection<AppUserTokenReadModel> result = new List<AppUserTokenReadModel>(p102.Count);
            
            IEnumerator<AppUserToken> enumerator = p102.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserToken item = enumerator.Current;
                result.Add(item == null ? null : new AppUserTokenReadModel()
                {
                    Token = item.Token,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    LoginProvider = item.LoginProvider,
                    Name = item.Name,
                    Value = item.Value
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRefreshTokenReadModel> funcMain92(ICollection<AppRefreshToken> p103)
        {
            if (p103 == null)
            {
                return null;
            }
            ICollection<AppRefreshTokenReadModel> result = new List<AppRefreshTokenReadModel>(p103.Count);
            
            IEnumerator<AppRefreshToken> enumerator = p103.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRefreshToken item = enumerator.Current;
                result.Add(item == null ? null : new AppRefreshTokenReadModel()
                {
                    UserId = item.UserId,
                    Token = item.Token,
                    JwtId = item.JwtId,
                    IsUsed = item.IsUsed,
                    IsRevoked = item.IsRevoked,
                    ExpiryDate = item.ExpiryDate,
                    Hash = item.Hash,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static AppAccessControlEntryReadModel funcMain100(AppAccessControlEntry p111)
        {
            return p111 == null ? null : new AppAccessControlEntryReadModel()
            {
                ResourcePattern = p111.ResourcePattern,
                PermissionPattern = p111.PermissionPattern,
                FeatureId = p111.FeatureId,
                Feature = funcMain101(p111.Feature),
                AppRoles = funcMain103(p111.AppRoles),
                AppUsers = TypeAdapter<ICollection<AppUser>, ICollection<AppUserReadModel>>.Map.Invoke(p111.AppUsers),
                AppResource = p111.AppResource == null ? null : new AppResourceReadModel()
                {
                    Url = p111.AppResource.Url,
                    Description = p111.AppResource.Description,
                    ResourceType = p111.AppResource.ResourceType,
                    AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p111.AppResource.AccessControlEntries),
                    Id = p111.AppResource.Id,
                    CreatedBy = p111.AppResource.CreatedBy,
                    CreatedDate = p111.AppResource.CreatedDate,
                    ModifiedBy = p111.AppResource.ModifiedBy,
                    ModifiedDate = p111.AppResource.ModifiedDate,
                    IsDeleted = p111.AppResource.IsDeleted,
                    DeletedBy = p111.AppResource.DeletedBy,
                    DeletedDate = p111.AppResource.DeletedDate
                },
                ResourceId = p111.ResourceId,
                Id = p111.Id,
                CreatedBy = p111.CreatedBy,
                CreatedDate = p111.CreatedDate,
                ModifiedBy = p111.ModifiedBy,
                ModifiedDate = p111.ModifiedDate,
                IsDeleted = p111.IsDeleted,
                DeletedBy = p111.DeletedBy,
                DeletedDate = p111.DeletedDate
            };
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain112(ICollection<AppUserRole> p123)
        {
            if (p123 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p123.Count);
            
            IEnumerator<AppUserRole> enumerator = p123.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(item == null ? null : new AppUserRoleReadModel()
                {
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Hash = item.Hash,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    RoleId = item.RoleId
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRoleClaimReadModel> funcMain113(ICollection<AppRoleClaim> p124)
        {
            if (p124 == null)
            {
                return null;
            }
            ICollection<AppRoleClaimReadModel> result = new List<AppRoleClaimReadModel>(p124.Count);
            
            IEnumerator<AppRoleClaim> enumerator = p124.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRoleClaim item = enumerator.Current;
                result.Add(item == null ? null : new AppRoleClaimReadModel()
                {
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Id = item.Id,
                    RoleId = item.RoleId,
                    ClaimType = item.ClaimType,
                    ClaimValue = item.ClaimValue
                });
            }
            return result;
            
        }
        
        private static AppUserRoleReadModel funcMain122(AppUserRole p133)
        {
            return p133 == null ? null : new AppUserRoleReadModel()
            {
                AppUser = funcMain123(p133.AppUser),
                AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(p133.AppRole),
                Hash = p133.Hash,
                CreatedBy = p133.CreatedBy,
                CreatedDate = p133.CreatedDate,
                ModifiedBy = p133.ModifiedBy,
                ModifiedDate = p133.ModifiedDate,
                IsDeleted = p133.IsDeleted,
                DeletedBy = p133.DeletedBy,
                DeletedDate = p133.DeletedDate,
                UserId = p133.UserId,
                RoleId = p133.RoleId
            };
        }
        
        private static AppUserRoleReadModel funcMain130(AppUserRole p141)
        {
            return p141 == null ? null : new AppUserRoleReadModel()
            {
                AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(p141.AppUser),
                AppRole = funcMain131(p141.AppRole),
                Hash = p141.Hash,
                CreatedBy = p141.CreatedBy,
                CreatedDate = p141.CreatedDate,
                ModifiedBy = p141.ModifiedBy,
                ModifiedDate = p141.ModifiedDate,
                IsDeleted = p141.IsDeleted,
                DeletedBy = p141.DeletedBy,
                DeletedDate = p141.DeletedDate,
                UserId = p141.UserId,
                RoleId = p141.RoleId
            };
        }
        
        private static AppUserRoleReadModel funcMain142(AppUserRole p158)
        {
            return p158 == null ? null : new AppUserRoleReadModel()
            {
                AppUser = funcMain143(p158.AppUser),
                AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(p158.AppRole),
                Hash = p158.Hash,
                CreatedBy = p158.CreatedBy,
                CreatedDate = p158.CreatedDate,
                ModifiedBy = p158.ModifiedBy,
                ModifiedDate = p158.ModifiedDate,
                IsDeleted = p158.IsDeleted,
                DeletedBy = p158.DeletedBy,
                DeletedDate = p158.DeletedDate,
                UserId = p158.UserId,
                RoleId = p158.RoleId
            };
        }
        
        private static AppUserRoleReadModel funcMain150(AppUserRole p166)
        {
            return p166 == null ? null : new AppUserRoleReadModel()
            {
                AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(p166.AppUser),
                AppRole = funcMain151(p166.AppRole),
                Hash = p166.Hash,
                CreatedBy = p166.CreatedBy,
                CreatedDate = p166.CreatedDate,
                ModifiedBy = p166.ModifiedBy,
                ModifiedDate = p166.ModifiedDate,
                IsDeleted = p166.IsDeleted,
                DeletedBy = p166.DeletedBy,
                DeletedDate = p166.DeletedDate,
                UserId = p166.UserId,
                RoleId = p166.RoleId
            };
        }
        
        private static AppAccessControlEntryReadModel funcMain163(AppAccessControlEntry p180)
        {
            return p180 == null ? null : new AppAccessControlEntryReadModel()
            {
                ResourcePattern = p180.ResourcePattern,
                PermissionPattern = p180.PermissionPattern,
                FeatureId = p180.FeatureId,
                Feature = funcMain164(p180.Feature),
                AppRoles = TypeAdapter<ICollection<AppRole>, ICollection<AppRoleReadModel>>.Map.Invoke(p180.AppRoles),
                AppUsers = funcMain166(p180.AppUsers),
                AppResource = p180.AppResource == null ? null : new AppResourceReadModel()
                {
                    Url = p180.AppResource.Url,
                    Description = p180.AppResource.Description,
                    ResourceType = p180.AppResource.ResourceType,
                    AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p180.AppResource.AccessControlEntries),
                    Id = p180.AppResource.Id,
                    CreatedBy = p180.AppResource.CreatedBy,
                    CreatedDate = p180.AppResource.CreatedDate,
                    ModifiedBy = p180.AppResource.ModifiedBy,
                    ModifiedDate = p180.AppResource.ModifiedDate,
                    IsDeleted = p180.AppResource.IsDeleted,
                    DeletedBy = p180.AppResource.DeletedBy,
                    DeletedDate = p180.AppResource.DeletedDate
                },
                ResourceId = p180.ResourceId,
                Id = p180.Id,
                CreatedBy = p180.CreatedBy,
                CreatedDate = p180.CreatedDate,
                ModifiedBy = p180.ModifiedBy,
                ModifiedDate = p180.ModifiedDate,
                IsDeleted = p180.IsDeleted,
                DeletedBy = p180.DeletedBy,
                DeletedDate = p180.DeletedDate
            };
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain174(ICollection<AppUserRole> p191)
        {
            if (p191 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p191.Count);
            
            IEnumerator<AppUserRole> enumerator = p191.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(item == null ? null : new AppUserRoleReadModel()
                {
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Hash = item.Hash,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    RoleId = item.RoleId
                });
            }
            return result;
            
        }
        
        private static ICollection<AppUserTokenReadModel> funcMain175(ICollection<AppUserToken> p192)
        {
            if (p192 == null)
            {
                return null;
            }
            ICollection<AppUserTokenReadModel> result = new List<AppUserTokenReadModel>(p192.Count);
            
            IEnumerator<AppUserToken> enumerator = p192.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserToken item = enumerator.Current;
                result.Add(item == null ? null : new AppUserTokenReadModel()
                {
                    Token = item.Token,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    LoginProvider = item.LoginProvider,
                    Name = item.Name,
                    Value = item.Value
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRefreshTokenReadModel> funcMain176(ICollection<AppRefreshToken> p193)
        {
            if (p193 == null)
            {
                return null;
            }
            ICollection<AppRefreshTokenReadModel> result = new List<AppRefreshTokenReadModel>(p193.Count);
            
            IEnumerator<AppRefreshToken> enumerator = p193.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRefreshToken item = enumerator.Current;
                result.Add(item == null ? null : new AppRefreshTokenReadModel()
                {
                    UserId = item.UserId,
                    Token = item.Token,
                    JwtId = item.JwtId,
                    IsUsed = item.IsUsed,
                    IsRevoked = item.IsRevoked,
                    ExpiryDate = item.ExpiryDate,
                    Hash = item.Hash,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static AppAccessControlEntryReadModel funcMain184(AppAccessControlEntry p202)
        {
            return p202 == null ? null : new AppAccessControlEntryReadModel()
            {
                ResourcePattern = p202.ResourcePattern,
                PermissionPattern = p202.PermissionPattern,
                FeatureId = p202.FeatureId,
                Feature = funcMain185(p202.Feature),
                AppRoles = funcMain187(p202.AppRoles),
                AppUsers = TypeAdapter<ICollection<AppUser>, ICollection<AppUserReadModel>>.Map.Invoke(p202.AppUsers),
                AppResource = p202.AppResource == null ? null : new AppResourceReadModel()
                {
                    Url = p202.AppResource.Url,
                    Description = p202.AppResource.Description,
                    ResourceType = p202.AppResource.ResourceType,
                    AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p202.AppResource.AccessControlEntries),
                    Id = p202.AppResource.Id,
                    CreatedBy = p202.AppResource.CreatedBy,
                    CreatedDate = p202.AppResource.CreatedDate,
                    ModifiedBy = p202.AppResource.ModifiedBy,
                    ModifiedDate = p202.AppResource.ModifiedDate,
                    IsDeleted = p202.AppResource.IsDeleted,
                    DeletedBy = p202.AppResource.DeletedBy,
                    DeletedDate = p202.AppResource.DeletedDate
                },
                ResourceId = p202.ResourceId,
                Id = p202.Id,
                CreatedBy = p202.CreatedBy,
                CreatedDate = p202.CreatedDate,
                ModifiedBy = p202.ModifiedBy,
                ModifiedDate = p202.ModifiedDate,
                IsDeleted = p202.IsDeleted,
                DeletedBy = p202.DeletedBy,
                DeletedDate = p202.DeletedDate
            };
        }
        
        private static ICollection<AppUserRoleReadModel> funcMain196(ICollection<AppUserRole> p214)
        {
            if (p214 == null)
            {
                return null;
            }
            ICollection<AppUserRoleReadModel> result = new List<AppUserRoleReadModel>(p214.Count);
            
            IEnumerator<AppUserRole> enumerator = p214.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserRole item = enumerator.Current;
                result.Add(item == null ? null : new AppUserRoleReadModel()
                {
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Hash = item.Hash,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    RoleId = item.RoleId
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRoleClaimReadModel> funcMain197(ICollection<AppRoleClaim> p215)
        {
            if (p215 == null)
            {
                return null;
            }
            ICollection<AppRoleClaimReadModel> result = new List<AppRoleClaimReadModel>(p215.Count);
            
            IEnumerator<AppRoleClaim> enumerator = p215.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRoleClaim item = enumerator.Current;
                result.Add(item == null ? null : new AppRoleClaimReadModel()
                {
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Id = item.Id,
                    RoleId = item.RoleId,
                    ClaimType = item.ClaimType,
                    ClaimValue = item.ClaimValue
                });
            }
            return result;
            
        }
        
        private static AppUserRoleReadModel funcMain206(AppUserRole p226)
        {
            return p226 == null ? null : new AppUserRoleReadModel()
            {
                AppUser = funcMain207(p226.AppUser),
                AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(p226.AppRole),
                Hash = p226.Hash,
                CreatedBy = p226.CreatedBy,
                CreatedDate = p226.CreatedDate,
                ModifiedBy = p226.ModifiedBy,
                ModifiedDate = p226.ModifiedDate,
                IsDeleted = p226.IsDeleted,
                DeletedBy = p226.DeletedBy,
                DeletedDate = p226.DeletedDate,
                UserId = p226.UserId,
                RoleId = p226.RoleId
            };
        }
        
        private static AppUserRoleReadModel funcMain214(AppUserRole p234)
        {
            return p234 == null ? null : new AppUserRoleReadModel()
            {
                AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(p234.AppUser),
                AppRole = funcMain215(p234.AppRole),
                Hash = p234.Hash,
                CreatedBy = p234.CreatedBy,
                CreatedDate = p234.CreatedDate,
                ModifiedBy = p234.ModifiedBy,
                ModifiedDate = p234.ModifiedDate,
                IsDeleted = p234.IsDeleted,
                DeletedBy = p234.DeletedBy,
                DeletedDate = p234.DeletedDate,
                UserId = p234.UserId,
                RoleId = p234.RoleId
            };
        }
        
        private static AppUserReadModel funcMain59(AppUser p70)
        {
            return p70 == null ? null : new AppUserReadModel()
            {
                Hash = p70.Hash,
                FirstName = p70.FirstName,
                LastName = p70.LastName,
                Mobile = p70.Mobile,
                CountryCode = p70.CountryCode,
                TwoFactorMethod = p70.TwoFactorMethod,
                CreatedBy = p70.CreatedBy,
                CreatedDate = p70.CreatedDate,
                ModifiedBy = p70.ModifiedBy,
                ModifiedDate = p70.ModifiedDate,
                IsDeleted = p70.IsDeleted,
                DeletedBy = p70.DeletedBy,
                DeletedDate = p70.DeletedDate,
                MembershipType = p70.MembershipType,
                UserRoles = TypeAdapter<ICollection<AppUserRole>, ICollection<AppUserRoleReadModel>>.Map.Invoke(p70.UserRoles),
                UserTokens = funcMain60(p70.UserTokens),
                RefreshTokens = funcMain61(p70.RefreshTokens),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p70.AccessControlEntries),
                Id = p70.Id,
                UserName = p70.UserName,
                NormalizedUserName = p70.NormalizedUserName,
                Email = p70.Email,
                NormalizedEmail = p70.NormalizedEmail,
                EmailConfirmed = p70.EmailConfirmed,
                PasswordHash = p70.PasswordHash,
                SecurityStamp = p70.SecurityStamp,
                ConcurrencyStamp = p70.ConcurrencyStamp,
                PhoneNumber = p70.PhoneNumber,
                PhoneNumberConfirmed = p70.PhoneNumberConfirmed,
                TwoFactorEnabled = p70.TwoFactorEnabled,
                LockoutEnd = p70.LockoutEnd,
                LockoutEnabled = p70.LockoutEnabled,
                AccessFailedCount = p70.AccessFailedCount
            };
        }
        
        private static AppRoleReadModel funcMain67(AppRole p78)
        {
            return p78 == null ? null : new AppRoleReadModel()
            {
                CreatedBy = p78.CreatedBy,
                CreatedDate = p78.CreatedDate,
                ModifiedBy = p78.ModifiedBy,
                ModifiedDate = p78.ModifiedDate,
                IsDeleted = p78.IsDeleted,
                DeletedBy = p78.DeletedBy,
                DeletedDate = p78.DeletedDate,
                AppUserRoles = TypeAdapter<ICollection<AppUserRole>, ICollection<AppUserRoleReadModel>>.Map.Invoke(p78.AppUserRoles),
                AppRoleClaims = funcMain68(p78.AppRoleClaims),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p78.AccessControlEntries),
                Hash = p78.Hash,
                Id = p78.Id,
                Name = p78.Name,
                NormalizedName = p78.NormalizedName,
                ConcurrencyStamp = p78.ConcurrencyStamp
            };
        }
        
        private static AppFeatureReadModel funcMain80(AppFeature p91)
        {
            return p91 == null ? null : new AppFeatureReadModel()
            {
                Name = p91.Name,
                Description = p91.Description,
                IsEnabled = p91.IsEnabled,
                Scope = p91.Scope,
                FeatureFlags = funcMain81(p91.FeatureFlags),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p91.AccessControlEntries),
                Id = p91.Id,
                CreatedBy = p91.CreatedBy,
                CreatedDate = p91.CreatedDate,
                ModifiedBy = p91.ModifiedBy,
                ModifiedDate = p91.ModifiedDate,
                IsDeleted = p91.IsDeleted,
                DeletedBy = p91.DeletedBy,
                DeletedDate = p91.DeletedDate
            };
        }
        
        private static ICollection<AppUserReadModel> funcMain82(ICollection<AppUser> p93)
        {
            if (p93 == null)
            {
                return null;
            }
            ICollection<AppUserReadModel> result = new List<AppUserReadModel>(p93.Count);
            
            IEnumerator<AppUser> enumerator = p93.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUser item = enumerator.Current;
                result.Add(TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static AppFeatureReadModel funcMain101(AppFeature p112)
        {
            return p112 == null ? null : new AppFeatureReadModel()
            {
                Name = p112.Name,
                Description = p112.Description,
                IsEnabled = p112.IsEnabled,
                Scope = p112.Scope,
                FeatureFlags = funcMain102(p112.FeatureFlags),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p112.AccessControlEntries),
                Id = p112.Id,
                CreatedBy = p112.CreatedBy,
                CreatedDate = p112.CreatedDate,
                ModifiedBy = p112.ModifiedBy,
                ModifiedDate = p112.ModifiedDate,
                IsDeleted = p112.IsDeleted,
                DeletedBy = p112.DeletedBy,
                DeletedDate = p112.DeletedDate
            };
        }
        
        private static ICollection<AppRoleReadModel> funcMain103(ICollection<AppRole> p114)
        {
            if (p114 == null)
            {
                return null;
            }
            ICollection<AppRoleReadModel> result = new List<AppRoleReadModel>(p114.Count);
            
            IEnumerator<AppRole> enumerator = p114.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRole item = enumerator.Current;
                result.Add(TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static AppUserReadModel funcMain123(AppUser p134)
        {
            return p134 == null ? null : new AppUserReadModel()
            {
                Hash = p134.Hash,
                FirstName = p134.FirstName,
                LastName = p134.LastName,
                Mobile = p134.Mobile,
                CountryCode = p134.CountryCode,
                TwoFactorMethod = p134.TwoFactorMethod,
                CreatedBy = p134.CreatedBy,
                CreatedDate = p134.CreatedDate,
                ModifiedBy = p134.ModifiedBy,
                ModifiedDate = p134.ModifiedDate,
                IsDeleted = p134.IsDeleted,
                DeletedBy = p134.DeletedBy,
                DeletedDate = p134.DeletedDate,
                MembershipType = p134.MembershipType,
                UserRoles = TypeAdapter<ICollection<AppUserRole>, ICollection<AppUserRoleReadModel>>.Map.Invoke(p134.UserRoles),
                UserTokens = funcMain124(p134.UserTokens),
                RefreshTokens = funcMain125(p134.RefreshTokens),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p134.AccessControlEntries),
                Id = p134.Id,
                UserName = p134.UserName,
                NormalizedUserName = p134.NormalizedUserName,
                Email = p134.Email,
                NormalizedEmail = p134.NormalizedEmail,
                EmailConfirmed = p134.EmailConfirmed,
                PasswordHash = p134.PasswordHash,
                SecurityStamp = p134.SecurityStamp,
                ConcurrencyStamp = p134.ConcurrencyStamp,
                PhoneNumber = p134.PhoneNumber,
                PhoneNumberConfirmed = p134.PhoneNumberConfirmed,
                TwoFactorEnabled = p134.TwoFactorEnabled,
                LockoutEnd = p134.LockoutEnd,
                LockoutEnabled = p134.LockoutEnabled,
                AccessFailedCount = p134.AccessFailedCount
            };
        }
        
        private static AppRoleReadModel funcMain131(AppRole p142)
        {
            return p142 == null ? null : new AppRoleReadModel()
            {
                CreatedBy = p142.CreatedBy,
                CreatedDate = p142.CreatedDate,
                ModifiedBy = p142.ModifiedBy,
                ModifiedDate = p142.ModifiedDate,
                IsDeleted = p142.IsDeleted,
                DeletedBy = p142.DeletedBy,
                DeletedDate = p142.DeletedDate,
                AppUserRoles = TypeAdapter<ICollection<AppUserRole>, ICollection<AppUserRoleReadModel>>.Map.Invoke(p142.AppUserRoles),
                AppRoleClaims = funcMain132(p142.AppRoleClaims),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p142.AccessControlEntries),
                Hash = p142.Hash,
                Id = p142.Id,
                Name = p142.Name,
                NormalizedName = p142.NormalizedName,
                ConcurrencyStamp = p142.ConcurrencyStamp
            };
        }
        
        private static AppUserReadModel funcMain143(AppUser p159)
        {
            return p159 == null ? null : new AppUserReadModel()
            {
                Hash = p159.Hash,
                FirstName = p159.FirstName,
                LastName = p159.LastName,
                Mobile = p159.Mobile,
                CountryCode = p159.CountryCode,
                TwoFactorMethod = p159.TwoFactorMethod,
                CreatedBy = p159.CreatedBy,
                CreatedDate = p159.CreatedDate,
                ModifiedBy = p159.ModifiedBy,
                ModifiedDate = p159.ModifiedDate,
                IsDeleted = p159.IsDeleted,
                DeletedBy = p159.DeletedBy,
                DeletedDate = p159.DeletedDate,
                MembershipType = p159.MembershipType,
                UserRoles = TypeAdapter<ICollection<AppUserRole>, ICollection<AppUserRoleReadModel>>.Map.Invoke(p159.UserRoles),
                UserTokens = funcMain144(p159.UserTokens),
                RefreshTokens = funcMain145(p159.RefreshTokens),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p159.AccessControlEntries),
                Id = p159.Id,
                UserName = p159.UserName,
                NormalizedUserName = p159.NormalizedUserName,
                Email = p159.Email,
                NormalizedEmail = p159.NormalizedEmail,
                EmailConfirmed = p159.EmailConfirmed,
                PasswordHash = p159.PasswordHash,
                SecurityStamp = p159.SecurityStamp,
                ConcurrencyStamp = p159.ConcurrencyStamp,
                PhoneNumber = p159.PhoneNumber,
                PhoneNumberConfirmed = p159.PhoneNumberConfirmed,
                TwoFactorEnabled = p159.TwoFactorEnabled,
                LockoutEnd = p159.LockoutEnd,
                LockoutEnabled = p159.LockoutEnabled,
                AccessFailedCount = p159.AccessFailedCount
            };
        }
        
        private static AppRoleReadModel funcMain151(AppRole p167)
        {
            return p167 == null ? null : new AppRoleReadModel()
            {
                CreatedBy = p167.CreatedBy,
                CreatedDate = p167.CreatedDate,
                ModifiedBy = p167.ModifiedBy,
                ModifiedDate = p167.ModifiedDate,
                IsDeleted = p167.IsDeleted,
                DeletedBy = p167.DeletedBy,
                DeletedDate = p167.DeletedDate,
                AppUserRoles = TypeAdapter<ICollection<AppUserRole>, ICollection<AppUserRoleReadModel>>.Map.Invoke(p167.AppUserRoles),
                AppRoleClaims = funcMain152(p167.AppRoleClaims),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p167.AccessControlEntries),
                Hash = p167.Hash,
                Id = p167.Id,
                Name = p167.Name,
                NormalizedName = p167.NormalizedName,
                ConcurrencyStamp = p167.ConcurrencyStamp
            };
        }
        
        private static AppFeatureReadModel funcMain164(AppFeature p181)
        {
            return p181 == null ? null : new AppFeatureReadModel()
            {
                Name = p181.Name,
                Description = p181.Description,
                IsEnabled = p181.IsEnabled,
                Scope = p181.Scope,
                FeatureFlags = funcMain165(p181.FeatureFlags),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p181.AccessControlEntries),
                Id = p181.Id,
                CreatedBy = p181.CreatedBy,
                CreatedDate = p181.CreatedDate,
                ModifiedBy = p181.ModifiedBy,
                ModifiedDate = p181.ModifiedDate,
                IsDeleted = p181.IsDeleted,
                DeletedBy = p181.DeletedBy,
                DeletedDate = p181.DeletedDate
            };
        }
        
        private static ICollection<AppUserReadModel> funcMain166(ICollection<AppUser> p183)
        {
            if (p183 == null)
            {
                return null;
            }
            ICollection<AppUserReadModel> result = new List<AppUserReadModel>(p183.Count);
            
            IEnumerator<AppUser> enumerator = p183.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUser item = enumerator.Current;
                result.Add(TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static AppFeatureReadModel funcMain185(AppFeature p203)
        {
            return p203 == null ? null : new AppFeatureReadModel()
            {
                Name = p203.Name,
                Description = p203.Description,
                IsEnabled = p203.IsEnabled,
                Scope = p203.Scope,
                FeatureFlags = funcMain186(p203.FeatureFlags),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p203.AccessControlEntries),
                Id = p203.Id,
                CreatedBy = p203.CreatedBy,
                CreatedDate = p203.CreatedDate,
                ModifiedBy = p203.ModifiedBy,
                ModifiedDate = p203.ModifiedDate,
                IsDeleted = p203.IsDeleted,
                DeletedBy = p203.DeletedBy,
                DeletedDate = p203.DeletedDate
            };
        }
        
        private static ICollection<AppRoleReadModel> funcMain187(ICollection<AppRole> p205)
        {
            if (p205 == null)
            {
                return null;
            }
            ICollection<AppRoleReadModel> result = new List<AppRoleReadModel>(p205.Count);
            
            IEnumerator<AppRole> enumerator = p205.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRole item = enumerator.Current;
                result.Add(TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item));
            }
            return result;
            
        }
        
        private static AppUserReadModel funcMain207(AppUser p227)
        {
            return p227 == null ? null : new AppUserReadModel()
            {
                Hash = p227.Hash,
                FirstName = p227.FirstName,
                LastName = p227.LastName,
                Mobile = p227.Mobile,
                CountryCode = p227.CountryCode,
                TwoFactorMethod = p227.TwoFactorMethod,
                CreatedBy = p227.CreatedBy,
                CreatedDate = p227.CreatedDate,
                ModifiedBy = p227.ModifiedBy,
                ModifiedDate = p227.ModifiedDate,
                IsDeleted = p227.IsDeleted,
                DeletedBy = p227.DeletedBy,
                DeletedDate = p227.DeletedDate,
                MembershipType = p227.MembershipType,
                UserRoles = TypeAdapter<ICollection<AppUserRole>, ICollection<AppUserRoleReadModel>>.Map.Invoke(p227.UserRoles),
                UserTokens = funcMain208(p227.UserTokens),
                RefreshTokens = funcMain209(p227.RefreshTokens),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p227.AccessControlEntries),
                Id = p227.Id,
                UserName = p227.UserName,
                NormalizedUserName = p227.NormalizedUserName,
                Email = p227.Email,
                NormalizedEmail = p227.NormalizedEmail,
                EmailConfirmed = p227.EmailConfirmed,
                PasswordHash = p227.PasswordHash,
                SecurityStamp = p227.SecurityStamp,
                ConcurrencyStamp = p227.ConcurrencyStamp,
                PhoneNumber = p227.PhoneNumber,
                PhoneNumberConfirmed = p227.PhoneNumberConfirmed,
                TwoFactorEnabled = p227.TwoFactorEnabled,
                LockoutEnd = p227.LockoutEnd,
                LockoutEnabled = p227.LockoutEnabled,
                AccessFailedCount = p227.AccessFailedCount
            };
        }
        
        private static AppRoleReadModel funcMain215(AppRole p235)
        {
            return p235 == null ? null : new AppRoleReadModel()
            {
                CreatedBy = p235.CreatedBy,
                CreatedDate = p235.CreatedDate,
                ModifiedBy = p235.ModifiedBy,
                ModifiedDate = p235.ModifiedDate,
                IsDeleted = p235.IsDeleted,
                DeletedBy = p235.DeletedBy,
                DeletedDate = p235.DeletedDate,
                AppUserRoles = TypeAdapter<ICollection<AppUserRole>, ICollection<AppUserRoleReadModel>>.Map.Invoke(p235.AppUserRoles),
                AppRoleClaims = funcMain216(p235.AppRoleClaims),
                AccessControlEntries = TypeAdapter<ICollection<AppAccessControlEntry>, ICollection<AppAccessControlEntryReadModel>>.Map.Invoke(p235.AccessControlEntries),
                Hash = p235.Hash,
                Id = p235.Id,
                Name = p235.Name,
                NormalizedName = p235.NormalizedName,
                ConcurrencyStamp = p235.ConcurrencyStamp
            };
        }
        
        private static ICollection<AppUserTokenReadModel> funcMain60(ICollection<AppUserToken> p71)
        {
            if (p71 == null)
            {
                return null;
            }
            ICollection<AppUserTokenReadModel> result = new List<AppUserTokenReadModel>(p71.Count);
            
            IEnumerator<AppUserToken> enumerator = p71.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserToken item = enumerator.Current;
                result.Add(item == null ? null : new AppUserTokenReadModel()
                {
                    Token = item.Token,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    LoginProvider = item.LoginProvider,
                    Name = item.Name,
                    Value = item.Value
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRefreshTokenReadModel> funcMain61(ICollection<AppRefreshToken> p72)
        {
            if (p72 == null)
            {
                return null;
            }
            ICollection<AppRefreshTokenReadModel> result = new List<AppRefreshTokenReadModel>(p72.Count);
            
            IEnumerator<AppRefreshToken> enumerator = p72.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRefreshToken item = enumerator.Current;
                result.Add(item == null ? null : new AppRefreshTokenReadModel()
                {
                    UserId = item.UserId,
                    Token = item.Token,
                    JwtId = item.JwtId,
                    IsUsed = item.IsUsed,
                    IsRevoked = item.IsRevoked,
                    ExpiryDate = item.ExpiryDate,
                    Hash = item.Hash,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRoleClaimReadModel> funcMain68(ICollection<AppRoleClaim> p79)
        {
            if (p79 == null)
            {
                return null;
            }
            ICollection<AppRoleClaimReadModel> result = new List<AppRoleClaimReadModel>(p79.Count);
            
            IEnumerator<AppRoleClaim> enumerator = p79.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRoleClaim item = enumerator.Current;
                result.Add(item == null ? null : new AppRoleClaimReadModel()
                {
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Id = item.Id,
                    RoleId = item.RoleId,
                    ClaimType = item.ClaimType,
                    ClaimValue = item.ClaimValue
                });
            }
            return result;
            
        }
        
        private static ICollection<AppFeatureFlagReadModel> funcMain81(ICollection<AppFeatureFlag> p92)
        {
            if (p92 == null)
            {
                return null;
            }
            ICollection<AppFeatureFlagReadModel> result = new List<AppFeatureFlagReadModel>(p92.Count);
            
            IEnumerator<AppFeatureFlag> enumerator = p92.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppFeatureFlag item = enumerator.Current;
                result.Add(item == null ? null : new AppFeatureFlagReadModel()
                {
                    FeatureId = item.FeatureId,
                    ScopeIdentifier = item.ScopeIdentifier,
                    IsEnabled = item.IsEnabled,
                    Feature = TypeAdapter<AppFeature, AppFeatureReadModel>.Map.Invoke(item.Feature),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static ICollection<AppFeatureFlagReadModel> funcMain102(ICollection<AppFeatureFlag> p113)
        {
            if (p113 == null)
            {
                return null;
            }
            ICollection<AppFeatureFlagReadModel> result = new List<AppFeatureFlagReadModel>(p113.Count);
            
            IEnumerator<AppFeatureFlag> enumerator = p113.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppFeatureFlag item = enumerator.Current;
                result.Add(item == null ? null : new AppFeatureFlagReadModel()
                {
                    FeatureId = item.FeatureId,
                    ScopeIdentifier = item.ScopeIdentifier,
                    IsEnabled = item.IsEnabled,
                    Feature = TypeAdapter<AppFeature, AppFeatureReadModel>.Map.Invoke(item.Feature),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static ICollection<AppUserTokenReadModel> funcMain124(ICollection<AppUserToken> p135)
        {
            if (p135 == null)
            {
                return null;
            }
            ICollection<AppUserTokenReadModel> result = new List<AppUserTokenReadModel>(p135.Count);
            
            IEnumerator<AppUserToken> enumerator = p135.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserToken item = enumerator.Current;
                result.Add(item == null ? null : new AppUserTokenReadModel()
                {
                    Token = item.Token,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    LoginProvider = item.LoginProvider,
                    Name = item.Name,
                    Value = item.Value
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRefreshTokenReadModel> funcMain125(ICollection<AppRefreshToken> p136)
        {
            if (p136 == null)
            {
                return null;
            }
            ICollection<AppRefreshTokenReadModel> result = new List<AppRefreshTokenReadModel>(p136.Count);
            
            IEnumerator<AppRefreshToken> enumerator = p136.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRefreshToken item = enumerator.Current;
                result.Add(item == null ? null : new AppRefreshTokenReadModel()
                {
                    UserId = item.UserId,
                    Token = item.Token,
                    JwtId = item.JwtId,
                    IsUsed = item.IsUsed,
                    IsRevoked = item.IsRevoked,
                    ExpiryDate = item.ExpiryDate,
                    Hash = item.Hash,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRoleClaimReadModel> funcMain132(ICollection<AppRoleClaim> p143)
        {
            if (p143 == null)
            {
                return null;
            }
            ICollection<AppRoleClaimReadModel> result = new List<AppRoleClaimReadModel>(p143.Count);
            
            IEnumerator<AppRoleClaim> enumerator = p143.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRoleClaim item = enumerator.Current;
                result.Add(item == null ? null : new AppRoleClaimReadModel()
                {
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Id = item.Id,
                    RoleId = item.RoleId,
                    ClaimType = item.ClaimType,
                    ClaimValue = item.ClaimValue
                });
            }
            return result;
            
        }
        
        private static ICollection<AppUserTokenReadModel> funcMain144(ICollection<AppUserToken> p160)
        {
            if (p160 == null)
            {
                return null;
            }
            ICollection<AppUserTokenReadModel> result = new List<AppUserTokenReadModel>(p160.Count);
            
            IEnumerator<AppUserToken> enumerator = p160.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserToken item = enumerator.Current;
                result.Add(item == null ? null : new AppUserTokenReadModel()
                {
                    Token = item.Token,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    LoginProvider = item.LoginProvider,
                    Name = item.Name,
                    Value = item.Value
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRefreshTokenReadModel> funcMain145(ICollection<AppRefreshToken> p161)
        {
            if (p161 == null)
            {
                return null;
            }
            ICollection<AppRefreshTokenReadModel> result = new List<AppRefreshTokenReadModel>(p161.Count);
            
            IEnumerator<AppRefreshToken> enumerator = p161.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRefreshToken item = enumerator.Current;
                result.Add(item == null ? null : new AppRefreshTokenReadModel()
                {
                    UserId = item.UserId,
                    Token = item.Token,
                    JwtId = item.JwtId,
                    IsUsed = item.IsUsed,
                    IsRevoked = item.IsRevoked,
                    ExpiryDate = item.ExpiryDate,
                    Hash = item.Hash,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRoleClaimReadModel> funcMain152(ICollection<AppRoleClaim> p168)
        {
            if (p168 == null)
            {
                return null;
            }
            ICollection<AppRoleClaimReadModel> result = new List<AppRoleClaimReadModel>(p168.Count);
            
            IEnumerator<AppRoleClaim> enumerator = p168.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRoleClaim item = enumerator.Current;
                result.Add(item == null ? null : new AppRoleClaimReadModel()
                {
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Id = item.Id,
                    RoleId = item.RoleId,
                    ClaimType = item.ClaimType,
                    ClaimValue = item.ClaimValue
                });
            }
            return result;
            
        }
        
        private static ICollection<AppFeatureFlagReadModel> funcMain165(ICollection<AppFeatureFlag> p182)
        {
            if (p182 == null)
            {
                return null;
            }
            ICollection<AppFeatureFlagReadModel> result = new List<AppFeatureFlagReadModel>(p182.Count);
            
            IEnumerator<AppFeatureFlag> enumerator = p182.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppFeatureFlag item = enumerator.Current;
                result.Add(item == null ? null : new AppFeatureFlagReadModel()
                {
                    FeatureId = item.FeatureId,
                    ScopeIdentifier = item.ScopeIdentifier,
                    IsEnabled = item.IsEnabled,
                    Feature = TypeAdapter<AppFeature, AppFeatureReadModel>.Map.Invoke(item.Feature),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static ICollection<AppFeatureFlagReadModel> funcMain186(ICollection<AppFeatureFlag> p204)
        {
            if (p204 == null)
            {
                return null;
            }
            ICollection<AppFeatureFlagReadModel> result = new List<AppFeatureFlagReadModel>(p204.Count);
            
            IEnumerator<AppFeatureFlag> enumerator = p204.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppFeatureFlag item = enumerator.Current;
                result.Add(item == null ? null : new AppFeatureFlagReadModel()
                {
                    FeatureId = item.FeatureId,
                    ScopeIdentifier = item.ScopeIdentifier,
                    IsEnabled = item.IsEnabled,
                    Feature = TypeAdapter<AppFeature, AppFeatureReadModel>.Map.Invoke(item.Feature),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static ICollection<AppUserTokenReadModel> funcMain208(ICollection<AppUserToken> p228)
        {
            if (p228 == null)
            {
                return null;
            }
            ICollection<AppUserTokenReadModel> result = new List<AppUserTokenReadModel>(p228.Count);
            
            IEnumerator<AppUserToken> enumerator = p228.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppUserToken item = enumerator.Current;
                result.Add(item == null ? null : new AppUserTokenReadModel()
                {
                    Token = item.Token,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    UserId = item.UserId,
                    LoginProvider = item.LoginProvider,
                    Name = item.Name,
                    Value = item.Value
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRefreshTokenReadModel> funcMain209(ICollection<AppRefreshToken> p229)
        {
            if (p229 == null)
            {
                return null;
            }
            ICollection<AppRefreshTokenReadModel> result = new List<AppRefreshTokenReadModel>(p229.Count);
            
            IEnumerator<AppRefreshToken> enumerator = p229.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRefreshToken item = enumerator.Current;
                result.Add(item == null ? null : new AppRefreshTokenReadModel()
                {
                    UserId = item.UserId,
                    Token = item.Token,
                    JwtId = item.JwtId,
                    IsUsed = item.IsUsed,
                    IsRevoked = item.IsRevoked,
                    ExpiryDate = item.ExpiryDate,
                    Hash = item.Hash,
                    AppUser = TypeAdapter<AppUser, AppUserReadModel>.Map.Invoke(item.AppUser),
                    Id = item.Id,
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate
                });
            }
            return result;
            
        }
        
        private static ICollection<AppRoleClaimReadModel> funcMain216(ICollection<AppRoleClaim> p236)
        {
            if (p236 == null)
            {
                return null;
            }
            ICollection<AppRoleClaimReadModel> result = new List<AppRoleClaimReadModel>(p236.Count);
            
            IEnumerator<AppRoleClaim> enumerator = p236.GetEnumerator();
            
            while (enumerator.MoveNext())
            {
                AppRoleClaim item = enumerator.Current;
                result.Add(item == null ? null : new AppRoleClaimReadModel()
                {
                    CreatedBy = item.CreatedBy,
                    CreatedDate = item.CreatedDate,
                    ModifiedBy = item.ModifiedBy,
                    ModifiedDate = item.ModifiedDate,
                    IsDeleted = item.IsDeleted,
                    DeletedBy = item.DeletedBy,
                    DeletedDate = item.DeletedDate,
                    AppRole = TypeAdapter<AppRole, AppRoleReadModel>.Map.Invoke(item.AppRole),
                    Id = item.Id,
                    RoleId = item.RoleId,
                    ClaimType = item.ClaimType,
                    ClaimValue = item.ClaimValue
                });
            }
            return result;
            
        }
    }
}