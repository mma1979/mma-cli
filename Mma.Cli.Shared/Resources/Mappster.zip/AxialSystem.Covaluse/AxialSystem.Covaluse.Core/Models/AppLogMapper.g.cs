using AxialSystem.Covaluse.Core.Database.LogTables;

namespace AxialSystem.Covaluse.Core.Database.LogTables
{
    public static partial class AppLogMapper
    {
        public static AppLogReadModel AdaptToReadModel(this AppLog p1)
        {
            return p1 == null ? null : new AppLogReadModel()
            {
                Id = p1.Id,
                Message = p1.Message,
                MessageTemplate = p1.MessageTemplate,
                Level = p1.Level,
                TimeStamp = p1.TimeStamp,
                Exception = p1.Exception,
                Properties = p1.Properties
            };
        }
        public static AppLogReadModel AdaptTo(this AppLog p2, AppLogReadModel p3)
        {
            if (p2 == null)
            {
                return null;
            }
            AppLogReadModel result = p3 ?? new AppLogReadModel();
            
            result.Id = p2.Id;
            result.Message = p2.Message;
            result.MessageTemplate = p2.MessageTemplate;
            result.Level = p2.Level;
            result.TimeStamp = p2.TimeStamp;
            result.Exception = p2.Exception;
            result.Properties = p2.Properties;
            return result;
            
        }
        public static AppLogModifyModel AdaptToModifyModel(this AppLog p4)
        {
            return p4 == null ? null : new AppLogModifyModel()
            {
                Id = p4.Id,
                Message = p4.Message,
                MessageTemplate = p4.MessageTemplate,
                Level = p4.Level,
                TimeStamp = p4.TimeStamp,
                Exception = p4.Exception,
                Properties = p4.Properties
            };
        }
        public static AppLogModifyModel AdaptTo(this AppLog p5, AppLogModifyModel p6)
        {
            if (p5 == null)
            {
                return null;
            }
            AppLogModifyModel result = p6 ?? new AppLogModifyModel();
            
            result.Id = p5.Id;
            result.Message = p5.Message;
            result.MessageTemplate = p5.MessageTemplate;
            result.Level = p5.Level;
            result.TimeStamp = p5.TimeStamp;
            result.Exception = p5.Exception;
            result.Properties = p5.Properties;
            return result;
            
        }
    }
}