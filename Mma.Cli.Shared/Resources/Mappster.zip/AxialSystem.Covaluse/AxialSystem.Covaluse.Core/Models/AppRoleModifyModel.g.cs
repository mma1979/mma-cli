using System;
using System.Collections.Generic;
using AxialSystem.Covaluse.Core.Database.Identity;

namespace AxialSystem.Covaluse.Core.Database.Identity
{
    public partial class AppRoleModifyModel
    {
        public Guid? CreatedBy { get; set; }
        public DateTime? CreatedDate { get; set; }
        public Guid? ModifiedBy { get; set; }
        public DateTime? ModifiedDate { get; set; }
        public bool? IsDeleted { get; set; }
        public Guid? DeletedBy { get; set; }
        public DateTime? DeletedDate { get; set; }
        public ICollection<AppUserRoleReadModel> AppUserRoles { get; set; }
        public ICollection<AppRoleClaimReadModel> AppRoleClaims { get; set; }
        public ICollection<AppAccessControlEntryReadModel> AccessControlEntries { get; set; }
        public int Hash { get; set; }
        public Guid Id { get; set; }
        public string Name { get; set; }
        public string NormalizedName { get; set; }
        public string ConcurrencyStamp { get; set; }
    }
}