using System;
using System.Collections.Generic;
using AxialSystem.Covaluse.Core.Database.Identity;
using AxialSystem.Covaluse.Core.Enums;

namespace AxialSystem.Covaluse.Core.Database.Identity
{
    public partial class AppResourceModifyModel
    {
        public string Url { get; set; }
        public string Description { get; set; }
        public ResourceTypes ResourceType { get; set; }
        public ICollection<AppAccessControlEntryReadModel> AccessControlEntries { get; set; }
        public Guid Id { get; set; }
        public Guid? CreatedBy { get; set; }
        public DateTime? CreatedDate { get; set; }
        public Guid? ModifiedBy { get; set; }
        public DateTime? ModifiedDate { get; set; }
        public bool? IsDeleted { get; set; }
        public Guid? DeletedBy { get; set; }
        public DateTime? DeletedDate { get; set; }
    }
}