using System.Collections.Generic;
using AxialSystem.Covaluse.Core.Database.Localization;

namespace AxialSystem.Covaluse.Core.Database.Localization
{
    public partial class LanguageModifyModel
    {
        public int Id { get; set; }
        public string LanguageCode { get; set; }
        public string LanguageName { get; set; }
        public ICollection<ResourceReadModel> Resources { get; set; }
    }
}