using AxialSystem.Covaluse.Core.Database.Identity;

namespace AxialSystem.Covaluse.Core.Database.Identity
{
    public static partial class AppUserLoginMapper
    {
        public static AppUserLoginReadModel AdaptToReadModel(this AppUserLogin p1)
        {
            return p1 == null ? null : new AppUserLoginReadModel()
            {
                CreatedBy = p1.CreatedBy,
                CreatedDate = p1.CreatedDate,
                ModifiedBy = p1.ModifiedBy,
                ModifiedDate = p1.ModifiedDate,
                IsDeleted = p1.IsDeleted,
                DeletedBy = p1.DeletedBy,
                DeletedDate = p1.DeletedDate,
                LoginProvider = p1.LoginProvider,
                ProviderKey = p1.ProviderKey,
                ProviderDisplayName = p1.ProviderDisplayName,
                UserId = p1.UserId
            };
        }
        public static AppUserLoginReadModel AdaptTo(this AppUserLogin p2, AppUserLoginReadModel p3)
        {
            if (p2 == null)
            {
                return null;
            }
            AppUserLoginReadModel result = p3 ?? new AppUserLoginReadModel();
            
            result.CreatedBy = p2.CreatedBy;
            result.CreatedDate = p2.CreatedDate;
            result.ModifiedBy = p2.ModifiedBy;
            result.ModifiedDate = p2.ModifiedDate;
            result.IsDeleted = p2.IsDeleted;
            result.DeletedBy = p2.DeletedBy;
            result.DeletedDate = p2.DeletedDate;
            result.LoginProvider = p2.LoginProvider;
            result.ProviderKey = p2.ProviderKey;
            result.ProviderDisplayName = p2.ProviderDisplayName;
            result.UserId = p2.UserId;
            return result;
            
        }
        public static AppUserLoginModifyModel AdaptToModifyModel(this AppUserLogin p4)
        {
            return p4 == null ? null : new AppUserLoginModifyModel()
            {
                CreatedBy = p4.CreatedBy,
                CreatedDate = p4.CreatedDate,
                ModifiedBy = p4.ModifiedBy,
                ModifiedDate = p4.ModifiedDate,
                IsDeleted = p4.IsDeleted,
                DeletedBy = p4.DeletedBy,
                DeletedDate = p4.DeletedDate,
                LoginProvider = p4.LoginProvider,
                ProviderKey = p4.ProviderKey,
                ProviderDisplayName = p4.ProviderDisplayName,
                UserId = p4.UserId
            };
        }
        public static AppUserLoginModifyModel AdaptTo(this AppUserLogin p5, AppUserLoginModifyModel p6)
        {
            if (p5 == null)
            {
                return null;
            }
            AppUserLoginModifyModel result = p6 ?? new AppUserLoginModifyModel();
            
            result.CreatedBy = p5.CreatedBy;
            result.CreatedDate = p5.CreatedDate;
            result.ModifiedBy = p5.ModifiedBy;
            result.ModifiedDate = p5.ModifiedDate;
            result.IsDeleted = p5.IsDeleted;
            result.DeletedBy = p5.DeletedBy;
            result.DeletedDate = p5.DeletedDate;
            result.LoginProvider = p5.LoginProvider;
            result.ProviderKey = p5.ProviderKey;
            result.ProviderDisplayName = p5.ProviderDisplayName;
            result.UserId = p5.UserId;
            return result;
            
        }
    }
}