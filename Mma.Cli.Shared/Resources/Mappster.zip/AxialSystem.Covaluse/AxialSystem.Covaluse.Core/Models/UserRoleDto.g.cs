using System;
using AxialSystem.Covaluse.Core.Database.Identity;

namespace AxialSystem.Covaluse.Core.Database.Identity
{
    public partial class UserRoleDto
    {
        public AppUserDto AppUser { get; set; }
        public RoleDto Role { get; set; }
        public long? CreatedBy { get; set; }
        public DateTime? CreatedDate { get; set; }
        public long? ModifiedBy { get; set; }
        public DateTime? ModifiedDate { get; set; }
        public bool? IsDeleted { get; set; }
        public long? DeletedBy { get; set; }
        public DateTime? DeletedDate { get; set; }
        public long UserId { get; set; }
        public long RoleId { get; set; }
    }
}