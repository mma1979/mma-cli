using AxialSystem.Covaluse.Core.Database.Notifications;

namespace AxialSystem.Covaluse.Core.Database.Notifications
{
    public static partial class NotificationTypeMapper
    {
        public static NotificationTypeReadModel AdaptToReadModel(this NotificationType p1)
        {
            return p1 == null ? null : new NotificationTypeReadModel()
            {
                Name = p1.Name,
                Description = p1.Description,
                Hash = p1.Hash,
                Id = p1.Id,
                CreatedBy = p1.CreatedBy,
                CreatedDate = p1.CreatedDate,
                ModifiedBy = p1.ModifiedBy,
                ModifiedDate = p1.ModifiedDate,
                IsDeleted = p1.IsDeleted,
                DeletedBy = p1.DeletedBy,
                DeletedDate = p1.DeletedDate
            };
        }
        public static NotificationTypeReadModel AdaptTo(this NotificationType p2, NotificationTypeReadModel p3)
        {
            if (p2 == null)
            {
                return null;
            }
            NotificationTypeReadModel result = p3 ?? new NotificationTypeReadModel();
            
            result.Name = p2.Name;
            result.Description = p2.Description;
            result.Hash = p2.Hash;
            result.Id = p2.Id;
            result.CreatedBy = p2.CreatedBy;
            result.CreatedDate = p2.CreatedDate;
            result.ModifiedBy = p2.ModifiedBy;
            result.ModifiedDate = p2.ModifiedDate;
            result.IsDeleted = p2.IsDeleted;
            result.DeletedBy = p2.DeletedBy;
            result.DeletedDate = p2.DeletedDate;
            return result;
            
        }
        public static NotificationTypeModifyModel AdaptToModifyModel(this NotificationType p4)
        {
            return p4 == null ? null : new NotificationTypeModifyModel()
            {
                Name = p4.Name,
                Description = p4.Description,
                Hash = p4.Hash,
                Id = p4.Id,
                CreatedBy = p4.CreatedBy,
                CreatedDate = p4.CreatedDate,
                ModifiedBy = p4.ModifiedBy,
                ModifiedDate = p4.ModifiedDate,
                IsDeleted = p4.IsDeleted,
                DeletedBy = p4.DeletedBy,
                DeletedDate = p4.DeletedDate
            };
        }
        public static NotificationTypeModifyModel AdaptTo(this NotificationType p5, NotificationTypeModifyModel p6)
        {
            if (p5 == null)
            {
                return null;
            }
            NotificationTypeModifyModel result = p6 ?? new NotificationTypeModifyModel();
            
            result.Name = p5.Name;
            result.Description = p5.Description;
            result.Hash = p5.Hash;
            result.Id = p5.Id;
            result.CreatedBy = p5.CreatedBy;
            result.CreatedDate = p5.CreatedDate;
            result.ModifiedBy = p5.ModifiedBy;
            result.ModifiedDate = p5.ModifiedDate;
            result.IsDeleted = p5.IsDeleted;
            result.DeletedBy = p5.DeletedBy;
            result.DeletedDate = p5.DeletedDate;
            return result;
            
        }
    }
}