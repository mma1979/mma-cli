using AxialSystem.Covaluse.Core.Database.Identity;

namespace AxialSystem.Covaluse.Core.Database.Identity
{
    public static partial class RoleClaimMapper
    {
        public static RoleClaimDto AdaptToDto(this RoleClaim p1)
        {
            return p1 == null ? null : new RoleClaimDto()
            {
                CreatedBy = p1.CreatedBy,
                CreatedDate = p1.CreatedDate,
                ModifiedBy = p1.ModifiedBy,
                ModifiedDate = p1.ModifiedDate,
                IsDeleted = p1.IsDeleted,
                DeletedBy = p1.DeletedBy,
                DeletedDate = p1.DeletedDate,
                Id = p1.Id,
                RoleId = p1.RoleId,
                ClaimType = p1.ClaimType,
                ClaimValue = p1.ClaimValue
            };
        }
        public static RoleClaimDto AdaptTo(this RoleClaim p2, RoleClaimDto p3)
        {
            if (p2 == null)
            {
                return null;
            }
            RoleClaimDto result = p3 ?? new RoleClaimDto();
            
            result.CreatedBy = p2.CreatedBy;
            result.CreatedDate = p2.CreatedDate;
            result.ModifiedBy = p2.ModifiedBy;
            result.ModifiedDate = p2.ModifiedDate;
            result.IsDeleted = p2.IsDeleted;
            result.DeletedBy = p2.DeletedBy;
            result.DeletedDate = p2.DeletedDate;
            result.Id = p2.Id;
            result.RoleId = p2.RoleId;
            result.ClaimType = p2.ClaimType;
            result.ClaimValue = p2.ClaimValue;
            return result;
            
        }
    }
}