
namespace AxialSystem.Covaluse.Core.Enums
{
    public enum TransactionStatuses:int
    {
        Pending = 0,
        Completed = 1,
        Cancelled = 2,
        Failed = 3
    }
}
