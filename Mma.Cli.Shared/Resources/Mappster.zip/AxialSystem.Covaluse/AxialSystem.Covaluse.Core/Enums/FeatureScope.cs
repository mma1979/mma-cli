
namespace AxialSystem.Covaluse.Core.Enums;

public enum FeatureScope:int
{
    Global,
    User,
    Role,
    Resource
}