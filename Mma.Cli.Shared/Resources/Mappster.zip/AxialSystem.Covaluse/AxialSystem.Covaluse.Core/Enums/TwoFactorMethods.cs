﻿namespace AxialSystem.Covaluse.Core.Enums
{
    public enum TwoFactorMethods : int
    {
        None = 0,
        Email = 1,
        Phone = 2,
        App = 3,
    }
}