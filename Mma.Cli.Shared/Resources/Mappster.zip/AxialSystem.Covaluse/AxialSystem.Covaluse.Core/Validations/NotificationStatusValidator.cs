using AxialSystem.Covaluse.Core.Database.Notifications;

using FluentValidation;



namespace AxialSystem.Covaluse.Core.Validations;

public class NotificationStatusValidator : AbstractValidator<NotificationStatusModifyModel>
{

    public NotificationStatusValidator()
    {

    }


}