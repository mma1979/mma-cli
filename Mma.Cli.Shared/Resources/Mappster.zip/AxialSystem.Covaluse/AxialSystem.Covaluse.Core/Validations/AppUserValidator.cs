﻿using FluentValidation;
using AxialSystem.Covaluse.Core.Database.Identity;

namespace AxialSystem.Covaluse.Core.Validations
{
    public class AppUserValidator : AbstractValidator<AppUserDto>
    {
        public AppUserValidator()
        {
            RuleFor(e => e.Email)
                .NotEmpty().WithMessage("Email_Required")
                .EmailAddress().WithMessage("Valid_Email_Required");
            //RuleFor(e => e.FirstName)
            //    .NotEmpty().WithMessage("FirstName_Required");
            //RuleFor(e => e.LastName)
            //    .NotEmpty().WithMessage("LastName_Required");
            //RuleFor(e => e.PhoneNumber)
            //    .NotEmpty().WithMessage("PhoneNumber_Required");
            //RuleFor(e => e.Password)
            //    .NotEmpty().WithMessage("Password_Required");

        }
    }
}
