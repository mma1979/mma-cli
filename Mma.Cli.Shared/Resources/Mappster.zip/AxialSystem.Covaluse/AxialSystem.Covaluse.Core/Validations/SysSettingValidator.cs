﻿using FluentValidation;
using AxialSystem.Covaluse.Core.Database.Tables;

namespace AxialSystem.Covaluse.Core.Validations
{
    public class SysSettingValidator : AbstractValidator<SysSettingDto>
    {
        public SysSettingValidator()
        {

            RuleFor(e => e.Enviroment).NotNull().WithMessage("Enviroment_Required");
            RuleFor(e => e.SysKey).NotNull().WithMessage("Key_Required");
            RuleFor(e => e.SysValue).NotNull().WithMessage("Value_Required");
        }
    }
}
