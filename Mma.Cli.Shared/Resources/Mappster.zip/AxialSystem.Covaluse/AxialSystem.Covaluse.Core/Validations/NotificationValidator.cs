using AxialSystem.Covaluse.Core.Database.Notifications;

using FluentValidation;



namespace AxialSystem.Covaluse.Core.Validations;

public class NotificationValidator : AbstractValidator<NotificationModifyModel>
{

    public NotificationValidator()
    {

    }


}