﻿using FluentValidation;
using AxialSystem.Covaluse.Core.Database.Identity;

namespace AxialSystem.Covaluse.Core.Validations
{
    public class RoleValidator : AbstractValidator<Role>
    {
        public RoleValidator()
        {
            RuleFor(e => e.Name).NotEmpty().WithMessage("Field_Required");
        }
    }
}
