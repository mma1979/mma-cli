using AxialSystem.Covaluse.Core.Database.Identity;

using FluentValidation;



namespace AxialSystem.Covaluse.Core.Validations;

public class RoleValidator : AbstractValidator<AppRoleModifyModel>
{
    public RoleValidator()
    {
        RuleFor(e => e.Name).NotEmpty().WithMessage("Field_Required");
    }
}
