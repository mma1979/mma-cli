﻿using Mapster;

using AxialSystem.Covaluse.Core.Enums;

namespace AxialSystem.Covaluse.Core.Database.Tables
{
    [AdaptTo("[name]Dto"), GenerateMapper]
    public class SysSetting : BaseEntity<int>
    {
        public string SysKey { get; private set; }
        public string SysValue { get; private set; }
        public SettingsTypeEnum Enviroment { get; private set; }
    }
}
