using Mapster;

namespace AxialSystem.Covaluse.Core.Database.Tables;

[AdaptTo("[name]ReadModel")]
[AdaptTo("[name]ModifyModel")]
[GenerateMapper]

public class SysSetting : BaseEntity<int>
{
    public string SysKey { get; private set; }
    public string SysValue { get; private set; }
}
