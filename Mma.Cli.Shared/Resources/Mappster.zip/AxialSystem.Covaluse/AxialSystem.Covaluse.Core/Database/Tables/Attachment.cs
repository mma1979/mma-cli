﻿using Mapster;

namespace AxialSystem.Covaluse.Core.Database.Tables
{
    [AdaptTo("[name]Dto"), GenerateMapper]
    public  class Attachment : BaseEntity<long>
    {
        public string AttachmentName { get; private set; }
        public string FilePath { get; private set; }
        public decimal? FileSize { get; private set; }
        public string ContentType { get; private set; }
        public long KeyId { get; private set; }
    }
}
