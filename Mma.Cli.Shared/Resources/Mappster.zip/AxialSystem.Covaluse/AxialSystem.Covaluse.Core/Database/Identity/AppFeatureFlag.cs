using Mapster;

using System;

namespace AxialSystem.Covaluse.Core.Database.Identity;

[AdaptTo("[name]ReadModel")]
[AdaptTo("[name]ModifyModel")]
[GenerateMapper]
public class AppFeatureFlag:BaseEntity<Guid>
{
    public Guid FeatureId { get; set; }
    public Guid? ScopeIdentifier { get; set; }
    public bool IsEnabled { get; set; }
    public virtual AppFeature Feature { get; set; } 
}
