using AxialSystem.Covaluse.Core.Enums;

using Mapster;

using System;
using System.Collections.Generic;

namespace AxialSystem.Covaluse.Core.Database.Identity;

[AdaptTo("[name]ReadModel")]
[AdaptTo("[name]ModifyModel")]
[GenerateMapper]
public class AppFeature: BaseEntity<Guid>
{
    public string Name { get; set; }
    public string Description { get; set; }
    public bool IsEnabled { get; set; }
    public FeatureScope Scope { get; set; }
    public virtual ICollection<AppFeatureFlag> FeatureFlags { get; set; }
    public virtual ICollection<AppAccessControlEntry> AccessControlEntries { get; set; }
}
