﻿using Mapster;
using Microsoft.AspNetCore.Identity;
using System;

namespace AxialSystem.Covaluse.Core.Database.Identity
{
    [AdaptTo("[name]Dto"), GenerateMapper]
    public class UserLogin : IdentityUserLogin<long>
    {
        public long? CreatedBy { get; set; }
        public DateTime? CreatedDate { get; set; }
        public long? ModifiedBy { get; set; }
        public DateTime? ModifiedDate { get; set; }
        public bool? IsDeleted { get; set; }
        public long? DeletedBy { get; set; }
        public DateTime? DeletedDate { get; set; }
    }
}
