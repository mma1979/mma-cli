﻿using Mapster;
using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;

namespace AxialSystem.Covaluse.Core.Database.Identity
{
    [AdaptTo("[name]Dto"), GenerateMapper]
    public class Role : IdentityRole<long>
    {
        public long? CreatedBy { get; set; }
        public DateTime? CreatedDate { get; set; }
        public long? ModifiedBy { get; set; }
        public DateTime? ModifiedDate { get; set; }
        public bool? IsDeleted { get; set; }
        public long? DeletedBy { get; set; }
        public DateTime? DeletedDate { get; set; }
        public virtual ICollection<UserRole> UserRoles { get; set; }

        private Role() {
            UserRoles = new HashSet<UserRole>();
        }

        public Role(string rolename)
        {
            Name = rolename;
        }
    }
}
