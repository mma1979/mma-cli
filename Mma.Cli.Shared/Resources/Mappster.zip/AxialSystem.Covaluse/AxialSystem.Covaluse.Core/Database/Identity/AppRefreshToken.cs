

using Mapster;

using System;

namespace AxialSystem.Covaluse.Core.Database.Identity;


[AdaptTo("[name]ReadModel")]
[AdaptTo("[name]ModifyModel")]
[GenerateMapper]
public partial class AppRefreshToken : BaseEntity<Guid>
{
    public Guid UserId { get; private set; } // Linked to the AspNet Identity User Id
    public string Token { get; private set; }
    public string JwtId { get; private set; } // Map the token with jwtId
    public bool IsUsed { get; private set; } // if its used we dont want generate a new Jwt token with the same refresh token
    public bool IsRevoked { get; private set; } // if it has been revoke for security reasons
    public DateTime ExpiryDate { get; private set; } // Refresh token is long lived it could last for months.
    public int Hash { get; private set; } // Refresh token is long lived it could last for months.

    public virtual AppUser AppUser { get; private set; }

    #region Actions
    private AppRefreshToken()
    {

    }

    public AppRefreshToken(AppRefreshTokenModifyModel model)
    {
        UserId = model.UserId;
        Token = model.Token;
        JwtId = model.JwtId;
        IsUsed = model.IsUsed;
        IsRevoked = model.IsRevoked;
        CreatedDate = model.CreatedDate;
        ExpiryDate = model.ExpiryDate;
        Hash = GetHashCode();
    }


    public AppRefreshToken Update(AppRefreshTokenModifyModel model)
    {
        UserId = model.UserId;
        Token = model.Token;
        JwtId = model.JwtId;
        IsUsed = model.IsUsed;
        IsRevoked = model.IsRevoked;
        ModifiedDate = model.CreatedDate;
        ExpiryDate = model.ExpiryDate;
        Hash = GetHashCode();
        return this;
    }

    public AppRefreshToken MarkAsUsed()
    {
        IsUsed = true;
        ModifiedDate = DateTime.UtcNow;
        Hash = GetHashCode();

        return this;

    }

    public override int GetHashCode()
    {
        return HashCode.Combine(UserId, Token, JwtId, IsUsed, IsRevoked, CreatedDate, ExpiryDate);
    }

    public override bool Equals(object obj)
    {
        return obj is AppRefreshToken other &&
            UserId == other.UserId &&
            Token == other.Token &&
            JwtId == other.JwtId &&
            IsUsed == other.IsUsed &&
            IsRevoked == other.IsRevoked &&
            CreatedDate == other.CreatedDate &&
            ExpiryDate == other.ExpiryDate;
    }
    #endregion

}
