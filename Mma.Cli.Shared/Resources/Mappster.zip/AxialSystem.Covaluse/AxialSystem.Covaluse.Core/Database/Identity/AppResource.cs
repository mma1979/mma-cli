using AxialSystem.Covaluse.Core.Enums;

using Mapster;

using System;
using System.Collections.Generic;

namespace AxialSystem.Covaluse.Core.Database.Identity;


[AdaptTo("[name]ReadModel")]
[AdaptTo("[name]ModifyModel")]
[GenerateMapper]
public class AppResource : BaseEntity<Guid>
{
    public string Url { get; set; }
    public string Description { get; set; }
    public ResourceTypes ResourceType { get; set; }
    public virtual ICollection<AppAccessControlEntry> AccessControlEntries { get; set; }
}
