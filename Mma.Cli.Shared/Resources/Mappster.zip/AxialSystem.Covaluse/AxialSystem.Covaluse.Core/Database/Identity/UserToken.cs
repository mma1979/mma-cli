﻿using Mapster;
using Microsoft.AspNetCore.Identity;
using System;

namespace AxialSystem.Covaluse.Core.Database.Identity
{
    [AdaptTo("[name]Dto"), GenerateMapper]
    public class UserToken : IdentityUserToken<long>
    {
        public string Token { get; private set; }
        public virtual AppUser AppUser { get; private set; }
        public long? CreatedBy { get; private set; }
        public DateTime? CreatedDate { get; private set; }
        public long? ModifiedBy { get; private set; }
        public DateTime? ModifiedDate { get; private set; }
        public bool? IsDeleted { get; private set; }
        public long? DeletedBy { get; private set; }
        public DateTime? DeletedDate { get; private set; }

        public UserToken()
        {

        }

        public UserToken(UserTokenDto tokenDto)
        {
            Name = tokenDto.Name;
            LoginProvider = tokenDto.LoginProvider;
            Value = tokenDto.Value;
            Token = tokenDto.Token;

            CreatedBy = tokenDto.CreatedBy;
            CreatedDate = DateTime.UtcNow;
        }

    }
}
