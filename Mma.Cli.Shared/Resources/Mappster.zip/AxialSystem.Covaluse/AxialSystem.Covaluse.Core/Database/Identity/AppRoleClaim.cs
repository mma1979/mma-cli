using Mapster;

using Microsoft.AspNetCore.Identity;

using System;

namespace AxialSystem.Covaluse.Core.Database.Identity;

[AdaptTo("[name]ReadModel")]
[AdaptTo("[name]ModifyModel")]
[GenerateMapper]
public class AppRoleClaim : IdentityRoleClaim<Guid>,IAuditEntity
{
    public Guid? CreatedBy { get; set; }
    public DateTime? CreatedDate { get; set; }
    public Guid? ModifiedBy { get; set; }
    public DateTime? ModifiedDate { get; set; }
    public bool? IsDeleted { get; set; }
    public Guid? DeletedBy { get; set; }
    public DateTime? DeletedDate { get; set; }
    public virtual AppRole AppRole { get; set; }
}
