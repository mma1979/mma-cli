﻿using AxialSystem.Covaluse.Core.Enums;

using Mapster;

using Microsoft.AspNetCore.Identity;

using System;
using System.Collections.Generic;


namespace AxialSystem.Covaluse.Core.Database.Identity
{
    [AdaptTo("[name]Dto"), GenerateMapper]
    public partial class AppUser : IdentityUser<long>
    {

        public int Hash { get; private set; }
        public string FirstName { get; private set; }
        public string LastName { get; private set; }
        public string Mobile { get; private set; }
        public string CountryCode { get; private set; }

        public TwoFactorMethods TwoFactorMethod { get; private set; }

        public long? CreatedBy { get; private set; }
        public DateTime? CreatedDate { get; private set; }
        public long? ModifiedBy { get; private set; }
        public DateTime? ModifiedDate { get; private set; }
        public bool? IsDeleted { get; private set; }
        public long? DeletedBy { get; private set; }
        public DateTime? DeletedDate { get; private set; }
        public MembershipTypes MembershipType { get; private set; }

        public virtual ICollection<UserRole> UserRoles { get; private set; }
        public virtual ICollection<UserToken> UserTokens { get; private set; }
        public virtual ICollection<RefreshToken> RefreshTokens { get; private set; }


        #region Actions
        private AppUser()
        {
            UserRoles = new HashSet<UserRole>();
            UserTokens = new HashSet<UserToken>();
            RefreshTokens = new HashSet<RefreshToken>();
            MembershipType = Enums.MembershipTypes.Free;
        }

        public AppUser(AppUserDto dto)
        {
            Email = dto.Email;
            NormalizedEmail = dto.Email.ToUpper();
            UserName = dto.UserName;
            NormalizedUserName = dto.UserName.ToUpper();
            FirstName = dto.FirstName;
            LastName = dto.LastName;
            CountryCode = dto.CountryCode;
            PhoneNumber = dto.PhoneNumber;
            SecurityStamp = Guid.NewGuid().ToString();
            TwoFactorEnabled = true;
            TwoFactorMethod = Enums.TwoFactorMethods.Email;
            MembershipType = dto.MembershipType;

            CreatedDate = DateTime.UtcNow;
            CreatedBy = 1;

            Hash = GetHashCode();
        }

        public AppUser Update(AppUserDto dto)
        {
            Email = dto.Email;
            NormalizedEmail = dto.Email.ToUpper();
            UserName = dto.UserName;
            NormalizedUserName = dto.UserName.ToUpper();
            FirstName = dto.FirstName;
            LastName = dto.LastName;
            CountryCode = dto.CountryCode;
            PhoneNumber = dto.PhoneNumber;
            SecurityStamp = Guid.NewGuid().ToString();
            MembershipType = dto.MembershipType;

            CreatedDate = DateTime.UtcNow;
            CreatedBy = 1;

            Hash = GetHashCode();

            return this;
        }

        public AppUser SetRole(RoleDto role)
        {
            UserRoles = new HashSet<UserRole>
            {
                new UserRole{RoleId=role.Id}
            };
            CreatedDate = DateTime.UtcNow;
            CreatedBy = 1;

            Hash = GetHashCode();

            return this;
        }


        public AppUser AddUserToken(UserTokenDto tokenDto)
        {
            UserTokens ??= new HashSet<UserToken>();
            UserTokens.Add(new UserToken(tokenDto));
            return this;
        }

        public AppUser SetMembership(MembershipTypes memberShip)
        {
            MembershipType = memberShip;

            ModifiedDate = DateTime.UtcNow;
            return this;
        }
        #endregion

        public override int GetHashCode()
        {
            return HashCode.Combine(Id, UserName, Email, PhoneNumber, FirstName, LastName, Mobile, CountryCode);
        }
        public override bool Equals(object obj)
        {
            return obj is AppUser other &&
                Id == other.Id &&
                UserName == other.UserName &&
                Email == other.Email &&
                PhoneNumber == other.PhoneNumber &&
                FirstName == other.FirstName &&
                LastName == other.LastName &&
                Mobile == other.Mobile &&
                CountryCode == other.CountryCode;
        }
    }
}
