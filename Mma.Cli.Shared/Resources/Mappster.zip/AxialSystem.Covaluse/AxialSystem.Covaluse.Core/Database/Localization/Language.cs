using Mapster;

using System.Collections.Generic;

namespace AxialSystem.Covaluse.Core.Database.Localization;

[AdaptTo("[name]ReadModel")]
[AdaptTo("[name]ModifyModel")]
[GenerateMapper]
public class Language
{
    public Language()
    {
        Resources = new HashSet<Resource>();
    }
    public int Id { get; set; }
    public string LanguageCode { get; set; }
    public string LanguageName { get; set; }

    public virtual ICollection<Resource> Resources { get; set; }
}
