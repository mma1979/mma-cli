using Mapster;

using System;

namespace AxialSystem.Covaluse.Core.Database.LogTables;

[AdaptTo("[name]ReadModel")]
[AdaptTo("[name]ModifyModel")]
[GenerateMapper]

public class AppLog
{

    public Guid Id { get; set; }
    public string Message { get; set; }
    public string MessageTemplate { get; set; }
    public string Level { get; set; }
    public DateTime TimeStamp { get; set; }
    public string Exception { get; set; }
    public string Properties { get; set; }
}
