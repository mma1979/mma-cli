﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AxialSystem.Covaluse.Core.Consts
{
    public class TokenTypes
    {
        public const string EMAIL_CONFIRMATION = "Email Confirmation";
        public const string PHONE_NUMBER_CONFIRMATION = "Phone Number Confirmation";
    }
}
