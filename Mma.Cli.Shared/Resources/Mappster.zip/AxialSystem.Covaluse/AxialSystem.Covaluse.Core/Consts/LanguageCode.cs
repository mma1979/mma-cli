namespace AxialSystem.Covaluse.Core.Consts
{
    public static class LanguageCode
    {
        public const string Arabic = "ar";
        public const string English = "en";
    }
}
