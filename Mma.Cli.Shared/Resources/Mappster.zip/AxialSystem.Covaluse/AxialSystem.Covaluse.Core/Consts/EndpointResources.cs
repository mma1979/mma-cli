﻿namespace AxialSystem.Covaluse.Core.Consts
{
    public static class EndpointResources
    {
        public const string LOGIN_RESOURCE = "api/account/login";
    }
}
