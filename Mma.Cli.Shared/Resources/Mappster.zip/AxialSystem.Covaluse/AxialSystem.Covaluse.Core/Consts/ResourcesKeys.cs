﻿namespace AxialSystem.Covaluse.Core.Consts
{
    public static class ResourcesKeys
    {
        public const string RequiredField = "RequiredField";
    }
}
