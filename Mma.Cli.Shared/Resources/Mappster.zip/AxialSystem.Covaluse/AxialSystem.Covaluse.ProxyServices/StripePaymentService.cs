﻿using AxialSystem.Covaluse.Core.Models;

using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;

using Stripe;

using System;

namespace AxialSystem.Covaluse.ProxyServices
{
    public class StripePaymentService
    {
        public string BaseUrl { get; set; }
        public string SecretKey { get; set; }
        public string PublishableKey { get; set; }

        public StripePaymentService()
        {
            var stripeConfiguration = GetConfiguration();
            BaseUrl ??= stripeConfiguration.GetValue<string>("BaseUrl");
            SecretKey ??= stripeConfiguration.GetValue<string>("SecretKey");
            PublishableKey ??= stripeConfiguration.GetValue<string>("PublishableKey");
        }

        public StripePaymentService(IConfigurationSection stripeConfiguration)
        {
            BaseUrl ??= stripeConfiguration.GetValue<string>("BaseUrl");
            SecretKey ??= stripeConfiguration.GetValue<string>("SecretKey");
            PublishableKey ??= stripeConfiguration.GetValue<string>("PublishableKey");
        }
        private static IConfigurationSection GetConfiguration()
        {
            var env = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT") ?? "Development";
            var builder = new ConfigurationBuilder()
                .AddJsonFile("appsettings.json", optional: true, reloadOnChange: true)
                   .AddJsonFile($"appsettings.{env}.json", optional: true, reloadOnChange: true);

            var Configuration = builder.Build();

            var config = Configuration.GetSection("Stripe");

            return config;
        }




        public PaymentIntent Payment(PaymentIntentCreateRequest request)
        {
            var paymentIntentService = new PaymentIntentService();

            var paymentIntent = paymentIntentService.Create(new PaymentIntentCreateOptions
            {
                Amount = request.Amount,
                Currency = request.Currency,
                AutomaticPaymentMethods = new PaymentIntentAutomaticPaymentMethodsOptions
                {
                    Enabled = true,
                },
            });

            return paymentIntent;

        }

        public bool Refound()
        {
            return true;
        }
    }

    public static class StripePaymentExtensions
    {
        public static IServiceCollection AddStripeService(this IServiceCollection serviceCollection, Action<StripePaymentService> optionsAction = null, ServiceLifetime contextLifetime = ServiceLifetime.Scoped, ServiceLifetime optionsLifetime = ServiceLifetime.Scoped)
        {
            var stripe = new StripePaymentService();
            if (optionsAction != null)
                optionsAction(stripe);
            serviceCollection.TryAdd(
                new ServiceDescriptor(typeof(StripePaymentService),
                provider => new StripePaymentService(),
                optionsLifetime));

            StripeConfiguration.ApiKey = stripe.SecretKey;

            return serviceCollection;
        }
    }
}
