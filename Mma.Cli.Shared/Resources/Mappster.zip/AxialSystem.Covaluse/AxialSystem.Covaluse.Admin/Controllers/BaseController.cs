﻿using AxialSystem.Covaluse.Admin.Filters;
using AxialSystem.Covaluse.Common.Extensions;

using Microsoft.AspNetCore.Mvc;

using System.Linq;

namespace AxialSystem.Covaluse.Admin.Controllers
{
    [JWTAuthorize]
    public class BaseController : Controller
    {
        protected long? UserId
        {
            get
            {
                return User.Claims.FirstOrDefault(e => e.Type == "Id")?.Value.ToNullableLong();
            }
        }

        protected string Language
        {
            get
            {
                var lang = string.IsNullOrWhiteSpace(HttpContext.Request.Cookies["Language"]) ?
                    "en" : HttpContext.Request.Cookies["Language"];
                return lang;

            }
        }
    }
}
