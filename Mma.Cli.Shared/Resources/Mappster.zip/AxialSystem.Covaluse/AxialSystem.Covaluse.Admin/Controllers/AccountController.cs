﻿using AxialSystem.Covaluse.Common.Helpers;
using AxialSystem.Covaluse.Core.Consts;
using AxialSystem.Covaluse.Core.Models;

using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

using System.Threading.Tasks;

namespace AxialSystem.Covaluse.Admin.Controllers
{
    public class AccountController : BaseController
    {
        private readonly ILogger<AccountController> _logger;
        private readonly RestHelper _restHelper;

        public AccountController(ILogger<AccountController> logger, RestHelper restHelper)
        {
            _logger = logger;
            _restHelper = restHelper;
        }
        [AllowAnonymous]
        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

        [AllowAnonymous]
        [HttpPost]
        public async Task<IActionResult> Login(AccountModels.LoginDto dto)
        {
            var result = await _restHelper.Post<ResultViewModel<AccountModels.TokenDto>>(EndpointResources.LOGIN_RESOURCE, dto);
            if (result.IsSuccess)
            {
                return RedirectToAction("Index", "Home");
            }

            ViewBag.Messages = result.Messages;
            return View(dto);
        }

    }
}
