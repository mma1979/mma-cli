
using AxialSystem.Covaluse.Common.Models;
using AxialSystem.Covaluse.EntityFramework;
using AxialSystem.Covaluse.HangfireApp.Filters;

using Hangfire;
using Hangfire.SqlServer;

using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Microsoft.Extensions.Hosting;
using Microsoft.OpenApi.Models;

using System;

var builder = WebApplication.CreateBuilder(args);
builder.Configuration.AddJsonFile("appsettings.json", optional: true, reloadOnChange: true);
builder.Configuration.AddJsonFile($"appsettings.{builder.Environment.EnvironmentName}.json", optional: true, reloadOnChange: true);
builder.Configuration.AddEnvironmentVariables();

// configure strongly typed settings objects
IConfigurationSection appSettingsSection = builder.Configuration.GetSection("AppSettings");
builder.Services.Configure<AppSettings>(appSettingsSection);

builder.Services.AddControllers();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new OpenApiInfo { Title = "AxialSystem.Covaluse.HangfireApp", Version = "v1" });
});

// For Entity Framework
builder.Services.AddDbContext<ApplicationDbContext>(options => options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

builder.Services.AddDbContext<LocalizationDbContext>(options => options.UseSqlite(builder.Configuration.GetConnectionString("LocalizationConnection")));





builder.Services.AddHangfireServer();
builder.Services.AddHangfire(configuration => configuration
.SetDataCompatibilityLevel(CompatibilityLevel.Version_170)
.UseSimpleAssemblyNameTypeSerializer()
.UseRecommendedSerializerSettings()
.UseSqlServerStorage(builder.Configuration.GetConnectionString("HangfireConnection"), new SqlServerStorageOptions
{
    CommandBatchMaxTimeout = TimeSpan.FromMinutes(5),
    SlidingInvisibilityTimeout = TimeSpan.FromMinutes(5),
    QueuePollInterval = TimeSpan.Zero,
    UseRecommendedIsolationLevel = true,
    DisableGlobalLocks = true
}));
builder.Services.TryAddTransient<IHttpContextAccessor, HttpContextAccessor>();



var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseDeveloperExceptionPage();
    app.UseSwagger();
    app.UseSwaggerUI(c => c.SwaggerEndpoint("/swagger/v1/swagger.json", "AxialSystem.Covaluse.HangfireApp v1"));
}

app.UseHttpsRedirection();

app.UseStaticFiles();
app.UseHangfireDashboard("/manager", new DashboardOptions
{
    Authorization = new[] { new HangfireAuthorizationFilter() }
});



app.UseRouting();

app.UseAuthorization();

app.MapControllers();
app.MapHangfireDashboard();

app.UseHangfireDashboard();

static void CreateJobs(IServiceProvider services)
{

}

CreateJobs(app.Services);


app.Run();